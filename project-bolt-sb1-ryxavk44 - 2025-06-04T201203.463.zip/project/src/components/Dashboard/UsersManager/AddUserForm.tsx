import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Eye, EyeOff, UserIcon, Mail, Phone, Shield, Key } from 'lucide-react';
import type { User } from '../../../types';
import { generateId } from '../../../utils';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';

type UserFormData = Omit<User, 'id' | 'dateCreated'>;

const initialFormData: UserFormData = {
  firstName: '',
  lastName: '',
  email: '',
  phone: '',
  password: '',
  role: 'Seller',
};

export function AddUserForm() {
  const [users, setUsers] = useLocalStorage<User[]>('users', []);
  const [formData, setFormData] = useState<UserFormData>(initialFormData);
  const [showPassword, setShowPassword] = useState(false);
  const [focusedField, setFocusedField] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newUser: User = {
      ...formData,
      id: generateId(),
      dateCreated: new Date().toISOString(),
    };
    setUsers([...users, newUser]);
    setFormData(initialFormData);

    // Create seller panel automatically if role is Seller
    if (newUser.role === 'Seller') {
      // Initialize seller-specific data structures if needed
      // For now, the shared leads will be handled through the lead's assignedTo field
      toast.success('Utilisateur créé avec succès. Panel vendeur initialisé.');
    } else {
      toast.success('Utilisateur créé avec succès');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative max-w-4xl mx-auto"
    >
      {/* Background effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl" />
      <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl" />
      
      {/* Content */}
      <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-8">
          Créer un nouvel utilisateur
        </h2>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* First Name */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                <UserIcon className="w-4 h-4 mr-2 text-blue-400" />
                Prénom
              </label>
              <input
                type="text"
                value={formData.firstName}
                onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                onFocus={() => setFocusedField('firstName')}
                onBlur={() => setFocusedField(null)}
                className={cn(
                  "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                  "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                  "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                  focusedField === 'firstName' && "shadow-[0_0_15px_rgba(59,130,246,0.5)]"
                )}
                required
              />
            </div>

            {/* Last Name */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                <UserIcon className="w-4 h-4 mr-2 text-purple-400" />
                Nom
              </label>
              <input
                type="text"
                value={formData.lastName}
                onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                onFocus={() => setFocusedField('lastName')}
                onBlur={() => setFocusedField(null)}
                className={cn(
                  "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                  "focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50",
                  "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                  focusedField === 'lastName' && "shadow-[0_0_15px_rgba(147,51,234,0.5)]"
                )}
                required
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                <Mail className="w-4 h-4 mr-2 text-cyan-400" />
                Email
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                onFocus={() => setFocusedField('email')}
                onBlur={() => setFocusedField(null)}
                className={cn(
                  "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                  "focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/50",
                  "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                  focusedField === 'email' && "shadow-[0_0_15px_rgba(34,211,238,0.5)]"
                )}
                required
              />
            </div>

            {/* Phone */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                <Phone className="w-4 h-4 mr-2 text-emerald-400" />
                Téléphone
              </label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                onFocus={() => setFocusedField('phone')}
                onBlur={() => setFocusedField(null)}
                className={cn(
                  "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                  "focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/50",
                  "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                  focusedField === 'phone' && "shadow-[0_0_15px_rgba(16,185,129,0.5)]"
                )}
                required
              />
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                <Key className="w-4 h-4 mr-2 text-pink-400" />
                Mot de passe
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  onFocus={() => setFocusedField('password')}
                  onBlur={() => setFocusedField(null)}
                  className={cn(
                    "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3 pr-10",
                    "focus:outline-none focus:ring-2 focus:ring-pink-500/50 focus:border-pink-500/50",
                    "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                    focusedField === 'password' && "shadow-[0_0_15px_rgba(236,72,153,0.5)]"
                  )}
                  required
                  minLength={6}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-300 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              <p className="mt-1 text-xs text-gray-500">Minimum 6 caractères</p>
            </div>

            {/* Role */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                <Shield className="w-4 h-4 mr-2 text-amber-400" />
                Rôle
              </label>
              <select
                value={formData.role}
                onChange={(e) => setFormData({ ...formData, role: e.target.value as 'Admin' | 'Seller' })}
                onFocus={() => setFocusedField('role')}
                onBlur={() => setFocusedField(null)}
                className={cn(
                  "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                  "focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500/50",
                  "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                  focusedField === 'role' && "shadow-[0_0_15px_rgba(245,158,11,0.5)]"
                )}
              >
                <option value="Seller">Seller</option>
                <option value="Admin">Admin</option>
              </select>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex justify-end">
            <motion.button
              type="submit"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="relative group px-8 py-3 rounded-lg overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
              <span className="relative text-white font-medium">
                Créer l'utilisateur
              </span>
            </motion.button>
          </div>
        </form>
      </div>
    </motion.div>
  );
}