import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertCircle, Zap, DollarSign, Clock, Shield, ChevronRight, Info, Hash } from 'lucide-react';
import type { EnergyOffer, Lead, EnergyHolding } from '../../../../types';
import { useLocalStorage } from '../../../../hooks/useLocalStorage';
import { FuturisticTimer } from '../../../common/FuturisticTimer';
import { toast } from 'react-hot-toast';
import { cn } from '../../../../utils/cn';

interface InvestModalProps {
  offer: EnergyOffer;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (amount: number, cardHolder: string, cardNumber: string, expiryDate: string, cvv: string) => void;
  currentBalance: number;
}

function InvestModal({ offer, isOpen, onClose, onConfirm, currentBalance = 0 }: InvestModalProps) {
  const [isSignatureConfirmed, setIsSignatureConfirmed] = useState(false);

  if (!isOpen) return null;

  const balanceAfterInvestment = currentBalance - (offer?.totalPrice || 0);

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative w-full max-w-lg mx-4"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8 energy-offer-text">
          <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-6">
            Confirmation d'investissement
          </h2>

          <div className="space-y-6">
            {/* Investment Details */}
            <div className="bg-gray-800/50 border border-white/5 rounded-xl p-6 space-y-4">
              {offer.reference && (
                <div className="flex items-center justify-center mb-4">
                  <div className="reference-tag py-2 px-4 rounded-lg flex items-center">
                    <Hash className="h-5 w-5 text-blue-400 mr-2" />
                    <span className="text-lg font-mono font-bold text-blue-300 tracking-wider">
                      RÉF: {offer.reference}
                    </span>
                  </div>
                </div>
              )}
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-gray-400 text-sm">Entreprise</p>
                  <p className="text-white font-medium">{offer.companyName}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Quantité</p>
                  <p className="text-white font-medium">{offer.megawatts} MW</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Prix par MW</p>
                  <p className="text-white font-medium">{offer.pricePerMegawatt}€</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Prix total</p>
                  <p className="text-white font-medium">{offer.totalPrice}€</p>
                </div>
              </div>
            </div>

            {/* Balance Info */}
            <div className="bg-gray-800/50 border border-white/5 rounded-xl p-6 space-y-4">
              <div>
                <p className="text-gray-400 text-sm">Solde actuel</p>
                <p className="text-white font-medium">{currentBalance.toLocaleString()}€</p>
              </div>
              <div>
                <p className="text-gray-400 text-sm">Solde après investissement</p>
                <p className="text-white font-medium">{balanceAfterInvestment.toLocaleString()}€</p>
              </div>
            </div>

            {/* Signature Confirmation */}
            <label className="flex items-center space-x-3 cursor-pointer">
              <input
                type="checkbox"
                checked={isSignatureConfirmed}
                onChange={(e) => setIsSignatureConfirmed(e.target.checked)}
                className="w-5 h-5 rounded border-gray-600 text-blue-600 focus:ring-blue-500 bg-gray-800"
              />
              <span className="text-gray-300">Je confirme ma signature électronique</span>
            </label>

            {/* Action Buttons */}
            <div className="flex space-x-4">
              <button
                onClick={onClose}
                className="flex-1 px-6 py-3 text-sm font-medium text-gray-300 bg-gray-800/50 hover:bg-gray-700/50 rounded-lg backdrop-blur-sm transition-colors"
              >
                Annuler
              </button>
              <motion.button
                onClick={onConfirm}
                disabled={!isSignatureConfirmed}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex-1 relative group overflow-hidden px-6 py-3 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity"></div>
                <span className="relative text-white font-medium">
                  Valider l'investissement
                </span>
              </motion.button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export function Market() {
  const [energyOffers, setEnergyOffers] = useLocalStorage<EnergyOffer[]>('energyOffers', []);
  const [stocks, setStocks] = useLocalStorage<EnergyHolding[]>('stocks', []);
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [selectedOffer, setSelectedOffer] = useState<EnergyOffer | null>(null);
  const [currentLead, setCurrentLead] = useState<Lead | null>(null);
  const [availableOffers, setAvailableOffers] = useState<EnergyOffer[]>([]);

  // Initialize current lead
  useEffect(() => {
    const currentLeadStr = localStorage.getItem('currentLead');
    if (currentLeadStr) {
      setCurrentLead(JSON.parse(currentLeadStr));
    }
  }, []);

  // Check for expired offers and update available offers
  useEffect(() => {
    const checkExpiry = () => {
      const now = new Date().getTime();
      
      // Update assigned offers in current lead
      if (currentLead) {
        const updatedAssignedOffers = currentLead.assignedOffers?.map(offer => ({
          ...offer,
          status: new Date(offer.expiryDate).getTime() <= now ? 'Expired' as const : offer.status
        })) || [];

        if (JSON.stringify(updatedAssignedOffers) !== JSON.stringify(currentLead.assignedOffers)) {
          const updatedLead = {
            ...currentLead,
            assignedOffers: updatedAssignedOffers
          };
          localStorage.setItem('currentLead', JSON.stringify(updatedLead));
          setCurrentLead(updatedLead);
          
          setLeads(leads.map(lead => 
            lead.id === currentLead.id ? updatedLead : lead
          ));
        }
      }

      // Update energy offers
      const updatedOffers = energyOffers.map(offer => ({
        ...offer,
        status: new Date(offer.expiryDate).getTime() <= now ? 'Expired' as const : offer.status
      }));

      if (JSON.stringify(updatedOffers) !== JSON.stringify(energyOffers)) {
        setEnergyOffers(updatedOffers);
      }

      // Update stocks
      const updatedStocks = stocks.map(stock => ({
        ...stock,
        status: new Date(stock.expiryDate).getTime() <= now ? 'Expired' as const : stock.status
      }));

      if (JSON.stringify(updatedStocks) !== JSON.stringify(stocks)) {
        setStocks(updatedStocks);
      }

      // Update available offers
      updateAvailableOffers(updatedOffers, updatedStocks, currentLead);
    };

    const interval = setInterval(checkExpiry, 1000);
    return () => clearInterval(interval);
  }, [energyOffers, setEnergyOffers, currentLead, leads, setLeads, stocks, setStocks]);

  // Update available offers when dependencies change
  useEffect(() => {
    updateAvailableOffers(energyOffers, stocks, currentLead);
  }, [energyOffers, stocks, currentLead]);

  // Function to update available offers
  const updateAvailableOffers = (
    offers: EnergyOffer[],
    stocksData: EnergyHolding[],
    lead: Lead | null
  ) => {
    if (!lead) return;

    const stockOffers: EnergyOffer[] = stocksData
      .filter(stock => stock.status === 'Available')
      .map(stock => ({
        id: stock.id,
        companyName: stock.companyName,
        megawatts: stock.megawatts,
        saleDate: new Date().toISOString(),
        pricePerMegawatt: stock.pricePerMegawatt,
        totalPrice: stock.totalPrice,
        validityDays: 0,
        validityHours: 0,
        validityMinutes: 0,
        expiryDate: stock.expiryDate,
        status: 'Active' as const,
        dateCreated: stock.purchaseDate,
        priceVariation: stock.priceVariation,
        reference: stock.reference || 'N/A'
      }));

    // Include all active offers (both regular and scheduled)
    const allOffers = [
      ...offers.filter(offer => offer.status === 'Active'),
      ...stockOffers,
      ...(lead.assignedOffers?.filter(offer => offer.status === 'Active') || [])
    ];

    setAvailableOffers(allOffers);
  };

  const handleInvestment = () => {
    if (!selectedOffer || !currentLead) return;

    if (currentLead.balance < selectedOffer.totalPrice) {
      toast.error('Solde insuffisant pour cet investissement');
      setSelectedOffer(null);
      return;
    }

    const holding: EnergyHolding = {
      id: Math.random().toString(36).substr(2, 9),
      companyName: selectedOffer.companyName,
      megawatts: selectedOffer.megawatts,
      pricePerMegawatt: selectedOffer.pricePerMegawatt,
      totalPrice: selectedOffer.totalPrice,
      purchaseDate: new Date().toISOString(),
      expiryDate: selectedOffer.expiryDate,
      status: 'InProgress',
      priceVariation: selectedOffer.priceVariation || 0,
      reference: selectedOffer.reference || 'N/A'
    };

    const transaction = {
      id: Math.random().toString(36).substr(2, 9),
      amount: -selectedOffer.totalPrice,
      type: 'investment' as const,
      description: `Achat de ${selectedOffer.megawatts} MW d'énergie de ${selectedOffer.companyName} (Réf: ${selectedOffer.reference || 'N/A'})`,
      dateCreated: new Date().toISOString()
    };

    // Update current lead in state with new balance, holdings, and transaction
    const updatedLead = {
      ...currentLead,
      balance: currentLead.balance - selectedOffer.totalPrice,
      energyHoldings: [...(currentLead.energyHoldings || []), holding],
      transactions: [...(currentLead.transactions || []), transaction]
    };
    setCurrentLead(updatedLead);

    // Update localStorage
    localStorage.setItem('currentLead', JSON.stringify(updatedLead));

    // Update leads array
    const updatedLeads = leads.map(lead => 
      lead.id === currentLead.id ? updatedLead : lead
    );
    setLeads(updatedLeads);

    // Update energy offers
    const updatedOffers = energyOffers.map(offer =>
      offer.id === selectedOffer.id ? { ...offer, status: 'Expired' as const } : offer
    );
    setEnergyOffers(updatedOffers);

    // Update available offers
    const updatedAvailableOffers = availableOffers.filter(offer => offer.id !== selectedOffer.id);
    setAvailableOffers(updatedAvailableOffers);

    // Close modal and show success message
    setSelectedOffer(null);
    toast.success('Investissement effectué avec succès');
  };

  if (availableOffers.length === 0) {
    return (
      <div className="min-h-[400px] flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-800/50 backdrop-blur-xl mb-4">
            <AlertCircle className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-xl font-medium text-gray-300 energy-offer-text">
            Aucune offre disponible
          </h3>
          <p className="text-gray-500 max-w-sm energy-offer-text">
            Il n'y a actuellement aucune offre disponible sur le marché. Revenez plus tard.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {availableOffers.map((offer, index) => (
        <motion.div
          key={offer.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className="relative group energy-offer-text"
        >
          {/* Animated background glow */}
          <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-500/30 via-blue-500/30 to-purple-500/30 rounded-xl opacity-0 group-hover:opacity-100 blur-xl transition duration-1000 animate-pulse"></div>
          
          {/* Neon border */}
          <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500 rounded-xl opacity-75 group-hover:opacity-100 blur transition duration-1000"></div>
          
          {/* Glass card */}
          <div className="relative bg-black/40 backdrop-blur-xl border border-white/10 rounded-xl p-6">
            {/* Company name with glowing effect */}
            <div className="relative mb-6">
              <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500 rounded-lg opacity-75 blur"></div>
              <div className="relative bg-black/60 backdrop-blur-xl border border-white/10 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
                      {offer.companyName}
                    </h3>
                    <p className="text-sm text-gray-400">{new Date(offer.dateCreated).toLocaleDateString()}</p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Reference display with futuristic styling */}
            {offer.reference && (
              <div className="mb-6 flex justify-center">
                <div className="reference-tag py-3 px-5 rounded-lg">
                  <div className="flex items-center justify-center">
                    <Hash className="h-6 w-6 text-blue-400 mr-2" />
                    <span className="text-xl font-mono font-bold text-blue-300 tracking-widest">
                      RÉF: {offer.reference}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Main info sections */}
            <div className="space-y-4">
              {/* Energy info with glowing icon */}
              <div className="bg-gradient-to-r from-blue-500/5 to-purple-500/5 rounded-xl p-4 border border-white/5">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <div className="absolute -inset-1 bg-blue-500/30 rounded-lg blur"></div>
                    <div className="relative w-12 h-12 flex items-center justify-center bg-blue-500/10 rounded-lg border border-blue-500/20">
                      <Zap className="w-6 h-6 text-blue-400" />
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Quantité disponible</p>
                    <p className="text-xl font-bold text-white">{offer.megawatts} MW</p>
                  </div>
                </div>
              </div>

              {/* Price info with glowing elements */}
              <div className="bg-gradient-to-r from-emerald-500/5 to-cyan-500/5 rounded-xl p-4 border border-white/5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <div className="absolute -inset-1 bg-emerald-500/30 rounded-lg blur"></div>
                      <div className="relative w-12 h-12 flex items-center justify-center bg-emerald-500/10 rounded-lg border border-emerald-500/20">
                        <DollarSign className="w-6 h-6 text-emerald-400" />
                      </div>
                    </div>
                    <div>
                      <p className="text-sm text-gray-400">Prix par MW</p>
                      <p className="text-xl font-bold text-white">{offer.pricePerMegawatt}€</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Prix total</p>
                    <p className="text-xl font-bold text-white">{offer.totalPrice}€</p>
                  </div>
                </div>
              </div>

              {/* Safety net with glowing shield */}
              <div className="bg-gradient-to-r from-purple-500/5 to-pink-500/5 rounded-xl p-4 border border-white/5">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <div className="absolute -inset-1 bg-purple-500/30 rounded-lg blur"></div>
                    <div className="relative w-12 h-12 flex items-center justify-center bg-purple-500/10 rounded-lg border border-purple-500/20">
                      <Shield className="w-6 h-6 text-purple-400" />
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Filet de sécurité</p>
                    <p className="text-xl font-bold text-white">{offer.totalPrice * 0.9}€</p>
                  </div>
                </div>
              </div>

              {/* Timer with glowing effect */}
              <div className="bg-gradient-to-r from-cyan-500/5 to-blue-500/5 rounded-xl p-4 border border-white/5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <div className="absolute -inset-1 bg-cyan-500/30 rounded-lg blur"></div>
                      <div className="relative w-12 h-12 flex items-center justify-center bg-cyan-500/10 rounded-lg border border-cyan-500/20">
                        <Clock className="w-6 h-6 text-cyan-400" />
                      </div>
                    </div>
                    <p className="text-sm text-gray-400">Temps restant</p>
                  </div>
                  <FuturisticTimer expiryDate={offer.expiryDate} />
                </div>
              </div>

              {/* Action Button with gradient animation */}
              <motion.button
                onClick={() => setSelectedOffer(offer)}
                disabled={!currentLead || currentLead.balance < offer.totalPrice}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="relative w-full group overflow-hidden rounded-xl"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500 opacity-80 group-hover:opacity-100 transition-opacity animate-gradient-x"></div>
                <div className="relative bg-black/20 text-white py-4 px-6 backdrop-blur-sm font-medium tracking-wide">
                  Investir maintenant
                </div>
              </motion.button>
            </div>
          </div>
        </motion.div>
      ))}

      <AnimatePresence>
        {selectedOffer && currentLead && (
          <InvestModal
            offer={selectedOffer}
            isOpen={true}
            onClose={() => setSelectedOffer(null)}
            onConfirm={handleInvestment}
            currentBalance={currentLead.balance}
          />
        )}
      </AnimatePresence>
    </div>
  );
}