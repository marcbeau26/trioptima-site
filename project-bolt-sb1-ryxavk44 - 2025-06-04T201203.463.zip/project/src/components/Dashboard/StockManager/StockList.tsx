import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Clock, DollarSign, Building2, Gift, Hash } from 'lucide-react';
import type { EnergyHolding, Lead, Proposal } from '../../../types';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { formatDate, formatPrice, generateReference } from '../../../utils';
import { FuturisticTimer } from '../../common/FuturisticTimer';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';

interface MakeProposalModalProps {
  isOpen: boolean;
  onClose: () => void;
  holding: EnergyHolding & { lead: Lead };
  onSubmit: (amount: number, expiryDays: number, expiryHours: number, expiryMinutes: number, companyName: string) => void;
}

function MakeProposalModal({ isOpen, onClose, holding, onSubmit }: MakeProposalModalProps) {
  const [pricePerMegawatt, setPricePerMegawatt] = useState(holding.pricePerMegawatt);
  const [expiryDays, setExpiryDays] = useState(0);
  const [expiryHours, setExpiryHours] = useState(24);
  const [expiryMinutes, setExpiryMinutes] = useState(0);
  const [companyName, setCompanyName] = useState('');

  if (!isOpen) return null;

  const totalPrice = pricePerMegawatt * holding.megawatts;
  const profit = totalPrice - holding.totalPrice;
  const profitPercentage = (profit / holding.totalPrice) * 100;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[100]">
      <div className="absolute inset-0" onClick={onClose}></div>
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 50 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="relative w-full max-w-lg mx-4 max-h-[90vh] overflow-y-auto mt-16"
        onClick={e => e.stopPropagation()}
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-6">
            Faire une proposition
          </h2>

          <div className="space-y-6">
            {/* Stock Info */}
            <div className="bg-gray-800/50 border border-white/5 rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-medium text-white">Stock</h3>
                {holding.reference && (
                  <div className="flex items-center bg-blue-500/20 border border-blue-500/30 rounded-full px-2 py-1">
                    <Hash className="h-3 w-3 text-blue-400 mr-1" />
                    <span className="text-xs font-mono text-blue-300">{holding.reference}</span>
                  </div>
                )}
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-gray-400 text-sm">Client</p>
                  <p className="text-white">{holding.lead.firstName} {holding.lead.lastName}</p>
                  <p className="text-gray-400 text-sm">{holding.lead.email}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Entreprise</p>
                  <p className="text-white">{holding.companyName}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Quantité</p>
                  <p className="text-white">{holding.megawatts} MW</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Prix d'achat/MW</p>
                  <p className="text-white">{formatPrice(holding.pricePerMegawatt)}€</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Prix total d'achat</p>
                  <p className="text-white">{formatPrice(holding.totalPrice)}€</p>
                </div>
              </div>
            </div>

            {/* Proposal Form */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Nom de la compagnie
                </label>
                <input
                  type="text"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  placeholder="Ex: EDF"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Prix par mégawatt (€)
                </label>
                <input
                  type="number"
                  value={pricePerMegawatt}
                  onChange={(e) => setPricePerMegawatt(parseFloat(e.target.value) || 0)}
                  className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  min={0}
                  step="0.01"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Durée de validité
                </label>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs text-gray-400 mb-1">Jours</label>
                    <input
                      type="number"
                      value={expiryDays}
                      onChange={(e) => setExpiryDays(parseInt(e.target.value) || 0)}
                      className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                      min={0}
                      max={365}
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-400 mb-1">Heures</label>
                    <input
                      type="number"
                      value={expiryHours}
                      onChange={(e) => setExpiryHours(parseInt(e.target.value) || 0)}
                      className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                      min={0}
                      max={23}
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-400 mb-1">Minutes</label>
                    <input
                      type="number"
                      value={expiryMinutes}
                      onChange={(e) => setExpiryMinutes(parseInt(e.target.value) || 0)}
                      className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                      min={0}
                      max={59}
                    />
                  </div>
                </div>
                {expiryDays === 0 && expiryHours === 0 && expiryMinutes === 0 && (
                  <p className="mt-2 text-sm text-red-400">
                    Veuillez spécifier une durée de validité
                  </p>
                )}
              </div>

              {/* Summary */}
              <div className="bg-gray-800/50 border border-white/5 rounded-xl p-4 space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-400">Prix total</span>
                  <span className="text-white">{formatPrice(totalPrice)}€</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Profit potentiel</span>
                  <span className={profit >= 0 ? "text-green-400" : "text-red-400"}>
                    {profit >= 0 ? '+' : ''}{formatPrice(profit)}€ ({profitPercentage.toFixed(2)}%)
                  </span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex justify-end space-x-4">
              <button
                onClick={onClose}
                className="px-6 py-3 text-sm font-medium text-gray-300 bg-gray-800/50 hover:bg-gray-700/50 rounded-lg transition-colors"
              >
                Annuler
              </button>
              <motion.button
                onClick={() => onSubmit(pricePerMegawatt, expiryDays, expiryHours, expiryMinutes, companyName)}
                disabled={!companyName.trim() || (expiryDays === 0 && expiryHours === 0 && expiryMinutes === 0)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="relative group px-6 py-3 rounded-lg overflow-hidden disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
                <span className="relative text-white font-medium">
                  Envoyer la proposition
                </span>
              </motion.button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export function StockList({ onStockCountChange }: { onStockCountChange: (count: number) => void }) {
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [selectedHolding, setSelectedHolding] = useState<EnergyHolding & { lead: Lead } | null>(null);
  const [view, setView] = useState<'grid' | 'table'>('grid');

  // Get all leads' energy holdings
  const allHoldings = leads.flatMap(lead => 
    (lead.energyHoldings || []).map(holding => ({
      ...holding,
      lead
    }))
  ).filter(holding => holding.status === 'InProgress');

  // Check for expired holdings
  useEffect(() => {
    const checkExpiry = () => {
      const now = new Date().getTime();
      const updatedLeads = leads.map(lead => {
        if (lead.energyHoldings) {
          const updatedHoldings = lead.energyHoldings.map(holding => ({
            ...holding,
            status: new Date(holding.expiryDate).getTime() <= now ? 'Expired' as const : holding.status
          }));

          if (JSON.stringify(updatedHoldings) !== JSON.stringify(lead.energyHoldings)) {
            return {
              ...lead,
              energyHoldings: updatedHoldings
            };
          }
        }
        return lead;
      });

      if (JSON.stringify(updatedLeads) !== JSON.stringify(leads)) {
        setLeads(updatedLeads);
      }
    };

    const interval = setInterval(checkExpiry, 1000);
    return () => clearInterval(interval);
  }, [leads, setLeads]);

  const handleMakeProposal = (holding: EnergyHolding & { lead: Lead }) => {
    setSelectedHolding(holding);
  };

  const handleSubmitProposal = (pricePerMegawatt: number, expiryDays: number, expiryHours: number, expiryMinutes: number, companyName: string) => {
    if (!selectedHolding || !companyName.trim()) return;
    
    if (expiryDays === 0 && expiryHours === 0 && expiryMinutes === 0) {
      toast.error('Veuillez spécifier une durée de validité');
      return;
    }

    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + expiryDays);
    expiryDate.setHours(expiryDate.getHours() + expiryHours);
    expiryDate.setMinutes(expiryDate.getMinutes() + expiryMinutes);

    // Generate a unique reference for the proposal
    const reference = generateReference(5);

    const proposal: Proposal = {
      id: Math.random().toString(36).substr(2, 9),
      stockId: selectedHolding.id,
      buyerName: companyName,
      megawatts: selectedHolding.megawatts,
      pricePerMegawatt,
      reference,
      totalPrice: pricePerMegawatt * selectedHolding.megawatts,
      expiryDate: expiryDate.toISOString(),
      dateCreated: new Date().toISOString(),
      status: 'Active' as const
    };

    // Add proposal to lead
    const updatedLeads = leads.map(lead => {
      if (lead.id === selectedHolding.lead.id) {
        return {
          ...lead,
          proposals: [...(lead.proposals || []), proposal]
        };
      }
      return lead;
    });

    setLeads(updatedLeads);
    setSelectedHolding(null);
    toast.success(`Proposition envoyée avec succès. Référence: ${reference}`);
  };

  return (
    <div className="bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-6">
      <h2 className="text-xl font-bold text-white flex items-center mb-6">
        <Gift className="w-6 h-6 mr-2 text-purple-400" />
        Stocks des clients
      </h2>

      <div className="space-y-4">
        {allHoldings.map((holding) => (
          <motion.div
            key={holding.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="relative group"
          >
            <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-500 via-pink-500 to-blue-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
            <div className="relative bg-gray-800 rounded-lg p-4">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center">
                    <Building2 className="h-5 w-5 text-white" />
                  </div>
                  <div className="ml-4">
                    <div className="text-sm font-medium text-white">
                      {holding.lead.firstName} {holding.lead.lastName}
                    </div>
                    <div className="text-sm text-gray-400">
                      {holding.lead.email}
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => handleMakeProposal(holding)}
                  className="inline-flex items-center px-3 py-1.5 text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 rounded-md transition-colors"
                >
                  <Gift className="w-4 h-4 mr-1" />
                  Faire une proposition
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-400">Entreprise</p>
                  <div className="flex items-center">
                    <p className="text-white">{holding.companyName}</p>
                    {holding.reference && (
                      <div className="ml-2 bg-blue-500/20 border border-blue-500/30 rounded-full px-2 py-0.5 flex items-center">
                        <Hash className="h-3 w-3 text-blue-400 mr-1" />
                        <span className="text-xs font-mono text-blue-300">{holding.reference}</span>
                      </div>
                    )}
                  </div>
                  <p className="text-sm text-gray-400">{formatDate(holding.purchaseDate)}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Quantité</p>
                  <p className="text-white">{holding.megawatts} MW</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Prix total</p>
                  <p className="text-white">{formatPrice(holding.totalPrice)}€</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Prix par MW</p>
                  <p className="text-white">{formatPrice(holding.pricePerMegawatt)}€</p>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-gray-700">
                <div className="flex items-center">
                  <span className={cn(
                    "flex items-center",
                    holding.priceVariation >= 0 ? "text-green-400" : "text-red-400"
                  )}>
                    {holding.priceVariation >= 0 ? (
                      <TrendingUp className="h-4 w-4 mr-1" />
                    ) : (
                      <TrendingDown className="h-4 w-4 mr-1" />
                    )}
                    {holding.priceVariation}%
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        ))}

        {allHoldings.length === 0 && (
          <div className="text-center py-12">
            <Gift className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-300">Aucun stock client</h3>
            <p className="mt-1 text-sm text-gray-500">
              Les stocks des clients apparaîtront ici
            </p>
          </div>
        )}
      </div>

      {selectedHolding && (
        <MakeProposalModal
          isOpen={true}
          onClose={() => setSelectedHolding(null)}
          holding={selectedHolding}
          onSubmit={handleSubmitProposal}
        />
      )}
    </div>
  );
}