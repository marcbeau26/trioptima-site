import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Trash2, Edit2, BookOpen, Percent, Clock, DollarSign, Hash, Calculator, Info, Check, X, Image as ImageIcon, Upload, ZoomIn, ZoomOut } from 'lucide-react';
import type { Livret, CropArea } from '../../../types';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { formatDate } from '../../../utils';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';
import { useDropzone } from 'react-dropzone';
import Cropper from 'react-easy-crop';

interface EditLivretModalProps {
  livret: Livret;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedLivret: Livret) => void;
}

// Modal for image cropping
interface ImageCropModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageUrl: string;
  onCropComplete: (croppedImageUrl: string) => void;
}

function ImageCropModal({ isOpen, onClose, imageUrl, onCropComplete }: ImageCropModalProps) {
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [croppedAreaPixels, setCroppedAreaPixels] = useState<CropArea | null>(null);

  if (!isOpen) return null;

  const onCropChange = (location: { x: number; y: number }) => {
    setCrop(location);
  };

  const onZoomChange = (value: number) => {
    setZoom(value);
  };

  const onCropCompleteCallback = (croppedArea: any, croppedAreaPixels: CropArea) => {
    setCroppedAreaPixels(croppedAreaPixels);
  };

  const createCroppedImage = async () => {
    if (!croppedAreaPixels) return;

    try {
      const image = new Image();
      image.src = imageUrl;
      
      await new Promise((resolve) => {
        image.onload = resolve;
      });

      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      if (!ctx) {
        throw new Error('Could not get canvas context');
      }

      // Set canvas dimensions to the cropped size
      canvas.width = croppedAreaPixels.width;
      canvas.height = croppedAreaPixels.height;

      // Draw the cropped image onto the canvas
      ctx.drawImage(
        image,
        croppedAreaPixels.x,
        croppedAreaPixels.y,
        croppedAreaPixels.width,
        croppedAreaPixels.height,
        0,
        0,
        croppedAreaPixels.width,
        croppedAreaPixels.height
      );

      // Convert canvas to data URL
      const croppedImageUrl = canvas.toDataURL('image/png');
      
      onCropComplete(croppedImageUrl);
      onClose();
    } catch (error) {
      console.error('Error creating cropped image:', error);
      toast.error('Erreur lors du recadrage de l\'image');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="relative w-full max-w-4xl mx-4 bg-gray-900/90 backdrop-blur-xl border border-white/10 p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-bold text-white">Recadrer le logo</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-300 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="relative h-96 bg-gray-800 overflow-hidden">
          <Cropper
            image={imageUrl}
            crop={crop}
            zoom={zoom}
            aspect={1}
            onCropChange={onCropChange}
            onZoomChange={onZoomChange}
            onCropComplete={onCropCompleteCallback}
          />
        </div>

        <div className="mt-4 flex items-center space-x-4">
          <div className="flex items-center space-x-2 flex-1">
            <ZoomOut className="w-5 h-5 text-gray-400" />
            <input
              type="range"
              value={zoom}
              min={1}
              max={3}
              step={0.1}
              onChange={(e) => setZoom(parseFloat(e.target.value))}
              className="w-full"
            />
            <ZoomIn className="w-5 h-5 text-gray-400" />
          </div>
          <div className="flex space-x-3">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 transition-colors"
            >
              Annuler
            </button>
            <button
              onClick={createCroppedImage}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white transition-colors"
            >
              Appliquer
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function EditLivretModal({ livret, isOpen, onClose, onSave }: EditLivretModalProps) {
  const [editedLivret, setEditedLivret] = useState(livret);
  const [calculatedBenefit, setCalculatedBenefit] = useState<{total: number; monthly: number}>({total: 0, monthly: 0});
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(livret.logoUrl || null);
  const [showCropModal, setShowCropModal] = useState(false);
  const [originalImage, setOriginalImage] = useState<string | null>(null);

  // Calculate benefit whenever relevant form data changes
  React.useEffect(() => {
    const { interestRate, initialCapital, duration } = editedLivret;
    
    // Convert duration to years for calculation
    let durationInYears = duration.value;
    if (duration.unit === 'months') {
      durationInYears = duration.value / 12;
    }
    
    // Simple interest calculation: P * r * t
    const totalBenefit = initialCapital * (interestRate / 100) * durationInYears;
    
    // Calculate monthly benefit
    const monthlyBenefit = totalBenefit / (duration.unit === 'months' ? duration.value : duration.value * 12);
    
    setCalculatedBenefit({
      total: totalBenefit,
      monthly: monthlyBenefit
    });
  }, [editedLivret.interestRate, editedLivret.initialCapital, editedLivret.duration]);

  const onDrop = React.useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length === 0) return;
    
    const file = acceptedFiles[0];
    
    // Check if file is an image
    if (!file.type.startsWith('image/')) {
      toast.error('Veuillez sélectionner une image');
      return;
    }
    
    // Check file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      toast.error('L\'image ne doit pas dépasser 2MB');
      return;
    }
    
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setOriginalImage(result);
      setShowCropModal(true);
    };
    reader.readAsDataURL(file);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.gif']
    },
    maxFiles: 1
  });

  const handleCropComplete = (croppedImageUrl: string) => {
    setLogoPreview(croppedImageUrl);
    setEditedLivret({ ...editedLivret, logoUrl: croppedImageUrl });
  };

  const handleRemoveLogo = () => {
    setLogoPreview(null);
    setEditedLivret({ ...editedLivret, logoUrl: undefined });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-4xl mx-4 max-h-[90vh] overflow-auto"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 p-8">
          <div className="flex justify-between items-start mb-6">
            <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Modifier le Livret
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-300 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <form onSubmit={(e) => {
            e.preventDefault();
            onSave(editedLivret);
          }} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Livret Name */}
              <div className="col-span-2">
                <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                  <BookOpen className="w-4 h-4 mr-2 text-blue-400" />
                  Nom du Livret
                </label>
                <input
                  type="text"
                  value={editedLivret.name}
                  onChange={(e) => setEditedLivret({ ...editedLivret, name: e.target.value })}
                  onFocus={() => setFocusedField('name')}
                  onBlur={() => setFocusedField(null)}
                  className={cn(
                    "w-full bg-gray-800/50 text-white border border-gray-700/50 px-4 py-3",
                    "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                    "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                    focusedField === 'name' && "shadow-[0_0_15px_rgba(59,130,246,0.5)]"
                  )}
                  required
                />
              </div>

              {/* Logo Upload */}
              <div className="col-span-2">
                <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                  <ImageIcon className="w-4 h-4 mr-2 text-pink-400" />
                  Logo du Livret
                </label>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div 
                    {...getRootProps()} 
                    className={cn(
                      "col-span-2 border-2 border-dashed p-4 transition-all duration-200 cursor-pointer",
                      isDragActive
                        ? "border-blue-500 bg-blue-500/10"
                        : "border-gray-700 hover:border-blue-500/50 hover:bg-gray-800/50"
                    )}
                  >
                    <input {...getInputProps()} />
                    <div className="flex flex-col items-center justify-center space-y-2 text-center">
                      <Upload className="w-8 h-8 text-gray-400" />
                      <p className="text-sm text-gray-300">
                        {isDragActive
                          ? "Déposez l'image ici..."
                          : "Glissez-déposez une image ici, ou cliquez pour sélectionner"}
                      </p>
                      <p className="text-xs text-gray-500">
                        PNG, JPG, GIF jusqu'à 2MB
                      </p>
                    </div>
                  </div>
                  
                  {/* Logo Preview */}
                  <div className="relative">
                    {logoPreview ? (
                      <div className="relative aspect-square overflow-hidden border border-gray-700 bg-gray-800/50">
                        <img 
                          src={logoPreview} 
                          alt="Logo preview" 
                          className="w-full h-full object-contain"
                        />
                        <button
                          type="button"
                          onClick={handleRemoveLogo}
                          className="absolute top-2 right-2 p-1 bg-red-500/80 text-white hover:bg-red-600/80 transition-colors"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <div className="aspect-square border border-gray-700 bg-gray-800/50 flex items-center justify-center">
                        <ImageIcon className="w-10 h-10 text-gray-600" />
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Interest Rate */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                  <Percent className="w-4 h-4 mr-2 text-green-400" />
                  Taux d'Intérêt (%)
                </label>
                <input
                  type="number"
                  value={editedLivret.interestRate || ''}
                  onChange={(e) => setEditedLivret({ ...editedLivret, interestRate: parseFloat(e.target.value) || 0 })}
                  onFocus={() => setFocusedField('interestRate')}
                  onBlur={() => setFocusedField(null)}
                  className={cn(
                    "w-full bg-gray-800/50 text-white border border-gray-700/50 px-4 py-3",
                    "focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50",
                    "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                    focusedField === 'interestRate' && "shadow-[0_0_15px_rgba(34,197,94,0.5)]"
                  )}
                  step="0.01"
                  min="0"
                  required
                />
              </div>

              {/* Initial Capital */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                  <DollarSign className="w-4 h-4 mr-2 text-purple-400" />
                  Capital Initial (€)
                </label>
                <input
                  type="number"
                  value={editedLivret.initialCapital || ''}
                  onChange={(e) => setEditedLivret({ ...editedLivret, initialCapital: parseFloat(e.target.value) || 0 })}
                  onFocus={() => setFocusedField('initialCapital')}
                  onBlur={() => setFocusedField(null)}
                  className={cn(
                    "w-full bg-gray-800/50 text-white border border-gray-700/50 px-4 py-3",
                    "focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50",
                    "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                    focusedField === 'initialCapital' && "shadow-[0_0_15px_rgba(147,51,234,0.5)]"
                  )}
                  min="0"
                  step="100"
                  required
                />
              </div>

              {/* Duration */}
              <div className="col-span-2">
                <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                  <Clock className="w-4 h-4 mr-2 text-cyan-400" />
                  Durée
                </label>
                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="number"
                    value={editedLivret.duration.value || ''}
                    onChange={(e) => setEditedLivret({
                      ...editedLivret,
                      duration: {
                        ...editedLivret.duration,
                        value: parseInt(e.target.value) || 0
                      }
                    })}
                    onFocus={() => setFocusedField('durationValue')}
                    onBlur={() => setFocusedField(null)}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                      focusedField === 'durationValue' && "shadow-[0_0_15px_rgba(34,211,238,0.5)]"
                    )}
                    min="1"
                    required
                  />
                  <select
                    value={editedLivret.duration.unit}
                    onChange={(e) => setEditedLivret({
                      ...editedLivret,
                      duration: {
                        ...editedLivret.duration,
                        unit: e.target.value as 'months' | 'years'
                      }
                    })}
                    onFocus={() => setFocusedField('durationUnit')}
                    onBlur={() => setFocusedField(null)}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                      focusedField === 'durationUnit' && "shadow-[0_0_15px_rgba(34,211,238,0.5)]"
                    )}
                  >
                    <option value="months">Mois</option>
                    <option value="years">Années</option>
                  </select>
                </div>
              </div>

              {/* Description */}
              <div className="col-span-2">
                <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                  <Info className="w-4 h-4 mr-2 text-pink-400" />
                  Description
                </label>
                <textarea
                  value={editedLivret.description || ''}
                  onChange={(e) => setEditedLivret({ ...editedLivret, description: e.target.value })}
                  onFocus={() => setFocusedField('description')}
                  onBlur={() => setFocusedField(null)}
                  className={cn(
                    "w-full bg-gray-800/50 text-white border border-gray-700/50 px-4 py-3",
                    "focus:outline-none focus:ring-2 focus:ring-pink-500/50 focus:border-pink-500/50",
                    "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                    focusedField === 'description' && "shadow-[0_0_15px_rgba(236,72,153,0.5)]"
                  )}
                  rows={4}
                  placeholder="Description du livret..."
                />
              </div>

              {/* Status */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Statut
                </label>
                <select
                  value={editedLivret.status}
                  onChange={(e) => setEditedLivret({ ...editedLivret, status: e.target.value as 'Active' | 'Inactive' })}
                  onFocus={() => setFocusedField('status')}
                  onBlur={() => setFocusedField(null)}
                  className={cn(
                    "w-full bg-gray-800/50 text-white border border-gray-700/50 px-4 py-3",
                    "focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500/50",
                    "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                    focusedField === 'status' && "shadow-[0_0_15px_rgba(245,158,11,0.5)]"
                  )}
                >
                  <option value="Active">Actif</option>
                  <option value="Inactive">Inactif</option>
                </select>
              </div>

              {/* Benefit Calculator */}
              <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 p-4 border border-blue-500/20">
                <div className="flex items-center mb-2">
                  <Calculator className="w-5 h-5 text-blue-400 mr-2" />
                  <h3 className="text-lg font-medium text-white">Calculateur de Bénéfice</h3>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-400">Bénéfice Mensuel</p>
                    <p className="text-lg font-bold text-blue-400">+{calculatedBenefit.monthly.toLocaleString()}€</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Bénéfice Total</p>
                    <p className="text-lg font-bold text-blue-400">+{calculatedBenefit.total.toLocaleString()}€</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-sm text-gray-400">Montant Total à Terme</p>
                    <p className="text-xl font-bold text-white">{(editedLivret.initialCapital + calculatedBenefit.total).toLocaleString()}€</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-4 mt-6">
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-3 text-sm font-medium text-gray-300 bg-gray-800/50 hover:bg-gray-700/50 transition-colors"
              >
                Annuler
              </button>
              <motion.button
                type="submit"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="relative group px-6 py-3 overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
                <span className="relative flex items-center text-white font-medium">
                  <Check className="w-4 h-4 mr-2" />
                  Enregistrer
                </span>
              </motion.button>
            </div>
          </form>
        </div>
      </motion.div>

      {/* Image Crop Modal */}
      {showCropModal && originalImage && (
        <ImageCropModal
          isOpen={showCropModal}
          onClose={() => setShowCropModal(false)}
          imageUrl={originalImage}
          onCropComplete={handleCropComplete}
        />
      )}
    </div>
  );
}

export function LivretList() {
  const [livrets, setLivrets] = useLocalStorage<Livret[]>('livrets', []);
  const [selectedLivrets, setSelectedLivrets] = useState<string[]>([]);
  const [editingLivret, setEditingLivret] = useState<Livret | null>(null);

  const toggleSelectAll = () => {
    if (selectedLivrets.length === livrets.length) {
      setSelectedLivrets([]);
    } else {
      setSelectedLivrets(livrets.map(livret => livret.id));
    }
  };

  const toggleLivret = (livretId: string) => {
    if (selectedLivrets.includes(livretId)) {
      setSelectedLivrets(selectedLivrets.filter(id => id !== livretId));
    } else {
      setSelectedLivrets([...selectedLivrets, livretId]);
    }
  };

  const handleDelete = () => {
    setLivrets(livrets.filter(livret => !selectedLivrets.includes(livret.id)));
    setSelectedLivrets([]);
    toast.success(`${selectedLivrets.length} livret${selectedLivrets.length > 1 ? 's' : ''} supprimé${selectedLivrets.length > 1 ? 's' : ''}`);
  };

  const handleEdit = (livret: Livret) => {
    setEditingLivret(livret);
  };

  const handleSaveEdit = (updatedLivret: Livret) => {
    setLivrets(livrets.map(livret => 
      livret.id === updatedLivret.id ? updatedLivret : livret
    ));
    setEditingLivret(null);
    toast.success('Livret modifié avec succès');
  };

  // Calculate benefit for a livret
  const calculateBenefit = (livret: Livret): {total: number; monthly: number} => {
    const { interestRate, initialCapital, duration } = livret;
    
    // Convert duration to years for calculation
    let durationInYears = duration.value;
    if (duration.unit === 'months') {
      durationInYears = duration.value / 12;
    }
    
    // Simple interest calculation: P * r * t
    const totalBenefit = initialCapital * (interestRate / 100) * durationInYears;
    
    // Calculate monthly benefit
    const monthlyBenefit = totalBenefit / (duration.unit === 'months' ? duration.value : duration.value * 12);
    
    return { 
      total: totalBenefit,
      monthly: monthlyBenefit
    };
  };

  return (
    <div className="space-y-6">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-700">
          <thead className="bg-gray-800">
            <tr>
              <th scope="col" className="px-6 py-3 text-left">
                <input
                  type="checkbox"
                  checked={selectedLivrets.length === livrets.length && livrets.length > 0}
                  onChange={toggleSelectAll}
                  className="border-gray-600 text-blue-500 focus:ring-blue-500 bg-gray-700"
                />
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Logo
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Référence
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Nom
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Taux d'Intérêt
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Capital Initial
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Durée
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Bénéfice Mensuel
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Bénéfice Total
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Statut
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-gray-900 divide-y divide-gray-800">
            {livrets.map((livret) => {
              const benefit = calculateBenefit(livret);
              
              return (
                <tr key={livret.id} className="hover:bg-gray-800/50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <input
                      type="checkbox"
                      checked={selectedLivrets.includes(livret.id)}
                      onChange={() => toggleLivret(livret.id)}
                      className="border-gray-600 text-blue-500 focus:ring-blue-500 bg-gray-700"
                    />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="w-10 h-10 bg-gray-800 flex items-center justify-center overflow-hidden">
                      {livret.logoUrl ? (
                        <img 
                          src={livret.logoUrl} 
                          alt={`Logo ${livret.name}`} 
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <BookOpen className="w-5 h-5 text-gray-400" />
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Hash className="h-4 w-4 text-blue-400 mr-1" />
                      <span className="text-sm font-medium text-blue-400 font-mono">
                        {livret.reference}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="ml-4">
                        <div className="text-sm font-medium text-white">
                          {livret.name}
                        </div>
                        <div className="text-sm text-gray-400">
                          {formatDate(livret.dateCreated)}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center text-green-400">
                      <Percent className="h-4 w-4 mr-1" />
                      <span className="text-sm font-medium">
                        {livret.interestRate}%
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-white">
                      {livret.initialCapital.toLocaleString()}€
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-white">
                      {livret.duration.value} {livret.duration.unit === 'months' ? 'mois' : 'ans'}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-blue-400">
                      +{benefit.monthly.toLocaleString()}€
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-blue-400">
                      +{benefit.total.toLocaleString()}€
                    </div>
                    <div className="text-xs text-gray-400">
                      Total: {(livret.initialCapital + benefit.total).toLocaleString()}€
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={cn(
                      "px-2 inline-flex text-xs leading-5 font-semibold",
                      livret.status === 'Active' 
                        ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                        : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
                    )}>
                      {livret.status === 'Active' ? 'Actif' : 'Inactif'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button
                      onClick={() => handleEdit(livret)}
                      className="text-blue-400 hover:text-blue-300 transition-colors"
                    >
                      <Edit2 className="h-5 w-5" />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {livrets.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="mx-auto h-12 w-12 text-gray-400" />
            <h3 className="mt-2 text-sm font-medium text-gray-300">Aucun livret</h3>
            <p className="mt-1 text-sm text-gray-500">
              Commencez par créer un nouveau livret
            </p>
          </div>
        )}
      </div>

      {selectedLivrets.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed bottom-8 left-1/2 transform -translate-x-1/2"
        >
          <div className="bg-gray-800 shadow-lg border border-gray-700 p-4">
            <button
              onClick={handleDelete}
              className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Supprimer ({selectedLivrets.length})
            </button>
          </div>
        </motion.div>
      )}

      <AnimatePresence>
        {editingLivret && (
          <EditLivretModal
            livret={editingLivret}
            isOpen={true}
            onClose={() => setEditingLivret(null)}
            onSave={handleSaveEdit}
          />
        )}
      </AnimatePresence>
    </div>
  );
}