import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar, X, StopCircle, RefreshCw, Info } from 'lucide-react';
import { useGenerationProgress } from '../../../contexts/GenerationProgressContext';
import { toast } from 'react-hot-toast';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import type { ScheduledCampaign } from '../../../types';

export function GenerationProgressModal() {
  const {
    generationInProgress,
    setGenerationInProgress,
    currentOfferIndex,
    scheduledOffers,
    generationProgress,
    generationStartTime,
    generationEndTime,
    currentCampaignId,
    setCurrentCampaignId
  } = useGenerationProgress();
  
  const [campaigns, setCampaigns] = useLocalStorage<ScheduledCampaign[]>('scheduledCampaigns', []);
  const [isVisible, setIsVisible] = useState(false);

  // Show modal when generation starts
  useEffect(() => {
    if (generationInProgress) {
      setIsVisible(true);
    } else {
      // Hide modal with a delay when generation stops
      const timeout = setTimeout(() => {
        setIsVisible(false);
      }, 3000);
      
      return () => clearTimeout(timeout);
    }
  }, [generationInProgress]);

  // Calculate elapsed time
  const calculateElapsedTime = (): string => {
    if (!generationStartTime) return '0s';
    
    const start = new Date(generationStartTime).getTime();
    const now = new Date().getTime();
    const diff = now - start;
    
    const seconds = Math.floor(diff / 1000) % 60;
    const minutes = Math.floor(diff / (1000 * 60)) % 60;
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (hours > 0) {
      return `${hours}h ${minutes}m ${seconds}s`;
    } else if (minutes > 0) {
      return `${minutes}m ${seconds}s`;
    } else {
      return `${seconds}s`;
    }
  };

  // Calculate remaining time
  const calculateRemainingTime = (): string => {
    if (!generationEndTime) return 'Calcul...';
    
    const end = new Date(generationEndTime).getTime();
    const now = new Date().getTime();
    const diff = end - now;
    
    if (diff <= 0) return 'Terminé';
    
    const seconds = Math.floor(diff / 1000) % 60;
    const minutes = Math.floor(diff / (1000 * 60)) % 60;
    const hours = Math.floor(diff / (1000 * 60 * 60));
    
    if (hours > 0) {
      return `${hours}h ${minutes}m ${seconds}s`;
    } else if (minutes > 0) {
      return `${minutes}m ${seconds}s`;
    } else {
      return `${seconds}s`;
    }
  };

  // Handle cancel generation
  const handleCancel = () => {
    setGenerationInProgress(false);
    
    // Update campaign status if there's an active campaign
    if (currentCampaignId) {
      setCampaigns(campaigns.map(campaign => 
        campaign.id === currentCampaignId 
          ? { ...campaign, status: 'cancelled' as const }
          : campaign
      ));
      
      setCurrentCampaignId(null);
      toast.success('Génération annulée');
    }
  };

  if (!isVisible) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 50 }}
      className="fixed bottom-8 right-8 z-50"
    >
      <div className="bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-6 shadow-xl max-w-md">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium text-white flex items-center">
            <RefreshCw className="w-5 h-5 mr-2 text-blue-400 animate-spin" />
            Génération en cours
          </h3>
          <button
            onClick={() => setIsVisible(false)}
            className="text-gray-400 hover:text-gray-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span className="text-gray-400">Progression</span>
              <span className="text-gray-400">{generationProgress.toFixed(0)}%</span>
            </div>
            <div className="w-full bg-gray-700 h-2 rounded-full overflow-hidden">
              <div 
                className="bg-gradient-to-r from-blue-500 to-purple-500 h-full rounded-full transition-all duration-300 ease-out"
                style={{ width: `${generationProgress}%` }}
              ></div>
            </div>
          </div>
          
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Offres générées</span>
            <span className="text-white">{currentOfferIndex}/{scheduledOffers.length || '?'}</span>
          </div>
          
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Temps écoulé</span>
            <span className="text-white">{calculateElapsedTime()}</span>
          </div>
          
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Temps restant estimé</span>
            <span className="text-white">{calculateRemainingTime()}</span>
          </div>
        </div>
        
        <div className="mt-4 flex justify-between items-center">
          <button
            onClick={handleCancel}
            className="flex items-center px-4 py-2 bg-red-600/20 hover:bg-red-600/30 text-red-400 rounded-lg transition-colors"
          >
            <StopCircle className="w-4 h-4 mr-2" />
            Annuler
          </button>
          
          <div className="flex items-center text-sm text-gray-400">
            <Calendar className="w-4 h-4 mr-1" />
            <span>Voir dans "Suivi des Offres"</span>
          </div>
        </div>
        
        <div className="mt-4 bg-blue-900/20 border border-blue-500/20 rounded-lg p-3">
          <div className="flex items-center mb-2">
            <Info className="w-4 h-4 text-blue-400 mr-2" />
            <span className="text-sm font-medium text-blue-400">Information</span>
          </div>
          <p className="text-sm text-blue-300">
            La génération des offres se poursuit en arrière-plan. Vous pouvez fermer cette fenêtre et continuer à utiliser l'application.
          </p>
        </div>
      </div>
    </motion.div>
  );
}