import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Package, Check, X, Zap, LineChart, BookOpen, 
  ToggleLeft, ToggleRight, Info, AlertCircle
} from 'lucide-react';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';

interface Product {
  id: string;
  name: string;
  iconType: 'lineChart' | 'zap' | 'bookOpen';
  description: string;
  enabled: boolean;
  color: string;
}

const getIconComponent = (iconType: Product['iconType'], color: string) => {
  switch (iconType) {
    case 'lineChart':
      return <LineChart className={`w-6 h-6 text-${color}`} />;
    case 'zap':
      return <Zap className={`w-6 h-6 text-${color}`} />;
    case 'bookOpen':
      return <BookOpen className={`w-6 h-6 text-${color}`} />;
    default:
      return <Package className={`w-6 h-6 text-${color}`} />;
  }
};

const defaultProducts: Product[] = [
  {
    id: 'actions',
    name: 'Actions',
    iconType: 'lineChart',
    color: 'blue-400',
    description: 'Gestion des actions et investissements en bourse',
    enabled: true
  },
  {
    id: 'electricity',
    name: 'Électricité',
    iconType: 'zap',
    color: 'yellow-400',
    description: 'Investissements dans le secteur de l\'énergie',
    enabled: true
  },
  {
    id: 'livrets',
    name: 'Livrets',
    iconType: 'bookOpen',
    color: 'green-400',
    description: 'Livrets d\'épargne et produits financiers',
    enabled: true
  },
  {
    id: 'trading',
    name: 'Trading',
    iconType: 'lineChart',
    color: 'purple-400',
    description: 'Plateforme de trading en temps réel',
    enabled: true
  }
];

export function ProductManager() {
  const [products, setProducts] = useLocalStorage<Product[]>('products', defaultProducts);

  // Initialize products if they don't exist or are empty
  useEffect(() => {
    if (!products || products.length === 0) {
      setProducts(defaultProducts);
    }
  }, [products, setProducts]);

  const toggleProductStatus = (productId: string) => {
    const updatedProducts = products.map(product => 
      product.id === productId 
        ? { ...product, enabled: !product.enabled } 
        : product
    );
    
    setProducts(updatedProducts);
    
    const product = products.find(p => p.id === productId);
    if (product) {
      toast.success(`${product.name} ${product.enabled ? 'désactivé' : 'activé'} avec succès`);
    }
  };

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <div className="flex items-center mb-6">
            <Package className="w-8 h-8 text-blue-500 mr-3" />
            <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Liste des produits
            </h2>
          </div>

          {/* Information Card */}
          <div className="bg-blue-900/20 border border-blue-500/20 rounded-lg p-4 mb-8">
            <div className="flex items-center mb-2">
              <Info className="w-5 h-5 text-blue-400 mr-2" />
              <h3 className="text-blue-400 font-medium">Gestion des produits</h3>
            </div>
            <p className="text-blue-300 text-sm">
              Activez ou désactivez les différents produits disponibles pour vos clients. 
              Lorsqu'un produit est désactivé, les clients ne pourront pas y accéder et verront un message indiquant que le service est temporairement indisponible.
            </p>
          </div>

          {/* Products List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {products.map((product) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="relative group"
              >
                <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
                <div className="relative bg-gray-800 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      {getIconComponent(product.iconType, product.color)}
                      <h3 className="text-xl font-bold text-white ml-3">{product.name}</h3>
                    </div>
                    <div className="flex items-center">
                      <span className={cn(
                        "px-3 py-1 rounded-full text-xs font-medium mr-3",
                        product.enabled 
                          ? "bg-green-500/20 text-green-400 border border-green-500/30" 
                          : "bg-red-500/20 text-red-400 border border-red-500/30"
                      )}>
                        {product.enabled ? 'Activé' : 'Désactivé'}
                      </span>
                      <button
                        onClick={() => toggleProductStatus(product.id)}
                        className={cn(
                          "p-1 rounded-md transition-colors",
                          product.enabled 
                            ? "text-green-400 hover:text-green-300 hover:bg-green-500/10" 
                            : "text-red-400 hover:text-red-300 hover:bg-red-500/10"
                        )}
                      >
                        {product.enabled ? (
                          <ToggleRight className="w-8 h-8" />
                        ) : (
                          <ToggleLeft className="w-8 h-8" />
                        )}
                      </button>
                    </div>
                  </div>
                  <p className="text-gray-400">{product.description}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
}