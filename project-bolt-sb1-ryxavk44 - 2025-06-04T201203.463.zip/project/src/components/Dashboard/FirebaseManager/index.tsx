import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Database, RefreshCw, Check, AlertCircle, Server, Upload, Download } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { useFirebase } from '../../../contexts/FirebaseContext';
import { initializeFirebaseFromLocalStorage } from '../../../lib/firebaseService';

export function FirebaseManager() {
  const { isInitialized, isInitializing, initializeFirebase } = useFirebase();
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'success' | 'error'>('idle');
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(null);

  useEffect(() => {
    // Check if there's a last sync time in localStorage
    const storedSyncTime = localStorage.getItem('lastFirebaseSyncTime');
    if (storedSyncTime) {
      setLastSyncTime(storedSyncTime);
    }
  }, []);

  const handleSyncToFirebase = async () => {
    setSyncStatus('syncing');
    try {
      await initializeFirebaseFromLocalStorage();
      setSyncStatus('success');
      const now = new Date().toISOString();
      localStorage.setItem('lastFirebaseSyncTime', now);
      setLastSyncTime(now);
      toast.success('Synchronisation avec Firebase réussie');
    } catch (error) {
      console.error('Error syncing to Firebase:', error);
      setSyncStatus('error');
      toast.error('Échec de la synchronisation avec Firebase');
    }
  };

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <div className="flex items-center mb-6">
            <Database className="w-8 h-8 text-blue-500 mr-3" />
            <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Gestionnaire Firebase
            </h2>
          </div>

          {/* Status Card */}
          <div className="bg-gray-800/50 border border-white/10 rounded-xl p-6 mb-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Server className="w-6 h-6 text-blue-400 mr-3" />
                <div>
                  <h3 className="text-xl font-bold text-white">État de la connexion</h3>
                  <p className="text-gray-400 mt-1">
                    {isInitialized 
                      ? 'Firebase est connecté et synchronisé' 
                      : 'Firebase n\'est pas synchronisé'}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-4 h-4 rounded-full ${isInitialized ? 'bg-green-500' : 'bg-red-500'}`}></div>
                <span className={`text-sm ${isInitialized ? 'text-green-400' : 'text-red-400'}`}>
                  {isInitialized ? 'Connecté' : 'Non synchronisé'}
                </span>
              </div>
            </div>
            
            {lastSyncTime && (
              <div className="mt-4 text-sm text-gray-400">
                Dernière synchronisation: {new Date(lastSyncTime).toLocaleString()}
              </div>
            )}
          </div>

          {/* Sync Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Sync to Firebase */}
            <div className="bg-gray-800/50 border border-white/10 rounded-xl p-6">
              <div className="flex items-center mb-4">
                <Upload className="w-6 h-6 text-purple-400 mr-3" />
                <h3 className="text-lg font-bold text-white">Synchroniser vers Firebase</h3>
              </div>
              <p className="text-gray-400 mb-6">
                Envoyer toutes les données locales vers Firebase. Cette opération remplacera les données existantes dans Firebase.
              </p>
              <motion.button
                onClick={handleSyncToFirebase}
                disabled={isInitializing || syncStatus === 'syncing'}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="relative w-full group overflow-hidden rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity"></div>
                <span className="relative flex items-center justify-center text-white py-3">
                  {syncStatus === 'syncing' ? (
                    <>
                      <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                      Synchronisation en cours...
                    </>
                  ) : syncStatus === 'success' ? (
                    <>
                      <Check className="w-5 h-5 mr-2" />
                      Synchronisé avec succès
                    </>
                  ) : syncStatus === 'error' ? (
                    <>
                      <AlertCircle className="w-5 h-5 mr-2" />
                      Échec de la synchronisation
                    </>
                  ) : (
                    <>
                      <Upload className="w-5 h-5 mr-2" />
                      Synchroniser vers Firebase
                    </>
                  )}
                </span>
              </motion.button>
            </div>

            {/* Sync from Firebase */}
            <div className="bg-gray-800/50 border border-white/10 rounded-xl p-6">
              <div className="flex items-center mb-4">
                <Download className="w-6 h-6 text-green-400 mr-3" />
                <h3 className="text-lg font-bold text-white">Synchroniser depuis Firebase</h3>
              </div>
              <p className="text-gray-400 mb-6">
                Récupérer toutes les données depuis Firebase. Cette opération remplacera les données locales.
              </p>
              <motion.button
                disabled={true} // Disabled for now as we haven't implemented this functionality
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="relative w-full group overflow-hidden rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500 opacity-80 group-hover:opacity-100 transition-opacity"></div>
                <span className="relative flex items-center justify-center text-white py-3">
                  <Download className="w-5 h-5 mr-2" />
                  Synchroniser depuis Firebase
                </span>
              </motion.button>
              <p className="text-xs text-gray-500 mt-2">
                Fonctionnalité en cours de développement
              </p>
            </div>
          </div>

          {/* Information Section */}
          <div className="mt-8 bg-blue-900/20 border border-blue-500/20 rounded-lg p-4">
            <div className="flex items-center mb-2">
              <AlertCircle className="w-5 h-5 text-blue-400 mr-2" />
              <h4 className="text-blue-400 font-medium">Informations importantes</h4>
            </div>
            <p className="text-blue-300 text-sm">
              La synchronisation avec Firebase permet de sauvegarder toutes vos données dans le cloud. 
              Cela garantit que vos données sont sécurisées et accessibles depuis n'importe quel appareil.
              Nous vous recommandons de synchroniser régulièrement vos données pour éviter toute perte.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}