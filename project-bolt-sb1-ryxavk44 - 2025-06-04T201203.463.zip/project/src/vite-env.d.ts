/// <reference types="vite/client" />

interface Window {
  EyeDropper?: {
    new(): {
      open: () => Promise<{ sRGBHex: string }>;
    };
  };
}