import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Percent, Clock, Euro, Calculator, Info, AlertCircle } from 'lucide-react';
import type { Livret } from '../../../types';
import { generateId, generateReference } from '../../../utils';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';

type LivretFormData = Omit<Livret, 'id' | 'dateCreated' | 'reference'> & {
  minCapital: number;
  maxCapital: number;
  uniqueAmount: number | null;
  useUniqueAmount: boolean;
  customDuration: string;
  useCustomDuration: boolean;
};

const initialFormData: LivretFormData = {
  name: '',
  interestRate: 0,
  duration: {
    value: 12,
    unit: 'months'
  },
  initialCapital: 1000, // Kept for internal calculations
  minCapital: 500,
  maxCapital: 10000,
  uniqueAmount: null,
  useUniqueAmount: false,
  customDuration: '',
  useCustomDuration: false,
  status: 'Active',
  description: '',
  logoUrl: undefined
};

export function AddLivretForm() {
  const [livrets, setLivrets] = useLocalStorage<Livret[]>('livrets', []);
  const [formData, setFormData] = useState<LivretFormData>(initialFormData);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const [calculatedBenefit, setCalculatedBenefit] = useState<{total: number; monthly: number}>({total: 0, monthly: 0});
  const [formattedUniqueAmount, setFormattedUniqueAmount] = useState('');
  const benefitRef = useRef<HTMLDivElement>(null);

  // Format unique amount with thousand separators
  useEffect(() => {
    if (formData.uniqueAmount !== null) {
      setFormattedUniqueAmount(formData.uniqueAmount.toLocaleString());
    } else {
      setFormattedUniqueAmount('');
    }
  }, [formData.uniqueAmount]);

  // Parse custom duration input
  const parseDuration = (input: string): { value: number; unit: 'months' | 'years' } | null => {
    // Default values
    let value = 0;
    let unit: 'months' | 'years' = 'months';
    
    // Match patterns like "12 mois", "2 années", "6 ans", etc.
    const monthsRegex = /(\d+)\s*(mois|m)/i;
    const yearsRegex = /(\d+)\s*(ans|années|annees|a)/i;
    
    const monthsMatch = input.match(monthsRegex);
    const yearsMatch = input.match(yearsRegex);
    
    if (monthsMatch) {
      value = parseInt(monthsMatch[1], 10);
      unit = 'months';
      return { value, unit };
    } else if (yearsMatch) {
      value = parseInt(yearsMatch[1], 10);
      unit = 'years';
      return { value, unit };
    }
    
    // If input is just a number, assume months
    const numberMatch = input.match(/^(\d+)$/);
    if (numberMatch) {
      value = parseInt(numberMatch[1], 10);
      return { value, unit: 'months' };
    }
    
    return null;
  };

  // Update duration when custom duration changes
  useEffect(() => {
    if (formData.useCustomDuration && formData.customDuration) {
      const parsedDuration = parseDuration(formData.customDuration);
      if (parsedDuration) {
        setFormData(prev => ({
          ...prev,
          duration: parsedDuration
        }));
      }
    }
  }, [formData.customDuration, formData.useCustomDuration]);

  // Calculate benefit whenever relevant form data changes
  useEffect(() => {
    const { interestRate, duration, useUniqueAmount, uniqueAmount, minCapital } = formData;
    
    // Use unique amount or min capital for calculations
    const calculationAmount = useUniqueAmount && uniqueAmount !== null 
      ? uniqueAmount 
      : minCapital;
    
    // Convert duration to years for calculation
    let durationInYears = duration.value;
    if (duration.unit === 'months') {
      durationInYears = duration.value / 12;
    }
    
    // Simple interest calculation: P * r * t
    const totalBenefit = calculationAmount * (interestRate / 100) * durationInYears;
    
    // Calculate monthly benefit
    const monthlyBenefit = totalBenefit / (duration.unit === 'months' ? duration.value : duration.value * 12);
    
    setCalculatedBenefit({
      total: totalBenefit,
      monthly: monthlyBenefit
    });
  }, [formData.interestRate, formData.minCapital, formData.duration, formData.uniqueAmount, formData.useUniqueAmount]);

  // Handle unique amount change
  const handleUniqueAmountChange = (value: string) => {
    // Remove non-numeric characters and parse as number
    const numericValue = value.replace(/[^\d]/g, '');
    const amount = numericValue ? parseInt(numericValue, 10) : null;
    
    setFormData({
      ...formData,
      uniqueAmount: amount
    });
  };

  // Toggle between unique amount and min/max range
  const handleToggleUniqueAmount = (useUnique: boolean) => {
    setFormData({
      ...formData,
      useUniqueAmount: useUnique
    });
  };

  // Toggle between standard and custom duration input
  const handleToggleCustomDuration = (useCustom: boolean) => {
    setFormData({
      ...formData,
      useCustomDuration: useCustom,
      // If switching to standard, update customDuration to match current duration
      customDuration: useCustom ? formData.customDuration : `${formData.duration.value} ${formData.duration.unit}`
    });
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = "Le nom du livret est requis";
    }
    
    if (formData.interestRate <= 0) {
      newErrors.interestRate = "Le taux d'intérêt doit être supérieur à 0";
    }
    
    if (formData.useUniqueAmount) {
      if (formData.uniqueAmount === null || formData.uniqueAmount <= 0) {
        newErrors.uniqueAmount = "La somme unique doit être supérieure à 0";
      }
    } else {
      if (formData.minCapital <= 0) {
        newErrors.minCapital = "Le capital minimum doit être supérieur à 0";
      }
      
      if (formData.maxCapital <= 0) {
        newErrors.maxCapital = "Le capital maximum doit être supérieur à 0";
      }
      
      if (formData.minCapital > formData.maxCapital) {
        newErrors.minCapital = "Le capital minimum ne peut pas être supérieur au capital maximum";
      }
    }
    
    if (formData.useCustomDuration) {
      const parsedDuration = parseDuration(formData.customDuration);
      if (!parsedDuration) {
        newErrors.customDuration = "Format de durée invalide. Exemples valides: '12 mois', '2 ans', '24'";
      } else if (parsedDuration.value <= 0) {
        newErrors.customDuration = "La durée doit être supérieure à 0";
      }
    } else if (formData.duration.value <= 0) {
      newErrors.duration = "La durée doit être supérieure à 0";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    // Generate a unique reference
    const reference = generateReference(5);

    // Create the livret object
    // If using unique amount, set both initialCapital and minCapital to uniqueAmount
    // and maxCapital to the same value
    const { useUniqueAmount, uniqueAmount, minCapital, maxCapital, useCustomDuration, customDuration, ...livretData } = formData;
    
    const newLivret: Livret = {
      ...livretData,
      initialCapital: useUniqueAmount && uniqueAmount !== null ? uniqueAmount : minCapital,
      minCapital: useUniqueAmount && uniqueAmount !== null ? uniqueAmount : minCapital,
      maxCapital: useUniqueAmount && uniqueAmount !== null ? uniqueAmount : maxCapital,
      id: generateId(),
      dateCreated: new Date().toISOString(),
      reference
    };

    setLivrets([...livrets, newLivret]);
    setFormData(initialFormData);
    setFormattedUniqueAmount('');
    toast.success(`Livret créé avec succès. Référence: ${reference}`);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative max-w-4xl mx-auto"
    >
      {/* Background effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 blur-2xl" />
      <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 blur-xl" />
      
      {/* Content */}
      <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 p-8">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-8">
          Créer un Livret
        </h2>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Livret Name */}
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                <BookOpen className="w-4 h-4 mr-2 text-blue-400" />
                Nom du Livret
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                onFocus={() => setFocusedField('name')}
                onBlur={() => setFocusedField(null)}
                className={cn(
                  "w-full bg-gray-800/50 text-white border border-gray-700/50 px-4 py-3",
                  "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                  "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                  errors.name && "border-red-500/50 focus:ring-red-500/50",
                  focusedField === 'name' && "shadow-[0_0_15px_rgba(59,130,246,0.5)]"
                )}
                placeholder="Ex: Livret Épargne Plus"
              />
              {errors.name && (
                <p className="mt-2 text-sm text-red-400">{errors.name}</p>
              )}
            </div>

            {/* Interest Rate */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                <Percent className="w-4 h-4 mr-2 text-green-400" />
                Taux d'Intérêt (%)
              </label>
              <input
                type="number"
                value={formData.interestRate || ''}
                onChange={(e) => setFormData({ ...formData, interestRate: parseFloat(e.target.value) || 0 })}
                onFocus={() => setFocusedField('interestRate')}
                onBlur={() => setFocusedField(null)}
                className={cn(
                  "w-full bg-gray-800/50 text-white border border-gray-700/50 px-4 py-3",
                  "focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50",
                  "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                  errors.interestRate && "border-red-500/50 focus:ring-red-500/50",
                  focusedField === 'interestRate' && "shadow-[0_0_15px_rgba(34,197,94,0.5)]"
                )}
                step="0.01"
                min="0"
              />
              {errors.interestRate && (
                <p className="mt-2 text-sm text-red-400">{errors.interestRate}</p>
              )}
            </div>

            {/* Duration Section */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                <Clock className="w-4 h-4 mr-2 text-cyan-400" />
                Durée
              </label>
              
              {/* Duration Type Selection */}
              <div className="grid grid-cols-2 gap-4 mb-4">
                <button
                  type="button"
                  onClick={() => handleToggleCustomDuration(false)}
                  className={cn(
                    "p-2 rounded-lg border transition-colors text-center text-sm",
                    !formData.useCustomDuration
                      ? "bg-blue-600/20 border-blue-500/50 text-blue-400"
                      : "bg-gray-800/50 border-gray-700/50 text-gray-400 hover:bg-gray-700/50"
                  )}
                >
                  Sélection standard
                </button>
                <button
                  type="button"
                  onClick={() => handleToggleCustomDuration(true)}
                  className={cn(
                    "p-2 rounded-lg border transition-colors text-center text-sm",
                    formData.useCustomDuration
                      ? "bg-cyan-600/20 border-cyan-500/50 text-cyan-400"
                      : "bg-gray-800/50 border-gray-700/50 text-gray-400 hover:bg-gray-700/50"
                  )}
                >
                  Intervalle de temps
                </button>
              </div>
              
              {formData.useCustomDuration ? (
                /* Custom Duration Input */
                <div>
                  <input
                    type="text"
                    value={formData.customDuration}
                    onChange={(e) => setFormData({ ...formData, customDuration: e.target.value })}
                    onFocus={() => setFocusedField('customDuration')}
                    onBlur={() => setFocusedField(null)}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                      errors.customDuration && "border-red-500/50 focus:ring-red-500/50",
                      focusedField === 'customDuration' && "shadow-[0_0_15px_rgba(34,211,238,0.5)]"
                    )}
                    placeholder="Ex: 12 mois, 2 ans, 18 mois"
                  />
                  {errors.customDuration && (
                    <p className="mt-2 text-sm text-red-400">{errors.customDuration}</p>
                  )}
                  <p className="mt-1 text-xs text-gray-400">
                    Formats acceptés: "12 mois", "2 ans", "24" (mois par défaut)
                  </p>
                </div>
              ) : (
                /* Standard Duration Inputs */
                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="number"
                    value={formData.duration.value || ''}
                    onChange={(e) => setFormData({
                      ...formData,
                      duration: {
                        ...formData.duration,
                        value: parseInt(e.target.value) || 0
                      }
                    })}
                    onFocus={() => setFocusedField('durationValue')}
                    onBlur={() => setFocusedField(null)}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                      errors.duration && "border-red-500/50 focus:ring-red-500/50",
                      focusedField === 'durationValue' && "shadow-[0_0_15px_rgba(34,211,238,0.5)]"
                    )}
                    min="1"
                  />
                  <select
                    value={formData.duration.unit}
                    onChange={(e) => setFormData({
                      ...formData,
                      duration: {
                        ...formData.duration,
                        unit: e.target.value as 'months' | 'years'
                      }
                    })}
                    onFocus={() => setFocusedField('durationUnit')}
                    onBlur={() => setFocusedField(null)}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                      focusedField === 'durationUnit' && "shadow-[0_0_15px_rgba(34,211,238,0.5)]"
                    )}
                  >
                    <option value="months">Mois</option>
                    <option value="years">Années</option>
                  </select>
                </div>
              )}
              {errors.duration && !formData.useCustomDuration && (
                <p className="mt-2 text-sm text-red-400">{errors.duration}</p>
              )}
            </div>

            {/* Investment Type Selection */}
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                <Euro className="w-4 h-4 mr-2 text-purple-400" />
                Type d'investissement
              </label>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <button
                  type="button"
                  onClick={() => handleToggleUniqueAmount(false)}
                  className={cn(
                    "p-4 rounded-lg border transition-colors text-center",
                    !formData.useUniqueAmount
                      ? "bg-blue-600/20 border-blue-500/50 text-blue-400"
                      : "bg-gray-800/50 border-gray-700/50 text-gray-400 hover:bg-gray-700/50"
                  )}
                >
                  Plage de montants (min/max)
                </button>
                <button
                  type="button"
                  onClick={() => handleToggleUniqueAmount(true)}
                  className={cn(
                    "p-4 rounded-lg border transition-colors text-center",
                    formData.useUniqueAmount
                      ? "bg-purple-600/20 border-purple-500/50 text-purple-400"
                      : "bg-gray-800/50 border-gray-700/50 text-gray-400 hover:bg-gray-700/50"
                  )}
                >
                  Somme unique
                </button>
              </div>

              {formData.useUniqueAmount ? (
                /* Unique Amount */
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                    <Euro className="w-4 h-4 mr-2 text-purple-400" />
                    Somme unique (€)
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={formattedUniqueAmount}
                      onChange={(e) => handleUniqueAmountChange(e.target.value)}
                      onFocus={() => setFocusedField('uniqueAmount')}
                      onBlur={() => setFocusedField(null)}
                      className={cn(
                        "w-full bg-gray-800/50 text-white border border-gray-700/50 px-4 py-3",
                        "focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50",
                        "placeholder-gray-500 backdrop-blur-sm transition-all duration-200 [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none",
                        errors.uniqueAmount && "border-red-500/50 focus:ring-red-500/50",
                        focusedField === 'uniqueAmount' && "shadow-[0_0_15px_rgba(147,51,234,0.5)]"
                      )}
                      placeholder="Ex: 7000"
                    />
                  </div>
                  {errors.uniqueAmount && (
                    <p className="mt-2 text-sm text-red-400">{errors.uniqueAmount}</p>
                  )}
                  <p className="mt-1 text-sm text-gray-400 flex items-center">
                    <AlertCircle className="w-4 h-4 mr-1 text-blue-400" />
                    Le client pourra investir uniquement ce montant exact
                  </p>
                </div>
              ) : (
                /* Min/Max Capital Range */
                <div className="grid grid-cols-2 gap-4">
                  {/* Min Capital */}
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                      <Euro className="w-4 h-4 mr-2 text-blue-400" />
                      Capital Minimum (€)
                    </label>
                    <input
                      type="number"
                      value={formData.minCapital || ''}
                      onChange={(e) => setFormData({ ...formData, minCapital: parseFloat(e.target.value) || 0 })}
                      onFocus={() => setFocusedField('minCapital')}
                      onBlur={() => setFocusedField(null)}
                      className={cn(
                        "w-full bg-gray-800/50 text-white border border-gray-700/50 px-4 py-3",
                        "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                        "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                        errors.minCapital && "border-red-500/50 focus:ring-red-500/50",
                        focusedField === 'minCapital' && "shadow-[0_0_15px_rgba(59,130,246,0.5)]"
                      )}
                      min="0"
                      step="100"
                    />
                    {errors.minCapital && (
                      <p className="mt-2 text-sm text-red-400">{errors.minCapital}</p>
                    )}
                  </div>

                  {/* Max Capital */}
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                      <Euro className="w-4 h-4 mr-2 text-pink-400" />
                      Capital Maximum (€)
                    </label>
                    <input
                      type="number"
                      value={formData.maxCapital || ''}
                      onChange={(e) => setFormData({ ...formData, maxCapital: parseFloat(e.target.value) || 0 })}
                      onFocus={() => setFocusedField('maxCapital')}
                      onBlur={() => setFocusedField(null)}
                      className={cn(
                        "w-full bg-gray-800/50 text-white border border-gray-700/50 px-4 py-3",
                        "focus:outline-none focus:ring-2 focus:ring-pink-500/50 focus:border-pink-500/50",
                        "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                        errors.maxCapital && "border-red-500/50 focus:ring-red-500/50",
                        focusedField === 'maxCapital' && "shadow-[0_0_15px_rgba(236,72,153,0.5)]"
                      )}
                      min="0"
                      step="100"
                    />
                    {errors.maxCapital && (
                      <p className="mt-2 text-sm text-red-400">{errors.maxCapital}</p>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Description */}
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                <Info className="w-4 h-4 mr-2 text-pink-400" />
                Description
              </label>
              <textarea
                value={formData.description || ''}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                onFocus={() => setFocusedField('description')}
                onBlur={() => setFocusedField(null)}
                className={cn(
                  "w-full bg-gray-800/50 text-white border border-gray-700/50 px-4 py-3",
                  "focus:outline-none focus:ring-2 focus:ring-pink-500/50 focus:border-pink-500/50",
                  "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                  focusedField === 'description' && "shadow-[0_0_15px_rgba(236,72,153,0.5)]"
                )}
                rows={4}
                placeholder="Description du livret..."
              />
            </div>

            {/* Status */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Statut
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as 'Active' | 'Inactive' })}
                onFocus={() => setFocusedField('status')}
                onBlur={() => setFocusedField(null)}
                className={cn(
                  "w-full bg-gray-800/50 text-white border border-gray-700/50 px-4 py-3",
                  "focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500/50",
                  "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                  focusedField === 'status' && "shadow-[0_0_15px_rgba(245,158,11,0.5)]"
                )}
              >
                <option value="Active">Actif</option>
                <option value="Inactive">Inactif</option>
              </select>
            </div>

            {/* Benefit Calculator */}
            <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 p-4 border border-blue-500/20">
              <div className="flex items-center mb-2">
                <Calculator className="w-5 h-5 text-blue-400 mr-2" />
                <h3 className="text-lg font-medium text-white">Calculateur de Bénéfice</h3>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-400">Capital</p>
                  <p className="text-lg font-bold text-white">
                    {formData.useUniqueAmount && formData.uniqueAmount !== null
                      ? formData.uniqueAmount.toLocaleString()
                      : formData.minCapital.toLocaleString()}€
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Taux d'Intérêt</p>
                  <p className="text-lg font-bold text-green-400">{formData.interestRate}%</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Durée</p>
                  <p className="text-lg font-bold text-cyan-400">
                    {formData.duration.value} {formData.duration.unit === 'months' ? 'mois' : 'ans'}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Bénéfice Mensuel</p>
                  <p className="text-lg font-bold text-blue-400">+{calculatedBenefit.monthly.toLocaleString()}€</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Bénéfice Total</p>
                  <p className="text-lg font-bold text-blue-400">+{calculatedBenefit.total.toLocaleString()}€</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Montant Total à Terme</p>
                  <p className="text-lg font-bold text-white">
                    {(
                      (formData.useUniqueAmount && formData.uniqueAmount !== null
                        ? formData.uniqueAmount
                        : formData.minCapital) + calculatedBenefit.total
                    ).toLocaleString()}€
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex justify-end">
            <motion.button
              type="submit"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="relative group px-8 py-3 overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
              <span className="relative text-white font-medium">
                Créer le Livret
              </span>
            </motion.button>
          </div>
        </form>
      </div>
    </motion.div>
  );
}