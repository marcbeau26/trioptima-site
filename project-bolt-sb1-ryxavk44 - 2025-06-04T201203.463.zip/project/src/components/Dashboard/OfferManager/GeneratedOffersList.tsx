import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Trash2, UserCheck, Hash, Power, Play, Pause, Filter } from 'lucide-react';
import type { EnergyOffer, Lead } from '../../../types';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { formatDate } from '../../../utils';
import { FuturisticTimer } from '../../common/FuturisticTimer';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';

interface AssignLeadsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAssign: (leadId: string) => void;
}

function AssignLeadsModal({ isOpen, onClose, onAssign }: AssignLeadsModalProps) {
  const [leads] = useLocalStorage<Lead[]>('leads', []);
  const [selectedLead, setSelectedLead] = useState('');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-8 max-w-md w-full">
        <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">Attribuer les offres</h2>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Sélectionner un lead
            </label>
            <select
              value={selectedLead}
              onChange={(e) => setSelectedLead(e.target.value)}
              className="w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
            >
              <option value="">Choisir un lead...</option>
              {leads.map(lead => (
                <option key={lead.id} value={lead.id}>
                  {lead.firstName} {lead.lastName} ({lead.email})
                </option>
              ))}
            </select>
          </div>
          <div className="flex space-x-4">
            <button
              onClick={() => {
                if (selectedLead) {
                  onAssign(selectedLead);
                  onClose();
                }
              }}
              disabled={!selectedLead}
              className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors disabled:bg-gray-400"
            >
              Attribuer
            </button>
            <button
              onClick={onClose}
              className="flex-1 bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200 py-2 px-4 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
            >
              Annuler
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function GeneratedOffersList() {
  const [energyOffers, setEnergyOffers] = useLocalStorage<EnergyOffer[]>('energyOffers', []);
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [selectedOffers, setSelectedOffers] = useState<string[]>([]);
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [durationFilter, setDurationFilter] = useState<'all' | 'minutes' | 'hours' | 'days'>('all');
  const [forceUpdate, setForceUpdate] = useState(0); // Force component update for timer

  // Check for expired offers every second and force update for timer
  useEffect(() => {
    const checkExpiry = () => {
      const now = new Date().getTime();
      const updatedOffers = energyOffers.map(offer => ({
        ...offer,
        status: new Date(offer.expiryDate).getTime() <= now && offer.status === 'Active' ? 'Expired' as const : offer.status
      }));

      if (JSON.stringify(updatedOffers) !== JSON.stringify(energyOffers)) {
        setEnergyOffers(updatedOffers);
      }
      
      // Force update every second to ensure timer updates
      setForceUpdate(prev => prev + 1);
    };

    const interval = setInterval(checkExpiry, 1000);
    return () => clearInterval(interval);
  }, [energyOffers, setEnergyOffers]);

  const handleExpire = (offerId: string) => {
    setEnergyOffers(energyOffers.map(offer =>
      offer.id === offerId ? { ...offer, status: 'Expired' } : offer
    ));
  };

  const toggleSelectAll = () => {
    if (selectedOffers.length === filteredOffers.length) {
      setSelectedOffers([]);
    } else {
      setSelectedOffers(filteredOffers.map(offer => offer.id));
    }
  };

  const toggleOffer = (offerId: string) => {
    if (selectedOffers.includes(offerId)) {
      setSelectedOffers(selectedOffers.filter(id => id !== offerId));
    } else {
      setSelectedOffers([...selectedOffers, offerId]);
    }
  };

  const handleDelete = () => {
    setEnergyOffers(energyOffers.filter(offer => !selectedOffers.includes(offer.id)));
    setSelectedOffers([]);
    toast.success(`${selectedOffers.length} offre(s) supprimée(s)`);
  };

  const handleAssignToLead = (leadId: string) => {
    const selectedOffersList = energyOffers.filter(offer => selectedOffers.includes(offer.id));
    
    setLeads(leads.map(lead => {
      if (lead.id === leadId) {
        return {
          ...lead,
          assignedOffers: [
            ...(lead.assignedOffers || []),
            ...selectedOffersList
          ]
        };
      }
      return lead;
    }));

    setSelectedOffers([]);
    setIsAssignModalOpen(false);
    toast.success('Offres attribuées avec succès');
  };

  // Toggle offer status (Active/Expired)
  const toggleOfferStatus = (offerId: string) => {
    const offerToToggle = energyOffers.find(offer => offer.id === offerId);
    if (!offerToToggle) return;

    // If the offer is expired, reactivate it with a new expiry date
    if (offerToToggle.status === 'Expired') {
      // Calculate new expiry date (24 hours from now)
      const now = new Date();
      const expiryDate = new Date(now);
      expiryDate.setHours(expiryDate.getHours() + 24);

      // Update the offer
      const updatedOffers = energyOffers.map(offer => 
        offer.id === offerId 
          ? { ...offer, status: 'Active', expiryDate: expiryDate.toISOString() } 
          : offer
      );
      
      setEnergyOffers(updatedOffers);
      toast.success('Offre réactivée avec succès pour 24 heures');
    } 
    // If the offer is active, deactivate it
    else if (offerToToggle.status === 'Active') {
      const updatedOffers = energyOffers.map(offer => 
        offer.id === offerId 
          ? { ...offer, status: 'Expired' } 
          : offer
      );
      
      setEnergyOffers(updatedOffers);
      toast.success('Offre désactivée avec succès');
    }
  };

  // Filter offers that were generated automatically (from the offer generator)
  // We'll consider an offer as "generated" if it has validityMinutes, validityHours, or validityDays > 0
  // AND if it has a reference that starts with "GEN" (not "SCH" which is for scheduled offers)
  const generatedOffers = energyOffers.filter(offer => 
    (offer.validityMinutes > 0 || offer.validityHours > 0 || offer.validityDays > 0)
  );

  // Apply search and duration filters
  const filteredOffers = generatedOffers.filter(offer => {
    // Apply search filter
    const matchesSearch = offer.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (offer.reference && offer.reference.toLowerCase().includes(searchTerm.toLowerCase()));
    
    // Apply duration filter
    let matchesDuration = true;
    if (durationFilter !== 'all') {
      if (durationFilter === 'minutes' && offer.validityMinutes > 0) {
        matchesDuration = true;
      } else if (durationFilter === 'hours' && offer.validityHours > 0) {
        matchesDuration = true;
      } else if (durationFilter === 'days' && offer.validityDays > 0) {
        matchesDuration = true;
      } else {
        matchesDuration = false;
      }
    }
    
    return matchesSearch && matchesDuration;
  });

  // Group offers by duration type
  const minutesOffers = filteredOffers.filter(offer => offer.validityMinutes > 0);
  const hoursOffers = filteredOffers.filter(offer => offer.validityHours > 0);
  const daysOffers = filteredOffers.filter(offer => offer.validityDays > 0);

  // Determine which groups to display based on filter
  const displayMinutes = durationFilter === 'all' || durationFilter === 'minutes';
  const displayHours = durationFilter === 'all' || durationFilter === 'hours';
  const displayDays = durationFilter === 'all' || durationFilter === 'days';

  return (
    <div className="space-y-6">
      {/* Search Bar */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="relative w-full md:w-64">
          <input
            type="text"
            placeholder="Rechercher une offre..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
        </div>
        
        {/* Duration Filter */}
        <div className="relative w-full md:w-auto">
          <select
            value={durationFilter}
            onChange={(e) => setDurationFilter(e.target.value as 'all' | 'minutes' | 'hours' | 'days')}
            className="bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-9 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/50 appearance-none w-full md:w-auto"
          >
            <option value="all">Toutes les durées</option>
            <option value="minutes">Minutes</option>
            <option value="hours">Heures</option>
            <option value="days">Jours</option>
          </select>
          <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
        </div>
      </div>

      {/* Selected Offers Actions */}
      {selectedOffers.length > 0 && (
        <div className="flex space-x-4">
          <button
            onClick={handleDelete}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 dark:focus:ring-offset-gray-800"
          >
            <Trash2 size={16} className="mr-2" />
            Supprimer ({selectedOffers.length})
          </button>
          <button
            onClick={() => setIsAssignModalOpen(true)}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-800"
          >
            <UserCheck size={16} className="mr-2" />
            Attribuer à un lead ({selectedOffers.length})
          </button>
        </div>
      )}

      {/* Minutes Offers */}
      {displayMinutes && minutesOffers.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-white flex items-center">
            <Power className="w-5 h-5 mr-2 text-blue-400" />
            Offres générées en minutes ({minutesOffers.length})
          </h3>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-700">
              <thead className="bg-gray-800">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left">
                    <input
                      type="checkbox"
                      checked={selectedOffers.length === minutesOffers.length && minutesOffers.length > 0}
                      onChange={() => {
                        if (selectedOffers.length === minutesOffers.length) {
                          setSelectedOffers(selectedOffers.filter(id => !minutesOffers.some(offer => offer.id === id)));
                        } else {
                          setSelectedOffers([...selectedOffers, ...minutesOffers.map(offer => offer.id).filter(id => !selectedOffers.includes(id))]);
                        }
                      }}
                      className="rounded border-gray-600 text-blue-500 focus:ring-blue-500 bg-gray-700"
                    />
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Référence
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Entreprise
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Mégawatts
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Prix
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Durée
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Temps restant
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Statut
                  </th>
                </tr>
              </thead>
              <tbody className="bg-gray-900 divide-y divide-gray-800">
                {minutesOffers.map((offer) => (
                  <tr key={offer.id} className="hover:bg-gray-800/50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <input
                        type="checkbox"
                        checked={selectedOffers.includes(offer.id)}
                        onChange={() => toggleOffer(offer.id)}
                        className="rounded border-gray-600 text-blue-500 focus:ring-blue-500 bg-gray-700"
                      />
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Hash className="h-4 w-4 text-blue-400 mr-1" />
                        <span className="text-sm font-medium text-white">
                          {offer.reference || 'N/A'}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-white">
                        {offer.companyName}
                      </div>
                      <div className="text-sm text-gray-400">
                        {formatDate(offer.dateCreated)}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-white">
                        {offer.megawatts} MW
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-white">
                        {offer.totalPrice.toLocaleString()}€
                      </div>
                      <div className="text-sm text-gray-400">
                        {offer.pricePerMegawatt.toLocaleString()}€/MW
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-white">
                        {offer.validityMinutes} minutes
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {offer.status === 'Active' ? (
                        <FuturisticTimer
                          key={`timer-${offer.id}-${forceUpdate}`} // Force re-render of timer
                          expiryDate={offer.expiryDate}
                          onExpire={() => handleExpire(offer.id)}
                        />
                      ) : (
                        <span className="text-red-400">
                          Expirée
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          offer.status === 'Active'
                            ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100'
                            : 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100'
                        }`}>
                          {offer.status === 'Active' ? 'Active' : 'Expirée'}
                        </span>
                        
                        {/* Toggle button */}
                        <motion.button
                          onClick={() => toggleOfferStatus(offer.id)}
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          className={cn(
                            "p-1 rounded-md transition-colors",
                            offer.status === 'Active' 
                              ? "bg-red-500/20 text-red-400 hover:bg-red-500/30" 
                              : "bg-green-500/20 text-green-400 hover:bg-green-500/30"
                          )}
                          title={offer.status === 'Active' ? 'Désactiver' : 'Activer'}
                        >
                          {offer.status === 'Active' ? (
                            <Pause className="w-4 h-4" />
                          ) : (
                            <Play className="w-4 h-4" />
                          )}
                        </motion.button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Hours Offers */}
      {displayHours && hoursOffers.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-white flex items-center">
            <Power className="w-5 h-5 mr-2 text-purple-400" />
            Offres générées en heures ({hoursOffers.length})
          </h3>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-700">
              <thead className="bg-gray-800">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left">
                    <input
                      type="checkbox"
                      checked={selectedOffers.length === hoursOffers.length && hoursOffers.length > 0}
                      onChange={() => {
                        if (selectedOffers.length === hoursOffers.length) {
                          setSelectedOffers(selectedOffers.filter(id => !hoursOffers.some(offer => offer.id === id)));
                        } else {
                          setSelectedOffers([...selectedOffers, ...hoursOffers.map(offer => offer.id).filter(id => !selectedOffers.includes(id))]);
                        }
                      }}
                      className="rounded border-gray-600 text-blue-500 focus:ring-blue-500 bg-gray-700"
                    />
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Référence
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Entreprise
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Mégawatts
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Prix
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Durée
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Temps restant
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Statut
                  </th>
                </tr>
              </thead>
              <tbody className="bg-gray-900 divide-y divide-gray-800">
                {hoursOffers.map((offer) => (
                  <tr key={offer.id} className="hover:bg-gray-800/50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <input
                        type="checkbox"
                        checked={selectedOffers.includes(offer.id)}
                        onChange={() => toggleOffer(offer.id)}
                        className="rounded border-gray-600 text-blue-500 focus:ring-blue-500 bg-gray-700"
                      />
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Hash className="h-4 w-4 text-blue-400 mr-1" />
                        <span className="text-sm font-medium text-white">
                          {offer.reference || 'N/A'}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-white">
                        {offer.companyName}
                      </div>
                      <div className="text-sm text-gray-400">
                        {formatDate(offer.dateCreated)}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-white">
                        {offer.megawatts} MW
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-white">
                        {offer.totalPrice.toLocaleString()}€
                      </div>
                      <div className="text-sm text-gray-400">
                        {offer.pricePerMegawatt.toLocaleString()}€/MW
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-white">
                        {offer.validityHours} heures
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {offer.status === 'Active' ? (
                        <FuturisticTimer
                          key={`timer-${offer.id}-${forceUpdate}`} // Force re-render of timer
                          expiryDate={offer.expiryDate}
                          onExpire={() => handleExpire(offer.id)}
                        />
                      ) : (
                        <span className="text-red-400">
                          Expirée
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          offer.status === 'Active'
                            ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100'
                            : 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100'
                        }`}>
                          {offer.status === 'Active' ? 'Active' : 'Expirée'}
                        </span>
                        
                        {/* Toggle button */}
                        <motion.button
                          onClick={() => toggleOfferStatus(offer.id)}
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          className={cn(
                            "p-1 rounded-md transition-colors",
                            offer.status === 'Active' 
                              ? "bg-red-500/20 text-red-400 hover:bg-red-500/30" 
                              : "bg-green-500/20 text-green-400 hover:bg-green-500/30"
                          )}
                          title={offer.status === 'Active' ? 'Désactiver' : 'Activer'}
                        >
                          {offer.status === 'Active' ? (
                            <Pause className="w-4 h-4" />
                          ) : (
                            <Play className="w-4 h-4" />
                          )}
                        </motion.button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Days Offers */}
      {displayDays && daysOffers.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-white flex items-center">
            <Power className="w-5 h-5 mr-2 text-cyan-400" />
            Offres générées en jours ({daysOffers.length})
          </h3>
          
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-700">
              <thead className="bg-gray-800">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left">
                    <input
                      type="checkbox"
                      checked={selectedOffers.length === daysOffers.length && daysOffers.length > 0}
                      onChange={() => {
                        if (selectedOffers.length === daysOffers.length) {
                          setSelectedOffers(selectedOffers.filter(id => !daysOffers.some(offer => offer.id === id)));
                        } else {
                          setSelectedOffers([...selectedOffers, ...daysOffers.map(offer => offer.id).filter(id => !selectedOffers.includes(id))]);
                        }
                      }}
                      className="rounded border-gray-600 text-blue-500 focus:ring-blue-500 bg-gray-700"
                    />
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Référence
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Entreprise
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Mégawatts
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Prix
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Durée
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Temps restant
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Statut
                  </th>
                </tr>
              </thead>
              <tbody className="bg-gray-900 divide-y divide-gray-800">
                {daysOffers.map((offer) => (
                  <tr key={offer.id} className="hover:bg-gray-800/50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <input
                        type="checkbox"
                        checked={selectedOffers.includes(offer.id)}
                        onChange={() => toggleOffer(offer.id)}
                        className="rounded border-gray-600 text-blue-500 focus:ring-blue-500 bg-gray-700"
                      />
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Hash className="h-4 w-4 text-blue-400 mr-1" />
                        <span className="text-sm font-medium text-white">
                          {offer.reference || 'N/A'}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-white">
                        {offer.companyName}
                      </div>
                      <div className="text-sm text-gray-400">
                        {formatDate(offer.dateCreated)}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-white">
                        {offer.megawatts} MW
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-white">
                        {offer.totalPrice.toLocaleString()}€
                      </div>
                      <div className="text-sm text-gray-400">
                        {offer.pricePerMegawatt.toLocaleString()}€/MW
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-white">
                        {offer.validityDays} jours
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {offer.status === 'Active' ? (
                        <FuturisticTimer
                          key={`timer-${offer.id}-${forceUpdate}`} // Force re-render of timer
                          expiryDate={offer.expiryDate}
                          onExpire={() => handleExpire(offer.id)}
                        />
                      ) : (
                        <span className="text-red-400">
                          Expirée
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          offer.status === 'Active'
                            ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100'
                            : 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100'
                        }`}>
                          {offer.status === 'Active' ? 'Active' : 'Expirée'}
                        </span>
                        
                        {/* Toggle button */}
                        <motion.button
                          onClick={() => toggleOfferStatus(offer.id)}
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          className={cn(
                            "p-1 rounded-md transition-colors",
                            offer.status === 'Active' 
                              ? "bg-red-500/20 text-red-400 hover:bg-red-500/30" 
                              : "bg-green-500/20 text-green-400 hover:bg-green-500/30"
                          )}
                          title={offer.status === 'Active' ? 'Désactiver' : 'Activer'}
                        >
                          {offer.status === 'Active' ? (
                            <Pause className="w-4 h-4" />
                          ) : (
                            <Play className="w-4 h-4" />
                          )}
                        </motion.button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* No offers message */}
      {filteredOffers.length === 0 && (
        <div className="text-center py-12 bg-gray-800/30 rounded-lg border border-gray-700/50">
          <Power className="w-12 h-12 text-gray-600 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-300 mb-2">
            Aucune offre générée trouvée
          </h3>
          <p className="text-gray-500 max-w-md mx-auto">
            {searchTerm || durationFilter !== 'all' 
              ? "Aucune offre ne correspond à vos critères de recherche. Essayez de modifier vos filtres."
              : "Utilisez le Générateur d'Offres pour créer des offres en quantité."}
          </p>
        </div>
      )}

      <AnimatePresence>
        {isAssignModalOpen && (
          <AssignLeadsModal
            isOpen={isAssignModalOpen}
            onClose={() => setIsAssignModalOpen(false)}
            onAssign={handleAssignToLead}
          />
        )}
      </AnimatePresence>
    </div>
  );
}