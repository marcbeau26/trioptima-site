import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FileText, Upload, X, Check, AlertTriangle, 
  Eye, RefreshCw, Trash2, Download, File, 
  FileImage, FileArchive, FilePlus, Clock, 
  CheckCircle, XCircle, MessageSquare
} from 'lucide-react';
import { toast } from 'react-hot-toast';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import type { Lead, Document } from '../../../types';
import { generateId } from '../../../utils';
import { cn } from '../../../utils/cn';

// Document type icons mapping
const documentTypeIcons: Record<string, React.ReactNode> = {
  'application/pdf': <FileText className="w-6 h-6 text-red-400" />,
  'image/jpeg': <FileImage className="w-6 h-6 text-blue-400" />,
  'image/png': <FileImage className="w-6 h-6 text-green-400" />,
  'application/zip': <FileArchive className="w-6 h-6 text-yellow-400" />,
  'application/x-zip-compressed': <FileArchive className="w-6 h-6 text-yellow-400" />,
  'default': <File className="w-6 h-6 text-gray-400" />
};

// Document viewer component
interface DocumentViewerProps {
  document: Document;
  isOpen: boolean;
  onClose: () => void;
}

function DocumentViewer({ document, isOpen, onClose }: DocumentViewerProps) {
  if (!isOpen) return null;

  const isImage = document.type.startsWith('image/');
  const isPdf = document.type === 'application/pdf';

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-4xl mx-4 max-h-[90vh] flex flex-col"
      >
        {/* Header */}
        <div className="bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-t-xl p-4 flex justify-between items-center">
          <h3 className="text-xl font-bold text-white flex items-center">
            {getDocumentTypeIcon(document.type)}
            <span className="ml-2">{document.name}</span>
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Document content */}
        <div className="bg-gray-900/90 backdrop-blur-xl border-x border-white/10 flex-1 overflow-auto">
          {isImage && (
            <div className="flex items-center justify-center h-full p-4">
              <img 
                src={document.url} 
                alt={document.name} 
                className="max-w-full max-h-[70vh] object-contain"
              />
            </div>
          )}
          {isPdf && (
            <div className="h-[70vh]">
              <iframe 
                src={document.url} 
                title={document.name}
                className="w-full h-full"
              />
            </div>
          )}
          {!isImage && !isPdf && (
            <div className="flex flex-col items-center justify-center h-[50vh] p-8 text-center">
              <File className="w-16 h-16 text-gray-400 mb-4" />
              <h4 className="text-xl font-medium text-white mb-2">
                Aperçu non disponible
              </h4>
              <p className="text-gray-400 mb-6">
                Ce type de document ne peut pas être prévisualisé directement.
              </p>
              <a 
                href={document.url} 
                download={document.name}
                className="flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
              >
                <Download className="w-5 h-5 mr-2" />
                Télécharger le document
              </a>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-b-xl p-4 flex justify-between items-center">
          <div className="flex items-center">
            <span className="text-sm text-gray-400 mr-4">
              Taille: {formatFileSize(document.size)}
            </span>
          </div>
          <a 
            href={document.url} 
            download={document.name}
            className="flex items-center px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-lg transition-colors text-sm"
          >
            <Download className="w-4 h-4 mr-2" />
            Télécharger
          </a>
        </div>
      </motion.div>
    </div>
  );
}

// Document upload modal component
interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpload: (file: File, name: string) => void;
  isReplace?: boolean;
  documentToReplace?: Document;
}

function UploadModal({ isOpen, onClose, onUpload, isReplace = false, documentToReplace }: UploadModalProps) {
  const [file, setFile] = useState<File | null>(null);
  const [documentName, setDocumentName] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Initialize document name if replacing
  useEffect(() => {
    if (isReplace && documentToReplace) {
      setDocumentName(documentToReplace.name);
    } else {
      setDocumentName('');
    }
  }, [isReplace, documentToReplace]);

  if (!isOpen) return null;

  const handleFileChange = (selectedFile: File) => {
    setFile(selectedFile);
    if (!documentName) {
      // Use file name without extension as default document name
      const fileName = selectedFile.name.split('.').slice(0, -1).join('.');
      setDocumentName(fileName);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileChange(e.dataTransfer.files[0]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!file) {
      toast.error('Veuillez sélectionner un fichier');
      return;
    }
    
    if (!documentName.trim()) {
      toast.error('Veuillez nommer votre document');
      return;
    }
    
    onUpload(file, documentName);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-lg mx-4"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <div className="flex justify-between items-start mb-6">
            <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              {isReplace ? 'Remplacer le document' : 'Importer un document'}
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* File drop zone */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={(e) => {
                e.preventDefault();
                setIsDragging(false);
              }}
              onDrop={handleDrop}
              className={cn(
                "border-2 border-dashed rounded-xl p-8 transition-all duration-200 text-center",
                isDragging
                  ? "border-blue-500 bg-blue-500/10"
                  : "border-gray-700 hover:border-blue-500/50 hover:bg-gray-800/50"
              )}
            >
              <input
                ref={fileInputRef}
                type="file"
                onChange={(e) => {
                  if (e.target.files && e.target.files.length > 0) {
                    handleFileChange(e.target.files[0]);
                  }
                }}
                className="hidden"
              />
              
              {file ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-center">
                    {getDocumentTypeIcon(file.type)}
                  </div>
                  <div>
                    <p className="text-white font-medium">{file.name}</p>
                    <p className="text-sm text-gray-400">{formatFileSize(file.size)}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setFile(null);
                      if (fileInputRef.current) {
                        fileInputRef.current.value = '';
                      }
                    }}
                    className="text-red-400 hover:text-red-300 transition-colors text-sm"
                  >
                    Supprimer
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-center">
                    <Upload className="w-12 h-12 text-gray-500" />
                  </div>
                  <div>
                    <p className="text-lg font-medium text-white">
                      {isReplace ? 'Sélectionnez un nouveau fichier' : 'Déposez votre fichier ici'}
                    </p>
                    <p className="text-sm text-gray-400 mt-1">
                      ou cliquez pour parcourir vos fichiers
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-lg transition-colors text-sm"
                  >
                    Parcourir
                  </button>
                  <p className="text-xs text-gray-500">
                    Formats acceptés: PDF, JPG, PNG, ZIP (max 10MB)
                  </p>
                </div>
              )}
            </div>

            {/* Document name input */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Nom du document
              </label>
              <input
                type="text"
                value={documentName}
                onChange={(e) => setDocumentName(e.target.value)}
                className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                placeholder="Ex: Carte d'identité, Justificatif de domicile..."
                required
              />
            </div>

            {/* Action buttons */}
            <div className="flex justify-end space-x-4">
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-3 text-sm font-medium text-gray-300 bg-gray-800/50 hover:bg-gray-700/50 rounded-lg transition-colors"
              >
                Annuler
              </button>
              <motion.button
                type="submit"
                disabled={!file || !documentName.trim()}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="relative group px-6 py-3 rounded-lg overflow-hidden disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
                <span className="relative text-white font-medium">
                  {isReplace ? 'Remplacer' : 'Importer'}
                </span>
              </motion.button>
            </div>
          </form>
        </div>
      </motion.div>
    </div>
  );
}

// Document details modal component
interface DocumentDetailsProps {
  document: Document;
  isOpen: boolean;
  onClose: () => void;
}

function DocumentDetails({ document, isOpen, onClose }: DocumentDetailsProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-lg mx-4"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <div className="flex justify-between items-start mb-6">
            <div className="flex items-center">
              {getDocumentTypeIcon(document.type)}
              <h2 className="text-2xl font-bold text-white ml-3">
                {document.name}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="space-y-6">
            {/* Document info */}
            <div className="bg-gray-800/50 border border-white/5 rounded-xl p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-400">Date d'importation</p>
                  <div className="flex items-center mt-1">
                    <Clock className="w-4 h-4 text-gray-500 mr-2" />
                    <p className="text-white">
                      {new Date(document.dateUploaded).toLocaleDateString()} {new Date(document.dateUploaded).toLocaleTimeString()}
                    </p>
                  </div>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Taille</p>
                  <p className="text-white mt-1">{formatFileSize(document.size)}</p>
                </div>
              </div>
            </div>

            {/* Comments display for client */}
            {document.comments && (
              <div className="bg-gray-800/50 border border-white/5 rounded-xl p-6">
                <div className="flex items-center mb-2">
                  <MessageSquare className="w-5 h-5 text-blue-400 mr-2" />
                  <h3 className="text-lg font-medium text-white">Commentaires</h3>
                </div>
                <p className="text-gray-300">{document.comments}</p>
              </div>
            )}

            {/* Action buttons */}
            <div className="flex justify-between">
              <a 
                href={document.url} 
                download={document.name}
                className="flex items-center px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-lg transition-colors"
              >
                <Download className="w-5 h-5 mr-2" />
                Télécharger
              </a>
              
              <button
                onClick={onClose}
                className="px-6 py-2 text-sm font-medium text-gray-300 bg-gray-800/50 hover:bg-gray-700/50 rounded-lg transition-colors"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

// Helper function to get document type icon
function getDocumentTypeIcon(type: string) {
  return documentTypeIcons[type] || documentTypeIcons.default;
}

// Helper function to format file size
function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Main Documents component
export function Documents() {
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [currentLead, setCurrentLead] = useState<Lead | null>(null);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showViewerModal, setShowViewerModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [documentToReplace, setDocumentToReplace] = useState<Document | null>(null);
  const [isReplacing, setIsReplacing] = useState(false);

  // Load current lead and documents
  useEffect(() => {
    const leadData = localStorage.getItem('currentLead');
    if (leadData) {
      const lead = JSON.parse(leadData) as Lead;
      setCurrentLead(lead);
      setDocuments(lead.documents || []);
    }
  }, []);

  // Handle document upload
  const handleUpload = (file: File, name: string) => {
    if (!currentLead) return;

    // Create object URL for the file
    const url = URL.createObjectURL(file);

    // Create new document - set status to 'approved' directly
    const newDocument: Document = {
      id: generateId(),
      name,
      type: file.type,
      url,
      dateUploaded: new Date().toISOString(),
      status: 'approved', // Automatically approved
      size: file.size
    };

    // Update documents state
    const updatedDocuments = [...documents, newDocument];
    setDocuments(updatedDocuments);

    // Update lead in localStorage and state
    const updatedLead = {
      ...currentLead,
      documents: updatedDocuments
    };
    localStorage.setItem('currentLead', JSON.stringify(updatedLead));
    setCurrentLead(updatedLead);

    // Update leads array
    const updatedLeads = leads.map(lead => 
      lead.id === currentLead.id ? updatedLead : lead
    );
    setLeads(updatedLeads);

    toast.success('Document importé avec succès');
  };

  // Handle document replacement
  const handleReplace = (file: File, name: string) => {
    if (!currentLead || !documentToReplace) return;

    // Create object URL for the file
    const url = URL.createObjectURL(file);

    // Create updated document - set status to 'approved' directly
    const updatedDocument: Document = {
      ...documentToReplace,
      name,
      type: file.type,
      url,
      dateUploaded: new Date().toISOString(),
      status: 'approved', // Automatically approved
      comments: undefined, // Clear previous comments
      size: file.size
    };

    // Update documents state
    const updatedDocuments = documents.map(doc => 
      doc.id === documentToReplace.id ? updatedDocument : doc
    );
    setDocuments(updatedDocuments);

    // Update lead in localStorage and state
    const updatedLead = {
      ...currentLead,
      documents: updatedDocuments
    };
    localStorage.setItem('currentLead', JSON.stringify(updatedLead));
    setCurrentLead(updatedLead);

    // Update leads array
    const updatedLeads = leads.map(lead => 
      lead.id === currentLead.id ? updatedLead : lead
    );
    setLeads(updatedLeads);

    // Reset state
    setDocumentToReplace(null);
    setIsReplacing(false);

    toast.success('Document remplacé avec succès');
  };

  // Handle document deletion
  const handleDelete = (documentId: string) => {
    if (!currentLead) return;

    // Update documents state
    const updatedDocuments = documents.filter(doc => doc.id !== documentId);
    setDocuments(updatedDocuments);

    // Update lead in localStorage and state
    const updatedLead = {
      ...currentLead,
      documents: updatedDocuments
    };
    localStorage.setItem('currentLead', JSON.stringify(updatedLead));
    setCurrentLead(updatedLead);

    // Update leads array
    const updatedLeads = leads.map(lead => 
      lead.id === currentLead.id ? updatedLead : lead
    );
    setLeads(updatedLeads);

    toast.success('Document supprimé avec succès');
  };

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/5 to-pink-500/5 rounded-xl blur-xl"></div>
        
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div className="space-y-2">
              <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                Mes Documents
              </h2>
              <p className="text-gray-400">
                Importez et gérez vos documents importants
              </p>
            </div>
            
            <motion.button
              onClick={() => setShowUploadModal(true)}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="relative group overflow-hidden rounded-xl"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity"></div>
              <div className="relative flex items-center justify-center bg-gray-900/20 backdrop-blur-sm text-white py-3 px-6">
                <FilePlus className="w-5 h-5 mr-2" />
                <span className="font-medium">Importer un document</span>
              </div>
            </motion.button>
          </div>
        </div>
      </div>

      {/* Documents Grid */}
      {documents.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {documents.map((document) => (
            <motion.div
              key={document.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative group"
            >
              <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
              <div className="relative bg-gray-900 rounded-lg p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center">
                    {getDocumentTypeIcon(document.type)}
                    <div className="ml-3">
                      <h3 className="text-lg font-medium text-white">{document.name}</h3>
                      <p className="text-sm text-gray-400">
                        {new Date(document.dateUploaded).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 flex justify-between">
                  <div className="flex space-x-2">
                    <button
                      onClick={() => {
                        setSelectedDocument(document);
                        setShowViewerModal(true);
                      }}
                      className="p-2 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-lg transition-colors"
                      title="Voir le document"
                    >
                      <Eye className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => {
                        setDocumentToReplace(document);
                        setIsReplacing(true);
                        setShowUploadModal(true);
                      }}
                      className="p-2 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-lg transition-colors"
                      title="Remplacer le document"
                    >
                      <RefreshCw className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => handleDelete(document.id)}
                      className="p-2 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-lg transition-colors"
                      title="Supprimer le document"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                  
                  <button
                    onClick={() => {
                      setSelectedDocument(document);
                      setShowDetailsModal(true);
                    }}
                    className="text-sm text-blue-400 hover:text-blue-300 transition-colors"
                  >
                    Détails
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 bg-gray-800/30 rounded-lg border border-gray-700/50">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-800/50 backdrop-blur-xl mb-4">
            <FileText className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-xl font-medium text-gray-300">
            Aucun document
          </h3>
          <p className="text-gray-500 max-w-sm mx-auto mt-2">
            Vous n'avez pas encore importé de documents. Cliquez sur le bouton "Importer un document" pour commencer.
          </p>
        </div>
      )}

      {/* Modals */}
      <AnimatePresence>
        {showUploadModal && (
          <UploadModal
            isOpen={showUploadModal}
            onClose={() => {
              setShowUploadModal(false);
              setIsReplacing(false);
              setDocumentToReplace(null);
            }}
            onUpload={isReplacing ? handleReplace : handleUpload}
            isReplace={isReplacing}
            documentToReplace={documentToReplace || undefined}
          />
        )}

        {showViewerModal && selectedDocument && (
          <DocumentViewer
            document={selectedDocument}
            isOpen={showViewerModal}
            onClose={() => {
              setShowViewerModal(false);
              setSelectedDocument(null);
            }}
          />
        )}

        {showDetailsModal && selectedDocument && (
          <DocumentDetails
            document={selectedDocument}
            isOpen={showDetailsModal}
            onClose={() => {
              setShowDetailsModal(false);
              setSelectedDocument(null);
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}