import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation, useParams } from 'react-router-dom';
import { 
  BarChart2, UserPlus, Users, Activity, Settings, 
  LogOut, Gift, Package, Zap, Building2, Wallet, LineChart,
  MessageSquare, ArrowLeft, User, TrendingUp, History,
  CreditCard, FileText, BookOpen, AlertCircle, Bell, Menu, X,
  Globe
} from 'lucide-react';
import { SidebarLink, StatCard } from '../common';
import { Investment } from './Investment';
import { FundsManager } from '../Dashboard/LeadsManager/FundsManager';
import { PaymentSettings } from './PaymentSettings';
import { formatPrice } from '../../utils';
import type { Lead, PageType } from '../../types';
import { motion, AnimatePresence } from 'framer-motion';
import { Chat } from './Chat';
import { GeneralHistory } from './GeneralHistory';
import { VisaDeposit } from './VisaDeposit';
import { Documents } from './Documents';
import { toast } from 'react-hot-toast';
import { Settings as ClientSettings } from './Settings';
import { TradingAPI } from './TradingAPI';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { Footer } from '../Footer';

export function ClientDashboard() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const [lead, setLead] = useState<Lead | null>(null);
  const [activePage, setActivePage] = useState<PageType>('dashboard');
  const [showBackButton, setShowBackButton] = useState(false);
  const [products] = useLocalStorage<any[]>('products', []);
  const [hasNewMessage, setHasNewMessage] = useState(false);
  const [notificationCount, setNotificationCount] = useState(0);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const [settings] = useLocalStorage<any>('homepageSettings', {
    logoMode: 'image',
    logoText: 'Trioptima',
    logoTextColor: '#ffffff'
  });

  // Check if screen is mobile
  const isMobile = typeof window !== 'undefined' ? window.innerWidth < 768 : false;

  // Close sidebar on mobile when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (isMobile && isSidebarOpen && sidebarRef.current && !sidebarRef.current.contains(event.target as Node)) {
        setIsSidebarOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isMobile, isSidebarOpen]);

  // Close sidebar on mobile when changing routes
  useEffect(() => {
    if (isMobile) {
      setIsSidebarOpen(false);
    }
  }, [activePage, isMobile]);

  // Set sidebar state based on screen size
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setIsSidebarOpen(false);
      } else {
        setIsSidebarOpen(true);
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  useEffect(() => {
    const loadLead = () => {
      const leadData = localStorage.getItem('currentLead');
      if (!leadData) {
        navigate('/', { replace: true });
        return;
      }

      const parsedLead = JSON.parse(leadData) as Lead;
      if (parsedLead.id !== id) {
        navigate('/', { replace: true });
        return;
      }

      setLead(parsedLead);

      // Check if we came from the seller dashboard
      const fromSellerDashboard = localStorage.getItem('fromSellerDashboard');
      if (fromSellerDashboard === 'true') {
        setShowBackButton(true);
      } else {
        // Check if we came from the admin dashboard
        const user = localStorage.getItem('user');
        if (user) {
          const parsedUser = JSON.parse(user);
          setShowBackButton(parsedUser.role === 'Admin' || parsedUser.role === 'Seller');
        } else {
          setShowBackButton(false);
        }
      }
    };

    loadLead();

    // Set up an interval to refresh lead data from localStorage
    const refreshInterval = setInterval(() => {
      const freshLeadData = localStorage.getItem('currentLead');
      if (freshLeadData) {
        const freshLead = JSON.parse(freshLeadData) as Lead;
        setLead(prevLead => {
          // Only update if there's a change to avoid unnecessary re-renders
          if (JSON.stringify(prevLead) !== JSON.stringify(freshLead)) {
            return freshLead;
          }
          return prevLead;
        });
      }
    }, 1000); // Check every second

    return () => clearInterval(refreshInterval);
  }, [id, navigate]);

  // Check for new messages
  useEffect(() => {
    const checkMessages = () => {
      const currentLeadStr = localStorage.getItem('currentLead');
      if (!currentLeadStr) return;

      const currentLead = JSON.parse(currentLeadStr) as Lead;
      const chat = currentLead.chat;

      if (chat?.unreadCount && chat.unreadCount > 0) {
        // Only show notification if we're not already on the chat page
        if (activePage !== 'chat') {
          setHasNewMessage(true);
          setNotificationCount(chat.unreadCount);
          
          // Show toast notification
          toast((t) => (
            <div className="flex items-center">
              <MessageSquare className="w-5 h-5 mr-2 text-blue-400" />
              <span>
                {chat.unreadCount > 1 
                  ? `${chat.unreadCount} nouveaux messages` 
                  : 'Nouveau message'}
              </span>
              <button 
                onClick={() => {
                  setActivePage('chat');
                  toast.dismiss(t.id);
                }}
                className="ml-3 px-2 py-1 bg-blue-500 text-white text-xs rounded hover:bg-blue-600"
              >
                Voir
              </button>
            </div>
          ), {
            duration: 5000,
            icon: '💬',
          });
        }
      }
    };

    const interval = setInterval(checkMessages, 3000);
    return () => clearInterval(interval);
  }, [activePage]);

  // Reset notification when navigating to chat
  useEffect(() => {
    if (activePage === 'chat') {
      setHasNewMessage(false);
      setNotificationCount(0);
      
      // Mark messages as read in localStorage
      const currentLeadStr = localStorage.getItem('currentLead');
      if (currentLeadStr) {
        const currentLead = JSON.parse(currentLeadStr) as Lead;
        if (currentLead.chat) {
          const updatedLead = {
            ...currentLead,
            chat: {
              ...currentLead.chat,
              unreadCount: 0
            }
          };
          localStorage.setItem('currentLead', JSON.stringify(updatedLead));
        }
      }
    }
  }, [activePage]);

  const handleLogout = () => {
    localStorage.removeItem('currentLead');
    localStorage.removeItem('fromSellerDashboard');
    navigate('/', { replace: true });
  };

  const handleBackToDashboard = () => {
    // Check if we came from seller dashboard
    const fromSellerDashboard = localStorage.getItem('fromSellerDashboard');
    if (fromSellerDashboard === 'true') {
      localStorage.removeItem('fromSellerDashboard');
      navigate('/seller-dashboard', { state: { activeTab: 'leads' }, replace: true });
    } else {
      // Otherwise, go to admin dashboard
      navigate('/dashboard', { state: { activeTab: 'leads' }, replace: true });
    }
  };

  // Check if products are enabled
  const isProductEnabled = (productId: string): boolean => {
    const product = products.find(p => p.id === productId);
    return product ? product.enabled : true; // Default to true if product not found
  };

  // Get enabled status for each product
  const actionsEnabled = isProductEnabled('actions');
  const electricityEnabled = isProductEnabled('electricity');
  const livretsEnabled = isProductEnabled('livrets');
  const tradingAPIEnabled = isProductEnabled('trading');

  if (!lead) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-gray-400">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 flex flex-col">
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Mobile Header */}
        <div className="md:hidden flex items-center justify-between p-4 border-b border-gray-700" style={{ 
          backgroundColor: 'var(--client-header, #1e293b)',
          borderColor: 'var(--color-dividers, #374151)'
        }}>
          <div className="flex items-center">
            {showBackButton && (
              <button
                onClick={handleBackToDashboard}
                className="p-1.5 text-gray-400 hover:text-white transition-colors rounded-md hover:bg-white/5 mr-3"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
            )}
            {settings.logoMode === 'image' ? (
              <BarChart2 className="h-6 w-6 text-blue-500" />
            ) : (
              <span 
                className="font-['Orbitron'] font-bold text-lg"
                style={{ 
                  color: settings.logoTextColor || '#ffffff',
                  textShadow: '0 0 5px currentColor'
                }}
              >
                {settings.logoText || 'Trioptima'}
              </span>
            )}
          </div>
          <div className="flex items-center">
            {/* Notification Bell */}
            <div className="relative mr-4">
              <AnimatePresence>
                {hasNewMessage && (
                  <motion.div
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.8, opacity: 0 }}
                    className="absolute -top-1 -right-1"
                  >
                    <div className="flex items-center justify-center w-5 h-5 rounded-full bg-red-500 text-white text-xs font-bold">
                      {notificationCount > 9 ? '9+' : notificationCount}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
              <button 
                onClick={() => setActivePage('chat')}
                className={`p-2 rounded-full transition-colors ${hasNewMessage ? 'text-blue-400 hover:text-blue-300' : 'text-gray-400 hover:text-white'}`}
              >
                <Bell className="w-5 h-5" />
              </button>
            </div>
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700"
            >
              {isSidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Left Sidebar */}
        <AnimatePresence>
          {isSidebarOpen && (
            <motion.div
              ref={sidebarRef}
              initial={{ x: -300, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -300, opacity: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="fixed md:relative z-40 md:z-auto inset-y-0 left-0 w-64 border-r border-gray-700 flex flex-col bg-opacity-95 md:bg-opacity-100 backdrop-blur-lg md:backdrop-blur-none"
              style={{ 
                backgroundColor: 'var(--client-sidebar, #0f172a)',
                borderColor: 'var(--color-dividers, #374151)'
              }}
            >
              {/* Logo Section - Hidden on mobile */}
              <div className="hidden md:flex h-16 items-center px-4 border-b border-gray-700" style={{ borderColor: 'var(--color-dividers, #374151)' }}>
                {showBackButton && (
                  <button
                    onClick={handleBackToDashboard}
                    className="p-1.5 text-gray-400 hover:text-white transition-colors rounded-md hover:bg-white/5 mr-3"
                  >
                    <ArrowLeft className="h-5 w-5" />
                  </button>
                )}
                <div className="flex items-center ml-3">
                  {settings.logoMode === 'image' ? (
                    <BarChart2 className="h-5 w-5 text-blue-500" />
                  ) : (
                    <span 
                      className="font-['Orbitron'] font-bold text-lg"
                      style={{ 
                        color: settings.logoTextColor || '#ffffff',
                        textShadow: '0 0 5px currentColor'
                      }}
                    >
                      {settings.logoText || 'Trioptima'}
                    </span>
                  )}
                </div>
              </div>

              {/* Navigation */}
              <nav className="flex-1 overflow-y-auto py-6">
                <div className="px-4 space-y-1">
                  <SidebarLink 
                    icon={BarChart2} 
                    text="Tableau de bord" 
                    isActive={activePage === 'dashboard'}
                    onClick={() => setActivePage('dashboard')}
                  />
                  <SidebarLink 
                    icon={Zap} 
                    text="Investissement"
                    isActive={activePage === 'investment'}
                    onClick={() => setActivePage('investment')}
                  />
                  <SidebarLink 
                    icon={Globe} 
                    text="Trading API"
                    isActive={activePage === 'trading-api'}
                    onClick={() => setActivePage('trading-api')}
                  />
                  <SidebarLink 
                    icon={Wallet} 
                    text="Gestion des fonds"
                    isActive={activePage === 'funds'}
                    onClick={() => setActivePage('funds')}
                  />
                  <SidebarLink 
                    icon={History} 
                    text="Historique Général"
                    isActive={activePage === 'history'}
                    onClick={() => setActivePage('history')}
                  />
                  <SidebarLink 
                    icon={CreditCard} 
                    text="Dépôt Visa"
                    isActive={activePage === 'visa-deposit'}
                    onClick={() => setActivePage('visa-deposit')}
                  />
                  <SidebarLink 
                    icon={FileText} 
                    text="Documents"
                    isActive={activePage === 'documents'}
                    onClick={() => setActivePage('documents')}
                  />
                  <div className="relative">
                    <SidebarLink 
                      icon={MessageSquare} 
                      text="Chat"
                      isActive={activePage === 'chat'}
                      onClick={() => setActivePage('chat')}
                    />
                    {hasNewMessage && (
                      <div className="absolute top-1/2 -right-1 transform -translate-y-1/2">
                        <div className="flex items-center justify-center w-5 h-5 rounded-full bg-red-500 text-white text-xs font-bold">
                          {notificationCount > 9 ? '9+' : notificationCount}
                        </div>
                      </div>
                    )}
                  </div>
                  <SidebarLink 
                    icon={Settings} 
                    text="Paramètres de paiement"
                    isActive={activePage === 'payment-settings'}
                    onClick={() => setActivePage('payment-settings')}
                  />
                  <SidebarLink 
                    icon={Settings} 
                    text="Paramètres"
                    isActive={activePage === 'settings'}
                    onClick={() => setActivePage('settings')}
                  />
                </div>
              </nav>

              {/* User Profile and Balance */}
              <div className="p-4 border-t border-gray-700 space-y-4" style={{ borderColor: 'var(--color-dividers, #374151)' }}>
                {/* User Profile Card */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="relative group"
                >
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-pink-500/20 rounded-lg blur opacity-75 group-hover:opacity-100 transition duration-1000"></div>
                  <div className="relative bg-white/10 backdrop-blur-sm rounded-lg border border-white/20 px-4 py-3">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600">
                        <User className="w-5 h-5 text-white" />
                      </div>
                      <div className="ml-3">
                        <div className="font-medium text-white">
                          {lead.firstName} {lead.lastName}
                        </div>
                        <div className="flex items-center text-xs text-gray-400">
                          <span className="mr-2">Client</span>
                          <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>

                {/* Balance Card */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="relative group"
                >
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-emerald-500/20 to-blue-500/20 rounded-lg blur opacity-75 group-hover:opacity-100 transition duration-1000"></div>
                  <div className="relative flex items-center bg-white/10 backdrop-blur-sm rounded-lg border border-white/20 px-4 py-3">
                    <div className="flex-shrink-0 flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-blue-600">
                      <Wallet className="w-5 h-5 text-white" />
                    </div>
                    <div className="ml-3">
                      <div className="text-xs text-gray-400">Solde</div>
                      <div className="font-bold text-lg bg-clip-text text-transparent bg-gradient-to-r from-emerald-500 to-blue-600">
                        {formatPrice(lead.balance || 0)} €
                      </div>
                    </div>
                  </div>
                </motion.div>

                {/* Logout Button */}
                <SidebarLink 
                  icon={LogOut} 
                  text="Déconnexion"
                  onClick={handleLogout}
                  variant="danger"
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Mobile sidebar overlay */}
        {isSidebarOpen && isMobile && (
          <div 
            className="fixed inset-0 bg-black bg-opacity-50 z-30"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}

        {/* Main Content Area */}
        <div className="flex-1">
          {/* Header - Hidden on mobile */}
          <div className="hidden md:block border-b border-gray-700" style={{ 
            backgroundColor: 'var(--client-header, #1e293b)',
            borderColor: 'var(--color-dividers, #374151)'
          }}>
            <div className="h-16 px-6 flex items-center justify-between">
              <h1 className="text-xl font-bold text-white">
                {activePage === 'dashboard' && 'Tableau de bord'}
                {activePage === 'investment' && 'Investissement'}
                {activePage === 'trading-api' && 'Trading API'}
                {activePage === 'funds' && 'Gestion des fonds'}
                {activePage === 'history' && 'Historique Général'}
                {activePage === 'visa-deposit' && 'Dépôt Visa'}
                {activePage === 'documents' && 'Documents'}
                {activePage === 'chat' && 'Chat'}
                {activePage === 'payment-settings' && 'Paramètres de paiement'}
                {activePage === 'settings' && 'Paramètres'}
              </h1>
              
              {/* Notification Bell */}
              <div className="relative">
                <AnimatePresence>
                  {hasNewMessage && (
                    <motion.div
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.8, opacity: 0 }}
                      className="absolute -top-1 -right-1"
                    >
                      <div className="flex items-center justify-center w-5 h-5 rounded-full bg-red-500 text-white text-xs font-bold">
                        {notificationCount > 9 ? '9+' : notificationCount}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
                <button 
                  onClick={() => setActivePage('chat')}
                  className={`p-2 rounded-full transition-colors ${hasNewMessage ? 'text-blue-400 hover:text-blue-300' : 'text-gray-400 hover:text-white'}`}
                >
                  <Bell className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Page Content */}
          <div className="p-4 md:p-6" style={{ backgroundColor: 'var(--client-main-content, #111827)' }}>
            {activePage === 'dashboard' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
                <StatCard
                  title="Solde"
                  value={`${formatPrice(lead.balance || 0)} €`}
                  icon={<BarChart2 />}
                />
                <StatCard
                  title="Positions ouvertes"
                  value={`${lead.tradingPositions?.filter(p => p.status === 'open').length || 0}`}
                  icon={<Activity />}
                />
                <StatCard
                  title="P&L Total"
                  value={`${formatPrice(lead.tradingPositions?.reduce((sum, p) => sum + (p.pnl || 0), 0) || 0)} €`}
                  textColor={lead.tradingPositions?.reduce((sum, p) => sum + (p.pnl || 0), 0) >= 0 ? "text-green-600" : "text-red-600"}
                  icon={<TrendingUp />}
                />
              </div>
            )}
            {activePage === 'investment' && (
              actionsEnabled || electricityEnabled || livretsEnabled ? (
                <Investment />
              ) : (
                <ProductUnavailable productName="Investissement" />
              )
            )}
            {activePage === 'trading-api' && (
              tradingAPIEnabled ? (
                <TradingAPI />
              ) : (
                <ProductUnavailable productName="Trading API" />
              )
            )}
            {activePage === 'funds' && <FundsManager />}
            {activePage === 'history' && <GeneralHistory />}
            {activePage === 'visa-deposit' && <VisaDeposit />}
            {activePage === 'documents' && <Documents />}
            {activePage === 'chat' && <Chat />}
            {activePage === 'payment-settings' && <PaymentSettings />}
            {activePage === 'settings' && <ClientSettings />}
          </div>
          
          {/* Footer */}
          <Footer />
        </div>
      </div>
    </div>
  );
}

// Component to display when a product is unavailable
function ProductUnavailable({ productName }: { productName: string }) {
  return (
    <div className="min-h-[400px] flex items-center justify-center">
      <div className="text-center space-y-4">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-800/50 backdrop-blur-xl mb-4">
          <AlertCircle className="w-8 h-8 text-red-400" />
        </div>
        <h3 className="text-xl font-medium text-gray-300">
          Service temporairement indisponible
        </h3>
        <p className="text-gray-500 max-w-md mx-auto">
          Vous n'avez pas accès au service <strong>{productName}</strong> pour le moment. 
          Veuillez contacter votre conseiller pour plus d'informations.
        </p>
      </div>
    </div>
  );
}