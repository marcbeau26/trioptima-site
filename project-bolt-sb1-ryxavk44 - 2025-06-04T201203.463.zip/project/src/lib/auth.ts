import type { User, Lead } from '../types';

// Test users
const ADMIN_USER: User = {
  id: '1',
  email: 'admin@plate.com',
  firstName: 'Admin',
  lastName: 'User',
  phone: '',
  role: 'Admin',
  dateCreated: new Date().toISOString(),
  password: '123456'
};

const CLIENT_USER: User = {
  id: '2',
  email: 'seller@gmail.com',
  firstName: 'Seller',
  lastName: 'User',
  phone: '',
  role: 'Seller',
  dateCreated: new Date().toISOString(),
  password: '1234'
};

export async function signIn(email: string, password: string) {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 500));

  // Check admin credentials
  if (email === ADMIN_USER.email && password === ADMIN_USER.password) {
    localStorage.setItem('user', JSON.stringify(ADMIN_USER));
    return { data: { user: ADMIN_USER }, error: null };
  }

  // Check seller credentials
  if (email === CLIENT_USER.email && password === CLIENT_USER.password) {
    localStorage.setItem('user', JSON.stringify(CLIENT_USER));
    return { data: { user: CLIENT_USER }, error: null };
  }

  // Check users in localStorage
  const usersStr = localStorage.getItem('users');
  if (usersStr) {
    const users = JSON.parse(usersStr) as User[];
    const user = users.find(u => u.email === email && u.password === password);
    
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
      return { data: { user }, error: null };
    }
  }

  // Check lead credentials
  const leadsStr = localStorage.getItem('leads');
  if (leadsStr) {
    const leads = JSON.parse(leadsStr) as Lead[];
    const lead = leads.find(l => 
      l.email === email && 
      l.password === password && 
      (!l.isRegistration || l.registrationStatus === 'approved')
    );
    
    if (lead) {
      localStorage.setItem('currentLead', JSON.stringify(lead));
      return { data: { lead }, error: null };
    }
  }

  return { 
    data: null, 
    error: new Error('Email ou mot de passe invalide') 
  };
}

export async function signOut() {
  // Clear user and lead from localStorage
  localStorage.removeItem('user');
  localStorage.removeItem('currentLead');
  localStorage.removeItem('fromSellerDashboard');
  localStorage.removeItem('adminUser');
  return { error: null };
}

export async function getCurrentUser(): Promise<User | null> {
  const userStr = localStorage.getItem('user');
  if (!userStr) return null;
  
  try {
    return JSON.parse(userStr) as User;
  } catch (error) {
    console.error('Error parsing user from localStorage:', error);
    return null;
  }
}

// Fisher-Yates shuffle algorithm
function shuffleArray(array: number[]): number[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

// Generate password grid with shuffled positions
export function generatePasswordGrid() {
  // Create array of numbers 0-9
  const numbers = Array.from({ length: 10 }, (_, i) => i);
  
  // Shuffle the array
  const shuffled = shuffleArray(numbers);
  
  // Split into two rows
  return {
    topRow: shuffled.slice(0, 5),
    bottomRow: shuffled.slice(5)
  };
}