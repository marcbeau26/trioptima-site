import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { getStorage } from 'firebase/storage';

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBN3C97BHlGVUjViUszhixtv9xLnODCMZI",
  authDomain: "homeplate-5980c.firebaseapp.com",
  projectId: "homeplate-5980c",
  storageBucket: "homeplate-5980c.firebasestorage.app",
  messagingSenderId: "340186308310",
  appId: "1:340186308310:web:ee7392528c32c7eaa13377"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize services
export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);