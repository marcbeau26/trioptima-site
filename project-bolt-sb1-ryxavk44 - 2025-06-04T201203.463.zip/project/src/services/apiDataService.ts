// Mock API service to replace Polygon.io WebSocket
// This provides simulated data for the trading interface

// Store for crypto data
const cryptoStore: Record<string, any> = {
  'BTC-USD': {
    price: 65432.10,
    change: 1234.56,
    changePercent: 1.92,
    lastUpdated: new Date()
  },
  'ETH-USD': {
    price: 3456.78,
    change: 123.45,
    changePercent: 3.7,
    lastUpdated: new Date()
  },
  'XRP-USD': {
    price: 0.5678,
    change: 0.0234,
    changePercent: 4.3,
    lastUpdated: new Date()
  }
};

// Store for forex data
const forexStore: Record<string, any> = {
  'XAUUSD': {
    price: 2223.45,
    change: 12.34,
    changePercent: 0.56,
    lastUpdated: new Date()
  },
  'EURUSD': {
    price: 1.0876,
    change: 0.0023,
    changePercent: 0.21,
    lastUpdated: new Date()
  },
  'USDJPY': {
    price: 151.23,
    change: -0.45,
    changePercent: -0.30,
    lastUpdated: new Date()
  }
};

// Callbacks for data updates
const cryptoCallbacks: Array<(data: Record<string, any>) => void> = [];
const forexCallbacks: Array<(data: Record<string, any>) => void> = [];

// Connection status
let cryptoConnected = true;
let forexConnected = true;

// Connection status callbacks
const connectionStatusCallbacks: Array<(cryptoStatus: boolean, forexStatus: boolean) => void> = [];

// Subscribe to crypto data updates
export const subscribeToCryptoUpdates = (callback: (data: Record<string, any>) => void) => {
  cryptoCallbacks.push(callback);
  
  // Immediately notify with current data
  callback({ ...cryptoStore });
  
  // Return unsubscribe function
  return () => {
    const index = cryptoCallbacks.indexOf(callback);
    if (index !== -1) {
      cryptoCallbacks.splice(index, 1);
    }
  };
};

// Subscribe to forex data updates
export const subscribeToForexUpdates = (callback: (data: Record<string, any>) => void) => {
  forexCallbacks.push(callback);
  
  // Immediately notify with current data
  callback({ ...forexStore });
  
  // Return unsubscribe function
  return () => {
    const index = forexCallbacks.indexOf(callback);
    if (index !== -1) {
      forexCallbacks.splice(index, 1);
    }
  };
};

// Subscribe to connection status updates
export const subscribeToConnectionStatus = (callback: (cryptoStatus: boolean, forexStatus: boolean) => void) => {
  connectionStatusCallbacks.push(callback);
  
  // Immediately notify with current status
  callback(cryptoConnected, forexConnected);
  
  // Return unsubscribe function
  return () => {
    const index = connectionStatusCallbacks.indexOf(callback);
    if (index !== -1) {
      connectionStatusCallbacks.splice(index, 1);
    }
  };
};

// Function to manually check connection status and reconnect if needed
export const checkConnectionAndReconnect = () => {
  // Simulate random price changes
  updatePrices();
  return true;
};

// Get crypto symbols with friendly names
export const getCryptoSymbols = () => {
  return [
    { symbol: 'BTC-USD', name: 'Bitcoin' },
    { symbol: 'ETH-USD', name: 'Ethereum' },
    { symbol: 'XRP-USD', name: 'Ripple' },
    { symbol: 'LTC-USD', name: 'Litecoin' },
    { symbol: 'BCH-USD', name: 'Bitcoin Cash' },
    { symbol: 'ADA-USD', name: 'Cardano' },
    { symbol: 'DOT-USD', name: 'Polkadot' },
    { symbol: 'LINK-USD', name: 'Chainlink' },
    { symbol: 'XLM-USD', name: 'Stellar' },
    { symbol: 'DOGE-USD', name: 'Dogecoin' }
  ];
};

// Get forex pairs with friendly names
export const getForexPairs = () => {
  return [
    { pair: 'EUR/USD', name: 'Euro / US Dollar' },
    { pair: 'USD/JPY', name: 'US Dollar / Japanese Yen' },
    { pair: 'GBP/USD', name: 'British Pound / US Dollar' },
    { pair: 'USD/CAD', name: 'US Dollar / Canadian Dollar' },
    { pair: 'USD/CHF', name: 'US Dollar / Swiss Franc' },
    { pair: 'AUD/USD', name: 'Australian Dollar / US Dollar' },
    { pair: 'NZD/USD', name: 'New Zealand Dollar / US Dollar' },
    { pair: 'XAU/USD', name: 'Gold / US Dollar' }
  ];
};

// Format price with appropriate decimal places
export const formatCryptoPrice = (price: number) => {
  if (price >= 1000) {
    return price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  } else if (price >= 1) {
    return price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 4 });
  } else {
    return price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 6 });
  }
};

// Format forex price with appropriate decimal places
export const formatForexPrice = (price: number) => {
  return price.toLocaleString('en-US', { minimumFractionDigits: 4, maximumFractionDigits: 5 });
};

// Format percentage change
export const formatPercentChange = (change: number) => {
  return change.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + '%';
};

// Simulate price updates
function updatePrices() {
  // Update crypto prices
  Object.keys(cryptoStore).forEach(symbol => {
    const currentPrice = cryptoStore[symbol].price;
    const previousPrice = currentPrice;
    
    // Generate random price change between -2% and +2%
    const changePercent = (Math.random() * 4) - 2;
    const change = currentPrice * (changePercent / 100);
    const newPrice = currentPrice + change;
    
    cryptoStore[symbol] = {
      price: newPrice,
      previousPrice,
      change,
      changePercent,
      lastUpdated: new Date()
    };
  });
  
  // Update forex prices
  Object.keys(forexStore).forEach(pair => {
    const currentPrice = forexStore[pair].price;
    const previousPrice = currentPrice;
    
    // Generate random price change between -0.5% and +0.5%
    const changePercent = (Math.random() * 1) - 0.5;
    const change = currentPrice * (changePercent / 100);
    const newPrice = currentPrice + change;
    
    forexStore[pair] = {
      price: newPrice,
      previousPrice,
      change,
      changePercent,
      lastUpdated: new Date()
    };
  });
  
  // Notify callbacks
  notifyCryptoCallbacks();
  notifyForexCallbacks();
}

// Notify crypto callbacks
function notifyCryptoCallbacks() {
  cryptoCallbacks.forEach(callback => {
    callback({ ...cryptoStore });
  });
}

// Notify forex callbacks
function notifyForexCallbacks() {
  forexCallbacks.forEach(callback => {
    callback({ ...forexStore });
  });
}

// Set up a data refresh interval
setInterval(() => {
  updatePrices();
}, 5000); // Update every 5 seconds