import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FileText, Eye, Check, X, AlertTriangle, 
  CheckCircle, XCircle, MessageSquare, Download,
  File, FileImage, FileArchive
} from 'lucide-react';
import type { Document, Lead } from '../../../../types';
import { formatDate } from '../../../../utils';
import { cn } from '../../../../utils/cn';

interface DocumentsTabProps {
  lead: Lead;
  onUpdateLead: (updatedLead: Lead) => void;
}

// Document type icons mapping
const documentTypeIcons: Record<string, React.ReactNode> = {
  'application/pdf': <FileText className="w-6 h-6 text-red-400" />,
  'image/jpeg': <FileImage className="w-6 h-6 text-blue-400" />,
  'image/png': <FileImage className="w-6 h-6 text-green-400" />,
  'application/zip': <FileArchive className="w-6 h-6 text-yellow-400" />,
  'application/x-zip-compressed': <FileArchive className="w-6 h-6 text-yellow-400" />,
  'default': <File className="w-6 h-6 text-gray-400" />
};

// Document viewer component
interface DocumentViewerProps {
  document: Document;
  isOpen: boolean;
  onClose: () => void;
}

function DocumentViewer({ document, isOpen, onClose }: DocumentViewerProps) {
  if (!isOpen) return null;

  const isImage = document.type.startsWith('image/');
  const isPdf = document.type === 'application/pdf';

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-4xl mx-4 max-h-[90vh] flex flex-col"
      >
        {/* Header */}
        <div className="bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-t-xl p-4 flex justify-between items-center">
          <h3 className="text-xl font-bold text-white flex items-center">
            {getDocumentTypeIcon(document.type)}
            <span className="ml-2">{document.name}</span>
          </h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Document content */}
        <div className="bg-gray-900/90 backdrop-blur-xl border-x border-white/10 flex-1 overflow-auto">
          {isImage && (
            <div className="flex items-center justify-center h-full p-4">
              <img 
                src={document.url} 
                alt={document.name} 
                className="max-w-full max-h-[70vh] object-contain"
              />
            </div>
          )}
          {isPdf && (
            <div className="h-[70vh]">
              <iframe 
                src={document.url} 
                title={document.name}
                className="w-full h-full"
              />
            </div>
          )}
          {!isImage && !isPdf && (
            <div className="flex flex-col items-center justify-center h-[50vh] p-8 text-center">
              <File className="w-16 h-16 text-gray-400 mb-4" />
              <h4 className="text-xl font-medium text-white mb-2">
                Aperçu non disponible
              </h4>
              <p className="text-gray-400 mb-6">
                Ce type de document ne peut pas être prévisualisé directement.
              </p>
              <a 
                href={document.url} 
                download={document.name}
                className="flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
              >
                <Download className="w-5 h-5 mr-2" />
                Télécharger le document
              </a>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-b-xl p-4 flex justify-between items-center">
          <div className="flex items-center">
            <span className="text-sm text-gray-400 mr-4">
              Taille: {formatFileSize(document.size)}
            </span>
          </div>
          <a 
            href={document.url} 
            download={document.name}
            className="flex items-center px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-lg transition-colors text-sm"
          >
            <Download className="w-4 h-4 mr-2" />
            Télécharger
          </a>
        </div>
      </motion.div>
    </div>
  );
}

// Document details modal component
interface DocumentDetailsProps {
  document: Document;
  isOpen: boolean;
  onClose: () => void;
  onStatusChange: (documentId: string, status: 'approved' | 'rejected', comments?: string) => void;
}

function DocumentDetails({ document, isOpen, onClose, onStatusChange }: DocumentDetailsProps) {
  const [comments, setComments] = useState(document.comments || '');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-lg mx-4"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <div className="flex justify-between items-start mb-6">
            <div className="flex items-center">
              {getDocumentTypeIcon(document.type)}
              <h2 className="text-2xl font-bold text-white ml-3">
                {document.name}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="space-y-6">
            {/* Document info */}
            <div className="bg-gray-800/50 border border-white/5 rounded-xl p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-400">Date d'importation</p>
                  <p className="text-white mt-1">
                    {formatDate(document.dateUploaded)}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Taille</p>
                  <p className="text-white mt-1">{formatFileSize(document.size)}</p>
                </div>
              </div>
              <div>
                <p className="text-sm text-gray-400">Statut actuel</p>
                <div className="flex items-center mt-1">
                  {document.status === 'approved' && (
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-500/20 text-green-400 border border-green-500/30">
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Approuvé
                    </span>
                  )}
                  {document.status === 'rejected' && (
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-red-500/20 text-red-400 border border-red-500/30">
                      <XCircle className="w-4 h-4 mr-2" />
                      Refusé
                    </span>
                  )}
                  {document.status === 'pending' && (
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-yellow-500/20 text-yellow-400 border border-yellow-500/30">
                      <AlertTriangle className="w-4 h-4 mr-2" />
                      En attente de validation
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Admin actions */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Commentaires
                </label>
                <textarea
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                  className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  rows={3}
                  placeholder="Ajouter des commentaires sur ce document..."
                />
              </div>

              <div className="flex space-x-4">
                <motion.button
                  onClick={() => onStatusChange(document.id, 'rejected', comments)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex-1 relative group overflow-hidden rounded-lg"
                >
                  <div className="absolute inset-0 bg-red-500/80 opacity-80 group-hover:opacity-100 transition-opacity"></div>
                  <span className="relative flex items-center justify-center text-white py-3">
                    <X className="w-5 h-5 mr-2" />
                    Refuser
                  </span>
                </motion.button>
                
                <motion.button
                  onClick={() => onStatusChange(document.id, 'approved', comments)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex-1 relative group overflow-hidden rounded-lg"
                >
                  <div className="absolute inset-0 bg-green-500/80 opacity-80 group-hover:opacity-100 transition-opacity"></div>
                  <span className="relative flex items-center justify-center text-white py-3">
                    <Check className="w-5 h-5 mr-2" />
                    Approuver
                  </span>
                </motion.button>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex justify-between">
              <a 
                href={document.url} 
                download={document.name}
                className="flex items-center px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-lg transition-colors"
              >
                <Download className="w-5 h-5 mr-2" />
                Télécharger
              </a>
              
              <button
                onClick={onClose}
                className="px-6 py-2 text-sm font-medium text-gray-300 bg-gray-800/50 hover:bg-gray-700/50 rounded-lg transition-colors"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

// Helper function to get document type icon
function getDocumentTypeIcon(type: string) {
  return documentTypeIcons[type] || documentTypeIcons.default;
}

// Helper function to format file size
function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

export function DocumentsTab({ lead, onUpdateLead }: DocumentsTabProps) {
  const [showViewerModal, setShowViewerModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [activeTab, setActiveTab] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');

  // Filter documents based on active tab
  const documents = lead.documents || [];
  const filteredDocuments = documents.filter(doc => {
    if (activeTab === 'all') return true;
    return doc.status === activeTab;
  });

  // Handle document status change
  const handleStatusChange = (documentId: string, status: 'approved' | 'rejected', comments?: string) => {
    // Update the document status
    const updatedDocuments = documents.map(doc => {
      if (doc.id === documentId) {
        return {
          ...doc,
          status,
          comments
        };
      }
      return doc;
    });

    // Update lead with new documents
    const updatedLead = {
      ...lead,
      documents: updatedDocuments
    };

    // Call the update function
    onUpdateLead(updatedLead);

    // Close the modal
    setShowDetailsModal(false);
    setSelectedDocument(null);
  };

  return (
    <div className="space-y-6">
      {/* Tabs */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setActiveTab('all')}
          className={cn(
            "px-4 py-2 rounded-lg text-sm font-medium transition-colors",
            activeTab === 'all'
              ? "bg-blue-600 text-white"
              : "bg-gray-800/50 text-gray-400 hover:bg-gray-700/50 hover:text-white"
          )}
        >
          Tous ({documents.length})
        </button>
        <button
          onClick={() => setActiveTab('pending')}
          className={cn(
            "px-4 py-2 rounded-lg text-sm font-medium transition-colors",
            activeTab === 'pending'
              ? "bg-yellow-600 text-white"
              : "bg-gray-800/50 text-gray-400 hover:bg-gray-700/50 hover:text-white"
          )}
        >
          En attente ({documents.filter(d => d.status === 'pending').length})
        </button>
        <button
          onClick={() => setActiveTab('approved')}
          className={cn(
            "px-4 py-2 rounded-lg text-sm font-medium transition-colors",
            activeTab === 'approved'
              ? "bg-green-600 text-white"
              : "bg-gray-800/50 text-gray-400 hover:bg-gray-700/50 hover:text-white"
          )}
        >
          Approuvés ({documents.filter(d => d.status === 'approved').length})
        </button>
        <button
          onClick={() => setActiveTab('rejected')}
          className={cn(
            "px-4 py-2 rounded-lg text-sm font-medium transition-colors",
            activeTab === 'rejected'
              ? "bg-red-600 text-white"
              : "bg-gray-800/50 text-gray-400 hover:bg-gray-700/50 hover:text-white"
          )}
        >
          Refusés ({documents.filter(d => d.status === 'rejected').length})
        </button>
      </div>

      {/* Documents Table */}
      {filteredDocuments.length > 0 ? (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-700">
            <thead className="bg-gray-800">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                  Document
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                  Date d'importation
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                  Taille
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                  Statut
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-gray-900 divide-y divide-gray-800">
              {filteredDocuments.map((document) => (
                <tr key={document.id} className="hover:bg-gray-800/50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      {getDocumentTypeIcon(document.type)}
                      <div className="ml-4">
                        <div className="text-sm font-medium text-white">
                          {document.name}
                        </div>
                        <div className="text-sm text-gray-400">
                          {document.type.split('/')[1]?.toUpperCase() || document.type}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                    {formatDate(document.dateUploaded)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                    {formatFileSize(document.size)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {document.status === 'approved' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-500/20 text-green-400 border border-green-500/30">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Approuvé
                      </span>
                    )}
                    {document.status === 'rejected' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-500/20 text-red-400 border border-red-500/30">
                        <XCircle className="w-3 h-3 mr-1" />
                        Refusé
                      </span>
                    )}
                    {document.status === 'pending' && (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-500/20 text-yellow-400 border border-yellow-500/30">
                        <AlertTriangle className="w-3 h-3 mr-1" />
                        En attente
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex space-x-3">
                      <button
                        onClick={() => {
                          setSelectedDocument(document);
                          setShowViewerModal(true);
                        }}
                        className="text-blue-400 hover:text-blue-300 transition-colors"
                        title="Voir le document"
                      >
                        <Eye className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => {
                          setSelectedDocument(document);
                          setShowDetailsModal(true);
                        }}
                        className="text-blue-400 hover:text-blue-300 transition-colors"
                        title="Gérer le document"
                      >
                        <MessageSquare className="w-5 h-5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="text-center py-12 bg-gray-800/30 rounded-lg border border-gray-700/50">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-800/50 backdrop-blur-xl mb-4">
            <FileText className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-xl font-medium text-gray-300">
            Aucun document {activeTab !== 'all' ? `${activeTab}` : ''}
          </h3>
          <p className="text-gray-500 max-w-sm mx-auto mt-2">
            {activeTab === 'all' 
              ? "Ce client n'a pas encore importé de documents."
              : activeTab === 'pending'
                ? "Ce client n'a aucun document en attente de validation."
                : activeTab === 'approved'
                  ? "Ce client n'a aucun document approuvé."
                  : "Ce client n'a aucun document refusé."
            }
          </p>
        </div>
      )}

      {/* Modals */}
      <AnimatePresence>
        {showViewerModal && selectedDocument && (
          <DocumentViewer
            document={selectedDocument}
            isOpen={showViewerModal}
            onClose={() => {
              setShowViewerModal(false);
              setSelectedDocument(null);
            }}
          />
        )}

        {showDetailsModal && selectedDocument && (
          <DocumentDetails
            document={selectedDocument}
            isOpen={showDetailsModal}
            onClose={() => {
              setShowDetailsModal(false);
              setSelectedDocument(null);
            }}
            onStatusChange={handleStatusChange}
          />
        )}
      </AnimatePresence>
    </div>
  );
}