import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { FileSpreadsheet, CheckCircle, XCircle, AlertCircle, ArrowRight, ArrowLeft } from 'lucide-react';
import Papa from 'papaparse';
import type { Lead } from '../../../../types';
import { useLocalStorage } from '../../../../hooks/useLocalStorage';
import { generateId } from '../../../../utils';
import { toast } from 'react-hot-toast';
import { cn } from '../../../../utils/cn';

interface CSVRow {
  [key: string]: string;
}

interface ValidationError {
  row: number;
  field: string;
  message: string;
}

interface ColumnMapping {
  csvColumn: string;
  systemField: string;
}

const SYSTEM_FIELDS = [
  { id: 'firstName', label: 'Prénom' },
  { id: 'lastName', label: 'Nom' },
  { id: 'email', label: 'Email' },
  { id: 'phone', label: 'Téléphone' },
  { id: 'source', label: 'Source' }
];

export function ImportCSV() {
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [isDragging, setIsDragging] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [validationErrors, setValidationErrors] = useState<ValidationError[]>([]);
  const [parsedData, setParsedData] = useState<CSVRow[]>([]);
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const [columnMappings, setColumnMappings] = useState<ColumnMapping[]>([]);
  const [step, setStep] = useState<'upload' | 'mapping' | 'validation'>('upload');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const validateCSVData = (data: CSVRow[]): ValidationError[] => {
    const errors: ValidationError[] = [];

    data.forEach((row, index) => {
      // Get mapped values
      const firstName = row[columnMappings.find(m => m.systemField === 'firstName')?.csvColumn || ''];
      const lastName = row[columnMappings.find(m => m.systemField === 'lastName')?.csvColumn || ''];
      const email = row[columnMappings.find(m => m.systemField === 'email')?.csvColumn || ''];
      const source = row[columnMappings.find(m => m.systemField === 'source')?.csvColumn || ''];

      if (!firstName?.trim()) {
        errors.push({ row: index + 1, field: 'firstName', message: 'Le prénom est requis' });
      }
      if (!lastName?.trim()) {
        errors.push({ row: index + 1, field: 'lastName', message: 'Le nom est requis' });
      }
      if (!email?.trim() || !validateEmail(email)) {
        errors.push({ row: index + 1, field: 'email', message: 'Email invalide' });
      }
      if (!source?.trim()) {
        errors.push({ row: index + 1, field: 'source', message: 'La source est requise' });
      }

      // Check for duplicate email
      const existingLead = leads.find(l => l.email === email);
      if (existingLead) {
        errors.push({ row: index + 1, field: 'email', message: 'Email déjà utilisé' });
      }
    });

    return errors;
  };

  const handleFileUpload = (file: File) => {
    setIsValidating(true);
    setValidationErrors([]);
    setParsedData([]);
    setCsvHeaders([]);
    setColumnMappings([]);

    Papa.parse(file, {
      complete: (results) => {
        if (results.data && results.data.length > 0) {
          const headers = results.data[0] as string[];
          setCsvHeaders(headers);

          const rows = results.data.slice(1) as string[][];
          const parsedRows = rows
            .filter(row => row.some(cell => cell.trim())) // Skip empty rows
            .map(row => {
              return headers.reduce((obj, header, index) => ({
                ...obj,
                [header]: row[index] || ''
              }), {} as CSVRow);
            });

          setParsedData(parsedRows);
          setStep('mapping');
          toast.success('Fichier CSV chargé avec succès');
        } else {
          toast.error('Le fichier CSV est vide');
        }
        setIsValidating(false);
      },
      error: (error) => {
        console.error('Error parsing CSV:', error);
        toast.error('Erreur lors de la lecture du fichier CSV');
        setIsValidating(false);
      }
    });
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const file = e.dataTransfer.files[0];
    if (file && file.type === 'text/csv') {
      handleFileUpload(file);
    } else {
      toast.error('Veuillez sélectionner un fichier CSV');
    }
  };

  const handleColumnMapping = (csvColumn: string, systemField: string) => {
    setColumnMappings(prev => {
      // Remove any existing mapping for this system field
      const filtered = prev.filter(m => m.systemField !== systemField);
      // Add new mapping
      return [...filtered, { csvColumn, systemField }];
    });
  };

  const handleValidateMapping = () => {
    // Check if all required fields are mapped
    const unmappedFields = SYSTEM_FIELDS.filter(field => 
      !columnMappings.find(m => m.systemField === field.id)
    );

    if (unmappedFields.length > 0) {
      toast.error(`Champs requis non mappés: ${unmappedFields.map(f => f.label).join(', ')}`);
      return;
    }

    const errors = validateCSVData(parsedData);
    setValidationErrors(errors);

    if (errors.length === 0) {
      toast.success(`${parsedData.length} leads validés avec succès`);
    } else {
      toast.error(`${errors.length} erreur${errors.length > 1 ? 's' : ''} trouvée${errors.length > 1 ? 's' : ''}`);
    }

    setStep('validation');
  };

  const handleImport = () => {
    if (validationErrors.length > 0 || parsedData.length === 0) return;

    const newLeads: Lead[] = parsedData.map(row => ({
      id: generateId(),
      firstName: row[columnMappings.find(m => m.systemField === 'firstName')?.csvColumn || ''],
      lastName: row[columnMappings.find(m => m.systemField === 'lastName')?.csvColumn || ''],
      email: row[columnMappings.find(m => m.systemField === 'email')?.csvColumn || ''],
      phone: row[columnMappings.find(m => m.systemField === 'phone')?.csvColumn || ''],
      source: row[columnMappings.find(m => m.systemField === 'source')?.csvColumn || ''],
      password: '123456', // Default password
      dateCreated: new Date().toISOString(),
      balance: 0
    }));

    setLeads([...leads, ...newLeads]);
    setParsedData([]);
    setStep('upload');
    toast.success(`${newLeads.length} leads importés avec succès`);

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const renderStep = () => {
    switch (step) {
      case 'upload':
        return (
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={(e) => {
              e.preventDefault();
              setIsDragging(false);
            }}
            onDrop={handleDrop}
            className={cn(
              "relative border-2 border-dashed rounded-xl p-8 transition-all duration-200",
              isDragging
                ? "border-purple-500 bg-purple-500/10"
                : "border-gray-700 hover:border-purple-500/50 hover:bg-gray-800/50"
            )}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  handleFileUpload(file);
                }
              }}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            
            <div className="flex flex-col items-center justify-center space-y-4">
              <div className="p-4 bg-purple-500/10 rounded-full">
                <FileSpreadsheet className="w-8 h-8 text-purple-400" />
              </div>
              <div className="text-center">
                <p className="text-lg font-medium text-white">
                  Déposez votre fichier CSV ici
                </p>
                <p className="text-sm text-gray-400 mt-1">
                  ou cliquez pour sélectionner un fichier
                </p>
              </div>
              <div className="flex items-center justify-center">
                <span className="text-sm text-gray-400">
                  Format CSV uniquement
                </span>
              </div>
            </div>
          </div>
        );

      case 'mapping':
        return (
          <div className="space-y-6">
            <div className="bg-gray-800/50 border border-white/5 rounded-xl p-6">
              <h3 className="text-lg font-medium text-white mb-4">
                Mapping des colonnes
              </h3>
              <div className="space-y-4">
                {SYSTEM_FIELDS.map(field => (
                  <div key={field.id} className="space-y-2">
                    <label className="block text-sm font-medium text-gray-300">
                      {field.label}
                    </label>
                    <select
                      value={columnMappings.find(m => m.systemField === field.id)?.csvColumn || ''}
                      onChange={(e) => handleColumnMapping(e.target.value, field.id)}
                      className="w-full bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 text-white"
                    >
                      <option value="">Sélectionner une colonne</option>
                      {csvHeaders.map(header => (
                        <option key={header} value={header}>{header}</option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-between">
              <motion.button
                onClick={() => setStep('upload')}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="relative group px-4 py-2 rounded-lg overflow-hidden"
              >
                <div className="absolute inset-0 bg-gray-700 opacity-80 group-hover:opacity-100 transition-opacity" />
                <span className="relative flex items-center text-white text-sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Retour
                </span>
              </motion.button>

              <motion.button
                onClick={handleValidateMapping}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="relative group px-4 py-2 rounded-lg overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
                <span className="relative flex items-center text-white text-sm">
                  Valider le mapping
                  <ArrowRight className="w-4 h-4 ml-2" />
                </span>
              </motion.button>
            </div>
          </div>
        );

      case 'validation':
        return (
          <div className="space-y-6">
            {validationErrors.length > 0 ? (
              <div className="bg-red-900/20 border border-red-500/20 rounded-xl p-6">
                <div className="flex items-center mb-4">
                  <XCircle className="w-6 h-6 text-red-400 mr-2" />
                  <h3 className="text-lg font-medium text-red-400">
                    Erreurs de validation
                  </h3>
                </div>
                <div className="space-y-2">
                  {validationErrors.map((error, index) => (
                    <div key={index} className="flex items-start text-sm">
                      <AlertCircle className="w-4 h-4 text-red-400 mr-2 mt-0.5" />
                      <span className="text-red-300">
                        Ligne {error.row} - {error.field}: {error.message}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="bg-green-900/20 border border-green-500/20 rounded-xl p-6">
                <div className="flex items-center mb-4">
                  <CheckCircle className="w-6 h-6 text-green-400 mr-2" />
                  <h3 className="text-lg font-medium text-green-400">
                    Validation réussie
                  </h3>
                </div>
                <p className="text-green-300">
                  {parsedData.length} lead{parsedData.length > 1 ? 's' : ''} prêt{parsedData.length > 1 ? 's' : ''} à être importé{parsedData.length > 1 ? 's' : ''}
                </p>
              </div>
            )}

            <div className="flex justify-between">
              <motion.button
                onClick={() => setStep('mapping')}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="relative group px-4 py-2 rounded-lg overflow-hidden"
              >
                <div className="absolute inset-0 bg-gray-700 opacity-80 group-hover:opacity-100 transition-opacity" />
                <span className="relative flex items-center text-white text-sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Retour au mapping
                </span>
              </motion.button>

              {validationErrors.length === 0 && (
                <motion.button
                  onClick={handleImport}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="relative group px-4 py-2 rounded-lg overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500 opacity-80 group-hover:opacity-100 transition-opacity" />
                  <span className="relative flex items-center text-white text-sm">
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Importer {parsedData.length} lead{parsedData.length > 1 ? 's' : ''}
                  </span>
                </motion.button>
              )}
            </div>
          </div>
        );
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative max-w-4xl mx-auto"
    >
      {/* Background effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl" />
      <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl" />
      
      {/* Content */}
      <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
        <div className="flex justify-between items-start mb-8">
          <div>
            <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Import CSV
            </h2>
            <p className="mt-2 text-gray-400">
              Importez vos leads en masse à partir d'un fichier CSV
            </p>
          </div>
        </div>

        {/* Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-between relative">
            <div className="absolute left-0 right-0 top-1/2 h-0.5 bg-gray-700"></div>
            {['upload', 'mapping', 'validation'].map((s, i) => (
              <div
                key={s}
                className={cn(
                  "relative flex items-center justify-center w-8 h-8 rounded-full",
                  "border-2 transition-colors",
                  step === s
                    ? "border-blue-500 bg-blue-500/20 text-blue-400"
                    : i < ['upload', 'mapping', 'validation'].indexOf(step)
                      ? "border-green-500 bg-green-500/20 text-green-400"
                      : "border-gray-700 bg-gray-800 text-gray-400"
                )}
              >
                {i + 1}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-2">
            <span className="text-sm text-gray-400">Téléchargement</span>
            <span className="text-sm text-gray-400">Mapping</span>
            <span className="text-sm text-gray-400">Validation</span>
          </div>
        </div>

        {renderStep()}
      </div>
    </motion.div>
  );
}