import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  BarChart2, UserPlus, Activity, Settings, 
  LogOut, ArrowLeft, User, MessageSquare, Menu, X
} from 'lucide-react';
import { SidebarLink, StatCard } from '../../common';
import { LeadsList } from '../LeadsManager/LeadsList';
import { SettingsManager } from '../SettingsManager';
import { Chat } from './Chat';
import { Footer } from '../../Footer';
import type { PageType } from '../../../types';
import { getPageTitle } from '../../../utils';
import { getCurrentUser, signOut } from '../../../lib/auth';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { motion, AnimatePresence } from 'framer-motion';

export function SellerDashboard() {
  const navigate = useNavigate();
  const location = useLocation();
  const [activePage, setActivePage] = useState<PageType>('dashboard');
  const [userName, setUserName] = useState<string>('');
  const [showBackButton, setShowBackButton] = useState(false);
  const [leads] = useLocalStorage<Lead[]>('leads', []);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const [settings] = useLocalStorage<any>('homepageSettings', {
    logoMode: 'image',
    logoText: 'Trioptima',
    logoTextColor: '#ffffff'
  });

  // Check if screen is mobile
  const isMobile = typeof window !== 'undefined' ? window.innerWidth < 768 : false;

  // Close sidebar on mobile when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (isMobile && isSidebarOpen && sidebarRef.current && !sidebarRef.current.contains(event.target as Node)) {
        setIsSidebarOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isMobile, isSidebarOpen]);

  // Close sidebar on mobile when changing routes
  useEffect(() => {
    if (isMobile) {
      setIsSidebarOpen(false);
    }
  }, [activePage, isMobile]);

  // Set sidebar state based on screen size
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setIsSidebarOpen(false);
      } else {
        setIsSidebarOpen(true);
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  useEffect(() => {
    const checkUser = async () => {
      const user = await getCurrentUser();
      if (!user || user.role !== 'Seller') {
        navigate('/', { replace: true });
        return;
      }
      
      setUserName(`${user.firstName} ${user.lastName}`);

      // Check if we came from the admin dashboard
      const adminUser = localStorage.getItem('adminUser');
      setShowBackButton(!!adminUser);
    };

    checkUser();
  }, [navigate]);

  useEffect(() => {
    // Check if we have an activeTab in the location state
    if (location.state?.activeTab) {
      setActivePage(location.state.activeTab);
      // Clear the state so it doesn't persist
      window.history.replaceState({}, '');
    }
  }, [location]);

  const handleLogout = async () => {
    const { error } = await signOut();
    if (!error) {
      navigate('/', { replace: true });
    }
  };

  const handleBackToDashboard = () => {
    // Restore admin user session
    const adminUser = localStorage.getItem('adminUser');
    if (adminUser) {
      localStorage.setItem('user', adminUser);
      localStorage.removeItem('adminUser');
    }
    navigate('/dashboard', { replace: true });
  };

  // Get assigned leads for the current seller
  const getCurrentSellerLeads = () => {
    const userStr = localStorage.getItem('user');
    if (!userStr) return [];
    
    const user = JSON.parse(userStr);
    
    // Only return leads that are explicitly assigned to this seller
    // and are not pending registrations
    return leads.filter(lead => 
      lead.assignedTo === user.id && 
      (!lead.isRegistration || lead.registrationStatus === 'approved')
    );
  };

  const calculatePerformance = () => {
    const sellerLeads = getCurrentSellerLeads();
    const totalBalance = sellerLeads.reduce((sum, lead) => sum + (lead.balance || 0), 0);
    const totalTransactions = sellerLeads.reduce((sum, lead) => sum + (lead.transactions?.length || 0), 0);
    
    return {
      totalLeads: sellerLeads.length,
      totalBalance,
      totalTransactions
    };
  };

  const renderContent = () => {
    switch (activePage) {
      case 'dashboard': {
        const performance = calculatePerformance();
        
        return (
          <div className="space-y-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8">
              <StatCard 
                title="Vendeur" 
                value={userName}
                icon={<User className="h-5 w-5 text-blue-600" />}
              />
              <StatCard 
                title="Leads assignés" 
                value={performance.totalLeads.toString()}
                icon={<UserPlus className="h-5 w-5 text-purple-600" />}
              />
              <StatCard 
                title="Balance totale" 
                value={`${performance.totalBalance.toLocaleString()}€`}
                icon={<BarChart2 className="h-5 w-5 text-green-600" />}
              />
              <StatCard 
                title="Transactions" 
                value={performance.totalTransactions.toString()}
                icon={<Activity className="h-5 w-5 text-amber-600" />}
              />
            </div>
          </div>
        );
      }
      case 'leads':
        return <LeadsList />;
      case 'chat':
        return <Chat />;
      case 'settings':
        return <SettingsManager />;
      default:
        return <div className="text-gray-600">Page en construction</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 flex flex-col">
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Mobile Header */}
        <div className="md:hidden flex items-center justify-between p-4 border-b border-gray-700 bg-gray-800">
          <div className="flex items-center">
            {showBackButton && (
              <button
                onClick={handleBackToDashboard}
                className="p-1.5 text-gray-400 hover:text-white transition-colors rounded-md hover:bg-white/5 mr-3"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
            )}
            {settings.logoMode === 'image' ? (
              <BarChart2 className="h-6 w-6 text-blue-600" />
            ) : (
              <span 
                className="font-['Orbitron'] font-bold text-lg"
                style={{ 
                  color: settings.logoTextColor || '#ffffff',
                  textShadow: '0 0 5px currentColor'
                }}
              >
                {settings.logoText || 'Trioptima'}
              </span>
            )}
          </div>
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700"
          >
            {isSidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Sidebar */}
        <AnimatePresence>
          {isSidebarOpen && (
            <motion.div
              ref={sidebarRef}
              initial={{ x: -300, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -300, opacity: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="fixed md:relative z-40 md:z-auto inset-y-0 left-0 w-72 border-r border-gray-700 flex flex-col bg-opacity-95 md:bg-opacity-100 backdrop-blur-lg md:backdrop-blur-none bg-gray-900"
            >
              {/* Logo - Hidden on mobile */}
              <div className="hidden md:flex h-16 px-6 border-b border-gray-700 items-center">
                {showBackButton && (
                  <button
                    onClick={handleBackToDashboard}
                    className="p-1.5 text-gray-400 hover:text-white transition-colors rounded-md hover:bg-white/5 mr-3"
                  >
                    <ArrowLeft className="h-5 w-5" />
                  </button>
                )}
                <div className="flex items-center">
                  {settings.logoMode === 'image' ? (
                    <BarChart2 className="h-8 w-8 text-blue-600" />
                  ) : (
                    <span 
                      className="font-['Orbitron'] font-bold text-lg"
                      style={{ 
                        color: settings.logoTextColor || '#ffffff',
                        textShadow: '0 0 5px currentColor'
                      }}
                    >
                      {settings.logoText || 'Trioptima'}
                    </span>
                  )}
                </div>
              </div>

              {/* Navigation */}
              <nav className="flex-1 overflow-y-auto py-6">
                <div className="px-4 space-y-1">
                  <SidebarLink 
                    icon={BarChart2} 
                    text="Tableau de bord"
                    isActive={activePage === 'dashboard'}
                    onClick={() => setActivePage('dashboard')}
                  />
                  <SidebarLink 
                    icon={UserPlus} 
                    text="Mes Leads"
                    isActive={activePage === 'leads'}
                    onClick={() => setActivePage('leads')}
                  />
                  <SidebarLink 
                    icon={MessageSquare} 
                    text="Chat"
                    isActive={activePage === 'chat'}
                    onClick={() => setActivePage('chat')}
                  />
                  <SidebarLink 
                    icon={Settings} 
                    text="Paramètres"
                    isActive={activePage === 'settings'}
                    onClick={() => setActivePage('settings')}
                  />
                </div>
              </nav>

              {/* Logout Button */}
              <div className="p-4 border-t border-gray-700">
                <SidebarLink 
                  icon={LogOut} 
                  text="Déconnexion"
                  onClick={handleLogout}
                  variant="danger"
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Mobile sidebar overlay */}
        {isSidebarOpen && isMobile && (
          <div 
            className="fixed inset-0 bg-black bg-opacity-50 z-30"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}

        {/* Main Content */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Header - Hidden on mobile as we have the top header */}
          <header className="hidden md:block bg-gray-800 border-b border-gray-700">
            <div className="h-16 px-6 flex items-center">
              <h1 className="text-2xl font-bold text-white">
                {getPageTitle(activePage)}
              </h1>
            </div>
          </header>

          {/* Main Content Area */}
          <main className="flex-1 overflow-auto p-4 md:p-8 bg-gray-900">
            {renderContent()}
          </main>
          
          {/* Footer */}
          <Footer />
        </div>
      </div>
    </div>
  );
}