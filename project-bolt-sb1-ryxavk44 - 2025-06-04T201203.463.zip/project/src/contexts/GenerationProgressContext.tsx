import React, { createContext, useContext, useState } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';
import type { EnergyOffer } from '../types';

interface GenerationProgressContextType {
  generationInProgress: boolean;
  setGenerationInProgress: (value: boolean) => void;
  scheduledOffers: EnergyOffer[];
  setScheduledOffers: (offers: EnergyOffer[]) => void;
  currentOfferIndex: number;
  setCurrentOfferIndex: (index: number) => void;
  generationProgress: number;
  setGenerationProgress: (progress: number) => void;
  generationStartTime: string | null;
  setGenerationStartTime: (time: string | null) => void;
  generationEndTime: string | null;
  setGenerationEndTime: (time: string | null) => void;
  currentCampaignId: string | null;
  setCurrentCampaignId: (id: string | null) => void;
  generatedOffers: EnergyOffer[];
  setGeneratedOffers: (offers: EnergyOffer[]) => void;
}

const GenerationProgressContext = createContext<GenerationProgressContextType | undefined>(undefined);

export const useGenerationProgress = (): GenerationProgressContextType => {
  const context = useContext(GenerationProgressContext);
  if (!context) {
    throw new Error('useGenerationProgress must be used within a GenerationProgressProvider');
  }
  return context;
};

export const GenerationProgressProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [generationInProgress, setGenerationInProgress] = useLocalStorage('generationInProgress', false);
  const [scheduledOffers, setScheduledOffers] = useLocalStorage<EnergyOffer[]>('scheduledOffers', []);
  const [currentOfferIndex, setCurrentOfferIndex] = useLocalStorage('currentOfferIndex', 0);
  const [generationProgress, setGenerationProgress] = useLocalStorage('generationProgress', 0);
  const [generationStartTime, setGenerationStartTime] = useLocalStorage<string | null>('generationStartTime', null);
  const [generationEndTime, setGenerationEndTime] = useLocalStorage<string | null>('generationEndTime', null);
  const [currentCampaignId, setCurrentCampaignId] = useLocalStorage<string | null>('currentCampaignId', null);
  const [generatedOffers, setGeneratedOffers] = useLocalStorage<EnergyOffer[]>('generatedOffers', []);

  const value = {
    generationInProgress,
    setGenerationInProgress,
    scheduledOffers,
    setScheduledOffers,
    currentOfferIndex,
    setCurrentOfferIndex,
    generationProgress,
    setGenerationProgress,
    generationStartTime,
    setGenerationStartTime,
    generationEndTime,
    setGenerationEndTime,
    currentCampaignId,
    setCurrentCampaignId,
    generatedOffers,
    setGeneratedOffers
  };

  return (
    <GenerationProgressContext.Provider value={value}>
      {children}
    </GenerationProgressContext.Provider>
  );
};