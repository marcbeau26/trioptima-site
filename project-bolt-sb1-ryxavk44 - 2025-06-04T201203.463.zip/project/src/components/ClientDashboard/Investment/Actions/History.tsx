import React from 'react';
import { TrendingUp, TrendingDown, Hash, Wallet } from 'lucide-react';
import type { Lead, Transaction } from '../../../../types';
import { formatDate } from '../../../../utils';

export function History() {
  const currentLeadStr = localStorage.getItem('currentLead');
  const currentLead = currentLeadStr ? JSON.parse(currentLeadStr) as Lead : null;

  if (!currentLead || !currentLead.transactions || currentLead.transactions.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500 dark:text-gray-400">
        Aucune transaction à afficher
      </div>
    );
  }

  // Filter only stock action transactions
  // This includes:
  // 1. Investment transactions for stock actions (not containing "MW d'énergie")
  // 2. Sale transactions for stock actions (containing "action" and not containing "MW")
  const actionTransactions = currentLead.transactions
    .filter(t => {
      // Check if it's a stock action investment
      if (t.type === 'investment' && !t.description.includes("MW d'énergie") && t.description.includes("action")) {
        return true;
      }
      // Check if it's a stock action sale (future implementation)
      if (t.type === 'sale' && t.description.includes("action") && !t.description.includes("MW")) {
        return true;
      }
      return false;
    })
    .map(transaction => {
      // For sale transactions, extract additional details (future implementation)
      if (transaction.type === 'sale') {
        // Extract purchase price from description
        const purchaseMatch = transaction.description.match(/Achat: ([\d,]+)€/);
        if (!purchaseMatch) return transaction;

        const purchasePrice = parseFloat(purchaseMatch[1].replace(/,/g, ''));
        const salePrice = transaction.amount;
        const profit = salePrice - purchasePrice;
        const profitPercentage = (profit / purchasePrice) * 100;

        // Extract reference from description
        const refMatch = transaction.description.match(/Réf: ([A-Z0-9]+)/);
        const reference = refMatch ? refMatch[1] : null;

        // Calculate balance before and after the transaction
        const transactionIndex = currentLead.transactions.findIndex(t => t.id === transaction.id);
        const previousTransactions = currentLead.transactions.slice(0, transactionIndex);
        
        // Calculate the balance before this transaction
        const balanceBefore = previousTransactions.reduce((sum, t) => {
          if (t.type === 'deposit') return sum + t.amount;
          if (t.type === 'withdrawal') return sum - Math.abs(t.amount);
          if (t.type === 'investment') return sum + t.amount; // Investments are negative
          if (t.type === 'sale') return sum + t.amount; // Sales are positive
          if (t.type === 'trading') return sum + t.amount; // Trading can be positive or negative
          return sum;
        }, 0);
        
        // Calculate the balance after this transaction
        const balanceAfter = balanceBefore + salePrice;

        return {
          ...transaction,
          purchasePrice,
          salePrice,
          profit,
          profitPercentage,
          reference,
          balanceBefore,
          balanceAfter
        };
      }
      
      // For investment transactions, just extract the reference
      const refMatch = transaction.description.match(/Réf: ([A-Z0-9]+)/);
      const reference = refMatch ? refMatch[1] : null;
      
      // Calculate balance before and after the transaction
      const transactionIndex = currentLead.transactions.findIndex(t => t.id === transaction.id);
      const previousTransactions = currentLead.transactions.slice(0, transactionIndex);
      
      // Calculate the balance before this transaction
      const balanceBefore = previousTransactions.reduce((sum, t) => {
        if (t.type === 'deposit') return sum + t.amount;
        if (t.type === 'withdrawal') return sum - Math.abs(t.amount);
        if (t.type === 'investment') return sum + t.amount; // Investments are negative
        if (t.type === 'sale') return sum + t.amount; // Sales are positive
        if (t.type === 'trading') return sum + t.amount; // Trading can be positive or negative
        return sum;
      }, 0);
      
      // Calculate the balance after this transaction
      const balanceAfter = balanceBefore + transaction.amount;
      
      return {
        ...transaction,
        reference,
        balanceBefore,
        balanceAfter
      };
    })
    .sort((a, b) => new Date(b.dateCreated).getTime() - new Date(a.dateCreated).getTime());

  return (
    <div className="space-y-6">
      {actionTransactions.map((transaction) => {
        // For investment transactions
        if (transaction.type === 'investment') {
          return (
            <div 
              key={transaction.id}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6"
            >
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                    Souscription d'action
                  </h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {formatDate(transaction.dateCreated)}
                  </p>
                </div>
              </div>

              {/* Reference display */}
              {transaction.reference && (
                <div className="mb-4 flex justify-center">
                  <div className="reference-tag py-2 px-4 rounded-lg">
                    <div className="flex items-center justify-center">
                      <Hash className="h-5 w-5 text-blue-400 mr-2" />
                      <span className="text-lg font-mono font-bold text-blue-300 tracking-widest">
                        RÉF: {transaction.reference}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500 dark:text-gray-400">Description</span>
                  <span className="text-gray-900 dark:text-white font-medium">
                    {transaction.description}
                  </span>
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-gray-500 dark:text-gray-400">Montant investi</span>
                  <span className="text-gray-900 dark:text-white font-medium">
                    {Math.abs(transaction.amount).toLocaleString()}€
                  </span>
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-gray-500 dark:text-gray-400">Type</span>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-800 dark:text-blue-100">
                    Souscription d'action
                  </span>
                </div>
              </div>

              {/* Balance Information Section */}
              <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3 flex items-center">
                  <Wallet className="w-4 h-4 mr-2 text-blue-500" />
                  Impact sur le solde
                </h4>
                <div className="grid grid-cols-2 gap-6">
                  <div className="bg-gray-50 dark:bg-gray-700/30 rounded-lg p-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500 dark:text-gray-400">Solde avant opération</span>
                      <span className="font-medium text-gray-900 dark:text-white">
                        {transaction.balanceBefore.toLocaleString()}€
                      </span>
                    </div>
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-700/30 rounded-lg p-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500 dark:text-gray-400">Solde après opération</span>
                      <span className="font-medium text-gray-900 dark:text-white">
                        {transaction.balanceAfter.toLocaleString()}€
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        }
        
        // For sale transactions (future implementation)
        if (transaction.type === 'sale') {
          return (
            <div 
              key={transaction.id}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6"
            >
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                    Vente d'action
                  </h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {formatDate(transaction.dateCreated)}
                  </p>
                </div>
                {transaction.profitPercentage && (
                  <div className="flex items-center">
                    {transaction.profit >= 0 ? (
                      <div className="flex items-center text-green-600 dark:text-green-400">
                        <TrendingUp className="h-5 w-5 mr-1" />
                        <span className="font-medium">
                          +{transaction.profitPercentage.toFixed(2)}%
                        </span>
                      </div>
                    ) : (
                      <div className="flex items-center text-red-600 dark:text-red-400">
                        <TrendingDown className="h-5 w-5 mr-1" />
                        <span className="font-medium">
                          {transaction.profitPercentage.toFixed(2)}%
                        </span>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Reference display */}
              {transaction.reference && (
                <div className="mb-4 flex justify-center">
                  <div className="reference-tag py-2 px-4 rounded-lg">
                    <div className="flex items-center justify-center">
                      <Hash className="h-5 w-5 text-blue-400 mr-2" />
                      <span className="text-lg font-mono font-bold text-blue-300 tracking-widest">
                        RÉF: {transaction.reference}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500 dark:text-gray-400">Description</span>
                  <span className="text-gray-900 dark:text-white font-medium">
                    {transaction.description}
                  </span>
                </div>

                {transaction.purchasePrice && (
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        Résultat financier
                      </h4>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-500 dark:text-gray-400">Montant investi</span>
                          <span className="font-medium text-gray-900 dark:text-white">
                            {transaction.purchasePrice.toLocaleString()}€
                          </span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-500 dark:text-gray-400">Montant reçu</span>
                          <span className="font-medium text-gray-900 dark:text-white">
                            {transaction.salePrice.toLocaleString()}€
                          </span>
                        </div>
                        <div className="flex justify-between text-sm pt-2 border-t border-gray-200 dark:border-gray-700">
                          <span className="font-medium text-gray-700 dark:text-gray-300">Profit net</span>
                          <span className={`font-medium ${
                            transaction.profit >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                          }`}>
                            {transaction.profit >= 0 ? '+' : ''}{transaction.profit.toLocaleString()}€
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Balance Information Section */}
              <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3 flex items-center">
                  <Wallet className="w-4 h-4 mr-2 text-blue-500" />
                  Impact sur le solde
                </h4>
                <div className="grid grid-cols-2 gap-6">
                  <div className="bg-gray-50 dark:bg-gray-700/30 rounded-lg p-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500 dark:text-gray-400">Solde avant opération</span>
                      <span className="font-medium text-gray-900 dark:text-white">
                        {transaction.balanceBefore.toLocaleString()}€
                      </span>
                    </div>
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-700/30 rounded-lg p-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500 dark:text-gray-400">Solde après opération</span>
                      <span className="font-medium text-gray-900 dark:text-white">
                        {transaction.balanceAfter.toLocaleString()}€
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        }
        
        return null;
      })}

      {actionTransactions.length === 0 && (
        <div className="text-center py-12 text-gray-500 dark:text-gray-400">
          Aucune transaction d'action à afficher
        </div>
      )}
    </div>
  );
}