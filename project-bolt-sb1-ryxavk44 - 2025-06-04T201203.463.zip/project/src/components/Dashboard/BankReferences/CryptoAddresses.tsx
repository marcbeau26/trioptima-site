import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Copy } from 'lucide-react';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { generateId } from '../../../utils';
import { toast } from 'react-hot-toast';
import { motion } from 'framer-motion';
import { cn } from '../../../utils/cn';

interface CryptoAddress {
  id: string;
  name: string;
  network: string;
  address: string;
  dateCreated: string;
  label?: string;
}

export function CryptoAddresses() {
  const [addresses, setAddresses] = useLocalStorage<CryptoAddress[]>('cryptoAddresses', []);
  const [selectedAddresses, setSelectedAddresses] = useState<string[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    network: '',
    address: '',
    label: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    if (!formData.name.trim()) {
      setErrors(prev => ({ ...prev, name: 'Le nom de la crypto-monnaie est requis' }));
      return;
    }
    if (!formData.network.trim()) {
      setErrors(prev => ({ ...prev, network: 'Le réseau est requis' }));
      return;
    }
    if (!formData.address.trim()) {
      setErrors(prev => ({ ...prev, address: 'L\'adresse est requise' }));
      return;
    }
    
    const newAddress: CryptoAddress = {
      ...formData,
      id: generateId(),
      dateCreated: new Date().toISOString()
    };

    setAddresses([...addresses, newAddress]);
    setFormData({ name: '', network: '', address: '', label: '' });
    setShowForm(false);
    toast.success('Adresse crypto ajoutée avec succès');
  };

  const handleDelete = () => {
    setAddresses(addresses.filter(address => !selectedAddresses.includes(address.id)));
    setSelectedAddresses([]);
    toast.success('Adresses crypto supprimées');
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Adresse copiée dans le presse-papier');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-medium text-gray-900 dark:text-white">
          Adresses Crypto
        </h2>
        <button
          onClick={() => setShowForm(!showForm)}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
        >
          <Plus size={20} className="mr-2" />
          Ajouter une adresse
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6 space-y-4">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                Nom de la crypto-monnaie
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className={cn(
                  "mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white",
                  errors.name && "border-red-500 focus:ring-red-500"
                )}
                required
                placeholder="Ex: Bitcoin, Ethereum, etc."
              />
              {errors.name && (
                <p className="mt-1 text-sm text-red-500">{errors.name}</p>
              )}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                Réseau
              </label>
              <input
                type="text"
                value={formData.network}
                onChange={(e) => setFormData({ ...formData, network: e.target.value })}
                className={cn(
                  "mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white",
                  errors.network && "border-red-500 focus:ring-red-500"
                )}
                required
                placeholder="Ex: BTC, ETH, BSC, etc."
              />
              {errors.network && (
                <p className="mt-1 text-sm text-red-500">{errors.network}</p>
              )}
            </div>
            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                Adresse
              </label>
              <input
                type="text"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className={cn(
                  "mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white",
                  errors.address && "border-red-500 focus:ring-red-500"
                )}
                required
                placeholder="Entrez l'adresse du portefeuille"
              />
              {errors.address && (
                <p className="mt-1 text-sm text-red-500">{errors.address}</p>
              )}
            </div>
            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                Libellé (optionnel)
              </label>
              <input
                type="text"
                value={formData.label || ''}
                onChange={(e) => setFormData({ ...formData, label: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                placeholder="Ex: Adresse de dépôt principale"
              />
            </div>
          </div>
          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md dark:bg-gray-600 dark:text-gray-300 dark:hover:bg-gray-500"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md"
            >
              Enregistrer
            </button>
          </div>
        </form>
      )}

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-800">
            <tr>
              <th scope="col" className="px-6 py-3 text-left">
                <input
                  type="checkbox"
                  checked={selectedAddresses.length === addresses.length && addresses.length > 0}
                  onChange={() => {
                    if (selectedAddresses.length === addresses.length) {
                      setSelectedAddresses([]);
                    } else {
                      setSelectedAddresses(addresses.map(address => address.id));
                    }
                  }}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700"
                />
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Crypto-monnaie
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Réseau
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Adresse
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Libellé
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200 dark:bg-gray-900 dark:divide-gray-700">
            {addresses.map((address) => (
              <tr key={address.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                <td className="px-6 py-4 whitespace-nowrap">
                  <input
                    type="checkbox"
                    checked={selectedAddresses.includes(address.id)}
                    onChange={() => {
                      if (selectedAddresses.includes(address.id)) {
                        setSelectedAddresses(selectedAddresses.filter(id => id !== address.id));
                      } else {
                        setSelectedAddresses([...selectedAddresses, address.id]);
                      }
                    }}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700"
                  />
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                  {address.name}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                  {address.network}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white font-mono">
                  <div className="flex items-center">
                    <span className="truncate max-w-xs">{address.address}</span>
                    <button
                      onClick={() => handleCopy(address.address)}
                      className="ml-2 text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                    >
                      <Copy size={16} />
                    </button>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                  {address.label || '-'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                  <button
                    onClick={() => {
                      setSelectedAddresses([address.id]);
                      handleDelete();
                    }}
                    className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                  >
                    <Trash2 size={16} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {addresses.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 dark:text-gray-400">
              Aucune adresse crypto trouvée
            </p>
          </div>
        )}
      </div>

      {selectedAddresses.length > 0 && (
        <div className="mt-4">
          <button
            onClick={handleDelete}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700"
          >
            <Trash2 size={16} className="mr-2" />
            Supprimer ({selectedAddresses.length})
          </button>
        </div>
      )}
    </div>
  );
}