import React, { useState } from 'react';
import { Plus, Trash2, Check, Copy, AlertCircle } from 'lucide-react';
import type { CryptoAddress, Lead } from '../../../types';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { toast } from 'react-hot-toast';
import { generateId } from '../../../utils';
import { cn } from '../../../utils/cn';
import { motion } from 'framer-motion';

interface AddressFormData {
  network: string;
  currency: string;
  address: string;
  label?: string;
}

const initialFormData: AddressFormData = {
  network: '',
  currency: '',
  address: '',
  label: ''
};

export function CryptoAddresses() {
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState<AddressFormData>(initialFormData);
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const currentLeadStr = localStorage.getItem('currentLead');
  const currentLead = currentLeadStr ? JSON.parse(currentLeadStr) as Lead : null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    if (!formData.network.trim()) {
      setErrors(prev => ({ ...prev, network: 'Le réseau est requis' }));
      return;
    }
    if (!formData.currency.trim()) {
      setErrors(prev => ({ ...prev, currency: 'La crypto-monnaie est requise' }));
      return;
    }
    if (!formData.address.trim()) {
      setErrors(prev => ({ ...prev, address: 'L\'adresse est requise' }));
      return;
    }

    const newAddress: CryptoAddress = {
      id: generateId(),
      network: formData.network,
      currency: formData.currency,
      address: formData.address,
      label: formData.label,
      dateCreated: new Date().toISOString(),
      isDefault: !(currentLead?.cryptoAddresses || []).length
    };

    if (!currentLead) return;

    const updatedLeads = leads.map(lead => {
      if (lead.id === currentLead.id) {
        return {
          ...lead,
          cryptoAddresses: [...(lead.cryptoAddresses || []), newAddress]
        };
      }
      return lead;
    });

    setLeads(updatedLeads);
    const updatedLead = updatedLeads.find(l => l.id === currentLead.id);
    if (updatedLead) {
      localStorage.setItem('currentLead', JSON.stringify(updatedLead));
    }

    setFormData(initialFormData);
    setShowForm(false);
    toast.success('Adresse ajoutée avec succès');
  };

  const handleDelete = (addressId: string) => {
    if (!currentLead) return;

    const updatedLeads = leads.map(lead => {
      if (lead.id === currentLead.id) {
        return {
          ...lead,
          cryptoAddresses: (lead.cryptoAddresses || []).filter(addr => addr.id !== addressId)
        };
      }
      return lead;
    });

    setLeads(updatedLeads);
    const updatedLead = updatedLeads.find(l => l.id === currentLead.id);
    if (updatedLead) {
      localStorage.setItem('currentLead', JSON.stringify(updatedLead));
    }

    toast.success('Adresse supprimée');
  };

  const handleSetDefault = (addressId: string) => {
    if (!currentLead) return;

    const updatedLeads = leads.map(lead => {
      if (lead.id === currentLead.id) {
        return {
          ...lead,
          cryptoAddresses: (lead.cryptoAddresses || []).map(addr => ({
            ...addr,
            isDefault: addr.id === addressId
          }))
        };
      }
      return lead;
    });

    setLeads(updatedLeads);
    const updatedLead = updatedLeads.find(l => l.id === currentLead.id);
    if (updatedLead) {
      localStorage.setItem('currentLead', JSON.stringify(updatedLead));
    }

    toast.success('Adresse définie par défaut');
  };

  const handleCopy = (address: string) => {
    navigator.clipboard.writeText(address);
    toast.success('Adresse copiée dans le presse-papier');
  };

  if (!currentLead) return null;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
          Mes adresses de retrait
        </h2>
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setShowForm(!showForm)}
          className="relative group overflow-hidden px-6 py-2 rounded-xl"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
          <div className="relative flex items-center text-white">
            <Plus size={20} className="mr-2" />
            <span className="font-medium">Ajouter une adresse</span>
          </div>
        </motion.button>
      </div>

      {showForm && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative"
        >
          {/* Background effects */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl" />
          <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl" />
          
          {/* Content */}
          <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Réseau
                  </label>
                  <input
                    type="text"
                    value={formData.network}
                    onChange={(e) => setFormData({ ...formData, network: e.target.value })}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                      errors.network && "border-red-500/50 focus:ring-red-500/50"
                    )}
                    placeholder="Ex: TRC20, ERC20"
                  />
                  {errors.network && (
                    <p className="mt-2 text-sm text-red-400">{errors.network}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Crypto-monnaie
                  </label>
                  <input
                    type="text"
                    value={formData.currency}
                    onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                      errors.currency && "border-red-500/50 focus:ring-red-500/50"
                    )}
                    placeholder="Ex: USDT, Bitcoin, Ethereum"
                  />
                  {errors.currency && (
                    <p className="mt-2 text-sm text-red-400">{errors.currency}</p>
                  )}
                </div>

                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Adresse
                  </label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                      errors.address && "border-red-500/50 focus:ring-red-500/50"
                    )}
                    placeholder="Entrez votre adresse crypto"
                  />
                  {errors.address && (
                    <p className="mt-2 text-sm text-red-400">{errors.address}</p>
                  )}
                </div>

                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Label (optionnel)
                  </label>
                  <input
                    type="text"
                    value={formData.label || ''}
                    onChange={(e) => setFormData({ ...formData, label: e.target.value })}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-pink-500/50 focus:border-pink-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200"
                    )}
                    placeholder="Ex: Mon portefeuille principal"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-3">
                <motion.button
                  type="button"
                  onClick={() => setShowForm(false)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="px-6 py-3 text-sm font-medium text-gray-300 bg-gray-800/50 hover:bg-gray-700/50 rounded-lg backdrop-blur-sm transition-colors"
                >
                  Annuler
                </motion.button>
                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="relative group px-6 py-3 rounded-lg overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
                  <span className="relative text-sm font-medium text-white">
                    Ajouter
                  </span>
                </motion.button>
              </div>
            </form>
          </div>
        </motion.div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {currentLead.cryptoAddresses?.map((address, index) => (
          <motion.div
            key={address.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="relative group"
          >
            {/* Card glow effect */}
            <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200" />
            
            {/* Card content */}
            <div className="relative bg-gray-900 rounded-xl p-6">
              <div className="flex justify-between items-start">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <h3 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                      {address.currency}
                    </h3>
                    {address.isDefault && (
                      <span className="px-2 py-1 text-xs font-medium bg-green-500/10 text-green-400 rounded-full border border-green-500/20">
                        Par défaut
                      </span>
                    )}
                  </div>
                  {address.label && (
                    <p className="text-sm text-gray-400">
                      {address.label}
                    </p>
                  )}
                  <div className="flex items-center space-x-2">
                    <span className="px-2 py-1 text-xs font-medium bg-blue-500/10 text-blue-400 rounded-full border border-blue-500/20">
                      {address.network}
                    </span>
                    <code className="text-sm font-mono text-gray-300">
                      {address.address}
                    </code>
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => handleCopy(address.address)}
                      className="p-1 text-blue-400 hover:text-blue-300 transition-colors"
                    >
                      <Copy size={16} />
                    </motion.button>
                  </div>
                </div>
                <div className="flex space-x-2">
                  {!address.isDefault && (
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => handleSetDefault(address.id)}
                      className="p-1.5 bg-green-500/10 text-green-400 rounded-lg hover:bg-green-500/20 transition-colors"
                    >
                      <Check size={16} />
                    </motion.button>
                  )}
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => handleDelete(address.id)}
                    className="p-1.5 bg-red-500/10 text-red-400 rounded-lg hover:bg-red-500/20 transition-colors"
                  >
                    <Trash2 size={16} />
                  </motion.button>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {(!currentLead.cryptoAddresses || currentLead.cryptoAddresses.length === 0) && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden rounded-xl"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 via-purple-500/5 to-pink-500/5 animate-gradient-xy" />
          <div className="relative flex flex-col items-center justify-center py-12 px-4">
            <AlertCircle className="h-12 w-12 text-gray-600 mb-4" />
            <h3 className="text-lg font-medium text-gray-300">
              Aucune adresse
            </h3>
            <p className="mt-2 text-sm text-gray-500 text-center max-w-sm">
              Commencez par ajouter une adresse crypto pour les retraits.
            </p>
          </div>
        </motion.div>
      )}
    </div>
  );
}