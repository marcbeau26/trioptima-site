export const generateId = () => Math.random().toString(36).substr(2, 9);

export const formatDate = (date: string) => {
  const d = new Date(date);
  return d.toLocaleString('fr-FR', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  });
};

export const formatPrice = (price: number): string => {
  return price.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
};

export const getPageTitle = (page: string) => {
  // Get current user role
  const userStr = localStorage.getItem('user');
  const user = userStr ? JSON.parse(userStr) : null;
  const isSeller = user?.role === 'Seller';

  const titles = {
    dashboard: isSeller ? 'Tableau de bord seller' : 'Tableau de bord',
    users: 'Gestionnaire d\'Utilisateurs',
    leads: isSeller ? 'Mes Leads seller' : 'Mes Leads',
    'bulk-leads': 'Leads en Masse',
    'offer-generator': 'Générateur d\'Offres',
    status: 'Gestion des Statuts',
    settings: isSeller ? 'Paramètres seller' : 'Paramètres',
    investment: 'Investissement',
    offers: 'Énergie',
    stock: 'Stock Énergie',
    actions: 'Journal des Actions',
    'bank-references': 'Gestion des Références Bancaires',
    'subscribed-actions': 'Actions souscrites',
    'chat-admin': 'Chat Admin',
    'chat': isSeller ? 'Chat seller' : 'Chat',
    'homepage': 'Gestion de la page d\'accueil',
    'funds': 'Gestion des fonds',
    'history': 'Historique Général',
    'visa-deposit': 'Dépôt Visa',
    'livret': 'Gestionnaire de Livret',
    'platform-editor': 'Édition plateforme',
    'products': 'Liste des produits',
    'trading': 'Trading',
    'trading-api': 'Trading API',
    'registrations': 'Inscriptions'
  };
  return titles[page] || 'Page en construction';
};

// Generate a random alphanumeric reference of specified length
export const generateReference = (length: number): string => {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
};