import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Clock, Zap, DollarSign, Building2, AlertCircle, Info, Hash, Image as ImageIcon, X, Search, Folder, Euro, Package, Calendar, Gift } from 'lucide-react';
import type { StockAction, Logo } from '../../../types';
import { generateId, generateReference } from '../../../utils';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';

// Logo selector modal component
interface LogoSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (logoUrl: string) => void;
}

function LogoSelectorModal({ isOpen, onClose, onSelect }: LogoSelectorModalProps) {
  const [logos, setLogos] = useLocalStorage<Logo[]>('logos', []);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');

  // Get unique categories
  const categories = Array.from(new Set(logos.map(logo => logo.category))).filter(Boolean);

  // Filter logos based on search term and category
  const filteredLogos = logos.filter(logo => {
    const matchesSearch = logo.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter ? logo.category === categoryFilter : true;
    
    return matchesSearch && matchesCategory;
  });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-4xl mx-4 max-h-[90vh] overflow-auto"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <div className="flex justify-between items-start mb-6">
            <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Sélectionner un Logo
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-300 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-wrap gap-2">
            {/* Search filter */}
            <div className="relative w-full md:w-64">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Rechercher un logo..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-gray-800/50 border border-gray-700/50 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>
            
            {/* Category Filter */}
            <div className="relative">
              <Folder className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
              <select
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-9 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/50 appearance-none"
              >
                <option value="">Toutes les catégories</option>
                {categories.map((category) => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Logos Grid */}
          {filteredLogos.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
              {filteredLogos.map((logo) => (
                <motion.div
                  key={logo.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="relative group cursor-pointer"
                  onClick={() => {
                    onSelect(logo.imageUrl);
                    onClose();
                  }}
                >
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl opacity-30 group-hover:opacity-100 transition duration-300"></div>
                  <div className="relative bg-gray-800 rounded-lg p-4 flex flex-col items-center">
                    <div className="w-full aspect-square bg-[#1a1a1a] flex items-center justify-center mb-2">
                      <img 
                        src={logo.imageUrl} 
                        alt={logo.name} 
                        className="max-w-full max-h-full object-contain p-2"
                      />
                    </div>
                    <p className="text-sm text-white text-center truncate w-full">{logo.name}</p>
                    {logo.category && (
                      <span className="mt-1 px-2 py-0.5 text-xs bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded-full">
                        {logo.category}
                      </span>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-gray-800/30 border border-gray-700/50 rounded-lg mt-6">
              <ImageIcon className="w-12 h-12 mx-auto mb-4 text-gray-600" />
              <h3 className="text-lg font-medium text-gray-300">
                Aucun logo trouvé
              </h3>
              <p className="text-gray-500 max-w-sm mx-auto mt-2">
                {searchTerm || categoryFilter
                  ? "Aucun logo ne correspond à vos critères de recherche."
                  : "Vous n'avez pas encore créé de logos. Utilisez l'outil de transparence pour en créer."}
              </p>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}

type StockActionFormData = Omit<StockAction, 'id' | 'dateCreated' | 'status' | 'reference'> & {
  showPracticalInfo?: boolean;
};

const initialFormData: StockActionFormData = {
  name: '',
  price: 0,
  priceUSD: 0,
  currentMarketPrice: 0,
  currentMarketPriceUSD: 0,
  minQuantity: 0,
  maxQuantity: 0,
  startDate: new Date().toISOString().split('T')[0],
  holdingPeriodDays: 0,
  holdingPeriodMonths: 0,
  holdingPeriodYears: 0,
  safetyNet: 0,
  safetyNetUSD: 0,
  bonusShares: 0,
  practicalInfo: '',
  showPracticalInfo: false,
  logoUrl: undefined
};

// Custom Quill modules configuration
const modules = {
  toolbar: [
    [{ 'header': [1, 2, 3, false] }],
    ['bold', 'italic'],
    [{ 'color': [
      '#FFFFFF', // White
      '#60A5FA', // Blue
      '#34D399', // Green
      '#F87171', // Red
      '#FBBF24', // Yellow
      '#A78BFA', // Purple
      '#EC4899'  // Pink
    ]}],
    [{ 'align': [] }],
    ['clean']
  ]
};

const formats = [
  'header',
  'bold', 'italic',
  'color',
  'align'
];

// Custom CSS for Quill editor
const quillStyles = `
  .ql-editor {
    font-family: 'Space Grotesk', -apple-system, BlinkMacSystemFont, sans-serif;
    letter-spacing: -0.025em;
    min-height: 200px;
    max-height: 400px;
    resize: vertical;
    overflow-y: auto;
    color: white !important;
    font-size: 16px;
    line-height: 1.75;
  }
  
  .ql-editor p {
    margin: 1.5em 0;
  }
  
  .ql-editor h1 {
    font-size: 2em;
    font-weight: 700;
    background: linear-gradient(to right, #60A5FA, #A78BFA);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin: 1.5em 0 1em;
  }
  
  .ql-editor h2 {
    font-size: 1.5em;
    font-weight: 600;
    color: #60A5FA;
    margin: 1.3em 0 0.8em;
  }
  
  .ql-editor h3 {
    font-size: 1.25em;
    font-weight: 600;
    color: #A78BFA;
    margin: 1.2em 0 0.7em;
  }
  
  .ql-editor strong {
    color: #F9FAFB;
    font-weight: 600;
  }
  
  .ql-editor em {
    font-style: italic;
    color: #D1D5DB;
  }
  
  .ql-toolbar {
    background-color: rgba(31, 41, 55, 0.5);
    border-color: rgba(255, 255, 255, 0.1) !important;
    border-top-left-radius: 0.5rem;
    border-top-right-radius: 0.5rem;
  }
  
  .ql-container {
    background-color: rgba(17, 24, 39, 0.5);
    border-color: rgba(255, 255, 255, 0.1) !important;
    border-bottom-left-radius: 0.5rem;
    border-bottom-right-radius: 0.5rem;
  }
  
  .ql-stroke {
    stroke: #9CA3AF !important;
  }
  
  .ql-fill {
    fill: #9CA3AF !important;
  }
  
  .ql-picker {
    color: #9CA3AF !important;
  }
  
  .ql-picker-options {
    background-color: #1F2937 !important;
    border-color: rgba(255, 255, 255, 0.1) !important;
  }
  
  .ql-toolbar button:hover .ql-stroke,
  .ql-toolbar button.ql-active .ql-stroke {
    stroke: #60A5FA !important;
  }
  
  .ql-toolbar button:hover .ql-fill,
  .ql-toolbar button.ql-active .ql-fill {
    fill: #60A5FA !important;
  }
  
  .ql-toolbar button:hover,
  .ql-toolbar button.ql-active {
    color: #60A5FA !important;
  }
  
  .ql-snow .ql-picker.ql-expanded .ql-picker-options {
    background-color: #1F2937;
    border-color: rgba(255, 255, 255, 0.1);
  }
  
  .ql-snow .ql-picker-label {
    color: #9CA3AF;
  }
  
  .ql-snow .ql-color-picker .ql-picker-item {
    border-radius: 3px;
  }
  
  .ql-snow .ql-color-picker .ql-picker-item:hover {
    border-color: #60A5FA;
  }
  
  .ql-snow .ql-tooltip {
    background-color: #1F2937;
    border-color: rgba(255, 255, 255, 0.1);
    color: white;
  }
`;

// Add styles to document
const styleSheet = document.createElement('style');
styleSheet.type = 'text/css';
styleSheet.innerText = quillStyles;
document.head.appendChild(styleSheet);

export function AddActionForm() {
  const [actions, setActions] = useLocalStorage<StockAction[]>('stockActions', []);
  const [formData, setFormData] = useState<StockActionFormData>(initialFormData);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const [currency, setCurrency] = useState<'EUR' | 'USD'>('EUR');
  const [showLogoSelector, setShowLogoSelector] = useState(false);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const benefitRef = useRef<HTMLDivElement>(null);

  // Exchange rate
  const EUR_TO_USD = 1.09;
  const USD_TO_EUR = 1 / EUR_TO_USD;

  // Calculate lot price based on selected currency
  const lotPrice = currency === 'EUR' 
    ? formData.price * formData.minQuantity 
    : formData.priceUSD * formData.minQuantity;

  const handleCurrencyChange = (newCurrency: 'EUR' | 'USD') => {
    setCurrency(newCurrency);
    
    if (newCurrency === 'EUR') {
      setFormData({
        ...formData,
        price: formData.priceUSD * USD_TO_EUR,
        currentMarketPrice: formData.currentMarketPriceUSD * USD_TO_EUR,
        safetyNet: formData.safetyNetUSD * USD_TO_EUR,
        priceUSD: 0,
        currentMarketPriceUSD: 0,
        safetyNetUSD: 0
      });
    } else {
      setFormData({
        ...formData,
        priceUSD: formData.price * EUR_TO_USD,
        currentMarketPriceUSD: formData.currentMarketPrice * EUR_TO_USD,
        safetyNetUSD: formData.safetyNet * EUR_TO_USD,
        price: 0,
        currentMarketPrice: 0,
        safetyNet: 0
      });
    }
  };

  const handlePriceChange = (value: number) => {
    if (currency === 'EUR') {
      setFormData({
        ...formData,
        price: value,
        priceUSD: 0
      });
    } else {
      setFormData({
        ...formData,
        priceUSD: value,
        price: 0
      });
    }
  };

  const handleSafetyNetChange = (value: number) => {
    if (currency === 'EUR') {
      setFormData({
        ...formData,
        safetyNet: value,
        safetyNetUSD: 0
      });
    } else {
      setFormData({
        ...formData,
        safetyNetUSD: value,
        safetyNet: 0
      });
    }
  };

  const handleLogoSelect = (logoUrl: string) => {
    setFormData({
      ...formData,
      logoUrl
    });
    setLogoPreview(logoUrl);
  };

  const handleRemoveLogo = () => {
    setFormData({
      ...formData,
      logoUrl: undefined
    });
    setLogoPreview(null);
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = "Le nom de l'action est requis";
    }

    const price = currency === 'EUR' ? formData.price : formData.priceUSD;
    if (price <= 0) {
      newErrors.price = "Le prix doit être supérieur à 0";
    }

    if (formData.minQuantity <= 0) {
      newErrors.minQuantity = "La quantité minimum doit être supérieure à 0";
    }

    if (formData.maxQuantity < formData.minQuantity) {
      newErrors.maxQuantity = "La quantité maximum ne peut pas être inférieure à la quantité minimum";
    }

    if (formData.holdingPeriodDays === 0 && formData.holdingPeriodMonths === 0 && formData.holdingPeriodYears === 0) {
      newErrors.holdingPeriod = "La période de garde doit être supérieure à 0";
    }

    const safetyNet = currency === 'EUR' ? formData.safetyNet : formData.safetyNetUSD;
    if (safetyNet <= 0) {
      newErrors.safetyNet = "Le filet de sécurité doit être supérieur à 0";
    }

    if (formData.bonusShares < 0) {
      newErrors.bonusShares = "Le nombre d'actions offertes ne peut pas être négatif";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    // Generate a unique 5-character reference
    const reference = generateReference(5);

    const newAction: StockAction = {
      ...formData,
      id: generateId(),
      dateCreated: new Date().toISOString(),
      status: 'Active',
      reference
    };

    // Remove the showPracticalInfo property as it's not part of the StockAction type
    const { showPracticalInfo, ...actionData } = newAction;
    
    // If showPracticalInfo is false, set practicalInfo to empty string
    const finalAction = {
      ...actionData,
      practicalInfo: showPracticalInfo ? actionData.practicalInfo : ''
    };

    setActions([...actions, finalAction]);
    setFormData(initialFormData);
    setLogoPreview(null);
    toast.success(`Action créée avec succès. Référence: ${reference}`);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative max-w-4xl mx-auto"
    >
      {/* Background effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl" />
      <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl" />
      
      {/* Content */}
      <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-8">
          Créer une offre d'action
        </h2>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Nom de l'action
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                onFocus={() => setFocusedField('name')}
                onBlur={() => setFocusedField(null)}
                className={cn(
                  "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                  "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                  "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                  errors.name && "border-red-500/50 focus:ring-red-500/50",
                  focusedField === 'name' && "shadow-[0_0_15px_rgba(59,130,246,0.5)]"
                )}
                placeholder="Ex: Tesla Inc."
              />
              {errors.name && (
                <p className="mt-2 text-sm text-red-400">{errors.name}</p>
              )}
            </div>

            {/* Logo Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                <ImageIcon className="w-4 h-4 mr-2 text-pink-400" />
                Logo de l'action (optionnel)
              </label>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <button
                  type="button"
                  onClick={() => setShowLogoSelector(true)}
                  className="col-span-2 flex flex-col items-center justify-center bg-gray-800/50 border border-gray-700/50 rounded-lg p-4 hover:bg-gray-700/50 transition-colors"
                >
                  <ImageIcon className="w-8 h-8 text-gray-400 mb-2" />
                  <span className="text-gray-300">Sélectionner un logo</span>
                  <span className="text-xs text-gray-500 mt-1">Choisir depuis la liste des logos</span>
                </button>
                
                {/* Logo Preview */}
                <div className="relative">
                  {logoPreview ? (
                    <div className="relative aspect-square overflow-hidden border border-gray-700 bg-gray-800/50 rounded-lg">
                      <img 
                        src={logoPreview} 
                        alt="Logo preview" 
                        className="w-full h-full object-contain"
                      />
                      <button
                        type="button"
                        onClick={handleRemoveLogo}
                        className="absolute top-2 right-2 p-1 bg-red-500/80 text-white hover:bg-red-600/80 transition-colors rounded-full"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="aspect-square border border-gray-700 bg-gray-800/50 rounded-lg flex items-center justify-center">
                      <ImageIcon className="w-10 h-10 text-gray-600" />
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Currency Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Devise
              </label>
              <div className="flex space-x-4">
                <button
                  type="button"
                  onClick={() => handleCurrencyChange('EUR')}
                  className={`
                    flex-1 inline-flex items-center justify-center px-4 py-2 border rounded-md
                    ${currency === 'EUR'
                      ? 'border-blue-500 bg-blue-50 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300'
                      : 'border-gray-300 bg-white text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300'
                    }
                  `}
                >
                  <Euro className="h-5 w-5 mr-2" />
                  EUR
                </button>
                <button
                  type="button"
                  onClick={() => handleCurrencyChange('USD')}
                  className={`
                    flex-1 inline-flex items-center justify-center px-4 py-2 border rounded-md
                    ${currency === 'USD'
                      ? 'border-blue-500 bg-blue-50 text-blue-700 dark:bg-blue-900/50 dark:text-blue-300'
                      : 'border-gray-300 bg-white text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300'
                    }
                  `}
                >
                  <DollarSign className="h-5 w-5 mr-2" />
                  USD
                </button>
              </div>
            </div>

            {/* Price */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Prix de l'action
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  {currency === 'EUR' ? (
                    <Euro className="h-5 w-5 text-gray-400" />
                  ) : (
                    <DollarSign className="h-5 w-5 text-gray-400" />
                  )}
                </div>
                <input
                  type="number"
                  value={currency === 'EUR' ? formData.price || '' : formData.priceUSD || ''}
                  onChange={(e) => handlePriceChange(parseFloat(e.target.value) || 0)}
                  className={cn(
                    "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-10 pr-4 py-3",
                    "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                    "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                    errors.price && "border-red-500/50 focus:ring-red-500/50"
                  )}
                  step="0.01"
                  min="0"
                />
                {errors.price && (
                  <p className="mt-2 text-sm text-red-400">{errors.price}</p>
                )}
              </div>
            </div>

            {/* Bonus Shares */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                <Gift className="w-4 h-4 mr-2 text-pink-400" />
                Actions offertes
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={formData.bonusShares || ''}
                  onChange={(e) => setFormData({ ...formData, bonusShares: parseInt(e.target.value) || 0 })}
                  onFocus={() => setFocusedField('bonusShares')}
                  onBlur={() => setFocusedField(null)}
                  className={cn(
                    "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                    "focus:outline-none focus:ring-2 focus:ring-pink-500/50 focus:border-pink-500/50",
                    "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                    errors.bonusShares && "border-red-500/50 focus:ring-red-500/50",
                    focusedField === 'bonusShares' && "shadow-[0_0_15px_rgba(236,72,153,0.5)]"
                  )}
                  min="0"
                  placeholder="Nombre d'actions offertes"
                />
                {errors.bonusShares && (
                  <p className="mt-2 text-sm text-red-400">{errors.bonusShares}</p>
                )}
                <p className="mt-1 text-xs text-gray-500">
                  Entrez le nombre d'actions supplémentaires offertes pour chaque souscription. Laissez 0 pour aucune action offerte.
                </p>
              </div>
            </div>

            {/* Quantities */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Quantité minimum
              </label>
              <div className="relative">
                <Package className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="number"
                  value={formData.minQuantity || ''}
                  onChange={(e) => setFormData({ ...formData, minQuantity: parseInt(e.target.value) })}
                  className={cn(
                    "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-10 pr-4 py-3",
                    "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                    "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                    errors.minQuantity && "border-red-500/50 focus:ring-red-500/50"
                  )}
                  min="0"
                />
                {errors.minQuantity && (
                  <p className="mt-2 text-sm text-red-400">{errors.minQuantity}</p>
                )}
              </div>
            </div>

            {/*  Lot Price Display */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Prix lot d'actions
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  {currency === 'EUR' ? (
                    <Euro className="h-5 w-5 text-gray-400" />
                  ) : (
                    <DollarSign className="h-5 w-5 text-gray-400" />
                  )}
                </div>
                <input
                  type="text"
                  value={lotPrice.toLocaleString()}
                  readOnly
                  className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-10 pr-4 py-3 opacity-75"
                />
                <p className="mt-1 text-xs text-gray-500">
                  Calculé automatiquement: Prix de l'action × Quantité minimum
                </p>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Quantité maximum
              </label>
              <div className="relative">
                <Package className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="number"
                  value={formData.maxQuantity || ''}
                  onChange={(e) => setFormData({ ...formData, maxQuantity: parseInt(e.target.value) })}
                  className={cn(
                    "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-10 pr-4 py-3",
                    "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                    "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                    errors.maxQuantity && "border-red-500/50 focus:ring-red-500/50"
                  )}
                  min="0"
                />
                {errors.maxQuantity && (
                  <p className="mt-2 text-sm text-red-400">{errors.maxQuantity}</p>
                )}
              </div>
            </div>

            {/* Date and Periods */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Date de début
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                  className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-10 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Période de garde
              </label>
              <div className="grid grid-cols-3 gap-2">
                <div className="relative">
                  <input
                    type="number"
                    value={formData.holdingPeriodYears || ''}
                    onChange={(e) => setFormData({ ...formData, holdingPeriodYears: parseInt(e.target.value) })}
                    className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50"
                    min="0"
                    placeholder="Années"
                  />
                </div>
                <div className="relative">
                  <input
                    type="number"
                    value={formData.holdingPeriodMonths || ''}
                    onChange={(e) => setFormData({ ...formData, holdingPeriodMonths: parseInt(e.target.value) })}
                    className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50"
                    min="0"
                    max="11"
                    placeholder="Mois"
                  />
                </div>
                <div className="relative">
                  <input
                    type="number"
                    value={formData.holdingPeriodDays || ''}
                    onChange={(e) => setFormData({ ...formData, holdingPeriodDays: parseInt(e.target.value) })}
                    className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50"
                    min="0"
                    max="30"
                    placeholder="Jours"
                  />
                </div>
              </div>
              {errors.holdingPeriod && (
                <p className="mt-2  text-sm text-red-400">{errors.holdingPeriod}</p>
              )}
              <p className="mt-1 text-xs text-gray-500">
                Spécifiez la durée en années, mois et jours
              </p>
            </div>

            {/* Safety Net */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Filet de sécurité
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  {currency === 'EUR' ? (
                    <Euro className="h-5 w-5 text-gray-400" />
                  ) : (
                    <DollarSign className="h-5 w-5 text-gray-400" />
                  )}
                </div>
                <input
                  type="number"
                  value={currency === 'EUR' ? formData.safetyNet || '' : formData.safetyNetUSD || ''}
                  onChange={(e) => handleSafetyNetChange(parseFloat(e.target.value) || 0)}
                  className={cn(
                    "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-10 pr-4 py-3",
                    "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                    "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                    errors.safetyNet && "border-red-500/50 focus:ring-red-500/50"
                  )}
                  step="0.01"
                  min="0"
                />
                {errors.safetyNet && (
                  <p className="mt-2 text-sm text-red-400">{errors.safetyNet}</p>
                )}
              </div>
              <p className="mt-2 text-sm text-gray-500">
                Prix minimum défini avec le client. Si l'action descend en dessous de ce prix, elle sera revendue automatiquement.
              </p>
            </div>

            {/* Info Pratique with Checkbox */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-medium text-gray-300 flex items-center">
                  <Info className="w-4 h-4 mr-2 text-blue-400" />
                  Info pratique
                </label>
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="showPracticalInfo"
                    checked={formData.showPracticalInfo}
                    onChange={(e) => setFormData({ ...formData, showPracticalInfo: e.target.checked })}
                    className="w-4 h-4 rounded border-gray-600 text-blue-600 focus:ring-blue-500 bg-gray-700"
                  />
                  <label htmlFor="showPracticalInfo" className="ml-2 text-sm text-gray-300">
                    Afficher dans le formulaire de souscription
                  </label>
                </div>
              </div>
              <div className={cn(
                "rounded-lg overflow-hidden transition-all duration-200",
                focusedField === 'practicalInfo' && "ring-2 ring-blue-500/50"
              )}>
                <ReactQuill
                  value={formData.practicalInfo}
                  onChange={(content) => setFormData({ ...formData, practicalInfo: content })}
                  modules={modules}
                  formats={formats}
                  theme="snow"
                  onFocus={() => setFocusedField('practicalInfo')}
                  onBlur={() => setFocusedField(null)}
                  placeholder="Ajoutez des informations pratiques ici..."
                />
              </div>
              <p className="mt-2 text-sm text-gray-500">
                Utilisez les outils de mise en forme pour créer une présentation claire et professionnelle.
                Les titres et le texte en gras vous permettent de mettre en valeur les informations importantes.
              </p>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex justify-end">
            <motion.button
              type="submit"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="relative group px-8 py-3 rounded-lg overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
              <span className="relative text-white font-medium">
                Créer l'offre
              </span>
            </motion.button>
          </div>
        </form>
      </div>

      {/* Logo Selector Modal */}
      {showLogoSelector && (
        <LogoSelectorModal
          isOpen={showLogoSelector}
          onClose={() => setShowLogoSelector(false)}
          onSelect={handleLogoSelect}
        />
      )}
    </motion.div>
  );
}