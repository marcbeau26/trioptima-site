import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Settings, Copyright } from 'lucide-react';
import { CopyrightSettings } from './CopyrightSettings';
import { cn } from '../../../utils/cn';
import { getCurrentUser } from '../../../lib/auth';

export function SettingsManager() {
  const [activeTab, setActiveTab] = useState<'general' | 'copyright'>('general');
  
  // Get current user
  const userStr = localStorage.getItem('user');
  const currentUser = userStr ? JSON.parse(userStr) : null;
  const isAdmin = currentUser?.role === 'Admin';

  return (
    <div className="space-y-6">
      {/* Tab Navigation */}
      {isAdmin && (
        <div className="flex space-x-4 border-b border-gray-700 mb-6">
          <button
            onClick={() => setActiveTab('general')}
            className={cn(
              "pb-2 px-4 font-medium transition-colors",
              activeTab === 'general' 
                ? "text-blue-400 border-b-2 border-blue-400" 
                : "text-gray-400 hover:text-gray-300"
            )}
          >
            <div className="flex items-center">
              <Settings className="w-4 h-4 mr-2" />
              <span>Paramètres généraux</span>
            </div>
          </button>
          <button
            onClick={() => setActiveTab('copyright')}
            className={cn(
              "pb-2 px-4 font-medium transition-colors",
              activeTab === 'copyright' 
                ? "text-blue-400 border-b-2 border-blue-400" 
                : "text-gray-400 hover:text-gray-300"
            )}
          >
            <div className="flex items-center">
              <Copyright className="w-4 h-4 mr-2" />
              <span>Copyright</span>
            </div>
          </button>
        </div>
      )}

      {/* Content */}
      {activeTab === 'general' || !isAdmin ? (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="relative overflow-hidden"
        >
          {/* Background gradient effects */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 rounded-xl blur-2xl"></div>
          <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/5 to-emerald-500/5 rounded-xl blur-xl"></div>
          
          {/* Main content */}
          <div className="relative bg-gray-800/80 backdrop-blur-xl rounded-xl shadow-xl border border-gray-700/20">
            {/* Glowing border */}
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-cyan-500"></div>
            
            <div className="p-6 space-y-8">
              <div className="text-center py-12">
                <h3 className="text-lg font-medium text-white mb-2">
                  Paramètres
                </h3>
                <p className="text-gray-400">
                  Les paramètres de l'application seront disponibles ici.
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      ) : (
        <CopyrightSettings />
      )}
    </div>
  );
}