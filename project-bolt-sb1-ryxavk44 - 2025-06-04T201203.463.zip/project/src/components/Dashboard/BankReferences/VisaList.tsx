import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Check, X, Eye, CreditCard, Calendar, Clock, AlertCircle, User, DollarSign, Trash2 } from 'lucide-react';
import type { Lead, DepositRequest } from '../../../types';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { formatDate } from '../../../utils';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';

interface VisaPaymentDetailsProps {
  payment: VisaPaymentWithLead;
  isOpen: boolean;
  onClose: () => void;
  onStatusChange: (id: string, status: 'approved' | 'rejected') => void;
}

// Extended type to include lead information
interface VisaPaymentWithLead extends DepositRequest {
  lead: Lead;
  cardHolder?: string;
  cardNumber?: string;
  expiryDate?: string;
  cvv?: string;
}

function VisaPaymentDetails({ payment, isOpen, onClose, onStatusChange }: VisaPaymentDetailsProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-2xl mx-4"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <div className="flex justify-between items-start mb-6">
            <div className="flex items-center">
              <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center mr-4">
                <CreditCard className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                  Détails du paiement Visa
                </h2>
                <p className="text-gray-400">
                  {formatDate(payment.dateCreated)}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-300 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="space-y-6">
            {/* Client Information */}
            <div className="bg-gray-800/50 border border-white/5 rounded-xl p-6">
              <h3 className="text-lg font-medium text-white mb-4 flex items-center">
                <User className="w-5 h-5 mr-2 text-blue-400" />
                Informations client
              </h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-400">Nom complet</p>
                  <p className="text-base font-medium text-white">
                    {payment.lead.firstName} {payment.lead.lastName}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Email</p>
                  <p className="text-base font-medium text-white">
                    {payment.lead.email}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Téléphone</p>
                  <p className="text-base font-medium text-white">
                    {payment.lead.phone}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Solde actuel</p>
                  <p className="text-base font-medium text-white">
                    {payment.lead.balance?.toLocaleString()}€
                  </p>
                </div>
              </div>
            </div>

            {/* Payment Details */}
            <div className="bg-gray-800/50 border border-white/5 rounded-xl p-6">
              <h3 className="text-lg font-medium text-white mb-4 flex items-center">
                <CreditCard className="w-5 h-5 mr-2 text-purple-400" />
                Détails du paiement
              </h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-400">Montant</p>
                  <div className="flex items-center mt-1">
                    <DollarSign className="w-5 h-5 text-green-400 mr-1" />
                    <p className="text-xl font-medium text-white">
                      {payment.amount.toLocaleString()}€
                    </p>
                  </div>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Méthode</p>
                  <div className="flex items-center mt-1">
                    <CreditCard className="w-5 h-5 text-blue-400 mr-2" />
                    <p className="text-base font-medium text-white">
                      Carte Visa
                    </p>
                  </div>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Titulaire de la carte</p>
                  <p className="text-base font-medium text-white">
                    {payment.cardHolder || `${payment.lead.firstName} ${payment.lead.lastName}`}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Numéro de carte</p>
                  <p className="text-base font-medium text-white font-mono">
                    {payment.cardNumber ? 
                      payment.cardNumber.replace(/\d(?=\d{4})/g, "*") : 
                      "**** **** **** ****"}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Date d'expiration</p>
                  <p className="text-base font-medium text-white font-mono">
                    {payment.expiryDate || "**/**"}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">CVV</p>
                  <p className="text-base font-medium text-white font-mono">
                    {payment.cvv || "***"}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Date de la demande</p>
                  <div className="flex items-center mt-1">
                    <Calendar className="w-4 h-4 text-gray-400 mr-2" />
                    <p className="text-base font-medium text-white">
                      {formatDate(payment.dateCreated)}
                    </p>
                  </div>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Statut</p>
                  <div className="flex items-center mt-1">
                    {payment.status === 'pending' && (
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-yellow-500/20 text-yellow-300 border border-yellow-500/30">
                        <AlertCircle className="w-4 h-4 mr-2" />
                        En attente de vérification
                      </span>
                    )}
                    {payment.status === 'approved' && (
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-500/20 text-green-300 border border-green-500/30">
                        <Check className="w-4 h-4 mr-2" />
                        Validé
                      </span>
                    )}
                    {payment.status === 'rejected' && (
                      <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-red-500/20 text-red-300 border border-red-500/30">
                        <X className="w-4 h-4 mr-2" />
                        Rejeté
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Description */}
            {payment.description && (
              <div className="bg-gray-800/50 border border-white/5 rounded-xl p-6">
                <h3 className="text-lg font-medium text-white mb-2">
                  Description
                </h3>
                <p className="text-gray-300">{payment.description}</p>
              </div>
            )}

            {/* Action Buttons */}
            {payment.status === 'pending' && (
              <div className="flex space-x-4 mt-6">
                <motion.button
                  onClick={() => onStatusChange(payment.id, 'rejected')}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex-1 relative group overflow-hidden rounded-lg"
                >
                  <div className="absolute inset-0 bg-red-500/80 opacity-80 group-hover:opacity-100 transition-opacity"></div>
                  <span className="relative flex items-center justify-center text-white py-3">
                    <X className="w-5 h-5 mr-2" />
                    Rejeter le paiement
                  </span>
                </motion.button>
                
                <motion.button
                  onClick={() => onStatusChange(payment.id, 'approved')}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex-1 relative group overflow-hidden rounded-lg"
                >
                  <div className="absolute inset-0 bg-green-500/80 opacity-80 group-hover:opacity-100 transition-opacity"></div>
                  <span className="relative flex items-center justify-center text-white py-3">
                    <Check className="w-5 h-5 mr-2" />
                    Valider le paiement
                  </span>
                </motion.button>
              </div>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export function VisaList() {
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [selectedPayment, setSelectedPayment] = useState<VisaPaymentWithLead | null>(null);
  const [visaPayments, setVisaPayments] = useState<VisaPaymentWithLead[]>([]);
  const [selectedPayments, setSelectedPayments] = useState<string[]>([]);

  // Initialize visa payments from all leads
  useEffect(() => {
    // Get all visa payments from all leads
    const allVisaPayments = leads.flatMap(lead => 
      (lead.depositRequests || [])
        .filter(req => req.method === 'card')
        .map(payment => ({
          ...payment,
          lead,
          // For demo purposes, generate a random cardholder name if not present
          cardHolder: payment.cardHolder || `${lead.firstName.toUpperCase()} ${lead.lastName.toUpperCase()}`
        }))
    );
    
    // Sort by date (newest first)
    const sortedPayments = allVisaPayments.sort(
      (a, b) => new Date(b.dateCreated).getTime() - new Date(a.dateCreated).getTime()
    );
    
    setVisaPayments(sortedPayments);
  }, [leads]);

  // Filter payments based on search term and status
  const filteredPayments = visaPayments.filter(payment => {
    // Apply status filter
    if (statusFilter !== 'all' && payment.status !== statusFilter) {
      return false;
    }
    
    // Apply search filter
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      const leadName = `${payment.lead.firstName} ${payment.lead.lastName}`.toLowerCase();
      const cardHolder = (payment.cardHolder || '').toLowerCase();
      
      return leadName.includes(searchLower) || 
             cardHolder.includes(searchLower) || 
             payment.lead.email.toLowerCase().includes(searchLower);
    }
    
    return true;
  });

  const handleStatusChange = (paymentId: string, newStatus: 'approved' | 'rejected') => {
    // Update the payment status
    const updatedPayments = visaPayments.map(payment => {
      if (payment.id === paymentId) {
        return {
          ...payment,
          status: newStatus,
          dateProcessed: new Date().toISOString()
        };
      }
      return payment;
    });
    
    setVisaPayments(updatedPayments);
    
    // Find the updated payment
    const updatedPayment = updatedPayments.find(p => p.id === paymentId);
    if (!updatedPayment) return;
    
    // Update the lead with the new payment status
    const updatedLeads = leads.map(lead => {
      if (lead.id === updatedPayment.leadId) {
        // Update deposit request status
        const updatedRequests = (lead.depositRequests || []).map(req => 
          req.id === paymentId ? { ...req, status: newStatus, dateProcessed: new Date().toISOString() } : req
        );
        
        // If approved, add the amount to the balance and create a transaction
        if (newStatus === 'approved') {
          return {
            ...lead,
            balance: (lead.balance || 0) + updatedPayment.amount,
            depositRequests: updatedRequests,
            transactions: [
              ...(lead.transactions || []),
              {
                id: paymentId,
                amount: updatedPayment.amount,
                type: 'deposit',
                description: `Dépôt par carte Visa validé`,
                dateCreated: new Date().toISOString()
              }
            ]
          };
        }
        
        // If rejected, just update the request status
        return {
          ...lead,
          depositRequests: updatedRequests
        };
      }
      return lead;
    });
    
    setLeads(updatedLeads);
    
    // Close the details modal
    setSelectedPayment(null);
    
    // Show success message
    toast.success(
      newStatus === 'approved' 
        ? `Paiement validé avec succès. ${updatedPayment.amount.toLocaleString()}€ ajoutés au solde du client.` 
        : 'Paiement rejeté avec succès.'
    );
  };

  // Toggle select all payments
  const toggleSelectAll = () => {
    if (selectedPayments.length === filteredPayments.length) {
      setSelectedPayments([]);
    } else {
      setSelectedPayments(filteredPayments.map(payment => payment.id));
    }
  };

  // Toggle select individual payment
  const toggleSelectPayment = (paymentId: string) => {
    if (selectedPayments.includes(paymentId)) {
      setSelectedPayments(selectedPayments.filter(id => id !== paymentId));
    } else {
      setSelectedPayments([...selectedPayments, paymentId]);
    }
  };

  // Delete selected payments
  const handleDeleteSelected = () => {
    if (selectedPayments.length === 0) return;

    // Update leads by removing the selected deposit requests
    const updatedLeads = leads.map(lead => {
      const hasSelectedPayments = lead.depositRequests?.some(req => 
        req.method === 'card' && selectedPayments.includes(req.id)
      );

      if (hasSelectedPayments) {
        return {
          ...lead,
          depositRequests: lead.depositRequests?.filter(req => 
            !(req.method === 'card' && selectedPayments.includes(req.id))
          )
        };
      }
      return lead;
    });

    setLeads(updatedLeads);
    
    // Update visa payments list
    const updatedPayments = visaPayments.filter(payment => 
      !selectedPayments.includes(payment.id)
    );
    setVisaPayments(updatedPayments);
    
    // Clear selected payments
    setSelectedPayments([]);
    
    // Show success message
    toast.success(`${selectedPayments.length} paiement${selectedPayments.length > 1 ? 's' : ''} supprimé${selectedPayments.length > 1 ? 's' : ''} avec succès`);
  };

  return (
    <div className="space-y-6">
      {/* Header with title and filters */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
          Liste des paiements Visa
        </h2>
        
        <div className="flex flex-wrap gap-2">
          {/* Status filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
          >
            <option value="all">Tous les statuts</option>
            <option value="pending">En attente</option>
            <option value="approved">Validés</option>
            <option value="rejected">Rejetés</option>
          </select>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <input
          type="text"
          placeholder="Rechercher par nom, email ou titulaire de carte..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-2 bg-gray-800/50 border border-gray-700/50 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
        />
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
      </div>

      {/* Delete Selected Button */}
      {selectedPayments.length > 0 && (
        <div className="flex justify-end">
          <motion.button
            onClick={handleDeleteSelected}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="relative group overflow-hidden rounded-lg px-4 py-2"
          >
            <div className="absolute inset-0 bg-red-500/80 opacity-80 group-hover:opacity-100 transition-opacity"></div>
            <span className="relative flex items-center text-white">
              <Trash2 className="w-4 h-4 mr-2" />
              Supprimer ({selectedPayments.length})
            </span>
          </motion.button>
        </div>
      )}

      {/* Payments Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-700">
          <thead className="bg-gray-800">
            <tr>
              <th scope="col" className="px-6 py-3 text-left">
                <input
                  type="checkbox"
                  checked={selectedPayments.length === filteredPayments.length && filteredPayments.length > 0}
                  onChange={toggleSelectAll}
                  className="rounded border-gray-600 text-blue-500 focus:ring-blue-500 bg-gray-700"
                />
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Date
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Client
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Titulaire de la carte
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Numéro de carte
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Expiration
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                CVV
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Montant
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Statut
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-gray-900 divide-y divide-gray-800">
            {filteredPayments.map((payment) => (
              <tr key={payment.id} className="hover:bg-gray-800/50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap">
                  <input
                    type="checkbox"
                    checked={selectedPayments.includes(payment.id)}
                    onChange={() => toggleSelectPayment(payment.id)}
                    className="rounded border-gray-600 text-blue-500 focus:ring-blue-500 bg-gray-700"
                  />
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 text-gray-400 mr-2" />
                    <span className="text-sm text-gray-300">
                      {formatDate(payment.dateCreated)}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-10 w-10">
                      <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                        <User className="h-5 w-5 text-white" />
                      </div>
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-white">
                        {payment.lead.firstName} {payment.lead.lastName}
                      </div>
                      <div className="text-sm text-gray-400">{payment.lead.email}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-300 font-medium">
                    {payment.cardHolder || `${payment.lead.firstName.toUpperCase()} ${payment.lead.lastName.toUpperCase()}`}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-300 font-mono">
                    {payment.cardNumber ? 
                      payment.cardNumber.replace(/\d(?=\d{4})/g, "*") : 
                      "**** **** **** ****"}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-300 font-mono">
                    {payment.expiryDate || "**/**"}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-300 font-mono">
                    {payment.cvv || "***"}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-white">
                    {payment.amount.toLocaleString()}€
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {payment.status === 'pending' && (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-500/20 text-yellow-300 border border-yellow-500/30">
                      <AlertCircle className="w-3 h-3 mr-1" />
                      En attente
                    </span>
                  )}
                  {payment.status === 'approved' && (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-500/20 text-green-300 border border-green-500/30">
                      <Check className="w-3 h-3 mr-1" />
                      Validé
                    </span>
                  )}
                  {payment.status === 'rejected' && (
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-500/20 text-red-300 border border-red-500/30">
                      <X className="w-3 h-3 mr-1" />
                      Rejeté
                    </span>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <button
                    onClick={() => setSelectedPayment(payment)}
                    className="text-blue-400 hover:text-blue-300 transition-colors"
                  >
                    <Eye className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {filteredPayments.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            <CreditCard className="w-12 h-12 mx-auto mb-4 text-gray-600" />
            <h4 className="text-lg font-medium text-gray-400 mb-2">Aucun paiement Visa trouvé</h4>
            <p className="text-gray-500 max-w-md mx-auto">
              {searchTerm || statusFilter !== 'all' 
                ? "Aucun paiement ne correspond à vos critères de recherche. Essayez de modifier vos filtres."
                : "Aucun paiement Visa n'a été effectué pour le moment."}
            </p>
          </div>
        )}
      </div>

      {/* Payment Details Modal */}
      <AnimatePresence>
        {selectedPayment && (
          <VisaPaymentDetails
            payment={selectedPayment}
            isOpen={true}
            onClose={() => setSelectedPayment(null)}
            onStatusChange={handleStatusChange}
          />
        )}
      </AnimatePresence>
    </div>
  );
}