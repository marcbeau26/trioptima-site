import React from 'react';
import { Building2, CreditCard, Bitcoin, Eye, X } from 'lucide-react';
import type { Lead, DepositRequest, WithdrawalRequest } from '../../../../types';
import { formatDate } from '../../../../utils';
import { cn } from '../../../../utils/cn';

interface RequestDetailsModalProps {
  request: (DepositRequest | WithdrawalRequest) & { type: 'deposit' | 'withdrawal' };
  isOpen: boolean;
  onClose: () => void;
}

function RequestDetailsModal({ request, isOpen, onClose }: RequestDetailsModalProps) {
  if (!isOpen) return null;

  const methodIcons = {
    bank: <Building2 className="w-5 h-5" />,
    card: <CreditCard className="w-5 h-5" />,
    crypto: <Bitcoin className="w-5 h-5" />
  };

  const methodLabels = {
    bank: 'Virement bancaire',
    card: 'Carte bancaire',
    crypto: 'Crypto-monnaie'
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-2xl w-full m-4">
        <div className="flex justify-between items-start mb-6">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            Détails de la demande de {request.type === 'deposit' ? 'dépôt' : 'retrait'}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500 dark:hover:text-gray-300"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-6">
          {/* Transaction Details */}
          <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
              Détails de la transaction
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Montant</p>
                <p className="text-lg font-semibold text-gray-900 dark:text-white">
                  {request.amount.toLocaleString()}€
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Méthode</p>
                <div className="flex items-center space-x-2 text-gray-900 dark:text-white">
                  {methodIcons[request.method]}
                  <span>{methodLabels[request.method]}</span>
                </div>
              </div>
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Date de la demande</p>
                <p className="text-base font-medium text-gray-900 dark:text-white">
                  {formatDate(request.dateCreated)}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Statut</p>
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  request.status === 'pending'
                    ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100'
                    : request.status === 'approved'
                    ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100'
                    : 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100'
                }`}>
                  {request.status === 'pending' ? 'En attente' : request.status === 'approved' ? 'Approuvé' : 'Refusé'}
                </span>
              </div>
            </div>
          </div>

          {/* Payment Details */}
          {'bankDetails' in request && request.bankDetails && (
            <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                Coordonnées bancaires
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Banque</p>
                  <p className="text-base font-medium text-gray-900 dark:text-white">
                    {request.bankDetails.bankName}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Titulaire</p>
                  <p className="text-base font-medium text-gray-900 dark:text-white">
                    {request.bankDetails.accountHolder}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">IBAN</p>
                  <p className="text-base font-medium text-gray-900 dark:text-white font-mono">
                    {request.bankDetails.iban}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">BIC/SWIFT</p>
                  <p className="text-base font-medium text-gray-900 dark:text-white font-mono">
                    {request.bankDetails.bic}
                  </p>
                </div>
              </div>
            </div>
          )}

          {'cryptoDetails' in request && request.cryptoDetails && (
            <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                Détails crypto
              </h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Crypto-monnaie</p>
                  <p className="text-base font-medium text-gray-900 dark:text-white">
                    {request.cryptoDetails.currency}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Réseau</p>
                  <p className="text-base font-medium text-gray-900 dark:text-white">
                    {request.cryptoDetails.network}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Adresse</p>
                  <p className="text-base font-medium text-gray-900 dark:text-white font-mono break-all">
                    {request.cryptoDetails.address}
                  </p>
                </div>
              </div>
            </div>
          )}

          {request.description && (
            <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                Description
              </h3>
              <p className="text-gray-600 dark:text-gray-300">{request.description}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function RequestHistory() {
  const [selectedRequest, setSelectedRequest] = React.useState<(DepositRequest | WithdrawalRequest) & { type: 'deposit' | 'withdrawal' } | null>(null);
  const currentLeadStr = localStorage.getItem('currentLead');
  const currentLead = currentLeadStr ? JSON.parse(currentLeadStr) as Lead : null;

  if (!currentLead) return null;

  // Combine deposit and withdrawal requests
  const allRequests = [
    ...(currentLead.depositRequests || []).map(request => ({ ...request, type: 'deposit' as const })),
    ...(currentLead.withdrawalRequests || []).map(request => ({ ...request, type: 'withdrawal' as const }))
  ].sort((a, b) => new Date(b.dateCreated).getTime() - new Date(a.dateCreated).getTime());

  return (
    <div className="space-y-6">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-800">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Type
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Montant
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Méthode
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Date
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Statut
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200 dark:bg-gray-900 dark:divide-gray-700">
            {allRequests.map((request) => (
              <tr key={request.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={cn(
                    "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
                    request.type === 'deposit'
                      ? "bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100"
                      : "bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100"
                  )}>
                    {request.type === 'deposit' ? 'Dépôt' : 'Retrait'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900 dark:text-white">
                    {request.amount.toLocaleString()}€
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    {request.method === 'bank' && <Building2 className="w-5 h-5 text-blue-500 mr-2" />}
                    {request.method === 'card' && <CreditCard className="w-5 h-5 text-green-500 mr-2" />}
                    {request.method === 'crypto' && <Bitcoin className="w-5 h-5 text-yellow-500 mr-2" />}
                    <span className="text-sm text-gray-900 dark:text-white">
                      {request.method === 'bank' ? 'Virement' : request.method === 'card' ? 'Carte' : 'Crypto'}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                  {formatDate(request.dateCreated)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                    request.status === 'pending'
                      ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100'
                      : request.status === 'approved'
                      ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100'
                      : 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100'
                  }`}>
                    {request.status === 'pending' ? 'En attente' : request.status === 'approved' ? 'Approuvé' : 'Refusé'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <button
                    onClick={() => setSelectedRequest(request)}
                    className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300"
                  >
                    <Eye className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {allRequests.length === 0 && (
          <div className="text-center py-12 text-gray-500 dark:text-gray-400">
            Aucune demande à afficher
          </div>
        )}
      </div>

      {selectedRequest && (
        <RequestDetailsModal
          request={selectedRequest}
          isOpen={true}
          onClose={() => setSelectedRequest(null)}
        />
      )}
    </div>
  );
}