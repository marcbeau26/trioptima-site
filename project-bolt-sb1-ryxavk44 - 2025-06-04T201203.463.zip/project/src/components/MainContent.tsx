import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { BarChart2, Mail, User, Phone } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'react-hot-toast';
import { cn } from '../utils/cn';
import { signIn, generatePasswordGrid } from '../lib/auth';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { generateId } from '../utils';
import { Footer } from './Footer';

// URL de l'image par défaut - la même que dans HomepageManager
const DEFAULT_IMAGE_URL = 'https://images.unsplash.com/photo-1579547945413-497e1b99dac0?q=80&w=1470&auto=format&fit=crop';

interface HomepageSettings {
  imageUrl: string;
  neonBorderColor?: string;
  leftBackgroundColor?: string;
  emailBorderColor?: string;
  passwordBorderColor?: string;
  loginButtonColor?: string;
  welcomeTextColor?: string;
  passwordDotsColor?: string;
  trakitLineColor?: string;
  logoBackgroundColor?: string;
  neonEffectsEnabled?: boolean;
  logoSize?: number;
  logoUrl?: string;
  logoMode?: 'image' | 'text';
  logoText?: string;
  logoTextColor?: string;
}

interface PasswordGrid {
  topRow: number[];
  bottomRow: number[];
}

export function MainContent() {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phone, setPhone] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [settings] = useLocalStorage<HomepageSettings>('homepageSettings', {
    imageUrl: DEFAULT_IMAGE_URL, // Utiliser l'image par défaut
    logoSize: 80,
    logoMode: 'text', // Définir le mode texte par défaut
    logoText: 'Trioptima',
    logoTextColor: '#ffffff'
  });
  const [homepageColors] = useLocalStorage('homepageColors', {
    neonBorder: '#9333ea',
    leftBackground: '#111827',
    emailBorder: '#9333ea',
    passwordBorder: '#9333ea',
    loginButton: '#9333ea',
    welcomeText: '#ffffff',
    passwordDots: '#9333ea',
    trakitLine: '#9333ea',
    logoBackground: '#111827',
  });
  const [neonEffectsEnabled] = useLocalStorage('neonEffectsEnabled', true);
  const [passwordGrid, setPasswordGrid] = useState<PasswordGrid>(generatePasswordGrid());
  const [leads, setLeads] = useLocalStorage('leads', []);
  
  // Get logo size with fallback to 80px
  const logoSize = settings.logoSize || 80;
  // Get custom logo URL
  const customLogoUrl = settings.logoUrl || null;
  // Get logo mode with fallback to 'text'
  const logoMode = settings.logoMode || 'text';
  // Get logo text with fallback to 'Trioptima'
  const logoText = settings.logoText || 'Trioptima';
  // Get logo text color with fallback to white
  const logoTextColor = settings.logoTextColor || '#ffffff';

  // Update document title when logo text changes
  useEffect(() => {
    document.title = logoText;
    const pageTitle = document.getElementById('page-title');
    if (pageTitle) {
      pageTitle.textContent = logoText;
    }
  }, [logoText]);

  // Initialiser l'image par défaut si aucune image n'est définie
  useEffect(() => {
    if (!settings.imageUrl) {
      // Utiliser l'image par défaut si aucune image n'est définie
      const defaultSettings = {
        ...settings,
        imageUrl: DEFAULT_IMAGE_URL
      };
      localStorage.setItem('homepageSettings', JSON.stringify(defaultSettings));
    }
  }, [settings]);

  // Regenerate password grid on mount and when password is cleared
  useEffect(() => {
    if (!password) {
      setPasswordGrid(generatePasswordGrid());
    }
  }, [password]);

  const handleNumberClick = (number: number) => {
    if (password.length < 6) {
      setPassword(prev => prev + number);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const { data, error } = await signIn(email, password);
      
      if (error) {
        toast.error('Email ou mot de passe incorrect');
        setPassword(''); // Clear password on error
        setIsLoading(false);
        return;
      }

      if (data?.user) {
        toast.success('Connexion réussie');
        
        // Redirect based on user role
        if (data.user.role === 'Admin') {
          navigate('/dashboard', { replace: true });
        } else if (data.user.role === 'Seller') {
          navigate('/seller-dashboard', { replace: true });
        }
      } else if (data?.lead) {
        toast.success('Connexion réussie');
        navigate(`/client/${data.lead.id}`, { replace: true });
      }
    } catch (error) {
      toast.error('Une erreur est survenue');
      setPassword(''); // Clear password on error
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    if (!email || !password || !firstName || !lastName || !phone) {
      toast.error('Veuillez remplir tous les champs');
      setIsLoading(false);
      return;
    }
    
    if (password.length !== 6) {
      toast.error('Le mot de passe doit contenir exactement 6 chiffres');
      setIsLoading(false);
      return;
    }
    
    // Check if email already exists
    const emailExists = leads.some(lead => lead.email === email);
    if (emailExists) {
      toast.error('Cette adresse email est déjà utilisée');
      setIsLoading(false);
      return;
    }
    
    try {
      // Create new lead as a registration
      const leadWithId = {
        firstName,
        lastName,
        email,
        phone,
        source: 'Website Registration',
        password,
        id: generateId(),
        dateCreated: new Date().toISOString(),
        balance: 0,
        transactions: [],
        isRegistration: true,
        registrationStatus: 'pending'
      };
      
      setLeads([...leads, leadWithId]);
      
      toast.success('Inscription envoyée avec succès. Un administrateur va examiner votre demande.');
      
      // Reset form
      setEmail('');
      setPassword('');
      setFirstName('');
      setLastName('');
      setPhone('');
      setIsRegistering(false);
    } catch (error) {
      console.error('Registration error:', error);
      toast.error('Erreur lors de l\'inscription. Veuillez réessayer.');
    } finally {
      setIsLoading(false);
    }
  };

  // Get the colors from homepageColors or use defaults
  const neonBorderColor = homepageColors.neonBorder || '#9333ea';
  const leftBackgroundColor = homepageColors.leftBackground || '#111827';
  const emailBorderColor = homepageColors.emailBorder || '#9333ea';
  const passwordBorderColor = homepageColors.passwordBorder || '#9333ea';
  const loginButtonColor = homepageColors.loginButton || '#9333ea';
  const welcomeTextColor = homepageColors.welcomeText || '#ffffff';
  const passwordDotsColor = homepageColors.passwordDots || '#9333ea';
  const trakitLineColor = homepageColors.trakitLine || homepageColors.neonBorder || '#9333ea';
  const logoBackgroundColor = homepageColors.logoBackground || homepageColors.leftBackground || '#111827';

  return (
    <div className="min-h-screen flex flex-col">
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Left Section - Login */}
        <div className="w-full md:w-1/2 flex flex-col order-last md:order-first">
          {/* Logo */}
          <div className="p-4 md:p-8 relative" style={{ backgroundColor: logoBackgroundColor }}>
            <div className="flex items-center justify-center">
              {logoMode === 'image' ? (
                // Logo image mode
                <div style={{ width: `${logoSize}px`, height: 'auto', maxWidth: '100%' }}>
                  {customLogoUrl ? (
                    <img src={customLogoUrl} alt="Logo" className="h-full w-full object-contain" />
                  ) : (
                    <BarChart2 className="h-full w-full text-purple-500" />
                  )}
                </div>
              ) : (
                // Logo text mode - Using Orbitron with enhanced neon effect
                <div 
                  className="font-['Orbitron'] font-bold"
                  style={{ 
                    fontSize: `${logoSize/3}px`, 
                    color: logoTextColor,
                    textShadow: neonEffectsEnabled 
                      ? `0 0 5px ${logoTextColor}, 0 0 10px ${logoTextColor}, 0 0 15px ${logoTextColor}, 0 0 20px ${logoTextColor}`
                      : 'none',
                    letterSpacing: '2px',
                    animation: neonEffectsEnabled ? 'pulse 2s infinite' : 'none'
                  }}
                >
                  {logoText}
                </div>
              )}
            </div>
          </div>
          
          {/* Trakit - Horizontal line under logo - Full width */}
          <div 
            className="w-full"
            style={{ 
              height: '2px',
              backgroundColor: trakitLineColor,
              boxShadow: neonEffectsEnabled ? `0 0 10px ${trakitLineColor}, 0 0 20px ${trakitLineColor}` : 'none'
            }}
          />

          {/* Login Form */}
          <div className="flex-1 flex items-center justify-center px-4 md:px-8 py-6 md:py-0" style={{ backgroundColor: leftBackgroundColor }}>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="w-full max-w-md space-y-6"
            >
              <div>
                <p 
                  className="text-2xl md:text-3xl font-bold"
                  style={{ color: welcomeTextColor }}
                >
                  {isRegistering ? 'Inscription' : 'Bienvenue'}
                </p>
                <p 
                  className="mt-2"
                  style={{ color: welcomeTextColor }}
                >
                  {isRegistering ? 'Créez votre compte' : 'Connectez-vous à votre compte'}
                </p>
              </div>

              <form onSubmit={isRegistering ? handleRegister : handleLogin} className="space-y-4 md:space-y-6">
                {/* Email Field */}
                <div className="relative group">
                  {/* Glowing border effect */}
                  <div 
                    className="absolute -inset-0 blur opacity-75 group-hover:opacity-100 transition duration-1000"
                    style={{ 
                      backgroundColor: emailBorderColor,
                      boxShadow: neonEffectsEnabled ? `0 0 10px ${emailBorderColor}, 0 0 20px ${emailBorderColor}` : 'none',
                      borderRadius: '0' // Square corners
                    }}
                  ></div>
                  
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Mail className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className={cn(
                        "block w-full pl-10 pr-3 py-3 bg-gray-900 text-white",
                        "border",
                        "focus:outline-none focus:ring-2",
                        "placeholder-gray-400",
                        "transition-all duration-200"
                      )}
                      style={{ 
                        borderColor: emailBorderColor,
                        boxShadow: neonEffectsEnabled ? `0 0 5px ${emailBorderColor}` : 'none',
                        borderRadius: '0' // Square corners
                      }}
                      placeholder="Entrez votre email"
                      required
                    />
                  </div>
                </div>

                {/* First Name Field - Only shown when registering */}
                {isRegistering && (
                  <div className="relative group">
                    {/* Glowing border effect */}
                    <div 
                      className="absolute -inset-0 blur opacity-75 group-hover:opacity-100 transition duration-1000"
                      style={{ 
                        backgroundColor: emailBorderColor,
                        boxShadow: neonEffectsEnabled ? `0 0 10px ${emailBorderColor}, 0 0 20px ${emailBorderColor}` : 'none',
                        borderRadius: '0' // Square corners
                      }}
                    ></div>
                    
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <User className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="text"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        className={cn(
                          "block w-full pl-10 pr-3 py-3 bg-gray-900 text-white",
                          "border",
                          "focus:outline-none focus:ring-2",
                          "placeholder-gray-400",
                          "transition-all duration-200"
                        )}
                        style={{ 
                          borderColor: emailBorderColor,
                          boxShadow: neonEffectsEnabled ? `0 0 5px ${emailBorderColor}` : 'none',
                          borderRadius: '0' // Square corners
                        }}
                        placeholder="Entrez votre prénom"
                        required
                      />
                    </div>
                  </div>
                )}

                {/* Last Name Field - Only shown when registering */}
                {isRegistering && (
                  <div className="relative group">
                    {/* Glowing border effect */}
                    <div 
                      className="absolute -inset-0 blur opacity-75 group-hover:opacity-100 transition duration-1000"
                      style={{ 
                        backgroundColor: emailBorderColor,
                        boxShadow: neonEffectsEnabled ? `0 0 10px ${emailBorderColor}, 0 0 20px ${emailBorderColor}` : 'none',
                        borderRadius: '0' // Square corners
                      }}
                    ></div>
                    
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <User className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="text"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        className={cn(
                          "block w-full pl-10 pr-3 py-3 bg-gray-900 text-white",
                          "border",
                          "focus:outline-none focus:ring-2",
                          "placeholder-gray-400",
                          "transition-all duration-200"
                        )}
                        style={{ 
                          borderColor: emailBorderColor,
                          boxShadow: neonEffectsEnabled ? `0 0 5px ${emailBorderColor}` : 'none',
                          borderRadius: '0' // Square corners
                        }}
                        placeholder="Entrez votre nom"
                        required
                      />
                    </div>
                  </div>
                )}

                {/* Phone Field - Only shown when registering */}
                {isRegistering && (
                  <div className="relative group">
                    {/* Glowing border effect */}
                    <div 
                      className="absolute -inset-0 blur opacity-75 group-hover:opacity-100 transition duration-1000"
                      style={{ 
                        backgroundColor: emailBorderColor,
                        boxShadow: neonEffectsEnabled ? `0 0 10px ${emailBorderColor}, 0 0 20px ${emailBorderColor}` : 'none',
                        borderRadius: '0' // Square corners
                      }}
                    ></div>
                    
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Phone className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className={cn(
                          "block w-full pl-10 pr-3 py-3 bg-gray-900 text-white",
                          "border",
                          "focus:outline-none focus:ring-2",
                          "placeholder-gray-400",
                          "transition-all duration-200"
                        )}
                        style={{ 
                          borderColor: emailBorderColor,
                          boxShadow: neonEffectsEnabled ? `0 0 5px ${emailBorderColor}` : 'none',
                          borderRadius: '0' // Square corners
                        }}
                        placeholder="Entrez votre numéro"
                        required
                      />
                    </div>
                  </div>
                )}

                {/* Dynamic Password Grid */}
                <div className="space-y-4">
                  <div className="relative">
                    <div 
                      className="absolute -inset-0 blur opacity-75 transition duration-1000"
                      style={{ 
                        backgroundColor: passwordBorderColor,
                        boxShadow: neonEffectsEnabled ? `0 0 10px ${passwordBorderColor}, 0 0 20px ${passwordBorderColor}` : 'none',
                        borderRadius: '0' // Square corners
                      }}
                    ></div>
                    <div 
                      className="relative bg-gray-900 p-4"
                      style={{ 
                        borderColor: passwordBorderColor,
                        border: `1px solid ${passwordBorderColor}`,
                        borderRadius: '0' // Square corners
                      }}
                    >
                      {/* Password Display */}
                      <div className="mb-4 flex justify-between items-center">
                        <div className="text-gray-400 text-sm">Mot de passe:</div>
                        <div className="flex space-x-2">
                          {Array.from({ length: 6 }).map((_, i) => (
                            <div
                              key={i}
                              className={cn(
                                "w-4 h-4 rounded-full",
                                password.length > i
                                  ? ""
                                  : "bg-gray-700"
                              )}
                              style={{ 
                                backgroundColor: password.length > i ? passwordDotsColor : '#374151'
                              }}
                            />
                          ))}
                        </div>
                      </div>

                      {/* Number Grid */}
                      <div className="space-y-2">
                        {/* Top Row */}
                        <div className="grid grid-cols-5 gap-2">
                          {passwordGrid.topRow.map((number, index) => (
                            <button
                              key={`top-${index}`}
                              type="button"
                              onClick={() => handleNumberClick(number)}
                              className="bg-gray-800 hover:bg-gray-700 text-white p-2 transition-colors"
                              style={{ borderRadius: '0' }} // Square corners
                            >
                              {number}
                            </button>
                          ))}
                        </div>
                        {/* Bottom Row */}
                        <div className="grid grid-cols-5 gap-2">
                          {passwordGrid.bottomRow.map((number, index) => (
                            <button
                              key={`bottom-${index}`}
                              type="button"
                              onClick={() => handleNumberClick(number)}
                              className="bg-gray-800 hover:bg-gray-700 text-white p-2 transition-colors"
                              style={{ borderRadius: '0' }} // Square corners
                            >
                              {number}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Clear Button */}
                      <button
                        type="button"
                        onClick={() => setPassword('')}
                        className="mt-4 w-full text-sm text-gray-400 hover:text-white transition-colors"
                      >
                        Effacer
                      </button>
                    </div>
                  </div>
                </div>

                {/* Submit Button */}
                <motion.button
                  type="submit"
                  disabled={isLoading || password.length !== 6 || (isRegistering && (!firstName || !lastName || !phone))}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className={cn(
                    "relative w-full group overflow-hidden",
                    "py-3 px-4 text-white font-medium",
                    "disabled:opacity-50 disabled:cursor-not-allowed"
                  )}
                  style={{ 
                    backgroundColor: loginButtonColor,
                    borderRadius: '0' // Square corners
                  }}
                >
                  {/* Button content */}
                  <span className="relative flex items-center justify-center">
                    {isLoading ? "Connexion en cours..." : isRegistering ? "S'inscrire" : "Se connecter"}
                  </span>
                </motion.button>

                {/* Toggle between login and register */}
                <div className="text-center">
                  <button
                    type="button"
                    onClick={() => {
                      setIsRegistering(!isRegistering);
                      setPassword('');
                      setFirstName('');
                      setLastName('');
                      setPhone('');
                    }}
                    className="text-sm hover:text-white transition-colors"
                    style={{ color: welcomeTextColor }}
                  >
                    {isRegistering ? "Déjà un compte ? Se connecter" : "Pas de compte ? S'inscrire"}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        </div>

        {/* Right Section - Image Display */}
        <div className="w-full md:w-1/2 bg-white relative order-first md:order-last">
          {/* Neon border effect - Square corners */}
          <div 
            className="absolute inset-0 pointer-events-none z-10"
            style={{ 
              boxShadow: neonEffectsEnabled ? `0 0 10px ${neonBorderColor}, 0 0 20px ${neonBorderColor}, 0 0 30px ${neonBorderColor}` : 'none',
              border: `2px solid ${neonBorderColor}`,
              borderRadius: '0' // Square corners
            }}
          ></div>
          
          {settings.imageUrl ? (
            <div className="absolute inset-0">
              <img
                src={settings.imageUrl}
                alt="Homepage"
                className="w-full h-full object-cover"
              />
              {/* Neon glow overlay */}
              {neonEffectsEnabled && (
                <>
                  <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-pink-500/10 mix-blend-overlay"></div>
                  <div className="absolute inset-0 bg-gradient-to-tr from-purple-500/5 to-pink-500/5"></div>
                </>
              )}
            </div>
          ) : (
            <div className="w-full h-full bg-gray-100 flex items-center justify-center">
              <p className="text-gray-400 text-lg">Image à définir dans le panneau admin</p>
            </div>
          )}
        </div>
      </div>
      
      {/* Footer */}
      <Footer />
    </div>
  );
}