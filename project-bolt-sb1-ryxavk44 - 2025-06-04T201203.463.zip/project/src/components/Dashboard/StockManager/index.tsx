import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { StockList } from './StockList';
import { cn } from '../../../utils/cn';

export function StockManager() {
  const [stockCount, setStockCount] = useState(0);

  return (
    <div className="space-y-6">
      {/* Content */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="relative"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/5 to-pink-500/5 rounded-xl blur-xl"></div>
        
        {/* Content container */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <StockList onStockCountChange={setStockCount} />
        </div>
      </motion.div>
    </div>
  );
}