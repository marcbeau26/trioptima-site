import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Trash2, Building2, Check, X } from 'lucide-react';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { generateId } from '../../../utils';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';
import type { Company } from '../../../types';

export function CompanyList() {
  const [companies, setCompanies] = useLocalStorage<Company[]>('companies', []);
  const [companyName, setCompanyName] = useState('');
  const [selectedCompanies, setSelectedCompanies] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleAddCompany = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!companyName.trim()) {
      toast.error("Le nom de l'entreprise est requis");
      return;
    }
    
    // Check if company already exists
    if (companies.some(company => company.name.toLowerCase() === companyName.trim().toLowerCase())) {
      toast.error("Cette entreprise existe déjà");
      return;
    }
    
    setIsSubmitting(true);
    
    const newCompany: Company = {
      id: generateId(),
      name: companyName.trim(),
      dateCreated: new Date().toISOString()
    };
    
    setCompanies([...companies, newCompany]);
    setCompanyName('');
    toast.success("Entreprise ajoutée avec succès");
    setIsSubmitting(false);
  };

  const handleDeleteSelected = () => {
    if (selectedCompanies.length === 0) return;
    
    setCompanies(companies.filter(company => !selectedCompanies.includes(company.id)));
    setSelectedCompanies([]);
    
    toast.success(
      selectedCompanies.length === 1
        ? "Entreprise supprimée avec succès"
        : `${selectedCompanies.length} entreprises supprimées avec succès`
    );
  };

  const toggleSelectAll = () => {
    if (selectedCompanies.length === companies.length) {
      setSelectedCompanies([]);
    } else {
      setSelectedCompanies(companies.map(company => company.id));
    }
  };

  const toggleSelectCompany = (companyId: string) => {
    if (selectedCompanies.includes(companyId)) {
      setSelectedCompanies(selectedCompanies.filter(id => id !== companyId));
    } else {
      setSelectedCompanies([...selectedCompanies, companyId]);
    }
  };

  return (
    <div className="space-y-6">
      {/* Add Company Form */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-6">
          <h2 className="text-xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-6">
            Ajouter une entreprise
          </h2>

          <form onSubmit={handleAddCompany} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                <Building2 className="w-4 h-4 mr-2 text-blue-400" />
                Nom de l'entreprise
              </label>
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                className={cn(
                  "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                  "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                  "placeholder-gray-500 backdrop-blur-sm transition-all duration-200"
                )}
                placeholder="Ex: EDF, Total Energies, Engie..."
              />
            </div>

            <div className="flex justify-end">
              <motion.button
                type="submit"
                disabled={isSubmitting || !companyName.trim()}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="relative group px-6 py-3 rounded-lg overflow-hidden disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
                <span className="relative flex items-center text-white font-medium">
                  <Plus className="w-4 h-4 mr-2" />
                  Ajouter l'entreprise
                </span>
              </motion.button>
            </div>
          </form>
        </div>
      </motion.div>

      {/* Companies List */}
      <div className="relative">
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/5 to-pink-500/5 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Liste des entreprises
            </h2>
            
            {selectedCompanies.length > 0 && (
              <motion.button
                onClick={handleDeleteSelected}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="relative group px-4 py-2 rounded-lg overflow-hidden"
              >
                <div className="absolute inset-0 bg-red-500/80 opacity-80 group-hover:opacity-100 transition-opacity" />
                <span className="relative flex items-center text-white text-sm">
                  <Trash2 className="w-4 h-4 mr-2" />
                  Supprimer ({selectedCompanies.length})
                </span>
              </motion.button>
            )}
          </div>

          {/* Companies Table */}
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-700">
              <thead className="bg-gray-800">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left">
                    <input
                      type="checkbox"
                      checked={selectedCompanies.length === companies.length && companies.length > 0}
                      onChange={toggleSelectAll}
                      className="rounded border-gray-600 text-blue-500 focus:ring-blue-500 bg-gray-700"
                    />
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Nom de l'entreprise
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Date d'ajout
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-gray-900 divide-y divide-gray-800">
                {companies.map((company) => (
                  <tr key={company.id} className="hover:bg-gray-800/50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <input
                        type="checkbox"
                        checked={selectedCompanies.includes(company.id)}
                        onChange={() => toggleSelectCompany(company.id)}
                        className="rounded border-gray-600 text-blue-500 focus:ring-blue-500 bg-gray-700"
                      />
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Building2 className="w-5 h-5 text-blue-400 mr-3" />
                        <span className="text-white font-medium">{company.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                      {new Date(company.dateCreated).toLocaleDateString()} {new Date(company.dateCreated).toLocaleTimeString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <button
                        onClick={() => {
                          setSelectedCompanies([company.id]);
                          handleDeleteSelected();
                        }}
                        className="text-red-400 hover:text-red-300 transition-colors"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {companies.length === 0 && (
              <div className="text-center py-12">
                <Building2 className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-300 mb-2">
                  Aucune entreprise
                </h3>
                <p className="text-gray-500 max-w-md mx-auto">
                  Ajoutez des entreprises pour pouvoir générer des offres d'énergie.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}