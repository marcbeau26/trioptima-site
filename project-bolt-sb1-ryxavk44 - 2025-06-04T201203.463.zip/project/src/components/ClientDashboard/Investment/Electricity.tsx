import React, { useState } from 'react';
import { List, Package, Gift, History as HistoryIcon } from 'lucide-react';
import { Market } from './Electricity/Market';
import { Stock } from './Electricity/Stock';
import { Propositions } from './Propositions';
import { History } from './Electricity/History';
import type { Lead } from '../../../types';

type ElectricityTab = 'market' | 'stock' | 'propositions' | 'history';

export function Electricity() {
  const [activeTab, setActiveTab] = useState<ElectricityTab>('market');
  const currentLeadStr = localStorage.getItem('currentLead');
  const currentLead = currentLeadStr ? JSON.parse(currentLeadStr) as Lead : null;

  // Count active proposals
  const activeProposalsCount = currentLead?.proposals?.filter(p => p.status === 'Active').length || 0;

  // Count active stocks
  const activeStocksCount = currentLead?.energyHoldings?.length || 0;

  // Count completed operations (sale transactions)
  const completedOperationsCount = currentLead?.transactions?.filter(t => t.type === 'sale').length || 0;

  return (
    <div className="space-y-6">
      <div className="border-b border-gray-200 dark:border-gray-700">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('market')}
            className={`
              py-4 px-1 inline-flex items-center border-b-2 text-sm font-medium
              ${activeTab === 'market'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
              }
            `}
          >
            <List className="h-4 w-4 mr-2" />
            Marché en direct pc
          </button>
          <button
            onClick={() => setActiveTab('stock')}
            className={`
              py-4 px-1 inline-flex items-center border-b-2 text-sm font-medium relative
              ${activeTab === 'stock'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
              }
            `}
          >
            <Package className="h-4 w-4 mr-2" />
            Stock pc
            {activeStocksCount > 0 && (
              <span className="absolute -top-1 -right-2 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-green-600 rounded-full">
                {activeStocksCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('propositions')}
            className={`
              py-4 px-1 inline-flex items-center border-b-2 text-sm font-medium relative
              ${activeTab === 'propositions'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
              }
            `}
          >
            <Gift className="h-4 w-4 mr-2" />
            Propositions pc
            {activeProposalsCount > 0 && (
              <span className="absolute -top-1 -right-2 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-red-600 rounded-full">
                {activeProposalsCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`
              py-4 px-1 inline-flex items-center border-b-2 text-sm font-medium relative
              ${activeTab === 'history'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300'
              }
            `}
          >
            <HistoryIcon className="h-4 w-4 mr-2" />
            Historique des opérations pc
            {completedOperationsCount > 0 && (
              <span className="absolute -top-1 -right-2 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-blue-600 rounded-full">
                {completedOperationsCount}
              </span>
            )}
          </button>
        </nav>
      </div>

      <div>
        {activeTab === 'market' && <Market />}
        {activeTab === 'stock' && <Stock />}
        {activeTab === 'propositions' && <Propositions />}
        {activeTab === 'history' && <History />}
      </div>
    </div>
  );
}