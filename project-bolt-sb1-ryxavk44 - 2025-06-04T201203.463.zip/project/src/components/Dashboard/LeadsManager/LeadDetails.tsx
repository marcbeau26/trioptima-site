import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, User, Mail, Phone, Calendar, MapPin, 
  MessageSquare, FileText, DollarSign, Building2, 
  Wallet, Clock, Tag, Edit, Save, X, Trash2, Plus,
  Shield, Info, Check, Hash, Send
} from 'lucide-react';
import type { Lead, Status, Comment } from '../../../types';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { formatDate, generateId } from '../../../utils';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';
import { CommentsModal } from './LeadDetails/CommentsModal';
import { BalanceModal } from './LeadDetails/BalanceModal';
import { DocumentsTab } from './LeadDetails/DocumentsTab';

type TabType = 'info' | 'documents' | 'transactions' | 'comments';

// Export both the default component and a named export for modal usage
function LeadDetailsModal(props: { lead: Lead; isOpen: boolean; onClose: () => void; onSave: (updatedLead: Lead) => void }) {
  return <LeadDetails />;
}

export function LeadDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [statuses] = useLocalStorage<Status[]>('statuses', []);
  const [lead, setLead] = useState<Lead | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editedLead, setEditedLead] = useState<Lead | null>(null);
  const [activeTab, setActiveTab] = useState<TabType>('info');
  const [showCommentsModal, setShowCommentsModal] = useState(false);
  const [showBalanceModal, setShowBalanceModal] = useState(false);
  const [newComment, setNewComment] = useState('');

  useEffect(() => {
    if (id) {
      const foundLead = leads.find(l => l.id === id);
      if (foundLead) {
        setLead(foundLead);
        setEditedLead(foundLead);
      } else {
        navigate('/dashboard', { replace: true });
      }
    }
  }, [id, leads, navigate]);

  const handleBack = () => {
    navigate('/dashboard', { replace: true, state: { activeTab: 'leads' } });
  };

  const handleSave = () => {
    if (!editedLead) return;

    const updatedLeads = leads.map(l => 
      l.id === editedLead.id ? editedLead : l
    );

    setLeads(updatedLeads);
    setLead(editedLead);
    setIsEditing(false);
    toast.success('Informations mises à jour avec succès');
  };

  const handleCancel = () => {
    setEditedLead(lead);
    setIsEditing(false);
  };

  const handleDelete = () => {
    if (!lead) return;

    if (window.confirm(`Êtes-vous sûr de vouloir supprimer ${lead.firstName} ${lead.lastName} ?`)) {
      const updatedLeads = leads.filter(l => l.id !== lead.id);
      setLeads(updatedLeads);
      navigate('/dashboard', { replace: true, state: { activeTab: 'leads' } });
      toast.success('Lead supprimé avec succès');
    }
  };

  const handleUpdateLead = (updatedLead: Lead) => {
    const updatedLeads = leads.map(l => 
      l.id === updatedLead.id ? updatedLead : l
    );
    setLeads(updatedLeads);
    setLead(updatedLead);
  };

  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!lead || !newComment.trim()) return;
    
    const comment: Comment = {
      id: generateId(),
      text: newComment.trim(),
      dateCreated: new Date().toISOString()
    };
    
    const updatedLead = {
      ...lead,
      comments: [...(lead.comments || []), comment]
    };
    
    handleUpdateLead(updatedLead);
    setNewComment('');
    toast.success('Commentaire ajouté avec succès');
  };

  const handleDeleteComment = (commentId: string) => {
    if (!lead) return;
    
    const updatedLead = {
      ...lead,
      comments: (lead.comments || []).filter(c => c.id !== commentId)
    };
    
    handleUpdateLead(updatedLead);
    toast.success('Commentaire supprimé');
  };

  if (!lead) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-400">Chargement...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with futuristic design */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-6">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <button
                onClick={handleBack}
                className="p-2 mr-4 text-gray-400 hover:text-white hover:bg-gray-700/50 rounded-full transition-colors"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                  {lead.firstName} {lead.lastName}
                </h1>
                <div className="flex items-center mt-1 text-gray-400">
                  <Mail className="w-4 h-4 mr-1" />
                  <span>{lead.email}</span>
                </div>
              </div>
            </div>
            <div className="flex space-x-2">
              {isEditing ? (
                <>
                  <button
                    onClick={handleCancel}
                    className="p-2 text-gray-400 hover:text-white hover:bg-gray-700/50 rounded-lg transition-colors"
                  >
                    <X className="h-5 w-5" />
                  </button>
                  <button
                    onClick={handleSave}
                    className="p-2 text-green-400 hover:text-green-300 hover:bg-green-900/20 rounded-lg transition-colors"
                  >
                    <Save className="h-5 w-5" />
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => setIsEditing(true)}
                    className="p-2 text-blue-400 hover:text-blue-300 hover:bg-blue-900/20 rounded-lg transition-colors"
                  >
                    <Edit className="h-5 w-5" />
                  </button>
                  <button
                    onClick={handleDelete}
                    className="p-2 text-red-400 hover:text-red-300 hover:bg-red-900/20 rounded-lg transition-colors"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Tabs with futuristic design */}
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-pink-500/10 rounded-xl blur-xl"></div>
        
        <div className="relative bg-gray-900/50 backdrop-blur-xl border border-white/10 rounded-xl p-2">
          <nav className="flex space-x-2" aria-label="Tabs">
            <TabButton
              icon={<User />}
              text="Informations"
              isActive={activeTab === 'info'}
              onClick={() => setActiveTab('info')}
            />
            <TabButton
              icon={<FileText />}
              text="Documents"
              isActive={activeTab === 'documents'}
              onClick={() => setActiveTab('documents')}
            />
            <TabButton
              icon={<DollarSign />}
              text="Transactions"
              isActive={activeTab === 'transactions'}
              onClick={() => setActiveTab('transactions')}
            />
            <TabButton
              icon={<MessageSquare />}
              text="Commentaires"
              isActive={activeTab === 'comments'}
              onClick={() => setActiveTab('comments')}
            />
          </nav>
        </div>
      </div>

      {/* Content */}
      <div>
        {activeTab === 'info' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-6"
          >
            {/* Personal Information */}
            <div className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
              <div className="relative bg-gray-900 rounded-lg p-6 space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-lg font-medium text-white flex items-center">
                    <User className="h-5 w-5 mr-2 text-blue-400" />
                    Informations personnelles
                  </h2>
                  <button
                    onClick={() => setShowCommentsModal(true)}
                    className="p-2 text-gray-400 hover:text-white hover:bg-gray-700/50 rounded-lg transition-colors"
                  >
                    <MessageSquare className="h-5 w-5" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm text-gray-400">Prénom</label>
                    {isEditing ? (
                      <input
                        type="text"
                        value={editedLead?.firstName || ''}
                        onChange={(e) => setEditedLead(prev => prev ? {...prev, firstName: e.target.value} : null)}
                        className="mt-1 block w-full rounded-md border-gray-600 bg-gray-800/50 text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      />
                    ) : (
                      <p className="text-white">{lead.firstName}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm text-gray-400">Nom</label>
                    {isEditing ? (
                      <input
                        type="text"
                        value={editedLead?.lastName || ''}
                        onChange={(e) => setEditedLead(prev => prev ? {...prev, lastName: e.target.value} : null)}
                        className="mt-1 block w-full rounded-md border-gray-600 bg-gray-800/50 text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      />
                    ) : (
                      <p className="text-white">{lead.lastName}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm text-gray-400">Email</label>
                    {isEditing ? (
                      <input
                        type="email"
                        value={editedLead?.email || ''}
                        onChange={(e) => setEditedLead(prev => prev ? {...prev, email: e.target.value} : null)}
                        className="mt-1 block w-full rounded-md border-gray-600 bg-gray-800/50 text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      />
                    ) : (
                      <div className="flex items-center">
                        <Mail className="h-4 w-4 mr-2 text-gray-400" />
                        <p className="text-white">{lead.email}</p>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm text-gray-400">Téléphone</label>
                    {isEditing ? (
                      <input
                        type="tel"
                        value={editedLead?.phone || ''}
                        onChange={(e) => setEditedLead(prev => prev ? {...prev, phone: e.target.value} : null)}
                        className="mt-1 block w-full rounded-md border-gray-600 bg-gray-800/50 text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      />
                    ) : (
                      <div className="flex items-center">
                        <Phone className="h-4 w-4 mr-2 text-gray-400" />
                        <p className="text-white">{lead.phone}</p>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm text-gray-400">Adresse</label>
                    {isEditing ? (
                      <input
                        type="text"
                        value={editedLead?.address || ''}
                        onChange={(e) => setEditedLead(prev => prev ? {...prev, address: e.target.value} : null)}
                        className="mt-1 block w-full rounded-md border-gray-600 bg-gray-800/50 text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        placeholder="Adresse"
                      />
                    ) : (
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-2 text-gray-400" />
                        <p className="text-white">{lead.address || 'Non renseignée'}</p>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm text-gray-400">Date d'entrée</label>
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                      <p className="text-white">{formatDate(lead.dateCreated)}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Account Information */}
            <div className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-500 via-pink-500 to-blue-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
              <div className="relative bg-gray-900 rounded-lg p-6 space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-lg font-medium text-white flex items-center">
                    <Building2 className="h-5 w-5 mr-2 text-purple-400" />
                    Informations du compte
                  </h2>
                  <button
                    onClick={() => setShowBalanceModal(true)}
                    className="p-2 text-gray-400 hover:text-white hover:bg-gray-700/50 rounded-lg transition-colors"
                  >
                    <Wallet className="h-5 w-5" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm text-gray-400">Solde</label>
                    <div className="flex items-center">
                      <DollarSign className="h-4 w-4 mr-2 text-green-400" />
                      <p className="text-white">{(lead.balance || 0).toLocaleString()}€</p>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm text-gray-400">Source</label>
                    {isEditing ? (
                      <input
                        type="text"
                        value={editedLead?.source || ''}
                        onChange={(e) => setEditedLead(prev => prev ? {...prev, source: e.target.value} : null)}
                        className="mt-1 block w-full rounded-md border-gray-600 bg-gray-800/50 text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      />
                    ) : (
                      <p className="text-white">{lead.source}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm text-gray-400">Statut</label>
                    {isEditing ? (
                      <select
                        value={editedLead?.statusId || ''}
                        onChange={(e) => setEditedLead(prev => prev ? {...prev, statusId: e.target.value} : null)}
                        className="mt-1 block w-full rounded-md border-gray-600 bg-gray-800/50 text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      >
                        <option value="">Sélectionner un statut</option>
                        {statuses.map((status) => (
                          <option key={status.id} value={status.id}>
                            {status.name}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <div className="flex items-center">
                        <Tag className="h-4 w-4 mr-2 text-gray-400" />
                        <span 
                          className="px-2 py-1 rounded-full text-xs font-medium" 
                          style={{ 
                            backgroundColor: lead.statusId 
                              ? statuses.find(s => s.id === lead.statusId)?.color || '#4B5563' 
                              : '#4B5563',
                            color: '#ffffff'
                          }}
                        >
                          {lead.statusId 
                            ? statuses.find(s => s.id === lead.statusId)?.name || 'Non défini' 
                            : 'Non défini'}
                        </span>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm text-gray-400">Assigné à</label>
                    {isEditing ? (
                      <select
                        value={editedLead?.assignedTo || ''}
                        onChange={(e) => setEditedLead(prev => prev ? {...prev, assignedTo: e.target.value || undefined} : null)}
                        className="mt-1 block w-full rounded-md border-gray-600 bg-gray-800/50 text-white shadow-sm focus:border-blue-500 focus:ring-blue-500"
                      >
                        <option value="">Non assigné</option>
                        {/* Seller options would go here */}
                      </select>
                    ) : (
                      <p className="text-white">{lead.assignedTo ? 'Assigné' : 'Non assigné'}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm text-gray-400">Dernière activité</label>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-2 text-gray-400" />
                      <p className="text-white">
                        {lead.transactions && lead.transactions.length > 0
                          ? formatDate(lead.transactions[lead.transactions.length - 1].dateCreated)
                          : 'Aucune activité'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'documents' && (
          <DocumentsTab lead={lead} onUpdateLead={handleUpdateLead} />
        )}

        {activeTab === 'transactions' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-green-500 via-emerald-500 to-teal-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
              <div className="relative bg-gray-900 rounded-lg p-6">
                <h2 className="text-lg font-medium text-white mb-4 flex items-center">
                  <DollarSign className="h-5 w-5 mr-2 text-green-400" />
                  Historique des transactions
                </h2>

                {lead.transactions && lead.transactions.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-700">
                      <thead className="bg-gray-800/50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            Date
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            Type
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            Montant
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                            Description
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-gray-900 divide-y divide-gray-800">
                        {lead.transactions
                          .sort((a, b) => new Date(b.dateCreated).getTime() - new Date(a.dateCreated).getTime())
                          .map((transaction) => (
                            <tr key={transaction.id} className="hover:bg-gray-800/50 transition-colors">
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                                {formatDate(transaction.dateCreated)}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                  transaction.type === 'deposit'
                                    ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
                                    : transaction.type === 'withdrawal'
                                    ? 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
                                    : transaction.type === 'investment'
                                    ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400'
                                    : transaction.type === 'sale'
                                    ? 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400'
                                    : 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400'
                                }`}>
                                  {transaction.type}
                                </span>
                              </td>
                              <td className={`px-6 py-4 whitespace-nowrap text-sm font-medium ${
                                transaction.amount >= 0 ? 'text-green-400' : 'text-red-400'
                              }`}>
                                {transaction.amount >= 0 ? '+' : ''}{transaction.amount.toLocaleString()}€
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                                {transaction.description}
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-400">Aucune transaction à afficher</p>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'comments' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
              <div className="relative bg-gray-900 rounded-lg p-6">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-lg font-medium text-white flex items-center">
                    <MessageSquare className="h-5 w-5 mr-2 text-blue-400" />
                    Commentaires
                  </h2>
                  <div className="text-sm text-gray-400">
                    {lead.comments?.length || 0} commentaire{(lead.comments?.length || 0) !== 1 ? 's' : ''}
                  </div>
                </div>

                {/* Add Comment Form */}
                <form onSubmit={handleAddComment} className="mb-6">
                  <div className="flex space-x-2">
                    <div className="flex-1 relative">
                      <textarea
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        placeholder="Ajouter un commentaire..."
                        className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50 resize-none"
                        rows={2}
                      />
                    </div>
                    <motion.button
                      type="submit"
                      disabled={!newComment.trim()}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="relative group px-4 py-3 rounded-lg overflow-hidden disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
                      <span className="relative flex items-center text-white">
                        <Send className="w-5 h-5" />
                      </span>
                    </motion.button>
                  </div>
                </form>

                {/* Comments List */}
                <div className="space-y-4 max-h-[400px] overflow-y-auto custom-scrollbar pr-2">
                  {lead.comments && lead.comments.length > 0 ? (
                    lead.comments
                      .sort((a, b) => new Date(b.dateCreated).getTime() - new Date(a.dateCreated).getTime())
                      .map((comment) => (
                        <motion.div
                          key={comment.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="relative group"
                        >
                          <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
                          <div className="relative bg-gray-800/50 rounded-lg p-4">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <p className="text-white whitespace-pre-wrap">
                                  {comment.text}
                                </p>
                                <p className="text-sm text-gray-400 mt-2">
                                  {formatDate(comment.dateCreated)}
                                </p>
                              </div>
                              <button
                                onClick={() => handleDeleteComment(comment.id)}
                                className="ml-4 text-gray-400 hover:text-red-400 transition-colors opacity-0 group-hover:opacity-100"
                                title="Supprimer le commentaire"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      ))
                  ) : (
                    <div className="text-center py-8">
                      <MessageSquare className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                      <p className="text-gray-400">
                        Aucun commentaire pour le moment
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* Modals */}
      <AnimatePresence>
        {showCommentsModal && (
          <CommentsModal
            lead={lead}
            isOpen={showCommentsModal}
            onClose={() => setShowCommentsModal(false)}
            onUpdate={handleUpdateLead}
          />
        )}

        {showBalanceModal && (
          <BalanceModal
            lead={lead}
            isOpen={showBalanceModal}
            onClose={() => setShowBalanceModal(false)}
            onUpdate={handleUpdateLead}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

// TabButton component with futuristic design
interface TabButtonProps {
  icon: React.ReactNode;
  text: string;
  isActive: boolean;
  onClick: () => void;
}

const TabButton: React.FC<TabButtonProps> = ({ icon, text, isActive, onClick }) => (
  <motion.button
    onClick={onClick}
    className={cn(
      "relative group overflow-hidden rounded-lg",
      "py-3 px-6 text-sm font-medium transition-all duration-300"
    )}
    whileHover={{ scale: 1.02 }}
    whileTap={{ scale: 0.98 }}
  >
    {/* Active/Hover background */}
    <div className={cn(
      "absolute inset-0 transition-opacity duration-300",
      isActive
        ? "opacity-100"
        : "opacity-0 group-hover:opacity-50",
      "bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500"
    )} />

    {/* Content */}
    <div className="relative flex items-center justify-center space-x-2">
      {React.cloneElement(icon as React.ReactElement, {
        className: cn(
          "w-4 h-4 transition-colors",
          isActive ? "text-white" : "text-gray-400 group-hover:text-white"
        )
      })}
      <span className={cn(
        "transition-colors",
        isActive ? "text-white" : "text-gray-400 group-hover:text-white"
      )}>
        {text}
      </span>
    </div>
  </motion.button>
);