import React, { useState } from 'react';
import { X, TrendingUp, TrendingDown, Euro, DollarSign } from 'lucide-react';
import type { Lead } from '../../../types';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { formatDate, formatPrice } from '../../../utils';
import { toast } from 'react-hot-toast';
import { motion } from 'framer-motion';

export function SubscribedActions() {
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);

  // Get all leads with stock holdings
  const leadsWithStocks = leads.filter(lead => lead.stockHoldings && lead.stockHoldings.length > 0);

  const handleDeleteStock = (leadId: string, stockId: string) => {
    const lead = leads.find(l => l.id === leadId);
    if (!lead || !lead.stockHoldings) return;

    const stock = lead.stockHoldings.find(s => s.id === stockId);
    if (!stock) return;

    // Update lead's balance and remove stock
    const updatedLeads = leads.map(l => {
      if (l.id === leadId) {
        return {
          ...l,
          balance: (l.balance || 0) + stock.totalCost,
          stockHoldings: l.stockHoldings?.filter(s => s.id !== stockId),
          transactions: [
            ...(l.transactions || []),
            {
              id: Math.random().toString(36).substr(2, 9),
              amount: stock.totalCost,
              type: 'withdrawal',
              description: `Annulation de l'achat de ${stock.quantity} actions de ${stock.name}`,
              dateCreated: new Date().toISOString()
            }
          ]
        };
      }
      return l;
    });

    setLeads(updatedLeads);

    // Update current lead in localStorage if needed
    const currentLeadStr = localStorage.getItem('currentLead');
    if (currentLeadStr) {
      const currentLead = JSON.parse(currentLeadStr);
      if (currentLead.id === leadId) {
        const updatedLead = updatedLeads.find(l => l.id === leadId);
        if (updatedLead) {
          localStorage.setItem('currentLead', JSON.stringify(updatedLead));
        }
      }
    }

    toast.success('Action supprimée avec succès');
  };

  if (leadsWithStocks.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <div className="text-center py-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 dark:bg-gray-700 mb-4">
            <TrendingUp className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            Aucune action souscrite
          </h3>
          <p className="text-gray-500 dark:text-gray-400">
            Aucun client n'a encore souscrit d'actions.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
      <div className="p-6 space-y-6">
        {leadsWithStocks.map((lead) => (
          <div key={lead.id} className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                {lead.firstName} {lead.lastName}
              </h3>
              <span className="text-sm text-gray-500 dark:text-gray-400">
                {lead.email}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {lead.stockHoldings?.map((stock) => (
                <motion.div
                  key={stock.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="relative group"
                >
                  {/* Glowing border effect */}
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
                  
                  {/* Card content */}
                  <div className="relative bg-gray-900 rounded-lg p-4 ring-1 ring-gray-800/50">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h4 className="text-lg font-medium text-white">
                          {stock.name}
                        </h4>
                        <p className="text-sm text-gray-400">
                          {formatDate(stock.purchaseDate)}
                        </p>
                      </div>
                      <button
                        onClick={() => handleDeleteStock(lead.id, stock.id)}
                        className="text-gray-400 hover:text-red-400 transition-colors"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Quantité</span>
                        <span className="text-white">{stock.quantity}</span>
                      </div>

                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Prix unitaire</span>
                        <div className="flex items-center text-white">
                          {stock.currency === 'USD' ? (
                            <>
                              <DollarSign className="w-4 h-4 mr-1" />
                              <span>{formatPrice(stock.purchasePrice)}</span>
                            </>
                          ) : (
                            <>
                              <span>{formatPrice(stock.purchasePrice)}</span>
                              <Euro className="w-4 h-4 ml-1" />
                            </>
                          )}
                        </div>
                      </div>

                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Coût total</span>
                        <div className="flex items-center text-white">
                          {stock.currency === 'USD' ? (
                            <>
                              <DollarSign className="w-4 h-4 mr-1" />
                              <span>{formatPrice(stock.totalCost)}</span>
                            </>
                          ) : (
                            <>
                              <span>{formatPrice(stock.totalCost)}</span>
                              <Euro className="w-4 h-4 ml-1" />
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}