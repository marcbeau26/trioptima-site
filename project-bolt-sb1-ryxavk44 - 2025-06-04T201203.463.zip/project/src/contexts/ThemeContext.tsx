import React, { createContext, useContext } from 'react';
import type { ThemeContextType } from '../types';

const ThemeContext = createContext<ThemeContextType>({
  isDarkMode: true,
  toggleTheme: () => {},
});

const useTheme = () => useContext(ThemeContext);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Always use dark mode
  const isDarkMode = true;
  const toggleTheme = () => {}; // No-op function

  // Apply dark mode to document
  document.documentElement.classList.add('dark');

  return (
    <ThemeContext.Provider value={{ isDarkMode, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

;