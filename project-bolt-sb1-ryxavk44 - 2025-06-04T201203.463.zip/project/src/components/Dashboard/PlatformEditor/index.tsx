import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Home, Image as ImageIcon } from 'lucide-react';
import { HomepageInterface } from './HomepageInterface';
import { cn } from '../../../utils/cn';
import type { TabType } from '../../../types';

interface TabButtonProps {
  icon: React.ReactNode;
  text: string;
  isActive: boolean;
  onClick: () => void;
}

const TabButton: React.FC<TabButtonProps> = ({ icon, text, isActive, onClick }) => (
  <motion.button
    onClick={onClick}
    className={cn(
      "relative group overflow-hidden rounded-lg",
      "py-3 px-6 text-sm font-medium transition-all duration-300"
    )}
    whileHover={{ scale: 1.02 }}
    whileTap={{ scale: 0.98 }}
  >
    {/* Active/Hover background */}
    <div className={cn(
      "absolute inset-0 transition-opacity duration-300",
      isActive
        ? "opacity-100"
        : "opacity-0 group-hover:opacity-50",
      "bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500"
    )} />

    {/* Content */}
    <div className="relative flex items-center justify-center space-x-2">
      {React.cloneElement(icon as React.ReactElement, {
        className: cn(
          "w-4 h-4 transition-colors",
          isActive ? "text-white" : "text-gray-400 group-hover:text-white"
        )
      })}
      <span className={cn(
        "transition-colors",
        isActive ? "text-white" : "text-gray-400 group-hover:text-white"
      )}>
        {text}
      </span>
    </div>
  </motion.button>
);

export function PlatformEditor() {
  const [activeTab, setActiveTab] = useState<TabType>('homepage');

  return (
    <div className="space-y-6">
      {/* Futuristic Tab Navigation */}
      <div className="relative">
        {/* Glowing background effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Navigation container */}
        <div className="relative bg-gray-900/50 backdrop-blur-xl border border-white/10 rounded-xl p-2">
          <nav className="flex flex-wrap gap-2" aria-label="Tabs">
            <TabButton
              icon={<ImageIcon />}
              text="Page d'accueil"
              isActive={activeTab === 'homepage'}
              onClick={() => setActiveTab('homepage')}
            />
          </nav>
        </div>
      </div>

      {/* Content */}
      <motion.div
        key={activeTab}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="relative"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/5 to-pink-500/5 rounded-xl blur-xl"></div>
        
        {/* Content container */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          {activeTab === 'homepage' && <HomepageInterface />}
        </div>
      </motion.div>
    </div>
  );
}