import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, Info, Shield, Trash2, ChevronRight, X } from 'lucide-react';
import type { Lead, User, Message, Chat as ChatType } from '../../../types';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { ChatWindow } from '../../Chat/ChatWindow';
import { generateId } from '../../../utils';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';

interface DeleteConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  leadName: string;
}

function DeleteConfirmModal({ isOpen, onClose, onConfirm, leadName }: DeleteConfirmModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-md mx-4"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-red-500/20 to-pink-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-orange-500/20 to-red-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <h2 className="text-2xl font-bold text-white mb-4">
            Supprimer la conversation
          </h2>
          
          <p className="text-gray-300 mb-6">
            Êtes-vous sûr de vouloir supprimer définitivement la conversation avec {leadName} ? Cette action est irréversible.
          </p>

          <div className="flex space-x-4">
            <button
              onClick={onClose}
              className="flex-1 px-6 py-3 text-sm font-medium text-gray-300 bg-gray-800/50 hover:bg-gray-700/50 border border-white/10 rounded-lg transition-colors"
            >
              Annuler
            </button>
            <motion.button
              onClick={onConfirm}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="flex-1 relative group overflow-hidden px-6 py-3 rounded-lg"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-red-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity"></div>
              <span className="relative text-sm font-medium text-white">
                Supprimer
              </span>
            </motion.button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export function Chat() {
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);
  const [unreadCounts, setUnreadCounts] = useState<Record<string, number>>({});
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [leadToDelete, setLeadToDelete] = useState<Lead | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Get current seller
  const currentUserStr = localStorage.getItem('user');
  const currentUser = currentUserStr ? JSON.parse(currentUserStr) : null;

  // Get leads assigned to current seller
  // Only include leads that are explicitly assigned and not pending registrations
  const assignedLeads = leads.filter(lead => 
    lead.assignedTo === currentUser?.id && 
    (!lead.isRegistration || lead.registrationStatus === 'approved')
  );

  // Get selected lead's chat
  const selectedLead = leads.find(lead => lead.id === selectedLeadId);
  const selectedChat = selectedLead?.chat || (selectedLead ? {
    id: generateId(),
    leadId: selectedLead.id,
    messages: [],
    unreadCount: 0,
    lastMessageTimestamp: new Date().toISOString()
  } : null);

  useEffect(() => {
    // Check for selected lead from leads list
    const selectedLeadId = localStorage.getItem('selectedChatLead');
    if (selectedLeadId) {
      setSelectedLeadId(selectedLeadId);
      // Clear the selected lead from localStorage
      localStorage.removeItem('selectedChatLead');
    }
  }, []);

  useEffect(() => {
    // Calculate unread counts
    const counts: Record<string, number> = {};
    
    // Count unread messages from leads assigned to this seller
    assignedLeads.forEach(lead => {
      if (lead.chat) {
        counts[lead.id] = lead.chat.unreadCount || 0;
      }
    });
    
    setUnreadCounts(counts);
  }, [assignedLeads]);

  const handleSendMessage = (leadId: string, content: string, attachments?: File[]) => {
    const message: Message = {
      id: generateId(),
      senderId: currentUser.id,
      senderType: 'admin',
      content,
      timestamp: new Date().toISOString(),
      attachments: attachments?.map(file => ({
        name: file.name,
        url: URL.createObjectURL(file),
        type: file.type
      }))
    };

    const updatedLeads = leads.map(lead => {
      if (lead.id === leadId) {
        return {
          ...lead,
          chat: {
            id: lead.chat?.id || generateId(),
            leadId: lead.id,
            messages: [...(lead.chat?.messages || []), message],
            unreadCount: 0,
            lastMessageTimestamp: message.timestamp
          }
        };
      }
      return lead;
    });

    setLeads(updatedLeads);
    toast.success('Message envoyé');
  };

  const handleLeadSelect = (leadId: string) => {
    setSelectedLeadId(leadId);
    
    // Mark messages as read
    const updatedLeads = leads.map(lead => {
      if (lead.id === leadId && lead.chat) {
        return {
          ...lead,
          chat: {
            ...lead.chat,
            unreadCount: 0
          }
        };
      }
      return lead;
    });
    
    setLeads(updatedLeads);
  };

  const handleDeleteChat = (lead: Lead, e: React.MouseEvent) => {
    e.stopPropagation();
    setLeadToDelete(lead);
    setDeleteConfirmOpen(true);
  };

  const confirmDeleteChat = () => {
    if (!leadToDelete) return;

    const updatedLeads = leads.map(lead => {
      if (lead.id === leadToDelete.id) {
        // Remove chat from lead
        const { chat, ...leadWithoutChat } = lead;
        return leadWithoutChat;
      }
      return lead;
    });

    setLeads(updatedLeads);

    // Update current lead in localStorage if needed
    const currentLeadStr = localStorage.getItem('currentLead');
    if (currentLeadStr) {
      const currentLead = JSON.parse(currentLeadStr);
      if (currentLead.id === leadToDelete.id) {
        const { chat, ...currentLeadWithoutChat } = currentLead;
        localStorage.setItem('currentLead', JSON.stringify(currentLeadWithoutChat));
      }
    }

    // Reset selection if deleted chat was selected
    if (selectedLeadId === leadToDelete.id) {
      setSelectedLeadId(null);
    }

    setDeleteConfirmOpen(false);
    setLeadToDelete(null);
    toast.success('Conversation supprimée');
  };

  return (
    <div className="relative h-[calc(100vh-12rem)]">
      {/* Background effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 rounded-xl blur-2xl"></div>
      <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/5 to-pink-500/5 rounded-xl blur-xl"></div>

      {/* Content */}
      <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl h-full overflow-hidden">
        <div className="flex h-full">
          {/* Leads List */}
          <div className="w-80 border-r border-gray-700/50">
            <div className="p-4 border-b border-gray-700/50">
              <h2 className="text-lg font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                Conversations
              </h2>
            </div>
            <div className="overflow-y-auto h-[calc(100%-4rem)] custom-scrollbar">
              <AnimatePresence>
                {assignedLeads.map((lead) => (
                  <motion.button
                    key={lead.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    onClick={() => handleLeadSelect(lead.id)}
                    className={cn(
                      "w-full p-4 text-left transition-all duration-200 relative group",
                      selectedLeadId === lead.id 
                        ? "bg-gray-800/80" 
                        : "hover:bg-gray-800/50"
                    )}
                  >
                    {/* Hover glow effect */}
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-500/0 via-purple-500/10 to-pink-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                    <div className="relative">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="relative">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                              <Shield className="w-5 h-5 text-white" />
                            </div>
                            {unreadCounts[lead.id] > 0 && (
                              <div className="absolute -top-1 -right-1">
                                <span className="flex h-4 w-4">
                                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                                  <span className="relative inline-flex rounded-full h-4 w-4 bg-blue-500 items-center justify-center text-[10px] font-bold text-white">
                                    {unreadCounts[lead.id]}
                                  </span>
                                </span>
                              </div>
                            )}
                          </div>
                          <div>
                            <h3 className="font-medium text-white">
                              {lead.firstName} {lead.lastName}
                            </h3>
                            <p className="text-sm text-gray-400">{lead.email}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={(e) => handleDeleteChat(lead, e)}
                            className="text-gray-400 hover:text-red-400 transition-colors opacity-0 group-hover:opacity-100"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                          <ChevronRight className="w-4 h-4 text-gray-500 group-hover:text-gray-300 transition-colors" />
                        </div>
                      </div>
                      {lead.chat?.lastMessageTimestamp && (
                        <div className="mt-2 flex items-center text-xs text-gray-500">
                          {new Date(lead.chat.lastMessageTimestamp).toLocaleString()}
                        </div>
                      )}
                    </div>
                  </motion.button>
                ))}
              </AnimatePresence>
              {assignedLeads.length === 0 && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex flex-col items-center justify-center h-full text-gray-500"
                >
                  <MessageSquare className="w-12 h-12 mb-2" />
                  <p>Aucune conversation</p>
                </motion.div>
              )}
            </div>
          </div>

          {/* Chat Window */}
          <div className="flex-1 bg-gray-900/50">
            {selectedChat ? (
              <ChatWindow
                chat={selectedChat}
                isAdmin={true}
                onSendMessage={(content, attachments) => 
                  handleSendMessage(selectedLeadId!, content, attachments)
                }
              />
            ) : (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center h-full space-y-4"
              >
                <div className="relative">
                  <div className="absolute -inset-4 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-full blur-xl opacity-50 animate-pulse"></div>
                  <div className="relative w-16 h-16 rounded-full bg-gray-800/80 backdrop-blur-xl border border-white/10 flex items-center justify-center">
                    <Info className="w-8 h-8 text-gray-400" />
                  </div>
                </div>
                <p className="text-gray-400 text-center max-w-md">
                  Sélectionnez une conversation pour commencer
                </p>
              </motion.div>
            )}
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {leadToDelete && (
          <DeleteConfirmModal
            isOpen={deleteConfirmOpen}
            onClose={() => {
              setDeleteConfirmOpen(false);
              setLeadToDelete(null);
            }}
            onConfirm={confirmDeleteChat}
            leadName={`${leadToDelete.firstName} ${leadToDelete.lastName}`}
          />
        )}
      </AnimatePresence>
    </div>
  );
}