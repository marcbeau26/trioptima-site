import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Users, UserCheck, Zap, Sparkles } from 'lucide-react';
import { AddLeadForm } from './AddLeadForm';
import { LeadsList } from './LeadsList';
import { AssignedLeads } from './AssignedLeads';
import type { TabType } from '../../../types';
import { cn } from '../../../utils/cn';

interface TabButtonProps {
  icon: React.ReactNode;
  text: string;
  isActive: boolean;
  onClick: () => void;
}

const TabButton: React.FC<TabButtonProps> = ({ icon, text, isActive, onClick }) => (
  <motion.button
    onClick={onClick}
    className={cn(
      "relative group overflow-hidden rounded-lg",
      "py-3 px-6 text-sm font-medium transition-all duration-300"
    )}
    whileHover={{ 
      scale: 1.05,
      boxShadow: "0 0 15px rgba(59, 130, 246, 0.5)"
    }}
    whileTap={{ scale: 0.95 }}
  >
    {/* Animated background glow */}
    <div className={cn(
      "absolute inset-0 transition-opacity duration-300",
      isActive
        ? "opacity-100"
        : "opacity-0 group-hover:opacity-70",
      "bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600"
    )} />
    
    {/* Animated border effect */}
    <div className={cn(
      "absolute inset-0 opacity-0 group-hover:opacity-100",
      "border border-blue-500/50 rounded-lg",
      isActive ? "animate-pulse" : ""
    )} />

    {/* Content */}
    <div className="relative flex items-center justify-center space-x-2 z-10">
      {React.cloneElement(icon as React.ReactElement, {
        className: cn(
          "w-4 h-4 transition-all duration-300 filter drop-shadow-glow",
          isActive ? "text-white" : "text-gray-400 group-hover:text-white"
        )
      })}
      <span className={cn(
        "transition-all duration-300 font-['Space_Grotesk'] tracking-wide",
        isActive ? "text-white" : "text-gray-400 group-hover:text-white"
      )}>
        {text}
      </span>
    </div>
    
    {/* Subtle particle effect */}
    {isActive && (
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-1/4 w-1 h-1 bg-blue-400 rounded-full animate-float opacity-70"></div>
        <div className="absolute bottom-1/4 right-1/3 w-1 h-1 bg-purple-400 rounded-full animate-float opacity-70" style={{animationDelay: '1s'}}></div>
        <div className="absolute top-1/3 right-1/4 w-1 h-1 bg-indigo-400 rounded-full animate-float opacity-70" style={{animationDelay: '2s'}}></div>
      </div>
    )}
  </motion.button>
);

export function LeadsManager() {
  const [activeTab, setActiveTab] = useState<TabType>('list');

  return (
    <div className="space-y-6">
      {/* Futuristic Tab Navigation */}
      <div className="relative">
        {/* Animated background glow effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-pink-500/20 rounded-xl blur-xl animate-pulse" style={{animationDuration: '4s'}}></div>
        
        {/* Navigation container with glass effect */}
        <div className="relative bg-gray-900/70 backdrop-blur-xl border border-white/10 rounded-xl p-3 shadow-lg">
          {/* Subtle light beam effect */}
          <div className="absolute inset-0 overflow-hidden rounded-xl">
            <div className="absolute -inset-[10%] bg-gradient-to-r from-transparent via-white/5 to-transparent skew-x-12 animate-[gradient-x_8s_ease_infinite] pointer-events-none"></div>
          </div>
          
          {/* Animated glow line at top */}
          <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-blue-500 via-purple-500 to-blue-500 animate-gradient-x"></div>
          
          {/* Tabs with hover effects */}
          <nav className="relative flex flex-wrap gap-2 z-10 p-1" aria-label="Tabs">
            <TabButton
              icon={<Plus className="filter drop-shadow-glow" />}
              text="Ajouter un lead"
              isActive={activeTab === 'add'}
              onClick={() => setActiveTab('add')}
            />
            <TabButton
              icon={<Users className="filter drop-shadow-glow" />}
              text="Liste des leads"
              isActive={activeTab === 'list'}
              onClick={() => setActiveTab('list')}
            />
            <TabButton
              icon={<UserCheck className="filter drop-shadow-glow" />}
              text="Leads attribués"
              isActive={activeTab === 'assigned'}
              onClick={() => setActiveTab('assigned')}
            />
          </nav>
        </div>
      </div>

      {/* Content */}
      <motion.div
        key={activeTab}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="relative"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/5 to-pink-500/5 rounded-xl blur-xl"></div>
        
        {/* Content container */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          {activeTab === 'add' && <AddLeadForm />}
          {activeTab === 'list' && <LeadsList />}
          {activeTab === 'assigned' && <AssignedLeads />}
        </div>
      </motion.div>
    </div>
  );
}