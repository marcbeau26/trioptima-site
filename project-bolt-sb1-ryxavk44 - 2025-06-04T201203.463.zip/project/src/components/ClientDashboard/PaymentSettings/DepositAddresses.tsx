import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Plus, Trash2, Check, Copy, AlertCircle, Building2, Bitcoin } from 'lucide-react';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import type { Lead, DepositAddress, CryptoAddress } from '../../../types';
import { generateId } from '../../../utils';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';

interface AddressFormData {
  bankName: string;
  accountHolder: string;
  iban: string;
  bic: string;
  label?: string;
}

const initialFormData: AddressFormData = {
  bankName: '',
  accountHolder: '',
  iban: '',
  bic: '',
  label: ''
};

export function DepositAddresses() {
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState<AddressFormData>(initialFormData);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [cryptoAddresses] = useLocalStorage<CryptoAddress[]>('cryptoAddresses', []);
  
  const currentLeadStr = localStorage.getItem('currentLead');
  const currentLead = currentLeadStr ? JSON.parse(currentLeadStr) as Lead : null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    if (!formData.bankName.trim()) {
      setErrors(prev => ({ ...prev, bankName: 'Le nom de la banque est requis' }));
      return;
    }
    if (!formData.accountHolder.trim()) {
      setErrors(prev => ({ ...prev, accountHolder: 'Le titulaire du compte est requis' }));
      return;
    }
    if (!formData.iban.trim()) {
      setErrors(prev => ({ ...prev, iban: 'L\'IBAN est requis' }));
      return;
    }
    if (!formData.bic.trim()) {
      setErrors(prev => ({ ...prev, bic: 'Le BIC est requis' }));
      return;
    }

    const newAddress: DepositAddress = {
      id: generateId(),
      bankName: formData.bankName,
      accountHolder: formData.accountHolder,
      iban: formData.iban,
      bic: formData.bic,
      label: formData.label,
      dateCreated: new Date().toISOString(),
      isDefault: !(currentLead?.depositAddresses || []).length
    };

    if (!currentLead) return;

    const updatedLeads = leads.map(lead => {
      if (lead.id === currentLead.id) {
        return {
          ...lead,
          depositAddresses: [...(lead.depositAddresses || []), newAddress]
        };
      }
      return lead;
    });

    setLeads(updatedLeads);
    const updatedLead = updatedLeads.find(l => l.id === currentLead.id);
    if (updatedLead) {
      localStorage.setItem('currentLead', JSON.stringify(updatedLead));
    }

    setFormData(initialFormData);
    setShowForm(false);
    toast.success('Adresse de dépôt ajoutée avec succès');
  };

  const handleDelete = (addressId: string) => {
    if (!currentLead) return;

    const updatedLeads = leads.map(lead => {
      if (lead.id === currentLead.id) {
        return {
          ...lead,
          depositAddresses: (lead.depositAddresses || []).filter(addr => addr.id !== addressId)
        };
      }
      return lead;
    });

    setLeads(updatedLeads);
    const updatedLead = updatedLeads.find(l => l.id === currentLead.id);
    if (updatedLead) {
      localStorage.setItem('currentLead', JSON.stringify(updatedLead));
    }

    toast.success('Adresse supprimée');
  };

  const handleSetDefault = (addressId: string) => {
    if (!currentLead) return;

    const updatedLeads = leads.map(lead => {
      if (lead.id === currentLead.id) {
        return {
          ...lead,
          depositAddresses: (lead.depositAddresses || []).map(addr => ({
            ...addr,
            isDefault: addr.id === addressId
          }))
        };
      }
      return lead;
    });

    setLeads(updatedLeads);
    const updatedLead = updatedLeads.find(l => l.id === currentLead.id);
    if (updatedLead) {
      localStorage.setItem('currentLead', JSON.stringify(updatedLead));
    }

    toast.success('Adresse définie par défaut');
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Information copiée dans le presse-papier');
  };

  if (!currentLead) return null;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
          Mes adresses de dépôt
        </h2>
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setShowForm(!showForm)}
          className="relative group overflow-hidden px-6 py-2 rounded-xl"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
          <div className="relative flex items-center text-white">
            <Plus size={20} className="mr-2" />
            <span className="font-medium">Ajouter une adresse</span>
          </div>
        </motion.button>
      </div>

      {showForm && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative"
        >
          {/* Background effects */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl" />
          <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl" />
          
          {/* Content */}
          <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                    <Building2 className="w-4 h-4 mr-2 text-blue-400" />
                    Nom de la banque
                  </label>
                  <input
                    type="text"
                    value={formData.bankName}
                    onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                      errors.bankName && "border-red-500/50 focus:ring-red-500/50"
                    )}
                    placeholder="Ex: Société Générale"
                  />
                  {errors.bankName && (
                    <p className="mt-2 text-sm text-red-400">{errors.bankName}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Titulaire du compte
                  </label>
                  <input
                    type="text"
                    value={formData.accountHolder}
                    onChange={(e) => setFormData({ ...formData, accountHolder: e.target.value })}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                      errors.accountHolder && "border-red-500/50 focus:ring-red-500/50"
                    )}
                    placeholder="Ex: DUPONT JEAN"
                  />
                  {errors.accountHolder && (
                    <p className="mt-2 text-sm text-red-400">{errors.accountHolder}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    IBAN
                  </label>
                  <input
                    type="text"
                    value={formData.iban}
                    onChange={(e) => setFormData({ ...formData, iban: e.target.value })}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                      errors.iban && "border-red-500/50 focus:ring-red-500/50"
                    )}
                    placeholder="Ex: FR76 3000 4000 0123 4567 8900 123"
                  />
                  {errors.iban && (
                    <p className="mt-2 text-sm text-red-400">{errors.iban}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    BIC/SWIFT
                  </label>
                  <input
                    type="text"
                    value={formData.bic}
                    onChange={(e) => setFormData({ ...formData, bic: e.target.value })}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                      errors.bic && "border-red-500/50 focus:ring-red-500/50"
                    )}
                    placeholder="Ex: SOGEFRPP"
                  />
                  {errors.bic && (
                    <p className="mt-2 text-sm text-red-400">{errors.bic}</p>
                  )}
                </div>

                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Libellé (optionnel)
                  </label>
                  <input
                    type="text"
                    value={formData.label || ''}
                    onChange={(e) => setFormData({ ...formData, label: e.target.value })}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200"
                    )}
                    placeholder="Ex: Compte principal"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-3">
                <motion.button
                  type="button"
                  onClick={() => setShowForm(false)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="px-6 py-3 text-sm font-medium text-gray-300 bg-gray-800/50 hover:bg-gray-700/50 rounded-lg backdrop-blur-sm transition-colors"
                >
                  Annuler
                </motion.button>
                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="relative group px-6 py-3 rounded-lg overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
                  <span className="relative text-sm font-medium text-white">
                    Ajouter
                  </span>
                </motion.button>
              </div>
            </form>
          </div>
        </motion.div>
      )}

      {/* Bank Deposit Addresses */}
      {(currentLead.depositAddresses && currentLead.depositAddresses.length > 0) && (
        <div>
          <h3 className="text-lg font-medium text-white mb-4 flex items-center">
            <Building2 className="w-5 h-5 mr-2 text-blue-400" />
            Adresses bancaires
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {currentLead.depositAddresses.map((address, index) => (
              <motion.div
                key={address.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="relative group"
              >
                {/* Card glow effect */}
                <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200" />
                
                {/* Card content */}
                <div className="relative bg-gray-900 rounded-xl p-6">
                  <div className="flex justify-between items-start">
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <h3 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                          {address.bankName}
                        </h3>
                        {address.isDefault && (
                          <span className="px-2 py-1 text-xs font-medium bg-green-500/10 text-green-400 rounded-full border border-green-500/20">
                            Par défaut
                          </span>
                        )}
                      </div>
                      {address.label && (
                        <p className="text-sm text-gray-400">
                          {address.label}
                        </p>
                      )}
                      <div className="space-y-2 mt-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-400">Titulaire:</span>
                          <div className="flex items-center">
                            <span className="text-sm text-gray-300 mr-2">{address.accountHolder}</span>
                            <button
                              onClick={() => handleCopy(address.accountHolder)}
                              className="p-1 text-blue-400 hover:text-blue-300 transition-colors"
                            >
                              <Copy size={14} />
                            </button>
                          </div>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-400">IBAN:</span>
                          <div className="flex items-center">
                            <span className="text-sm font-mono text-gray-300 mr-2">{address.iban}</span>
                            <button
                              onClick={() => handleCopy(address.iban)}
                              className="p-1 text-blue-400 hover:text-blue-300 transition-colors"
                            >
                              <Copy size={14} />
                            </button>
                          </div>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-400">BIC/SWIFT:</span>
                          <div className="flex items-center">
                            <span className="text-sm font-mono text-gray-300 mr-2">{address.bic}</span>
                            <button
                              onClick={() => handleCopy(address.bic)}
                              className="p-1 text-blue-400 hover:text-blue-300 transition-colors"
                            >
                              <Copy size={14} />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      {!address.isDefault && (
                        <motion.button
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          onClick={() => handleSetDefault(address.id)}
                          className="p-1.5 bg-green-500/10 text-green-400 rounded-lg hover:bg-green-500/20 transition-colors"
                        >
                          <Check size={16} />
                        </motion.button>
                      )}
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        onClick={() => handleDelete(address.id)}
                        className="p-1.5 bg-red-500/10 text-red-400 rounded-lg hover:bg-red-500/20 transition-colors"
                      >
                        <Trash2 size={16} />
                      </motion.button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* Crypto Addresses from Admin */}
      {cryptoAddresses && cryptoAddresses.length > 0 && (
        <div className="mt-8">
          <h3 className="text-lg font-medium text-white mb-4 flex items-center">
            <Bitcoin className="w-5 h-5 mr-2 text-yellow-400" />
            Adresses crypto
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {cryptoAddresses.map((address, index) => (
              <motion.div
                key={address.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="relative group"
              >
                {/* Card glow effect */}
                <div className="absolute -inset-0.5 bg-gradient-to-r from-yellow-500 via-amber-500 to-orange-500 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200" />
                
                {/* Card content */}
                <div className="relative bg-gray-900 rounded-xl p-6">
                  <div className="flex justify-between items-start">
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <h3 className="text-xl font-bold bg-gradient-to-r from-yellow-400 to-amber-400 bg-clip-text text-transparent">
                          {address.currency}
                        </h3>
                        <span className="px-2 py-1 text-xs font-medium bg-amber-500/10 text-amber-400 rounded-full border border-amber-500/20">
                          {address.network}
                        </span>
                      </div>
                      {address.label && (
                        <p className="text-sm text-gray-400">
                          {address.label}
                        </p>
                      )}
                      <div className="mt-3">
                        <div className="flex items-center bg-gray-800/50 p-3 rounded-lg border border-gray-700/50">
                          <span className="text-sm font-mono text-gray-300 mr-2 break-all">{address.address}</span>
                          <button
                            onClick={() => handleCopy(address.address)}
                            className="p-1 text-blue-400 hover:text-blue-300 transition-colors ml-auto flex-shrink-0"
                          >
                            <Copy size={14} />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {(!currentLead.depositAddresses || currentLead.depositAddresses.length === 0) && 
       (!cryptoAddresses || cryptoAddresses.length === 0) && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden rounded-xl"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 via-purple-500/5 to-pink-500/5 animate-gradient-xy" />
          <div className="relative flex flex-col items-center justify-center py-12 px-4">
            <AlertCircle className="h-12 w-12 text-gray-600 mb-4" />
            <h3 className="text-lg font-medium text-gray-300">
              Aucune adresse de dépôt
            </h3>
            <p className="mt-2 text-sm text-gray-500 text-center max-w-sm">
              Commencez par ajouter une adresse bancaire pour recevoir des dépôts.
            </p>
          </div>
        </motion.div>
      )}
    </div>
  );
}