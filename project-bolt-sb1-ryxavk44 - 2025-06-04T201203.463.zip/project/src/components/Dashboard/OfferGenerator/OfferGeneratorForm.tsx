import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Zap, Clock, DollarSign, Package, AlertTriangle, Check, Calendar, Building2, Info } from 'lucide-react';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { generateId, generateReference } from '../../../utils';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';
import type { Company, EnergyOffer } from '../../../types';

type DurationType = 'minutes' | 'hours' | 'days';

interface FormData {
  offerCount: number;
  megawattsMin: number;
  megawattsMax: number;
  pricePerMWMin: number;
  pricePerMWMax: number;
  durationType: DurationType;
  durationMin: number;
  durationMax: number;
  periodType?: 'minute' | 'hour' | 'day' | 'week';
  periodDuration?: number;
  isProgrammed: boolean;
}

const initialFormData: FormData = {
  offerCount: 10,
  megawattsMin: 30,
  megawattsMax: 130,
  pricePerMWMin: 51,
  pricePerMWMax: 60,
  durationType: 'hours',
  durationMin: 2,
  durationMax: 5,
  periodType: 'hour',
  periodDuration: 5,
  isProgrammed: false
};

export function OfferGeneratorForm() {
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [companies] = useLocalStorage<Company[]>('companies', []);
  const [energyOffers, setEnergyOffers] = useLocalStorage<EnergyOffer[]>('energyOffers', []);
  const [isGenerating, setIsGenerating] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [generatedOffers, setGeneratedOffers] = useState<EnergyOffer[]>([]);

  // Validate form data
  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (formData.offerCount <= 0) {
      newErrors.offerCount = "Le nombre d'offres doit être supérieur à 0";
    }

    if (formData.megawattsMin <= 0) {
      newErrors.megawattsMin = "La quantité minimum doit être supérieure à 0";
    }

    if (formData.megawattsMax <= formData.megawattsMin) {
      newErrors.megawattsMax = "La quantité maximum doit être supérieure à la quantité minimum";
    }

    if (formData.pricePerMWMin <= 0) {
      newErrors.pricePerMWMin = "Le prix minimum doit être supérieur à 0";
    }

    if (formData.pricePerMWMax <= formData.pricePerMWMin) {
      newErrors.pricePerMWMax = "Le prix maximum doit être supérieur au prix minimum";
    }

    if (formData.durationMin <= 0) {
      newErrors.durationMin = "La durée minimum doit être supérieure à 0";
    }

    if (formData.durationMax <= formData.durationMin) {
      newErrors.durationMax = "La durée maximum doit être supérieure à la durée minimum";
    }

    if (formData.isProgrammed) {
      if (!formData.periodDuration || formData.periodDuration <= 0) {
        newErrors.periodDuration = "La durée de la période doit être supérieure à 0";
      }
    }

    if (companies.length === 0) {
      newErrors.companies = "Vous devez ajouter au moins une entreprise dans la liste des entreprises";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Generate a random number between min and max (inclusive)
  const getRandomNumber = (min: number, max: number): number => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  };

  // Get a random company name, avoiding the last used one if possible
  const getRandomCompany = (lastUsed?: string): Company => {
    if (companies.length === 0) return { id: '', name: 'Entreprise', dateCreated: new Date().toISOString() };
    
    // If there's only one company or no last used company, return a random one
    if (companies.length === 1 || !lastUsed) {
      return companies[Math.floor(Math.random() * companies.length)];
    }
    
    // Filter out the last used company
    const availableCompanies = companies.filter(company => company.name !== lastUsed);
    
    // If all companies were filtered out (shouldn't happen), return a random one
    if (availableCompanies.length === 0) {
      return companies[Math.floor(Math.random() * companies.length)];
    }
    
    // Return a random company from the filtered list
    return availableCompanies[Math.floor(Math.random() * availableCompanies.length)];
  };

  // Calculate expiry date based on duration
  const calculateExpiryDate = (durationType: DurationType, duration: number): string => {
    const now = new Date();
    const expiryDate = new Date(now);
    
    switch (durationType) {
      case 'minutes':
        expiryDate.setMinutes(expiryDate.getMinutes() + duration);
        break;
      case 'hours':
        expiryDate.setHours(expiryDate.getHours() + duration);
        break;
      case 'days':
        // A day is defined as 72 hours (3x24h) as per requirements
        expiryDate.setHours(expiryDate.getHours() + (duration * 72));
        break;
    }
    
    return expiryDate.toISOString();
  };

  // Convert duration to days, hours, minutes for the EnergyOffer object
  const convertDurationToComponents = (durationType: DurationType, duration: number): { days: number, hours: number, minutes: number } => {
    switch (durationType) {
      case 'minutes':
        return { days: 0, hours: 0, minutes: duration };
      case 'hours':
        return { days: 0, hours: duration, minutes: 0 };
      case 'days':
        // A day is defined as 72 hours (3x24h) as per requirements
        return { days: duration, hours: 0, minutes: 0 };
      default:
        return { days: 0, hours: 0, minutes: 0 };
    }
  };

  // Convert period type to milliseconds
  const periodTypeToMs = (type: 'minute' | 'hour' | 'day' | 'week', duration: number): number => {
    switch (type) {
      case 'minute':
        return duration * 60 * 1000;
      case 'hour':
        return duration * 60 * 60 * 1000;
      case 'day':
        return duration * 24 * 60 * 60 * 1000;
      case 'week':
        return duration * 7 * 24 * 60 * 60 * 1000;
      default:
        return 0;
    }
  };

  // Generate offers
  const generateOffers = () => {
    if (!validateForm()) return;
    
    setIsGenerating(true);
    
    const newOffers: EnergyOffer[] = [];
    let lastCompanyName: string | undefined;
    
    if (formData.isProgrammed && formData.periodType && formData.periodDuration) {
      // Programmed offers - distributed over time
      
      // Calculate total period duration in milliseconds
      const totalPeriodMs = periodTypeToMs(formData.periodType, formData.periodDuration);
      
      // Current time
      const now = new Date().getTime();
      
      // End time
      const endTime = new Date(now + totalPeriodMs);
      
      // Generate timestamps for each offer, distributed evenly across the period
      const timestamps: number[] = [];
      
      // Calculate the base interval between offers
      const baseInterval = totalPeriodMs / formData.offerCount;
      
      // Generate timestamps with some randomness but ensuring they're distributed across the entire period
      for (let i = 0; i < formData.offerCount; i++) {
        // Calculate the base time for this offer
        const baseTime = now + (i * baseInterval);
        
        // Add some randomness to the timestamp, but keep it within its segment
        // Use a smaller random factor to ensure better distribution
        const randomOffset = Math.random() * (baseInterval * 0.8);
        
        // Add the timestamp, ensuring it stays within the period
        const timestamp = Math.min(baseTime + randomOffset, endTime.getTime() - 1000); // Ensure at least 1 second before end
        timestamps.push(timestamp);
      }
      
      // Sort timestamps chronologically
      timestamps.sort((a, b) => a - b);
      
      // Create offers at each timestamp
      for (let i = 0; i < timestamps.length; i++) {
        // Get random values within the specified ranges
        const megawatts = getRandomNumber(formData.megawattsMin, formData.megawattsMax);
        const pricePerMegawatt = getRandomNumber(formData.pricePerMWMin, formData.pricePerMWMax);
        const validityDuration = getRandomNumber(formData.durationMin, formData.durationMax);
        
        // Get random company, avoiding the last used one if possible
        const company = getRandomCompany(lastCompanyName);
        lastCompanyName = company.name;
        
        // Calculate total price
        const totalPrice = megawatts * pricePerMegawatt;
        
        // Convert validity to components
        const validityComponents = convertDurationToComponents(formData.durationType, validityDuration);
        
        // Calculate expiry date based on validity
        const creationDate = new Date(timestamps[i]);
        const expiryDate = new Date(creationDate);
        
        if (validityComponents.days > 0) {
          expiryDate.setDate(expiryDate.getDate() + validityComponents.days);
        }
        if (validityComponents.hours > 0) {
          expiryDate.setHours(expiryDate.getHours() + validityComponents.hours);
        }
        if (validityComponents.minutes > 0) {
          expiryDate.setMinutes(expiryDate.getMinutes() + validityComponents.minutes);
        }
        
        // Generate a random price variation between -5% and +15%
        const priceVariation = Math.round((Math.random() * 20 - 5) * 10) / 10; // One decimal place
        
        // Generate a unique reference with SCH prefix for scheduled offers
        const reference = 'SCH' + generateReference(5);
        
        // Create new offer
        const newOffer: EnergyOffer = {
          id: generateId(),
          companyName: company.name,
          megawatts,
          saleDate: creationDate.toISOString(),
          pricePerMegawatt,
          totalPrice,
          validityDays: validityComponents.days,
          validityHours: validityComponents.hours,
          validityMinutes: validityComponents.minutes,
          expiryDate: expiryDate.toISOString(),
          status: 'Active',
          dateCreated: creationDate.toISOString(),
          priceVariation,
          reference
        };
        
        newOffers.push(newOffer);
      }
    } else {
      // Immediate offers - all created now
      for (let i = 0; i < formData.offerCount; i++) {
        // Get random values within the specified ranges
        const megawatts = getRandomNumber(formData.megawattsMin, formData.megawattsMax);
        const pricePerMegawatt = getRandomNumber(formData.pricePerMWMin, formData.pricePerMWMax);
        const duration = getRandomNumber(formData.durationMin, formData.durationMax);
        
        // Get random company, avoiding the last used one if possible
        const company = getRandomCompany(lastCompanyName);
        lastCompanyName = company.name;
        
        // Calculate total price
        const totalPrice = megawatts * pricePerMegawatt;
        
        // Calculate expiry date
        const expiryDate = calculateExpiryDate(formData.durationType, duration);
        
        // Convert duration to components
        const durationComponents = convertDurationToComponents(formData.durationType, duration);
        
        // Generate a random price variation between -5% and +15%
        const priceVariation = Math.round((Math.random() * 20 - 5) * 10) / 10; // One decimal place
        
        // Generate a unique reference with GEN prefix for generated offers
        const reference = 'GEN' + generateReference(5);
        
        // Create new offer
        const newOffer: EnergyOffer = {
          id: generateId(),
          companyName: company.name,
          megawatts,
          saleDate: new Date().toISOString(),
          pricePerMegawatt,
          totalPrice,
          validityDays: durationComponents.days,
          validityHours: durationComponents.hours,
          validityMinutes: durationComponents.minutes,
          expiryDate,
          status: 'Active',
          dateCreated: new Date().toISOString(),
          priceVariation,
          reference
        };
        
        newOffers.push(newOffer);
      }
    }
    
    // Add new offers to existing ones
    setEnergyOffers([...energyOffers, ...newOffers]);
    setGeneratedOffers(newOffers);
    
    setIsGenerating(false);
    toast.success(`${formData.offerCount} offres générées avec succès`);
  };

  // Format period type for display
  const formatPeriodType = (type: 'minute' | 'hour' | 'day' | 'week', count: number): string => {
    switch (type) {
      case 'minute':
        return `${count} minute${count > 1 ? 's' : ''}`;
      case 'hour':
        return `${count} heure${count > 1 ? 's' : ''}`;
      case 'day':
        return `${count} jour${count > 1 ? 's' : ''}`;
      case 'week':
        return `${count} semaine${count > 1 ? 's' : ''}`;
      default:
        return '';
    }
  };

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-6">
          <h2 className="text-xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-6">
            Lancement massif d'offres d'énergie
          </h2>

          {companies.length === 0 ? (
            <div className="bg-yellow-900/20 border border-yellow-500/20 rounded-lg p-4 mb-6">
              <div className="flex items-center mb-2">
                <AlertTriangle className="w-5 h-5 text-yellow-400 mr-2" />
                <h3 className="text-yellow-400 font-medium">Attention</h3>
              </div>
              <p className="text-yellow-300 text-sm">
                Vous devez d'abord ajouter des entreprises dans l'onglet "Liste des Entreprises" avant de pouvoir générer des offres.
              </p>
            </div>
          ) : (
            <form onSubmit={(e) => { e.preventDefault(); generateOffers(); }} className="space-y-6">
              {/* Programmed vs Immediate toggle */}
              <div className="bg-gray-800/50 border border-gray-700/50 rounded-lg p-4 space-y-4">
                <h3 className="text-lg font-medium text-white flex items-center">
                  <Calendar className="w-5 h-5 mr-2 text-blue-400" />
                  Type de génération
                </h3>
                
                <div className="grid grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, isProgrammed: false })}
                    className={cn(
                      "p-3 rounded-lg border transition-colors text-center",
                      !formData.isProgrammed
                        ? "bg-blue-600/20 border-blue-500/50 text-blue-400"
                        : "bg-gray-800/50 border-gray-700/50 text-gray-400 hover:bg-gray-700/50"
                    )}
                  >
                    Génération immédiate
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, isProgrammed: true })}
                    className={cn(
                      "p-3 rounded-lg border transition-colors text-center",
                      formData.isProgrammed
                        ? "bg-blue-600/20 border-blue-500/50 text-blue-400"
                        : "bg-gray-800/50 border-gray-700/50 text-gray-400 hover:bg-gray-700/50"
                    )}
                  >
                    Génération programmée
                  </button>
                </div>
              </div>

              {/* Period Settings - Only shown when isProgrammed is true */}
              {formData.isProgrammed && (
                <div className="bg-gray-800/50 border border-gray-700/50 rounded-lg p-4 space-y-4">
                  <h3 className="text-lg font-medium text-white flex items-center">
                    <Calendar className="w-5 h-5 mr-2 text-blue-400" />
                    Période de programmation
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Period Type */}
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Type de période
                      </label>
                      <select
                        value={formData.periodType}
                        onChange={(e) => setFormData({ ...formData, periodType: e.target.value as 'minute' | 'hour' | 'day' | 'week' })}
                        className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                      >
                        <option value="minute">Minute</option>
                        <option value="hour">Heure</option>
                        <option value="day">Jour</option>
                        <option value="week">Semaine</option>
                      </select>
                    </div>
                    
                    {/* Period Duration */}
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Durée de la période
                      </label>
                      <input
                        type="text"
                        inputMode="numeric"
                        pattern="[0-9]*"
                        value={formData.periodDuration}
                        onChange={(e) => {
                          const value = e.target.value.replace(/\D/g, '');
                          setFormData({ ...formData, periodDuration: value ? parseInt(value) : 0 });
                        }}
                        className={cn(
                          "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                          "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                          "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                          errors.periodDuration && "border-red-500/50 focus:ring-red-500/50"
                        )}
                        placeholder="5"
                      />
                      {errors.periodDuration && (
                        <p className="mt-2 text-sm text-red-400">{errors.periodDuration}</p>
                      )}
                    </div>
                  </div>
                  
                  <p className="text-sm text-gray-400">
                    Les offres seront réparties aléatoirement sur une période de {formatPeriodType(formData.periodType || 'hour', formData.periodDuration || 0)}
                  </p>
                  
                  {/* Information about distribution */}
                  <div className="bg-blue-900/20 border border-blue-500/20 rounded-lg p-3">
                    <div className="flex items-center mb-2">
                      <Info className="w-5 h-5 text-blue-400 mr-2" />
                      <h5 className="text-sm font-medium text-blue-400">Distribution des offres</h5>
                    </div>
                    <p className="text-sm text-blue-300">
                      Les offres seront réparties de manière équilibrée sur toute la période, avec un intervalle aléatoire entre chaque offre. Aucune offre ne sera générée en même temps.
                    </p>
                  </div>
                </div>
              )}

              {/* Number of offers */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                  <Zap className="w-4 h-4 mr-2 text-blue-400" />
                  Nombre d'offres à générer
                </label>
                <input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  value={formData.offerCount}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, '');
                    setFormData({ ...formData, offerCount: value ? parseInt(value) : 0 });
                  }}
                  className={cn(
                    "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                    "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                    "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                    errors.offerCount && "border-red-500/50 focus:ring-red-500/50"
                  )}
                  placeholder="10"
                />
                {errors.offerCount && (
                  <p className="mt-2 text-sm text-red-400">{errors.offerCount}</p>
                )}
              </div>

              {/* Megawatts Range */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                    <Package className="w-4 h-4 mr-2 text-purple-400" />
                    Quantité minimum (MW)
                  </label>
                  <input
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    value={formData.megawattsMin}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, '');
                      setFormData({ ...formData, megawattsMin: value ? parseInt(value) : 0 });
                    }}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                      errors.megawattsMin && "border-red-500/50 focus:ring-red-500/50"
                    )}
                    placeholder="30"
                  />
                  {errors.megawattsMin && (
                    <p className="mt-2 text-sm text-red-400">{errors.megawattsMin}</p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                    <Package className="w-4 h-4 mr-2 text-purple-400" />
                    Quantité maximum (MW)
                  </label>
                  <input
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    value={formData.megawattsMax}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, '');
                      setFormData({ ...formData, megawattsMax: value ? parseInt(value) : 0 });
                    }}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                      errors.megawattsMax && "border-red-500/50 focus:ring-red-500/50"
                    )}
                    placeholder="130"
                  />
                  {errors.megawattsMax && (
                    <p className="mt-2 text-sm text-red-400">{errors.megawattsMax}</p>
                  )}
                </div>
              </div>

              {/* Price Range */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                    <DollarSign className="w-4 h-4 mr-2 text-green-400" />
                    Prix minimum par MW (€)
                  </label>
                  <input
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    value={formData.pricePerMWMin}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, '');
                      setFormData({ ...formData, pricePerMWMin: value ? parseInt(value) : 0 });
                    }}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                      errors.pricePerMWMin && "border-red-500/50 focus:ring-red-500/50"
                    )}
                    placeholder="51"
                  />
                  {errors.pricePerMWMin && (
                    <p className="mt-2 text-sm text-red-400">{errors.pricePerMWMin}</p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                    <DollarSign className="w-4 h-4 mr-2 text-green-400" />
                    Prix maximum par MW (€)
                  </label>
                  <input
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    value={formData.pricePerMWMax}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, '');
                      setFormData({ ...formData, pricePerMWMax: value ? parseInt(value) : 0 });
                    }}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                      errors.pricePerMWMax && "border-red-500/50 focus:ring-red-500/50"
                    )}
                    placeholder="60"
                  />
                  {errors.pricePerMWMax && (
                    <p className="mt-2 text-sm text-red-400">{errors.pricePerMWMax}</p>
                  )}
                </div>
              </div>

              {/* Duration Type */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                  <Clock className="w-4 h-4 mr-2 text-cyan-400" />
                  Type de durée de validité
                </label>
                <div className="grid grid-cols-3 gap-4">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, durationType: 'minutes' })}
                    className={cn(
                      "p-3 rounded-lg border transition-colors text-center",
                      formData.durationType === 'minutes'
                        ? "bg-blue-600/20 border-blue-500/50 text-blue-400"
                        : "bg-gray-800/50 border-gray-700/50 text-gray-400 hover:bg-gray-700/50"
                    )}
                  >
                    Minutes
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, durationType: 'hours' })}
                    className={cn(
                      "p-3 rounded-lg border transition-colors text-center",
                      formData.durationType === 'hours'
                        ? "bg-blue-600/20 border-blue-500/50 text-blue-400"
                        : "bg-gray-800/50 border-gray-700/50 text-gray-400 hover:bg-gray-700/50"
                    )}
                  >
                    Heures
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, durationType: 'days' })}
                    className={cn(
                      "p-3 rounded-lg border transition-colors text-center",
                      formData.durationType === 'days'
                        ? "bg-blue-600/20 border-blue-500/50 text-blue-400"
                        : "bg-gray-800/50 border-gray-700/50 text-gray-400 hover:bg-gray-700/50"
                    )}
                  >
                    Jours
                  </button>
                </div>
                {formData.durationType === 'days' && (
                  <p className="mt-2 text-sm text-cyan-400">
                    Note: 1 jour = 72 heures (3x24h)
                  </p>
                )}
              </div>

              {/* Duration Range */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                    <Clock className="w-4 h-4 mr-2 text-cyan-400" />
                    Durée minimum ({formData.durationType})
                  </label>
                  <input
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    value={formData.durationMin}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, '');
                      setFormData({ ...formData, durationMin: value ? parseInt(value) : 0 });
                    }}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                      errors.durationMin && "border-red-500/50 focus:ring-red-500/50"
                    )}
                    placeholder={formData.durationType === 'minutes' ? "30" : formData.durationType === 'hours' ? "2" : "1"}
                  />
                  {errors.durationMin && (
                    <p className="mt-2 text-sm text-red-400">{errors.durationMin}</p>
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                    <Clock className="w-4 h-4 mr-2 text-cyan-400" />
                    Durée maximum ({formData.durationType})
                  </label>
                  <input
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    value={formData.durationMax}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, '');
                      setFormData({ ...formData, durationMax: value ? parseInt(value) : 0 });
                    }}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                      errors.durationMax && "border-red-500/50 focus:ring-red-500/50"
                    )}
                    placeholder={formData.durationType === 'minutes' ? "60" : formData.durationType === 'hours' ? "5" : "3"}
                  />
                  {errors.durationMax && (
                    <p className="mt-2 text-sm text-red-400">{errors.durationMax}</p>
                  )}
                </div>
              </div>

              {/* Companies Info */}
              <div className="bg-gray-800/50 border border-gray-700/50 rounded-lg p-4">
                <div className="flex items-center mb-2">
                  <Building2 className="w-5 h-5 text-purple-400 mr-2" />
                  <h3 className="text-lg font-medium text-white">Entreprises disponibles</h3>
                </div>
                <p className="text-sm text-gray-400">
                  Les noms d'entreprises seront choisis aléatoirement parmi les {companies.length} entreprises disponibles.
                </p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {companies.slice(0, 5).map(company => (
                    <span key={company.id} className="px-2 py-1 bg-gray-700/50 text-gray-300 text-xs rounded-full">
                      {company.name}
                    </span>
                  ))}
                  {companies.length > 5 && (
                    <span className="px-2 py-1 bg-gray-700/50 text-gray-300 text-xs rounded-full">
                      +{companies.length - 5} autres
                    </span>
                  )}
                </div>
              </div>

              {/* Submit Button */}
              <div className="flex justify-end">
                <motion.button
                  type="submit"
                  disabled={isGenerating}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="relative group px-8 py-3 rounded-lg overflow-hidden disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
                  <span className="relative flex items-center text-white font-medium">
                    {isGenerating ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-white mr-3"></div>
                        Génération en cours...
                      </>
                    ) : (
                      <>
                        <Zap className="w-5 h-5 mr-2" />
                        Générer les offres
                      </>
                    )}
                  </span>
                </motion.button>
              </div>
            </form>
          )}
        </div>
      </motion.div>

      {/* Success Message */}
      {generatedOffers.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-green-500/20 to-emerald-500/20 rounded-xl blur-2xl"></div>
          <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-6">
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center mr-4">
                <Check className="w-5 h-5 text-green-400" />
              </div>
              <div>
                <h3 className="text-lg font-medium text-white">Offres générées avec succès</h3>
                <p className="text-gray-400">
                  {generatedOffers.length} offres sont disponibles dans l'onglet "Marché en Direct PC" du panel client.
                </p>
              </div>
            </div>
            
            {formData.isProgrammed && (
              <div className="mt-4 bg-gray-800/50 border border-gray-700/50 rounded-lg p-4">
                <h4 className="text-sm font-medium text-white mb-2">Répartition des offres :</h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-400">Offres en minutes :</span>
                    <span className="text-sm text-white">{generatedOffers.filter(o => o.validityMinutes > 0).length}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-400">Offres en heures :</span>
                    <span className="text-sm text-white">{generatedOffers.filter(o => o.validityHours > 0).length}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-400">Offres en jours :</span>
                    <span className="text-sm text-white">{generatedOffers.filter(o => o.validityDays > 0).length}</span>
                  </div>
                </div>
                <p className="mt-4 text-sm text-gray-400">
                  Les offres sont visibles dans l'onglet "Marché en direct pc".
                </p>
              </div>
            )}
          </div>
        </motion.div>
      )}
    </div>
  );
}