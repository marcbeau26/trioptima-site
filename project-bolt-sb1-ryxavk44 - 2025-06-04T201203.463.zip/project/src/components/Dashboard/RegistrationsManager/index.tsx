import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, Check, X, Eye, User, Mail, Phone, Calendar, 
  UserPlus, Trash2, Filter, Clock, AlertCircle, Key, EyeOff
} from 'lucide-react';
import type { Lead } from '../../../types';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { formatDate } from '../../../utils';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';

interface RegistrationDetailsModalProps {
  registration: Lead;
  isOpen: boolean;
  onClose: () => void;
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
}

function RegistrationDetailsModal({ 
  registration, 
  isOpen, 
  onClose, 
  onApprove, 
  onReject 
}: RegistrationDetailsModalProps) {
  const [showPassword, setShowPassword] = useState(false);
  
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-2xl mx-4"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <div className="flex justify-between items-start mb-6">
            <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Détails de l'inscription
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-300 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="space-y-6">
            {/* Personal Information */}
            <div className="bg-gray-800/50 border border-white/5 rounded-xl p-6">
              <h3 className="text-lg font-medium text-white mb-4">
                Informations personnelles
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-400">Prénom</p>
                  <p className="text-base font-medium text-white">
                    {registration.firstName}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Nom</p>
                  <p className="text-base font-medium text-white">
                    {registration.lastName}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Email</p>
                  <p className="text-base font-medium text-white">
                    {registration.email}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Téléphone</p>
                  <p className="text-base font-medium text-white">
                    {registration.phone}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Source</p>
                  <p className="text-base font-medium text-white">
                    {registration.source}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Date d'inscription</p>
                  <p className="text-base font-medium text-white">
                    {formatDate(registration.dateCreated)}
                  </p>
                </div>
                <div className="col-span-2">
                  <p className="text-sm text-gray-400 flex items-center">
                    <Key className="w-4 h-4 mr-2 text-gray-400" />
                    Mot de passe
                  </p>
                  <div className="flex items-center mt-1">
                    <p className="text-base font-medium text-white font-mono mr-2">
                      {showPassword ? registration.password : '••••••'}
                    </p>
                    <button
                      onClick={() => setShowPassword(!showPassword)}
                      className="p-1 text-gray-400 hover:text-gray-300 transition-colors"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-4">
              <motion.button
                onClick={() => onReject(registration.id)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex-1 relative group overflow-hidden rounded-lg"
              >
                <div className="absolute inset-0 bg-red-500/80 opacity-80 group-hover:opacity-100 transition-opacity"></div>
                <span className="relative flex items-center justify-center text-white py-3">
                  <X className="w-5 h-5 mr-2" />
                  Refuser l'inscription
                </span>
              </motion.button>
              
              <motion.button
                onClick={() => onApprove(registration.id)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex-1 relative group overflow-hidden rounded-lg"
              >
                <div className="absolute inset-0 bg-green-500/80 opacity-80 group-hover:opacity-100 transition-opacity"></div>
                <span className="relative flex items-center justify-center text-white py-3">
                  <Check className="w-5 h-5 mr-2" />
                  Valider l'inscription
                </span>
              </motion.button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export function RegistrationsManager() {
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [selectedRegistration, setSelectedRegistration] = useState<Lead | null>(null);
  const [selectedRegistrations, setSelectedRegistrations] = useState<string[]>([]);
  const [showPasswords, setShowPasswords] = useState<Record<string, boolean>>({});

  // Get all registrations (leads with isRegistration flag)
  const registrations = leads.filter(lead => lead.isRegistration === true);

  // Filter registrations based on search term and status
  const filteredRegistrations = registrations.filter(registration => {
    // Apply search filter
    const searchString = `${registration.firstName} ${registration.lastName} ${registration.email} ${registration.phone}`.toLowerCase();
    const matchesSearch = searchTerm ? searchString.includes(searchTerm.toLowerCase()) : true;
    
    // Apply status filter
    let matchesStatus = true;
    if (statusFilter !== 'all') {
      matchesStatus = registration.registrationStatus === statusFilter;
    }
    
    return matchesSearch && matchesStatus;
  });

  const handleApprove = (id: string) => {
    const updatedLeads = leads.map(lead => {
      if (lead.id === id) {
        // Update the lead to mark it as approved and remove the isRegistration flag
        return {
          ...lead,
          isRegistration: false,
          registrationStatus: 'approved' as const,
          dateApproved: new Date().toISOString()
        };
      }
      return lead;
    });

    setLeads(updatedLeads);
    setSelectedRegistration(null);
    toast.success('Inscription validée avec succès');
  };

  const handleReject = (id: string) => {
    const updatedLeads = leads.map(lead => {
      if (lead.id === id) {
        return {
          ...lead,
          isRegistration: true,
          registrationStatus: 'rejected' as const,
          dateRejected: new Date().toISOString()
        };
      }
      return lead;
    });

    setLeads(updatedLeads);
    setSelectedRegistration(null);
    toast.success('Inscription refusée');
  };

  // Toggle select all registrations
  const toggleSelectAll = () => {
    if (selectedRegistrations.length === filteredRegistrations.length) {
      setSelectedRegistrations([]);
    } else {
      setSelectedRegistrations(filteredRegistrations.map(registration => registration.id));
    }
  };

  // Toggle select individual registration
  const toggleSelectRegistration = (registrationId: string) => {
    if (selectedRegistrations.includes(registrationId)) {
      setSelectedRegistrations(selectedRegistrations.filter(id => id !== registrationId));
    } else {
      setSelectedRegistrations([...selectedRegistrations, registrationId]);
    }
  };

  // Delete selected registrations
  const handleDeleteSelected = () => {
    if (selectedRegistrations.length === 0) return;

    // Remove selected registrations from leads array
    const updatedLeads = leads.filter(lead => !selectedRegistrations.includes(lead.id));
    setLeads(updatedLeads);
    
    // Clear selected registrations
    setSelectedRegistrations([]);
    
    // Show success message
    toast.success(`${selectedRegistrations.length} inscription${selectedRegistrations.length > 1 ? 's' : ''} supprimée${selectedRegistrations.length > 1 ? 's' : ''} avec succès`);
  };

  // Toggle password visibility for a specific registration
  const togglePasswordVisibility = (id: string) => {
    setShowPasswords(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  return (
    <div className="space-y-6">
      {/* Search and Filter Bar */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="relative w-full md:w-64">
          <input
            type="text"
            placeholder="Rechercher..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
        </div>
        
        <div className="relative w-full md:w-auto">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as 'all' | 'pending' | 'approved' | 'rejected')}
            className="bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-9 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/50 appearance-none w-full md:w-auto"
          >
            <option value="all">Tous les statuts</option>
            <option value="pending">En attente</option>
            <option value="approved">Validées</option>
            <option value="rejected">Refusées</option>
          </select>
          <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
        </div>
      </div>

      {/* Delete Selected Button */}
      {selectedRegistrations.length > 0 && (
        <div className="flex justify-end">
          <motion.button
            onClick={handleDeleteSelected}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="relative group overflow-hidden rounded-lg px-4 py-2"
          >
            <div className="absolute inset-0 bg-red-500/80 opacity-80 group-hover:opacity-100 transition-opacity"></div>
            <span className="relative flex items-center text-white">
              <Trash2 className="w-4 h-4 mr-2" />
              Supprimer ({selectedRegistrations.length})
            </span>
          </motion.button>
        </div>
      )}

      {/* Registrations Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-700">
          <thead className="bg-gray-800">
            <tr>
              <th scope="col" className="px-6 py-3 text-left">
                <input
                  type="checkbox"
                  checked={selectedRegistrations.length === filteredRegistrations.length && filteredRegistrations.length > 0}
                  onChange={toggleSelectAll}
                  className="rounded border-gray-600 text-blue-500 focus:ring-blue-500 bg-gray-700"
                />
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Date
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Nom
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Email
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Téléphone
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Mot de passe
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Statut
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-gray-900 divide-y divide-gray-800">
            {filteredRegistrations.map((registration) => (
              <tr key={registration.id} className="hover:bg-gray-800/50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap">
                  <input
                    type="checkbox"
                    checked={selectedRegistrations.includes(registration.id)}
                    onChange={() => toggleSelectRegistration(registration.id)}
                    className="rounded border-gray-600 text-blue-500 focus:ring-blue-500 bg-gray-700"
                  />
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 text-gray-400 mr-2" />
                    <span className="text-sm text-gray-300">
                      {formatDate(registration.dateCreated)}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-10 w-10">
                      <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                        <User className="h-5 w-5 text-white" />
                      </div>
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-white">
                        {registration.firstName} {registration.lastName}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Mail className="w-4 h-4 text-gray-400 mr-2" />
                    <span className="text-sm text-gray-300">{registration.email}</span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Phone className="w-4 h-4 text-gray-400 mr-2" />
                    <span className="text-sm text-gray-300">{registration.phone}</span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Key className="w-4 h-4 text-gray-400 mr-2" />
                    <span className="text-sm text-gray-300 font-mono">
                      {showPasswords[registration.id] ? registration.password : '••••••'}
                    </span>
                    <button
                      onClick={() => togglePasswordVisibility(registration.id)}
                      className="ml-2 text-gray-400 hover:text-gray-300 transition-colors"
                    >
                      {showPasswords[registration.id] ? (
                        <EyeOff className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={cn(
                    "px-2 py-1 text-xs font-medium rounded-full",
                    registration.registrationStatus === 'pending' && "bg-yellow-500/20 text-yellow-300 border border-yellow-500/30",
                    registration.registrationStatus === 'approved' && "bg-green-500/20 text-green-300 border border-green-500/30",
                    registration.registrationStatus === 'rejected' && "bg-red-500/20 text-red-300 border border-red-500/30"
                  )}>
                    {registration.registrationStatus === 'pending' && (
                      <span className="flex items-center">
                        <Clock className="w-3 h-3 mr-1" />
                        En attente
                      </span>
                    )}
                    {registration.registrationStatus === 'approved' && (
                      <span className="flex items-center">
                        <Check className="w-3 h-3 mr-1" />
                        Validée
                      </span>
                    )}
                    {registration.registrationStatus === 'rejected' && (
                      <span className="flex items-center">
                        <X className="w-3 h-3 mr-1" />
                        Refusée
                      </span>
                    )}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setSelectedRegistration(registration)}
                      className="p-1.5 text-gray-400 hover:text-blue-400 transition-colors rounded-md hover:bg-blue-500/10"
                      title="Voir les détails"
                    >
                      <Eye size={16} />
                    </button>
                    {registration.registrationStatus === 'pending' && (
                      <>
                        <button
                          onClick={() => handleApprove(registration.id)}
                          className="p-1.5 text-gray-400 hover:text-green-400 transition-colors rounded-md hover:bg-green-500/10"
                          title="Valider l'inscription"
                        >
                          <Check size={16} />
                        </button>
                        <button
                          onClick={() => handleReject(registration.id)}
                          className="p-1.5 text-gray-400 hover:text-red-400 transition-colors rounded-md hover:bg-red-500/10"
                          title="Refuser l'inscription"
                        >
                          <X size={16} />
                        </button>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {filteredRegistrations.length === 0 && (
          <div className="text-center py-12 bg-gray-800/30 rounded-lg border border-gray-700/50">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-800/50 backdrop-blur-xl mb-4">
              <UserPlus className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-xl font-medium text-gray-300">
              Aucune inscription trouvée
            </h3>
            <p className="text-gray-500 max-w-sm mx-auto mt-2">
              {searchTerm || statusFilter !== 'all' 
                ? "Aucune inscription ne correspond à vos critères de recherche. Essayez de modifier vos filtres."
                : "Aucune inscription n'a été effectuée pour le moment."}
            </p>
          </div>
        )}
      </div>

      {/* Registration Details Modal */}
      <AnimatePresence>
        {selectedRegistration && (
          <RegistrationDetailsModal
            registration={selectedRegistration}
            isOpen={true}
            onClose={() => setSelectedRegistration(null)}
            onApprove={handleApprove}
            onReject={handleReject}
          />
        )}
      </AnimatePresence>
    </div>
  );
}