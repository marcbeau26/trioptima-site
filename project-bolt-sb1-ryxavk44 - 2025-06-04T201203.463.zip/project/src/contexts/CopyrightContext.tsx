import React, { createContext, useContext } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';

interface CopyrightContextType {
  companyName: string;
  year: string;
  updateCopyright: (companyName: string, year: string) => void;
}

const CopyrightContext = createContext<CopyrightContextType>({
  companyName: 'Trioptima',
  year: '2025',
  updateCopyright: () => {},
});

export const useCopyright = () => useContext(CopyrightContext);

export const CopyrightProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [copyright, setCopyright] = useLocalStorage<{ companyName: string; year: string }>('copyright', {
    companyName: 'Trioptima',
    year: '2025',
  });

  const updateCopyright = (companyName: string, year: string) => {
    setCopyright({ companyName, year });
  };

  return (
    <CopyrightContext.Provider
      value={{
        companyName: copyright.companyName,
        year: copyright.year,
        updateCopyright,
      }}
    >
      {children}
    </CopyrightContext.Provider>
  );
};