import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Electricity } from './Electricity';
import { Actions } from './Actions';
import { Livres } from './Livres';
import { Zap, LineChart, BookOpen, AlertCircle } from 'lucide-react';
import { cn } from '../../../utils/cn';
import { useLocalStorage } from '../../../hooks/useLocalStorage';

type InvestmentTab = 'actions' | 'electricity' | 'livres';

export function Investment() {
  const [activeTab, setActiveTab] = useState<InvestmentTab>('actions');
  const [products] = useLocalStorage<any[]>('products', []);

  // Check if products are enabled
  const isProductEnabled = (productId: string): boolean => {
    const product = products.find(p => p.id === productId);
    return product ? product.enabled : true; // Default to true if product not found
  };

  // Get enabled status for each product
  const actionsEnabled = isProductEnabled('actions');
  const electricityEnabled = isProductEnabled('electricity');
  const livretsEnabled = isProductEnabled('livrets');

  return (
    <div className="space-y-6">
      {/* Futuristic Tab Navigation */}
      <div className="relative">
        {/* Glowing background effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Navigation container */}
        <div className="relative bg-gray-900/50 backdrop-blur-xl border border-white/10 rounded-xl p-2">
          <nav className="flex space-x-2" aria-label="Tabs">
            <motion.button
              onClick={() => setActiveTab('actions')}
              className={cn(
                "flex-1 relative group overflow-hidden rounded-lg",
                "py-3 px-6 text-sm font-medium transition-all duration-300"
              )}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {/* Active/Hover background */}
              <div className={cn(
                "absolute inset-0 transition-opacity duration-300",
                activeTab === 'actions'
                  ? "opacity-100"
                  : "opacity-0 group-hover:opacity-50",
                "bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500"
              )} />

              {/* Content */}
              <div className="relative flex items-center justify-center space-x-2">
                <LineChart className={cn(
                  "w-4 h-4 transition-colors",
                  activeTab === 'actions' ? "text-white" : "text-gray-400 group-hover:text-white"
                )} />
                <span className={cn(
                  "transition-colors",
                  activeTab === 'actions' ? "text-white" : "text-gray-400 group-hover:text-white"
                )}>
                  Actions
                </span>
              </div>
            </motion.button>

            <motion.button
              onClick={() => setActiveTab('electricity')}
              className={cn(
                "flex-1 relative group overflow-hidden rounded-lg",
                "py-3 px-6 text-sm font-medium transition-all duration-300"
              )}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {/* Active/Hover background */}
              <div className={cn(
                "absolute inset-0 transition-opacity duration-300",
                activeTab === 'electricity'
                  ? "opacity-100"
                  : "opacity-0 group-hover:opacity-50",
                "bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500"
              )} />

              {/* Content */}
              <div className="relative flex items-center justify-center space-x-2">
                <Zap className={cn(
                  "w-4 h-4 transition-colors",
                  activeTab === 'electricity' ? "text-white" : "text-gray-400 group-hover:text-white"
                )} />
                <span className={cn(
                  "transition-colors",
                  activeTab === 'electricity' ? "text-white" : "text-gray-400 group-hover:text-white"
                )}>
                  Électricité
                </span>
              </div>
            </motion.button>

            <motion.button
              onClick={() => setActiveTab('livres')}
              className={cn(
                "flex-1 relative group overflow-hidden rounded-lg",
                "py-3 px-6 text-sm font-medium transition-all duration-300"
              )}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {/* Active/Hover background */}
              <div className={cn(
                "absolute inset-0 transition-opacity duration-300",
                activeTab === 'livres'
                  ? "opacity-100"
                  : "opacity-0 group-hover:opacity-50",
                "bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500"
              )} />

              {/* Content */}
              <div className="relative flex items-center justify-center space-x-2">
                <BookOpen className={cn(
                  "w-4 h-4 transition-colors",
                  activeTab === 'livres' ? "text-white" : "text-gray-400 group-hover:text-white"
                )} />
                <span className={cn(
                  "transition-colors",
                  activeTab === 'livres' ? "text-white" : "text-gray-400 group-hover:text-white"
                )}>
                  Livrets
                </span>
              </div>
            </motion.button>
          </nav>
        </div>
      </div>

      {/* Content */}
      <motion.div
        key={activeTab}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        {activeTab === 'actions' && (
          actionsEnabled ? (
            <Actions />
          ) : (
            <ProductUnavailable productName="Actions" />
          )
        )}
        {activeTab === 'electricity' && (
          electricityEnabled ? (
            <Electricity />
          ) : (
            <ProductUnavailable productName="Électricité" />
          )
        )}
        {activeTab === 'livres' && (
          livretsEnabled ? (
            <Livres />
          ) : (
            <ProductUnavailable productName="Livrets" />
          )
        )}
      </motion.div>
    </div>
  );
}

// Component to display when a product is unavailable
function ProductUnavailable({ productName }: { productName: string }) {
  return (
    <div className="min-h-[400px] flex items-center justify-center">
      <div className="text-center space-y-4">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-800/50 backdrop-blur-xl mb-4">
          <AlertCircle className="w-8 h-8 text-red-400" />
        </div>
        <h3 className="text-xl font-medium text-gray-300">
          Service temporairement indisponible
        </h3>
        <p className="text-gray-500 max-w-md mx-auto">
          Vous n'avez pas accès au service <strong>{productName}</strong> pour le moment. 
          Veuillez contacter votre conseiller pour plus d'informations.
        </p>
      </div>
    </div>
  );
}