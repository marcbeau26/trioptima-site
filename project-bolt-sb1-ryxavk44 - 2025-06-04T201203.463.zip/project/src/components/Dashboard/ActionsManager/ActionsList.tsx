import React, { useState } from 'react';
import { Trash2, Edit2, DollarSign, Euro, Hash } from 'lucide-react';
import type { StockAction } from '../../../types';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { formatDate, formatPrice } from '../../../utils';

export function ActionsList() {
  const [actions, setActions] = useLocalStorage<StockAction[]>('stockActions', []);
  const [selectedActions, setSelectedActions] = useState<string[]>([]);

  const toggleSelectAll = () => {
    if (selectedActions.length === actions.length) {
      setSelectedActions([]);
    } else {
      setSelectedActions(actions.map(action => action.id));
    }
  };

  const toggleAction = (actionId: string) => {
    if (selectedActions.includes(actionId)) {
      setSelectedActions(selectedActions.filter(id => id !== actionId));
    } else {
      setSelectedActions([...selectedActions, actionId]);
    }
  };

  const handleDelete = () => {
    setActions(actions.filter(action => !selectedActions.includes(action.id)));
    setSelectedActions([]);
  };

  return (
    <div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-800">
            <tr>
              <th scope="col" className="px-6 py-3 text-left">
                <input
                  type="checkbox"
                  checked={selectedActions.length === actions.length && actions.length > 0}
                  onChange={toggleSelectAll}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700"
                />
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Référence
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Nom
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Prix (EUR/USD)
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Prix marché (EUR/USD)
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Quantité
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Filet sécurité (EUR/USD)
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Statut
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200 dark:bg-gray-900 dark:divide-gray-700">
            {actions.map((action) => (
              <tr key={action.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                <td className="px-6 py-4 whitespace-nowrap">
                  <input
                    type="checkbox"
                    checked={selectedActions.includes(action.id)}
                    onChange={() => toggleAction(action.id)}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700"
                  />
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="reference-tag py-1 px-2 rounded-md inline-flex items-center energy-offer-text">
                    <Hash className="h-4 w-4 text-blue-400 mr-1" />
                    <span className="font-mono font-bold text-blue-300 tracking-wider">
                      {action.reference || 'N/A'}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                  {action.name}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 dark:text-white">
                    {action.price > 0 ? (
                      <span className="flex items-center">
                        <Euro className="h-4 w-4 mr-1" />
                        {formatPrice(action.price)}
                      </span>
                    ) : (
                      <span className="flex items-center text-gray-500">
                        <DollarSign className="h-4 w-4 mr-1" />
                        {formatPrice(action.priceUSD)}
                      </span>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 dark:text-white">
                    {action.price > 0 ? (
                      <span className="flex items-center">
                        <Euro className="h-4 w-4 mr-1" />
                        {formatPrice(action.currentMarketPrice)}
                      </span>
                    ) : (
                      <span className="flex items-center text-gray-500">
                        <DollarSign className="h-4 w-4 mr-1" />
                        {formatPrice(action.currentMarketPriceUSD)}
                      </span>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 dark:text-white">
                    {action.minQuantity} - {action.maxQuantity}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 dark:text-white">
                    {action.price > 0 ? (
                      <span className="flex items-center">
                        <Euro className="h-4 w-4 mr-1" />
                        {formatPrice(action.safetyNet)}
                      </span>
                    ) : (
                      <span className="flex items-center text-gray-500">
                        <DollarSign className="h-4 w-4 mr-1" />
                        {formatPrice(action.safetyNetUSD)}
                      </span>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                    action.status === 'Active'
                      ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100'
                      : 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100'
                  }`}>
                    {action.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {actions.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 dark:text-gray-400">
              Aucune action trouvée
            </p>
          </div>
        )}
      </div>

      {selectedActions.length > 0 && (
        <div className="mt-4">
          <button
            onClick={handleDelete}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 dark:focus:ring-offset-gray-800"
          >
            <Trash2 size={16} className="mr-2" />
            Supprimer ({selectedActions.length})
          </button>
        </div>
      )}
    </div>
  );
}