import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Minus, Wallet, History as HistoryIcon, TrendingUp, TrendingDown, X, Trash2 } from 'lucide-react';
import type { Lead, Transaction } from '../../../../types';
import { formatDate, generateId } from '../../../../utils';
import { toast } from 'react-hot-toast';
import { cn } from '../../../../utils/cn';

interface BalanceModalProps {
  lead: Lead;
  isOpen: boolean;
  onClose: () => void;
  onUpdate: (updatedLead: Lead) => void;
}

export function BalanceModal({ lead, isOpen, onClose, onUpdate }: BalanceModalProps) {
  const [activeTab, setActiveTab] = useState<'modify' | 'history'>('modify');
  const [amount, setAmount] = useState('');
  const [operation, setOperation] = useState<'add' | 'subtract' | 'set'>('add');
  const [description, setDescription] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    
    if (isNaN(numAmount) || numAmount <= 0) {
      toast.error('Veuillez saisir un montant valide');
      return;
    }

    let finalAmount: number;
    let newBalance: number;
    let transactionType: 'deposit' | 'withdrawal';

    switch (operation) {
      case 'add':
        finalAmount = numAmount;
        newBalance = (lead.balance || 0) + numAmount;
        transactionType = 'deposit';
        break;
      case 'subtract':
        finalAmount = -numAmount;
        newBalance = (lead.balance || 0) - numAmount;
        transactionType = 'withdrawal';
        break;
      case 'set':
        finalAmount = numAmount - (lead.balance || 0);
        newBalance = numAmount;
        transactionType = finalAmount >= 0 ? 'deposit' : 'withdrawal';
        break;
    }

    const transaction: Transaction = {
      id: generateId(),
      amount: finalAmount,
      type: transactionType,
      description: description || `${
        operation === 'add' ? 'Ajout' : 
        operation === 'subtract' ? 'Retrait' : 
        'Solde modifié'
      } de ${Math.abs(finalAmount).toLocaleString()}€`,
      dateCreated: new Date().toISOString()
    };

    const updatedLead = {
      ...lead,
      balance: newBalance,
      transactions: [...(lead.transactions || []), transaction]
    };

    onUpdate(updatedLead);
    setAmount('');
    setDescription('');
    toast.success('Solde mis à jour avec succès');
  };

  const handleDeleteHistory = () => {
    if (window.confirm('Êtes-vous sûr de vouloir supprimer tout l\'historique des transactions ?')) {
      const updatedLead = {
        ...lead,
        transactions: []
      };
      onUpdate(updatedLead);
      toast.success('Historique supprimé avec succès');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative w-full max-w-4xl mx-4"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl" />
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl" />
        
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                Gestion du solde
              </h2>
              <p className="mt-2 text-gray-400">
                Client : {lead.firstName} {lead.lastName}
              </p>
            </div>
            <div className="flex items-start space-x-4">
              <div className="text-right">
                <div className="text-sm text-gray-400">Solde actuel</div>
                <div className="text-2xl font-bold text-white">
                  {(lead.balance || 0).toLocaleString()}€
                </div>
              </div>
              <button
                onClick={onClose}
                className="text-gray-400 hover:text-gray-300 transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex space-x-4 mb-6">
            <button
              onClick={() => setActiveTab('modify')}
              className={cn(
                "flex items-center px-4 py-2 rounded-lg transition-colors",
                activeTab === 'modify'
                  ? "bg-blue-600 text-white"
                  : "bg-gray-800 text-gray-400 hover:text-white"
              )}
            >
              <Wallet className="w-4 h-4 mr-2" />
              Modifier le solde
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={cn(
                "flex items-center px-4 py-2 rounded-lg transition-colors",
                activeTab === 'history'
                  ? "bg-blue-600 text-white"
                  : "bg-gray-800 text-gray-400 hover:text-white"
              )}
            >
              <HistoryIcon className="w-4 h-4 mr-2" />
              Historique
            </button>
          </div>

          {activeTab === 'modify' ? (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-3 gap-4">
                <button
                  type="button"
                  onClick={() => setOperation('add')}
                  className={cn(
                    "p-4 rounded-lg border transition-colors",
                    operation === 'add'
                      ? "bg-green-600/20 border-green-500/50 text-green-400"
                      : "bg-gray-800/50 border-gray-700/50 text-gray-400 hover:bg-gray-700/50"
                  )}
                >
                  <Plus className="w-6 h-6 mx-auto mb-2" />
                  Ajouter des fonds
                </button>
                <button
                  type="button"
                  onClick={() => setOperation('subtract')}
                  className={cn(
                    "p-4 rounded-lg border transition-colors",
                    operation === 'subtract'
                      ? "bg-red-600/20 border-red-500/50 text-red-400"
                      : "bg-gray-800/50 border-gray-700/50 text-gray-400 hover:bg-gray-700/50"
                  )}
                >
                  <Minus className="w-6 h-6 mx-auto mb-2" />
                  Retirer des fonds
                </button>
                <button
                  type="button"
                  onClick={() => setOperation('set')}
                  className={cn(
                    "p-4 rounded-lg border transition-colors",
                    operation === 'set'
                      ? "bg-blue-600/20 border-blue-500/50 text-blue-400"
                      : "bg-gray-800/50 border-gray-700/50 text-gray-400 hover:bg-gray-700/50"
                  )}
                >
                  <Wallet className="w-6 h-6 mx-auto mb-2" />
                  Définir le solde
                </button>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  {operation === 'set' ? 'Nouveau solde (€)' : 'Montant (€)'}
                </label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  min="0"
                  step="0.01"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Description (optionnelle)
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  rows={3}
                  placeholder="Raison de la modification..."
                />
              </div>

              <div className="flex justify-end space-x-4">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-6 py-3 text-sm font-medium text-gray-300 bg-gray-800/50 hover:bg-gray-700/50 rounded-lg"
                >
                  Annuler
                </button>
                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className={cn(
                    "px-6 py-3 rounded-lg text-white font-medium",
                    operation === 'add' ? "bg-green-600 hover:bg-green-700" : 
                    operation === 'subtract' ? "bg-red-600 hover:bg-red-700" :
                    "bg-blue-600 hover:bg-blue-700"
                  )}
                >
                  {operation === 'add' ? 'Ajouter' : 
                   operation === 'subtract' ? 'Retirer' : 
                   'Modifier'}
                </motion.button>
              </div>
            </form>
          ) : (
            <div>
              {/* History Header with Delete Button */}
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-white">Historique des transactions</h3>
                {lead.transactions?.length > 0 && (
                  <button
                    onClick={handleDeleteHistory}
                    className="text-red-400 hover:text-red-300 transition-colors flex items-center"
                  >
                    <Trash2 className="w-4 h-4 mr-1" />
                    Supprimer l'historique
                  </button>
                )}
              </div>

              {/* Transactions List */}
              <div className="space-y-4 max-h-[400px] overflow-y-auto custom-scrollbar pr-4">
                {lead.transactions?.length ? (
                  lead.transactions
                    .filter(t => t.type === 'deposit' || t.type === 'withdrawal')
                    .sort((a, b) => new Date(b.dateCreated).getTime() - new Date(a.dateCreated).getTime())
                    .map((transaction) => (
                      <motion.div
                        key={transaction.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="relative group"
                      >
                        <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
                        <div className="relative bg-gray-800/50 rounded-lg p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="text-sm text-gray-400">
                                {formatDate(transaction.dateCreated)}
                              </p>
                              <p className="text-white mt-1">
                                {transaction.description}
                              </p>
                            </div>
                            <div className={cn(
                              "flex items-center",
                              transaction.amount >= 0 ? "text-green-400" : "text-red-400"
                            )}>
                              {transaction.amount >= 0 ? (
                                <TrendingUp className="w-4 h-4 mr-1" />
                              ) : (
                                <TrendingDown className="w-4 h-4 mr-1" />
                              )}
                              <span className="font-medium">
                                {transaction.amount >= 0 ? '+' : ''}
                                {transaction.amount.toLocaleString()}€
                              </span>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))
                ) : (
                  <div className="text-center py-8 text-gray-400">
                    Aucune modification de solde à afficher
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}