import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { List, Package, Gift, History as HistoryIcon } from 'lucide-react';
import { Market } from './Market';
import { Portfolio } from './Portfolio';
import { Propositions } from '../Propositions';
import { History } from './History';
import { cn } from '../../../../utils/cn';
import type { TabType } from '../../../../types';

interface TabButtonProps {
  icon: React.ReactNode;
  text: string;
  isActive: boolean;
  onClick: () => void;
}

const TabButton: React.FC<TabButtonProps> = ({ icon, text, isActive, onClick }) => (
  <motion.button
    onClick={onClick}
    className={cn(
      "relative group overflow-hidden rounded-lg",
      "py-3 px-6 text-sm font-medium transition-all duration-300"
    )}
    whileHover={{ scale: 1.02 }}
    whileTap={{ scale: 0.98 }}
  >
    {/* Active/Hover background */}
    <div className={cn(
      "absolute inset-0 transition-opacity duration-300",
      isActive
        ? "opacity-100"
        : "opacity-0 group-hover:opacity-50",
      "bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500"
    )} />

    {/* Content */}
    <div className="relative flex items-center justify-center space-x-2">
      {React.cloneElement(icon as React.ReactElement, {
        className: cn(
          "w-4 h-4 transition-colors",
          isActive ? "text-white" : "text-gray-400 group-hover:text-white"
        )
      })}
      <span className={cn(
        "transition-colors",
        isActive ? "text-white" : "text-gray-400 group-hover:text-white"
      )}>
        {text}
      </span>
    </div>
  </motion.button>
);

export function Actions() {
  const [activeTab, setActiveTab] = useState<TabType>('market');

  return (
    <div className="space-y-6">
      {/* Header with tabs */}
      <div className="flex justify-between items-center">
        <div className="flex space-x-2">
          <TabButton
            icon={<List />}
            text="Formulaire de souscription d'action"
            isActive={activeTab === 'market'}
            onClick={() => setActiveTab('market')}
          />
          <TabButton
            icon={<Package />}
            text="Mon portefeuille d'action"
            isActive={activeTab === 'portfolio'}
            onClick={() => setActiveTab('portfolio')}
          />
          <TabButton
            icon={<HistoryIcon />}
            text="Historique"
            isActive={activeTab === 'history'}
            onClick={() => setActiveTab('history')}
          />
        </div>
      </div>

      {/* Content */}
      <motion.div
        key={activeTab}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        {activeTab === 'market' && <Market />}
        {activeTab === 'portfolio' && <Portfolio />}
        {activeTab === 'history' && <History />}
      </motion.div>
    </div>
  );
}