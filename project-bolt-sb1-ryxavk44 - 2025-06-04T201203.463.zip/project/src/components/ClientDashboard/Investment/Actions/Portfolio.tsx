import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Euro, DollarSign, Calendar, Clock, Hash, Shield, Zap } from 'lucide-react';
import type { Lead } from '../../../../types';
import { useLocalStorage } from '../../../../hooks/useLocalStorage';
import { formatDate, formatPrice } from '../../../../utils';
import { cn } from '../../../../utils/cn';

export function Portfolio() {
  const [currentLead] = useLocalStorage<Lead>('currentLead', null);

  if (!currentLead?.stockHoldings?.length) {
    return (
      <div className="min-h-[400px] flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-800/50 backdrop-blur-xl mb-4">
            <TrendingUp className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-xl font-medium text-gray-300">
            Portefeuille vide
          </h3>
          <p className="text-gray-500 max-w-sm">
            Vous n'avez pas encore d'actions dans votre portefeuille. Commencez à investir dès maintenant !
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {currentLead.stockHoldings.map((holding, index) => (
        <motion.div
          key={holding.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className="relative group"
        >
          {/* Animated background glow */}
          <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-500/30 via-blue-500/30 to-purple-500/30 rounded-xl opacity-0 group-hover:opacity-100 blur-xl transition duration-1000 animate-pulse"></div>
          
          {/* Neon border */}
          <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500 rounded-xl opacity-75 group-hover:opacity-100 blur transition duration-1000"></div>
          
          {/* Glass card */}
          <div className="relative bg-black/40 backdrop-blur-xl border border-white/10 rounded-xl p-6">
            {/* Header with glowing effect */}
            <div className="relative mb-6">
              <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500 rounded-lg opacity-75 blur"></div>
              <div className="relative bg-black/60 backdrop-blur-xl border border-white/10 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent energy-offer-text">
                      {holding.name}
                    </h3>
                    <div className="flex items-center text-sm text-gray-400 mt-1">
                      <Calendar className="w-4 h-4 mr-1" />
                      <span>Acheté le {formatDate(holding.purchaseDate)}</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Shield className="w-5 h-5 text-purple-400" />
                    <Zap className="w-5 h-5 text-cyan-400" />
                  </div>
                </div>
              </div>
            </div>

            {/* Reference display with futuristic styling */}
            {holding.reference && (
              <div className="mb-6 flex justify-center">
                <div className="reference-tag py-3 px-5 rounded-lg">
                  <div className="flex items-center justify-center">
                    <Hash className="h-6 w-6 text-blue-400 mr-2" />
                    <span className="text-xl font-mono font-bold text-blue-300 tracking-widest energy-offer-text">
                      RÉF: {holding.reference}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* Main info sections with glowing icons */}
            <div className="grid grid-cols-2 gap-6">
              {/* Quantity info with glowing icon */}
              <div className="bg-gradient-to-r from-blue-500/5 to-purple-500/5 rounded-xl p-4 border border-white/5">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <div className="absolute -inset-1 bg-blue-500/30 rounded-lg blur"></div>
                    <div className="relative w-12 h-12 flex items-center justify-center bg-blue-500/10 rounded-lg border border-blue-500/20">
                      <Zap className="w-6 h-6 text-blue-400" />
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Quantité</p>
                    <p className="text-xl font-bold text-white">{holding.quantity}</p>
                  </div>
                </div>
              </div>

              {/* Duration info with glowing icon */}
              <div className="bg-gradient-to-r from-purple-500/5 to-pink-500/5 rounded-xl p-4 border border-white/5">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <div className="absolute -inset-1 bg-purple-500/30 rounded-lg blur"></div>
                    <div className="relative w-12 h-12 flex items-center justify-center bg-purple-500/10 rounded-lg border border-purple-500/20">
                      <Clock className="w-6 h-6 text-purple-400" />
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Durée de détention</p>
                    <p className="text-lg font-bold text-white">{formatHoldingDuration(holding.purchaseDate)}</p>
                  </div>
                </div>
              </div>

              {/* Purchase price info with glowing icon */}
              <div className="bg-gradient-to-r from-cyan-500/5 to-blue-500/5 rounded-xl p-4 border border-white/5">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <div className="absolute -inset-1 bg-cyan-500/30 rounded-lg blur"></div>
                    <div className="relative w-12 h-12 flex items-center justify-center bg-cyan-500/10 rounded-lg border border-cyan-500/20">
                      {holding.currency === 'USD' ? (
                        <DollarSign className="w-6 h-6 text-cyan-400" />
                      ) : (
                        <Euro className="w-6 h-6 text-cyan-400" />
                      )}
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Prix unitaire</p>
                    <div className="flex items-center text-xl font-bold text-white">
                      {holding.currency === 'USD' ? (
                        <>
                          <DollarSign className="w-4 h-4 mr-1" />
                          <span>{formatPrice(holding.purchasePrice)}</span>
                        </>
                      ) : (
                        <>
                          <span>{formatPrice(holding.purchasePrice)}</span>
                          <Euro className="w-4 h-4 ml-1" />
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Total cost info with glowing icon */}
              <div className="bg-gradient-to-r from-emerald-500/5 to-cyan-500/5 rounded-xl p-4 border border-white/5">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <div className="absolute -inset-1 bg-emerald-500/30 rounded-lg blur"></div>
                    <div className="relative w-12 h-12 flex items-center justify-center bg-emerald-500/10 rounded-lg border border-emerald-500/20">
                      <Shield className="w-6 h-6 text-emerald-400" />
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Coût total</p>
                    <div className="flex items-center text-xl font-bold text-white">
                      {holding.currency === 'USD' ? (
                        <>
                          <DollarSign className="w-4 h-4 mr-1" />
                          <span>{formatPrice(holding.totalCost)}</span>
                        </>
                      ) : (
                        <>
                          <span>{formatPrice(holding.totalCost)}</span>
                          <Euro className="w-4 h-4 ml-1" />
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}

function formatHoldingDuration(purchaseDate: string): string {
  const purchase = new Date(purchaseDate);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - purchase.getTime());
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) return "Moins d'un jour";
  if (diffDays === 1) return "1 jour";
  if (diffDays < 30) return `${diffDays} jours`;
  
  const months = Math.floor(diffDays / 30);
  if (months === 1) return "1 mois";
  if (months < 12) return `${months} mois`;
  
  const years = Math.floor(months / 12);
  const remainingMonths = months % 12;
  
  if (years === 1) {
    if (remainingMonths === 0) return "1 an";
    if (remainingMonths === 1) return "1 an et 1 mois";
    return `1 an et ${remainingMonths} mois`;
  }
  
  if (remainingMonths === 0) return `${years} ans`;
  if (remainingMonths === 1) return `${years} ans et 1 mois`;
  return `${years} ans et ${remainingMonths} mois`;
}