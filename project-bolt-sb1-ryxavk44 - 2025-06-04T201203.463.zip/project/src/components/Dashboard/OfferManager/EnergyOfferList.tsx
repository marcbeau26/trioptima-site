import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, Trash2, UserCheck, Hash, Power, Play, Pause } from 'lucide-react';
import type { EnergyOffer, Lead } from '../../../types';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { formatDate } from '../../../utils';
import { FuturisticTimer } from '../../common/FuturisticTimer';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';

interface AssignLeadsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAssign: (leadId: string) => void;
}

function AssignLeadsModal({ isOpen, onClose, onAssign }: AssignLeadsModalProps) {
  const [leads] = useLocalStorage<Lead[]>('leads', []);
  const [selectedLead, setSelectedLead] = useState('');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-8 max-w-md w-full">
        <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">Attribuer les offres</h2>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Sélectionner un lead
            </label>
            <select
              value={selectedLead}
              onChange={(e) => setSelectedLead(e.target.value)}
              className="w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
            >
              <option value="">Choisir un lead...</option>
              {leads.map(lead => (
                <option key={lead.id} value={lead.id}>
                  {lead.firstName} {lead.lastName} ({lead.email})
                </option>
              ))}
            </select>
          </div>
          <div className="flex space-x-4">
            <button
              onClick={() => {
                if (selectedLead) {
                  onAssign(selectedLead);
                  onClose();
                }
              }}
              disabled={!selectedLead}
              className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors disabled:bg-gray-400"
            >
              Attribuer
            </button>
            <button
              onClick={onClose}
              className="flex-1 bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200 py-2 px-4 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
            >
              Annuler
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function EnergyOfferList() {
  const [offers, setOffers] = useLocalStorage<EnergyOffer[]>('energyOffers', []);
  const [selectedOffers, setSelectedOffers] = useState<string[]>([]);
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [searchTerm, setSearchTerm] = useState('');

  // Check for expired offers every second
  useEffect(() => {
    const checkExpiry = () => {
      const now = new Date().getTime();
      const updatedOffers = offers.map(offer => ({
        ...offer,
        status: new Date(offer.expiryDate).getTime() <= now && offer.status === 'Active' ? 'Expired' as const : offer.status
      }));

      if (JSON.stringify(updatedOffers) !== JSON.stringify(offers)) {
        setOffers(updatedOffers);
      }
    };

    const interval = setInterval(checkExpiry, 1000);
    return () => clearInterval(interval);
  }, [offers, setOffers]);

  const handleExpire = (offerId: string) => {
    setOffers(offers.map(offer =>
      offer.id === offerId ? { ...offer, status: 'Expired' } : offer
    ));
  };

  const toggleSelectAll = () => {
    if (selectedOffers.length === filteredOffers.length) {
      setSelectedOffers([]);
    } else {
      setSelectedOffers(filteredOffers.map(offer => offer.id));
    }
  };

  const toggleOffer = (offerId: string) => {
    if (selectedOffers.includes(offerId)) {
      setSelectedOffers(selectedOffers.filter(id => id !== offerId));
    } else {
      setSelectedOffers([...selectedOffers, offerId]);
    }
  };

  const handleDelete = () => {
    setOffers(offers.filter(offer => !selectedOffers.includes(offer.id)));
    setSelectedOffers([]);
  };

  const handleAssignToLead = (leadId: string) => {
    const selectedOffersList = offers.filter(offer => selectedOffers.includes(offer.id));
    
    setLeads(leads.map(lead => {
      if (lead.id === leadId) {
        return {
          ...lead,
          assignedOffers: [
            ...(lead.assignedOffers || []),
            ...selectedOffersList
          ]
        };
      }
      return lead;
    }));

    setSelectedOffers([]);
  };

  // Toggle offer status (Active/Expired)
  const toggleOfferStatus = (offerId: string) => {
    const offerToToggle = offers.find(offer => offer.id === offerId);
    if (!offerToToggle) return;

    // If the offer is expired, reactivate it with a new expiry date
    if (offerToToggle.status === 'Expired') {
      // Calculate new expiry date (24 hours from now)
      const now = new Date();
      const expiryDate = new Date(now);
      expiryDate.setHours(expiryDate.getHours() + 24);

      // Update the offer
      const updatedOffers = offers.map(offer => 
        offer.id === offerId 
          ? { ...offer, status: 'Active', expiryDate: expiryDate.toISOString() } 
          : offer
      );
      
      setOffers(updatedOffers);
      toast.success('Offre réactivée avec succès pour 24 heures');
    } 
    // If the offer is active, deactivate it
    else if (offerToToggle.status === 'Active') {
      const updatedOffers = offers.map(offer => 
        offer.id === offerId 
          ? { ...offer, status: 'Expired' } 
          : offer
      );
      
      setOffers(updatedOffers);
      toast.success('Offre désactivée avec succès');
    }
  };

  // Filter out offers that were generated automatically (from the offer generator)
  // We'll consider an offer as "manual" if it doesn't have validityMinutes, validityHours, or validityDays > 0
  const manualOffers = offers.filter(offer => 
    !(offer.validityMinutes > 0 || offer.validityHours > 0 || offer.validityDays > 0)
  );

  // Apply search filter
  const filteredOffers = manualOffers.filter(offer => {
    if (!searchTerm) return true;
    
    return offer.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
           (offer.reference && offer.reference.toLowerCase().includes(searchTerm.toLowerCase()));
  });

  return (
    <div className="space-y-6">
      {/* Search Bar */}
      <div className="relative w-full md:w-64">
        <input
          type="text"
          placeholder="Rechercher une offre..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
        />
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-800">
            <tr>
              <th scope="col" className="px-6 py-3 text-left">
                <input
                  type="checkbox"
                  checked={selectedOffers.length === filteredOffers.length && filteredOffers.length > 0}
                  onChange={toggleSelectAll}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700"
                />
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Référence
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Entreprise
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Mégawatts
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Prix
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Temps restant
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Statut
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200 dark:bg-gray-900 dark:divide-gray-700">
            {filteredOffers.map((offer) => (
              <tr key={offer.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                <td className="px-6 py-4 whitespace-nowrap">
                  <input
                    type="checkbox"
                    checked={selectedOffers.includes(offer.id)}
                    onChange={() => toggleOffer(offer.id)}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700"
                  />
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <Hash className="h-4 w-4 text-blue-500 mr-1" />
                    <span className="text-sm font-medium text-gray-900 dark:text-white">
                      {offer.reference || 'N/A'}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900 dark:text-white">
                    {offer.companyName}
                  </div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    {formatDate(offer.saleDate)}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 dark:text-white">
                    {offer.megawatts} MW
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-900 dark:text-white">
                    {offer.totalPrice.toLocaleString()}€
                  </div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    {offer.pricePerMegawatt.toLocaleString()}€/MW
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {offer.status === 'Active' ? (
                    <FuturisticTimer
                      expiryDate={offer.expiryDate}
                      onExpire={() => handleExpire(offer.id)}
                    />
                  ) : (
                    <span className="text-red-500 dark:text-red-400">
                      Expirée
                    </span>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      offer.status === 'Active'
                        ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100'
                        : 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100'
                    }`}>
                      {offer.status === 'Active' ? 'Active' : 'Expirée'}
                    </span>
                    
                    {/* Toggle button */}
                    <motion.button
                      onClick={() => toggleOfferStatus(offer.id)}
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      className={cn(
                        "p-1 rounded-md transition-colors",
                        offer.status === 'Active' 
                          ? "bg-red-500/20 text-red-400 hover:bg-red-500/30" 
                          : "bg-green-500/20 text-green-400 hover:bg-green-500/30"
                      )}
                      title={offer.status === 'Active' ? 'Désactiver' : 'Activer'}
                    >
                      {offer.status === 'Active' ? (
                        <Pause className="w-4 h-4" />
                      ) : (
                        <Play className="w-4 h-4" />
                      )}
                    </motion.button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {filteredOffers.length === 0 && (
        <div className="text-center py-12 text-gray-500 dark:text-gray-400">
          Aucune offre manuelle trouvée
        </div>
      )}

      {selectedOffers.length > 0 && (
        <div className="mt-4 flex space-x-4">
          <button
            onClick={handleDelete}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 dark:focus:ring-offset-gray-800"
          >
            <Trash2 size={16} className="mr-2" />
            Supprimer ({selectedOffers.length})
          </button>
          <button
            onClick={() => setIsAssignModalOpen(true)}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-800"
          >
            <UserCheck size={16} className="mr-2" />
            Attribuer à un lead ({selectedOffers.length})
          </button>
        </div>
      )}

      <AssignLeadsModal
        isOpen={isAssignModalOpen}
        onClose={() => setIsAssignModalOpen(false)}
        onAssign={handleAssignToLead}
      />
    </div>
  );
}