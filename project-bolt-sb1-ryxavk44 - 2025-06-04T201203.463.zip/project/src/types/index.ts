import React from 'react';

export interface Message {
  id: string;
  senderId: string;
  senderType: 'admin' | 'lead';
  content: string;
  timestamp: string;
  attachments?: {
    name: string;
    url: string;
    type: string;
  }[];
}

export interface Chat {
  id: string;
  leadId: string;
  messages: Message[];
  unreadCount: number;
  lastMessageTimestamp: string;
}

interface StockHolding {
  id: string;
  name: string;
  quantity: number;
  purchasePrice: number;
  totalCost: number;
  purchaseDate: string;
  currency: 'EUR' | 'USD';
  reference?: string;
}

interface TradingPosition {
  id: string;
  symbol: string;
  type: 'buy' | 'sell';
  amount: number;
  leverage: number;
  entryPrice: number;
  currentPrice: number;
  stopLoss?: number;
  takeProfit?: number;
  margin: number;
  fees: {
    tradingFee: number;
    leverageFee: number;
    total: number;
  };
  pnl: number;
  pnlPercentage: number;
  dateCreated: string;
  status: 'open' | 'closed';
}

export interface TradingAPIPosition {
  id: string;
  symbol: string;
  type: 'buy' | 'sell';
  amount: number;
  entryPrice: number;
  currentPrice: number;
  leverage: number;
  pnl: number;
  pnlPercentage: number;
  dateCreated: string;
  metadata?: {
    adjustment?: {
      direction: 'up' | 'down' | 'neutral';
      percentage: number;
      marketPrice: number;
    }
  }
}

export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  password: string;
  role: 'Admin' | 'Seller';
  dateCreated: string;
}

export interface Comment {
  id: string;
  text: string;
  dateCreated: string;
  userId?: string;
}

export interface CryptoAddress {
  id: string;
  network: string;
  currency: string;
  address: string;
  label?: string;
  dateCreated: string;
  isDefault?: boolean;
}

export interface DepositAddress {
  id: string;
  bankName: string;
  accountHolder: string;
  iban: string;
  bic: string;
  label?: string;
  dateCreated: string;
  isDefault?: boolean;
}

export interface Document {
  id: string;
  name: string;
  type: string;
  url: string;
  dateUploaded: string;
  status: 'pending' | 'approved' | 'rejected';
  comments?: string;
  size: number;
}

export interface Livret {
  id: string;
  name: string;
  interestRate: number;
  duration: {
    value: number;
    unit: 'months' | 'years';
  };
  initialCapital: number;
  minCapital: number;
  maxCapital: number;
  dateCreated: string;
  status: 'Active' | 'Inactive';
  description?: string;
  reference: string;
  logoUrl?: string;
}

export interface LivretSubscription {
  id: string;
  livretId: string;
  livretName: string;
  amount: number;
  interestRate: number;
  duration: {
    value: number;
    unit: 'months' | 'years';
  };
  subscriptionDate: string;
  maturityDate: string;
  status: 'Active' | 'Completed' | 'Cancelled';
  reference: string;
  logoUrl?: string;
}

export interface Lead {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  source: string;
  dateCreated: string;
  assignedTo?: string;
  statusId?: string;
  comments?: Comment[];
  assignedOffers?: EnergyOffer[];
  balance: number;
  transactions?: Transaction[];
  energyHoldings?: EnergyHolding[];
  stockHoldings?: StockHolding[];
  tradingPositions?: TradingPosition[];
  tradingAPIPositions?: TradingAPIPosition[];
  proposals?: Proposal[];
  depositRequests?: DepositRequest[];
  withdrawalRequests?: WithdrawalRequest[];
  cryptoAddresses?: CryptoAddress[];
  depositAddresses?: DepositAddress[];
  livretSubscriptions?: LivretSubscription[];
  chat?: Chat;
  address?: string;
  city?: string;
  postalCode?: string;
  country?: string;
  documents?: Document[];
  password?: string;
  isRegistration?: boolean;
  registrationStatus?: 'pending' | 'approved' | 'rejected';
  dateApproved?: string;
  dateRejected?: string;
}

export interface Transaction {
  id: string;
  amount: number;
  type: 'deposit' | 'withdrawal' | 'investment' | 'sale' | 'trading';
  description: string;
  dateCreated: string;
  tradingPositionId?: string;
}

export interface Status {
  id: string;
  name: string;
  color: string;
  dateCreated: string;
}

export interface EnergyOffer {
  id: string;
  companyName: string;
  megawatts: number;
  saleDate: string;
  pricePerMegawatt: number;
  totalPrice: number;
  validityDays: number;
  validityHours: number;
  validityMinutes: number;
  expiryDate: string;
  status: 'Active' | 'Expired';
  dateCreated: string;
  priceVariation?: number;
  reference?: string;
}

export interface EnergyHolding {
  id: string;
  companyName: string;
  megawatts: number;
  pricePerMegawatt: number;
  totalPrice: number;
  purchaseDate: string;
  expiryDate: string;
  status: 'InProgress' | 'Available' | 'Expired';
  priceVariation: number;
  reference?: string;
}

export interface Proposal {
  id: string;
  stockId: string;
  buyerName: string;
  megawatts: number;
  pricePerMegawatt: number;
  reference: string;
  totalPrice: number;
  expiryDate: string;
  dateCreated: string;
  status: 'Active' | 'Expired' | 'Accepted' | 'Rejected';
}

export interface StockAction {
  id: string;
  name: string;
  price: number;
  priceUSD: number;
  currentMarketPrice: number;
  currentMarketPriceUSD: number;
  minQuantity: number;
  maxQuantity: number;
  startDate: string;
  holdingPeriodDays: number;
  holdingPeriodMonths: number;
  holdingPeriodYears: number;
  safetyNet: number;
  safetyNetUSD: number;
  dateCreated: string;
  status: 'Active' | 'Inactive';
  bonusShares: number;
  practicalInfo?: string;
  reference?: string;
  logoUrl?: string;
}

export interface DepositRequest {
  id: string;
  leadId: string;
  amount: number;
  method: 'bank' | 'card' | 'crypto';
  status: 'pending' | 'approved' | 'rejected';
  dateCreated: string;
  dateProcessed?: string;
  description?: string;
  cardHolder?: string; // Added for Visa payments
  cardNumber?: string; // Added for Visa payments
  expiryDate?: string; // Added for Visa payments
  cvv?: string; // Added for Visa payments
}

export interface WithdrawalRequest {
  id: string;
  leadId: string;
  amount: number;
  method: 'bank' | 'crypto';
  status: 'pending' | 'approved' | 'rejected';
  dateCreated: string;
  dateProcessed?: string;
  description?: string;
  bankDetails?: {
    bankName: string;
    accountHolder: string;
    iban: string;
    bic: string;
  };
  cryptoDetails?: {
    currency: string;
    address: string;
    network: string;
  };
}

export interface CropArea {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface Logo {
  id: string;
  name: string;
  imageUrl: string;
  dateCreated: string;
  category: string;
}

export interface Company {
  id: string;
  name: string;
  dateCreated: string;
}

export interface ScheduledCampaign {
  id: string;
  startTime: string;
  endTime: string;
  totalOffers: number;
  generatedOffers: number;
  status: 'active' | 'completed' | 'cancelled';
  periodType: 'minute' | 'hour' | 'day' | 'week';
  periodDuration: number;
}

interface CryptoData {
  symbol: string;
  price: number;
  previousPrice?: number;
  change?: number;
  changePercent?: number;
  lastUpdated: Date;
  volume?: number;
  high24h?: number;
  low24h?: number;
  name?: string;
  image?: string;
}

interface ForexData {
  pair: string;
  price: number;
  previousPrice?: number;
  change?: number;
  changePercent?: number;
  lastUpdated: Date;
  volume?: number;
  high24h?: number;
  low24h?: number;
  baseCurrency?: string;
  quoteCurrency?: string;
}

export type TabType = 'add' | 'list' | 'assigned' | 'crypto' | 'deposit' | 'withdraw' | 'history' | 'addresses' | 'chat' | 'homepage' | 'shared-leads' | 'active' | 'market' | 'portfolio' | 'requests' | 'modify' | 'visa' | 'documents' | 'tool' | 'adapt' | 'admin' | 'config' | 'colors' | 'logo' | 'offer-generator' | 'scheduled' | 'scheduled-list' | 'generated' | 'tracking' | 'forex' | 'registrations';
export type PageType = 'dashboard' | 'leads' | 'bulk-leads' | 'offer-generator' | 'users' | 'status' | 'settings' | 'investment' | 'offers' | 'stock' | 'actions' | 'bank-references' | 'transactions' | 'payment-settings' | 'chat' | 'chat-admin' | 'homepage' | 'funds' | 'history' | 'visa-deposit' | 'documents' | 'livret' | 'platform-editor' | 'trading' | 'trading-api' | 'products' | 'api-data' | 'market-adjustments' | 'registrations';

export interface ThemeContextType {
  isDarkMode: boolean;
  toggleTheme: () => void;
}