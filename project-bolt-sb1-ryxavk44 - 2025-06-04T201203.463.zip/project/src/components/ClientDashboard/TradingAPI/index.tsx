import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  TrendingUp, TrendingDown, DollarSign, ArrowUpRight, ArrowDownRight, 
  BarChart2, RefreshCw, Activity, Check, AlertCircle, Filter, Search,
  Wallet, Info, Globe, LineChart, ChevronDown
} from 'lucide-react';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { formatPrice } from '../../../utils';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';
import { subscribeToForexUpdates, subscribeToConnectionStatus, checkConnectionAndReconnect } from '../../../services/apiDataService';

// Interface pour les paires de trading
interface TradingPair {
  id: string;
  symbol: string;
  name: string;
  type: 'forex' | 'crypto';
}

export function TradingAPI() {
  const [currentPrice, setCurrentPrice] = useState<number>(3223.455); // Default gold price
  const [currentLead, setCurrentLead] = useLocalStorage<Lead>('currentLead', null);
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [positions, setPositions] = useState<TradingAPIPosition[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [error, setError] = useState<string | null>(null);
  const [marginInfo, setMarginInfo] = useState({
    totalBalance: 0,
    usedMargin: 0,
    availableMargin: 0
  });
  const [activeTab, setActiveTab] = useState<'forex' | 'crypto'>('forex');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [selectedPair, setSelectedPair] = useState<TradingPair>({
    id: 'xauusd',
    symbol: 'XAUUSD',
    name: 'Or / US Dollar',
    type: 'forex'
  });
  const [forexConnected, setForexConnected] = useState(false);
  
  // Liste des paires disponibles (pour l'instant, seulement XAUUSD)
  const availablePairs: TradingPair[] = [
    {
      id: 'xauusd',
      symbol: 'XAUUSD',
      name: 'Or / US Dollar',
      type: 'forex'
    }
  ];
  
  // Référence pour fermer le dropdown quand on clique à l'extérieur
  const dropdownRef = useRef<HTMLDivElement>(null);
  
  // Fermer le dropdown quand on clique à l'extérieur
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    }
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  // Initialize positions from lead
  useEffect(() => {
    if (currentLead?.tradingAPIPositions) {
      // Filter to only keep XAU/USD and BTC positions
      const filteredPositions = currentLead.tradingAPIPositions.filter(
        position => position.symbol === 'XAUUSD' || position.symbol === 'BTCUSD'
      );
      setPositions(filteredPositions);
    } else {
      // If no positions exist, create some sample positions for XAU/USD and BTC only
      const samplePositions = [
        {
          id: 'pos1',
          symbol: 'BTCUSD',
          type: 'buy',
          amount: 1000,
          entryPrice: 65000,
          currentPrice: 67500,
          leverage: 5,
          pnl: 192.31,
          pnlPercentage: 19.23,
          dateCreated: new Date().toISOString()
        },
        {
          id: 'pos3',
          symbol: 'XAUUSD',
          type: 'buy',
          amount: 2000,
          entryPrice: 2100,
          currentPrice: 2150,
          leverage: 2,
          pnl: 47.62,
          pnlPercentage: 2.38,
          dateCreated: new Date(Date.now() - 172800000).toISOString() // 2 days ago
        }
      ];
      
      if (currentLead) {
        const updatedLead = {
          ...currentLead,
          tradingAPIPositions: samplePositions
        };
        
        setCurrentLead(updatedLead);
        setPositions(samplePositions);
        
        // Update leads array
        const updatedLeads = leads.map(lead => 
          lead.id === currentLead.id ? updatedLead : lead
        );
        setLeads(updatedLeads);
      }
    }
  }, [currentLead, leads, setLeads, setCurrentLead]);

  // Subscribe to forex data updates
  useEffect(() => {
    // Subscribe to forex data updates
    const unsubscribeForex = subscribeToForexUpdates((data) => {
      // Check if we have data for XAU/USD
      if (data['XAUUSD']) {
        const xauUsdData = data['XAUUSD'];
        setCurrentPrice(xauUsdData.price);
        setLastUpdate(xauUsdData.lastUpdated);
      }
    });

    // Subscribe to connection status
    const unsubscribeStatus = subscribeToConnectionStatus((cryptoStatus, forexStatus) => {
      setForexConnected(forexStatus);
    });

    // Check connection on mount
    checkConnectionAndReconnect();

    return () => {
      unsubscribeForex();
      unsubscribeStatus();
    };
  }, []);

  // Update positions when price changes
  useEffect(() => {
    if (positions.length > 0) {
      const updatedPositions = positions.map(position => {
        // Calculate P&L based on position type and leverage
        let pnl = 0;
        if (position.type === 'buy') {
          // For buy positions, profit when price goes up
          const priceChange = currentPrice - position.entryPrice;
          const changePercentage = priceChange / position.entryPrice;
          pnl = position.amount * changePercentage * position.leverage;
        } else {
          // For sell positions, profit when price goes down
          const priceChange = position.entryPrice - currentPrice;
          const changePercentage = priceChange / position.entryPrice;
          pnl = position.amount * changePercentage * position.leverage;
        }
        
        // Calculate P&L percentage
        const pnlPercentage = (pnl / position.amount) * 100;
        
        return {
          ...position,
          currentPrice,
          pnl,
          pnlPercentage
        };
      });
      
      setPositions(updatedPositions);
      
      // Update lead with new positions
      if (currentLead) {
        // Keep other positions that aren't XAU/USD or BTC
        const otherPositions = (currentLead.tradingAPIPositions || []).filter(
          position => position.symbol !== 'XAUUSD' && position.symbol !== 'BTCUSD'
        );
        
        const updatedLead = {
          ...currentLead,
          tradingAPIPositions: [...otherPositions, ...updatedPositions]
        };
        
        // Update localStorage
        localStorage.setItem('currentLead', JSON.stringify(updatedLead));
        setCurrentLead(updatedLead);
        
        // Update leads array
        const updatedLeads = leads.map(lead => 
          lead.id === currentLead.id ? updatedLead : lead
        );
        setLeads(updatedLeads);
      }
    }
  }, [currentPrice]);

  // Calculate margin information and check for margin call
  useEffect(() => {
    if (!currentLead) return;

    const totalBalance = currentLead.balance || 0;
    
    // Calculate used margin from active positions
    const activePositions = positions;
    const usedMargin = activePositions.reduce((sum, position) => sum + position.amount, 0);
    
    // Calculate available margin
    const availableMargin = totalBalance - usedMargin;

    setMarginInfo({
      totalBalance,
      usedMargin,
      availableMargin
    });
  }, [currentLead, positions]);

  // Handle refresh button click
  const handleRefresh = () => {
    setIsLoading(true);
    
    // Force reconnection to WebSocket
    const reconnected = checkConnectionAndReconnect();
    
    // Simulate loading
    setTimeout(() => {
      setIsLoading(false);
      toast.success('Données actualisées');
    }, 500);
  };

  // Calculate total P&L
  const calculateTotalPnL = (): number => {
    return positions.reduce((total, position) => total + position.pnl, 0);
  };

  // Sélectionner une paire
  const handleSelectPair = (pair: TradingPair) => {
    setSelectedPair(pair);
    setIsDropdownOpen(false);
  };

  // Filter positions based on selected pair
  const filteredPositions = positions.filter(position => 
    position.symbol === selectedPair.symbol
  );

  return (
    <div className="space-y-6">
      {/* Header with title and refresh button */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="flex items-center">
              <Globe className="w-8 h-8 text-blue-500 mr-3" />
              <div>
                <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                  Trading API
                </h2>
                <p className="text-gray-400">
                  Suivez vos positions de trading en temps réel
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                {forexConnected ? (
                  <div className="flex items-center text-green-400">
                    <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                    <span className="text-sm">Connecté</span>
                  </div>
                ) : (
                  <div className="flex items-center text-red-400">
                    <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
                    <span className="text-sm">Déconnecté</span>
                  </div>
                )}
              </div>
              
              <button
                onClick={handleRefresh}
                disabled={isLoading}
                className="p-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors flex items-center space-x-2"
              >
                <RefreshCw className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
                <span>Actualiser</span>
              </button>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Dropdown pour sélectionner la paire */}
      <div className="relative" ref={dropdownRef}>
        <div 
          className="flex items-center justify-between p-4 bg-gray-800 border border-gray-700 rounded-lg cursor-pointer"
          onClick={() => setIsDropdownOpen(!isDropdownOpen)}
        >
          <div className="flex items-center">
            <BarChart2 className="w-5 h-5 text-yellow-400 mr-2" />
            <span className="text-white font-medium">{selectedPair.name}</span>
          </div>
          <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${isDropdownOpen ? 'transform rotate-180' : ''}`} />
        </div>
        
        {/* Dropdown menu */}
        {isDropdownOpen && (
          <div className="absolute z-10 w-full mt-2 bg-gray-800 border border-gray-700 rounded-lg shadow-lg">
            {availablePairs.map(pair => (
              <div 
                key={pair.id}
                className="p-3 hover:bg-gray-700 cursor-pointer flex items-center"
                onClick={() => handleSelectPair(pair)}
              >
                <BarChart2 className="w-5 h-5 text-yellow-400 mr-2" />
                <span className="text-white">{pair.name}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Prix actuel */}
      <div className="bg-gray-800 border border-gray-700 rounded-lg p-6">
        <div className="flex flex-col items-center">
          <p className="text-gray-400 mb-2">Prix actuel</p>
          <div className="text-4xl font-bold text-white mb-2">${currentPrice.toFixed(2)}</div>
          <p className="text-sm text-gray-400">
            Dernière mise à jour: {lastUpdate.toLocaleTimeString()}
          </p>
        </div>
      </div>

      {/* Margin Information Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {/* Total Balance */}
        <div className="relative group">
          <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
          <div className="relative bg-gray-900 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center mr-3">
                  <Wallet className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-400">Solde Total</p>
                  <p className="text-xl font-bold text-white">{formatPrice(marginInfo.totalBalance)}€</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Used Margin */}
        <div className="relative group">
          <div className="absolute -inset-0.5 bg-gradient-to-r from-red-500 to-orange-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
          <div className="relative bg-gray-900 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center mr-3">
                  <AlertCircle className="w-5 h-5 text-red-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-400">Marge Utilisée</p>
                  <p className="text-xl font-bold text-white">{formatPrice(marginInfo.usedMargin)}€</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Available Margin */}
        <div className="relative group">
          <div className="absolute -inset-0.5 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
          <div className="relative bg-gray-900 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center mr-3">
                  <TrendingUp className="w-5 h-5 text-green-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-400">Marge Disponible</p>
                  <p className="text-xl font-bold text-white">{formatPrice(marginInfo.availableMargin)}€</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Positions Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/5 to-pink-500/5 rounded-xl blur-xl"></div>
        
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-bold text-white flex items-center">
              <Activity className="w-6 h-6 mr-2 text-blue-400" />
              Positions Actives
            </h3>
            <div className="text-sm text-gray-400">
              Dernière mise à jour: {lastUpdate.toLocaleTimeString()}
            </div>
          </div>

          {filteredPositions.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-700">
                <thead className="bg-gray-800/50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Symbole
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Type
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Montant
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Levier
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Prix d'entrée
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Prix actuel
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      P&L
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Date
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Statut
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-gray-900 divide-y divide-gray-800">
                  <AnimatePresence>
                    {filteredPositions.map((position) => (
                      <motion.tr 
                        key={position.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="hover:bg-gray-800/50 transition-colors"
                      >
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <BarChart2 className="w-5 h-5 text-yellow-400 mr-2" />
                            <span className="text-white">{position.symbol}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={cn(
                            "px-2 py-1 rounded-full text-xs font-medium",
                            position.type === 'buy' 
                              ? "bg-green-500/10 text-green-400 border border-green-500/20"
                              : "bg-red-500/10 text-red-400 border border-red-500/20"
                          )}>
                            {position.type === 'buy' ? 'Achat' : 'Vente'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="text-white">{formatPrice(position.amount)}€</span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="text-white">x{position.leverage}</span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="text-white">${position.entryPrice.toFixed(2)}</span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="text-white">${position.currentPrice.toFixed(2)}</span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex flex-col">
                            <div className={cn(
                              "flex items-center",
                              position.pnl >= 0 ? "text-green-400" : "text-red-400"
                            )}>
                              {position.pnl >= 0 ? (
                                <TrendingUp className="w-4 h-4 mr-1" />
                              ) : (
                                <TrendingDown className="w-4 h-4 mr-1" />
                              )}
                              <span className="font-medium">
                                {position.pnl >= 0 ? '+' : ''}{formatPrice(position.pnl)}€
                              </span>
                            </div>
                            <span className={cn(
                              "text-xs",
                              position.pnlPercentage >= 0 ? "text-green-400" : "text-red-400"
                            )}>
                              {position.pnlPercentage >= 0 ? '+' : ''}{position.pnlPercentage.toFixed(2)}%
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="text-gray-400 text-sm">
                            {new Date(position.dateCreated).toLocaleString('fr-FR', {
                              day: '2-digit',
                              month: '2-digit',
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-500/20 text-blue-400 border border-blue-500/30">
                            Position en cours
                          </span>
                        </td>
                      </motion.tr>
                    ))}
                  </AnimatePresence>
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-12 bg-gray-800/30 rounded-lg border border-gray-700/50">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-800/50 backdrop-blur-xl mb-4">
                <AlertCircle className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-xl font-medium text-gray-300">
                Aucune position active
              </h3>
              <p className="text-gray-500 max-w-sm mx-auto mt-2">
                Vous n'avez pas encore de positions de trading API pour {selectedPair.name}.
              </p>
            </div>
          )}
        </div>
      </motion.div>

      {/* Information Section */}
      <div className="bg-blue-900/20 border border-blue-500/20 rounded-lg p-4">
        <div className="flex items-center mb-2">
          <Info className="w-5 h-5 text-blue-400 mr-2" />
          <h4 className="text-blue-400 font-medium">Informations</h4>
        </div>
        <p className="text-blue-300 text-sm">
          Le Trading API vous permet de suivre vos positions de trading en temps réel. Les prix sont mis à jour automatiquement via l'API Polygon.io.
          Vous pouvez également actualiser manuellement les données en cliquant sur le bouton "Actualiser".
        </p>
      </div>

      {/* Total P&L Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/5 to-pink-500/5 rounded-xl blur-xl"></div>
        
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-6">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-bold text-white flex items-center">
              <LineChart className="w-6 h-6 mr-2 text-purple-400" />
              Résumé des performances
            </h3>
            <div className={cn(
              "flex items-center text-xl font-bold",
              calculateTotalPnL() >= 0 ? "text-green-400" : "text-red-400"
            )}>
              {calculateTotalPnL() >= 0 ? (
                <TrendingUp className="w-5 h-5 mr-2" />
              ) : (
                <TrendingDown className="w-5 h-5 mr-2" />
              )}
              <span>
                {calculateTotalPnL() >= 0 ? '+' : ''}{formatPrice(calculateTotalPnL())}€
              </span>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}