import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import type { Lead, Message } from '../../../types';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { ChatWindow } from '../../Chat/ChatWindow';
import { generateId } from '../../../utils';
import { toast } from 'react-hot-toast';

export function Chat() {
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [users] = useLocalStorage<User[]>('users', []);
  const currentLeadStr = localStorage.getItem('currentLead');
  const currentLead = currentLeadStr ? JSON.parse(currentLeadStr) as Lead : null;

  if (!currentLead) return null;

  const handleSendMessage = (content: string, attachments?: File[]) => {
    if (!currentLead) return;

    const message: Message = {
      id: generateId(),
      senderId: currentLead.id,
      senderType: 'lead',
      content,
      timestamp: new Date().toISOString(),
      attachments: attachments?.map(file => ({
        name: file.name,
        url: URL.createObjectURL(file),
        type: file.type
      }))
    };

    // Check if lead is assigned to a seller
    if (currentLead.assignedTo) {
      // If assigned, send message to the seller
      const updatedLeads = leads.map(lead => {
        if (lead.id === currentLead.id) {
          return {
            ...lead,
            chat: {
              id: lead.chat?.id || generateId(),
              leadId: lead.id,
              messages: [...(lead.chat?.messages || []), message],
              unreadCount: (lead.chat?.unreadCount || 0) + 1,
              lastMessageTimestamp: message.timestamp
            }
          };
        }
        return lead;
      });

      setLeads(updatedLeads);
      
      // Update current lead in localStorage
      const updatedLead = updatedLeads.find(l => l.id === currentLead.id);
      if (updatedLead) {
        localStorage.setItem('currentLead', JSON.stringify(updatedLead));
      }

      toast.success('Message envoyé au conseiller');
    } else {
      // If not assigned, send message to admin
      const updatedLeads = leads.map(lead => {
        if (lead.id === currentLead.id) {
          return {
            ...lead,
            chat: {
              id: lead.chat?.id || generateId(),
              leadId: lead.id,
              messages: [...(lead.chat?.messages || []), message],
              unreadCount: (lead.chat?.unreadCount || 0) + 1,
              lastMessageTimestamp: message.timestamp
            }
          };
        }
        return lead;
      });

      setLeads(updatedLeads);
      
      // Update current lead in localStorage
      const updatedLead = updatedLeads.find(l => l.id === currentLead.id);
      if (updatedLead) {
        localStorage.setItem('currentLead', JSON.stringify(updatedLead));
      }

      toast.success('Message envoyé à l\'administrateur');
    }
  };

  return (
    <div className="bg-gray-900 rounded-lg shadow-xl overflow-hidden h-[calc(100vh-12rem)]">
      <ChatWindow
        chat={currentLead.chat || {
          id: generateId(),
          leadId: currentLead.id,
          messages: [],
          unreadCount: 0,
          lastMessageTimestamp: new Date().toISOString()
        }}
        onSendMessage={handleSendMessage}
      />
    </div>
  );
}