import React, { useState, useRef, useEffect, lazy, Suspense } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Paperclip, Smile, X } from 'lucide-react';
import type { Message, Chat } from '../../types';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { formatDate } from '../../utils';
import { cn } from '../../utils/cn';

// Lazy load the EmojiPicker component
const EmojiPicker = lazy(() => import('emoji-picker-react'));

interface ChatWindowProps {
  chat: Chat;
  isAdmin?: boolean;
  onSendMessage: (content: string, attachments?: File[]) => void;
  inputRef?: React.RefObject<HTMLTextAreaElement>;
}

export function ChatWindow({ chat, isAdmin = false, onSendMessage, inputRef }: ChatWindowProps) {
  const [message, setMessage] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const [leads] = useLocalStorage<Lead[]>('leads', []);
  const emojiPickerRef = useRef<HTMLDivElement>(null);
  const emojiButtonRef = useRef<HTMLButtonElement>(null);
  const [isEmojiPickerLoaded, setIsEmojiPickerLoaded] = useState(false);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chat.messages]);

  // Preload emoji picker when component mounts
  useEffect(() => {
    const preloadEmojiPicker = async () => {
      try {
        await import('emoji-picker-react');
        setIsEmojiPickerLoaded(true);
      } catch (error) {
        console.error('Failed to preload emoji picker:', error);
      }
    };
    
    preloadEmojiPicker();
  }, []);

  // Close emoji picker when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        emojiPickerRef.current && 
        !emojiPickerRef.current.contains(event.target as Node) &&
        emojiButtonRef.current && 
        !emojiButtonRef.current.contains(event.target as Node)
      ) {
        setShowEmojiPicker(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() || files.length > 0) {
      onSendMessage(message, files);
      setMessage('');
      setFiles([]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
    }
  };

  const handleEmojiClick = (emojiData: any) => {
    setMessage(prev => prev + emojiData.emoji);
    setShowEmojiPicker(false);
  };

  const removeFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  // Get lead name for messages
  const getMessageSender = (message: Message) => {
    if (message.senderType === 'admin') {
      return 'Support';
    } else {
      const lead = leads.find(l => l.id === chat.leadId);
      return lead ? `${lead.firstName} ${lead.lastName}` : 'Client';
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Chat Messages */}
      <div 
        ref={chatContainerRef}
        className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar"
      >
        {chat.messages.map((message) => (
          <div
            key={message.id}
            className={cn(
              "flex",
              message.senderType === (isAdmin ? 'admin' : 'lead') ? "justify-end" : "justify-start"
            )}
          >
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "max-w-[70%] rounded-lg p-3 space-y-1",
                message.senderType === (isAdmin ? 'admin' : 'lead')
                  ? "bg-blue-600 text-white"
                  : "bg-gray-800 text-white"
              )}
            >
              {/* Sender Name */}
              <div className="text-xs opacity-75 font-medium">
                {getMessageSender(message)}
              </div>
              
              {/* Message Content */}
              <p className="break-words">{message.content}</p>
              
              {/* Attachments */}
              {message.attachments?.map((attachment, index) => (
                <a
                  key={index}
                  href={attachment.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center mt-2 text-sm hover:underline"
                >
                  <Paperclip className="w-4 h-4 mr-1" />
                  {attachment.name}
                </a>
              ))}
              
              {/* Timestamp */}
              <div className="text-xs opacity-70 mt-1">
                {formatDate(message.timestamp)}
              </div>
            </motion.div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* File Preview */}
      <AnimatePresence>
        {files.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="p-2 border-t border-gray-700"
          >
            <div className="flex flex-wrap gap-2">
              {files.map((file, index) => (
                <div
                  key={index}
                  className="flex items-center bg-gray-800/50 rounded px-2 py-1"
                >
                  <span className="text-sm text-gray-300 truncate max-w-[150px]">
                    {file.name}
                  </span>
                  <button
                    onClick={() => removeFile(index)}
                    className="ml-2 text-gray-400 hover:text-gray-200"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Message Input */}
      <div className="border-t border-gray-700 p-4">
        <form onSubmit={handleSubmit} className="flex items-end space-x-2">
          <div className="flex-1 relative">
            <textarea
              ref={inputRef}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Écrivez votre message..."
              className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
              rows={1}
              style={{ minHeight: '42px' }}
            />
            
            {/* Emoji Picker - Position fixed to avoid being hidden */}
            <div className="absolute" style={{ bottom: '100%', right: '0', marginBottom: '10px' }} ref={emojiPickerRef}>
              <AnimatePresence>
                {showEmojiPicker && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    style={{ 
                      position: 'fixed', 
                      bottom: '80px', 
                      right: '80px', 
                      zIndex: 9999 
                    }}
                  >
                    <div className="bg-gray-800 rounded-lg shadow-xl border border-gray-700">
                      <Suspense fallback={
                        <div className="w-[350px] h-[435px] flex items-center justify-center bg-gray-800 rounded-lg">
                          <div className="text-center">
                            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500 mx-auto mb-4"></div>
                            <p className="text-gray-400">Chargement des emojis...</p>
                          </div>
                        </div>
                      }>
                        <EmojiPicker onEmojiClick={handleEmojiClick} />
                      </Suspense>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          <div className="flex space-x-2">
            <button
              type="button"
              ref={emojiButtonRef}
              onClick={() => setShowEmojiPicker(!showEmojiPicker)}
              className="p-2 text-gray-400 hover:text-gray-200 transition-colors"
            >
              <Smile className="w-6 h-6" />
            </button>

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-2 text-gray-400 hover:text-gray-200 transition-colors"
            >
              <Paperclip className="w-6 h-6" />
              <input
                ref={fileInputRef}
                type="file"
                multiple
                onChange={handleFileChange}
                className="hidden"
              />
            </button>

            <button
              type="submit"
              disabled={!message.trim() && files.length === 0}
              className="p-2 text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-6 h-6" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}