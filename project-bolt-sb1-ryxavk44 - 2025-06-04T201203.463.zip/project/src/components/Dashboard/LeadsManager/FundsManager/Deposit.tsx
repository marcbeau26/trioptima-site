import React, { useState } from 'react';
import { useLocalStorage } from '../../../../hooks/useLocalStorage';
import type { Lead, Transaction, DepositRequest } from '../../../../types';
import { generateId } from '../../../../utils';
import { toast } from 'react-hot-toast';
import { Building2, Bitcoin, ChevronRight, Copy, ArrowRight } from 'lucide-react';
import { cn } from '../../../../utils/cn';

type PaymentMethod = 'bank' | 'crypto';

interface PaymentOption {
  id: PaymentMethod;
  title: string;
  description: string;
  icon: React.ReactNode;
}

const paymentOptions: PaymentOption[] = [
  {
    id: 'bank',
    title: 'Virement bancaire',
    description: 'Transférez depuis votre compte bancaire',
    icon: <Building2 className="w-6 h-6" />
  },
  {
    id: 'crypto',
    title: 'Crypto-monnaie',
    description: 'Payez en Bitcoin, Ethereum, etc.',
    icon: <Bitcoin className="w-6 h-6" />
  }
];

interface CryptoAddress {
  id: string;
  name: string;
  network: string;
  address: string;
}

export default function Deposit() {
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [cryptoAddresses] = useLocalStorage<CryptoAddress[]>('cryptoAddresses', []);
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [step, setStep] = useState<'amount' | 'method' | 'details'>('amount');
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod | null>(null);
  const currentLeadStr = localStorage.getItem('currentLead');
  const currentLead = currentLeadStr ? JSON.parse(currentLeadStr) as Lead : null;

  const handleCopyAddress = (address: string) => {
    navigator.clipboard.writeText(address);
    toast.success('Adresse copiée dans le presse-papier');
  };

  const handleDeposit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!currentLead || !amount || !selectedMethod) {
      toast.error('Veuillez remplir tous les champs requis');
      return;
    }

    const depositAmount = parseFloat(amount);
    if (isNaN(depositAmount) || depositAmount <= 0) {
      toast.error('Veuillez saisir un montant valide');
      return;
    }

    // Create deposit request
    const depositRequest: DepositRequest = {
      id: generateId(),
      leadId: currentLead.id,
      amount: depositAmount,
      method: selectedMethod,
      status: 'pending',
      dateCreated: new Date().toISOString(),
      description: description || `Dépôt de ${depositAmount.toLocaleString()}€ par ${selectedMethod}`
    };

    // Update lead with new deposit request
    const updatedLeads = leads.map(lead => {
      if (lead.id === currentLead.id) {
        return {
          ...lead,
          depositRequests: [...(lead.depositRequests || []), depositRequest]
        };
      }
      return lead;
    });

    setLeads(updatedLeads);
    
    // Update current lead in localStorage
    const updatedLead = updatedLeads.find(l => l.id === currentLead.id);
    if (updatedLead) {
      localStorage.setItem('currentLead', JSON.stringify(updatedLead));
    }

    setAmount('');
    setDescription('');
    setStep('amount');
    setSelectedMethod(null);
    toast.success('Demande de dépôt envoyée avec succès');
  };

  const renderAmountStep = () => (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Montant du dépôt (€)
        </label>
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          className="w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
          min="0"
          step="0.01"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Description (optionnelle)
        </label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
          rows={3}
        />
      </div>

      <button
        onClick={() => setStep('method')}
        disabled={!amount || parseFloat(amount) <= 0}
        className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        Continuer
      </button>
    </div>
  );

  const renderPaymentMethodStep = () => (
    <div className="space-y-6">
      <h3 className="text-lg font-medium text-gray-900 dark:text-white">
        Choisissez votre méthode de paiement
      </h3>
      <div className="space-y-4">
        {paymentOptions.map((option) => (
          <button
            key={option.id}
            onClick={() => {
              setSelectedMethod(option.id);
              setStep('details');
            }}
            className={cn(
              "w-full flex items-center justify-between p-4 rounded-lg border transition-all duration-200",
              "hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20",
              "group focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800"
            )}
          >
            <div className="flex items-center space-x-4">
              <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900/50 text-blue-600 dark:text-blue-400">
                {option.icon}
              </div>
              <div className="text-left">
                <h4 className="text-base font-medium text-gray-900 dark:text-white">
                  {option.title}
                </h4>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {option.description}
                </p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-blue-500 transition-colors" />
          </button>
        ))}
      </div>
      <button
        onClick={() => setStep('amount')}
        className="w-full mt-4 bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300 py-2 px-4 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
      >
        Retour
      </button>
    </div>
  );

  const renderPaymentDetails = () => {
    if (!selectedMethod) return null;

    switch (selectedMethod) {
      case 'bank':
        return (
          <div className="space-y-6">
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-6 border border-blue-200 dark:border-blue-800">
              <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                Coordonnées bancaires
              </h4>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Banque</p>
                  <p className="text-base font-medium text-gray-900 dark:text-white">Société Générale</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">IBAN</p>
                  <p className="text-base font-medium text-gray-900 dark:text-white font-mono">
                    FR76 3000 4000 0123 4567 8900 123
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">BIC/SWIFT</p>
                  <p className="text-base font-medium text-gray-900 dark:text-white font-mono">
                    SOGEFRPP
                  </p>
                </div>
              </div>
            </div>
          </div>
        );

      case 'crypto':
        return (
          <div className="space-y-6">
            {cryptoAddresses.map((address) => (
              <div
                key={address.id}
                className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-lg p-6 border border-gray-700 space-y-4"
              >
                <div className="flex items-center justify-between">
                  <h4 className="text-lg font-medium text-white">
                    {address.name}
                  </h4>
                  <span className="px-2 py-1 text-xs font-medium text-gray-300 bg-gray-700 rounded-full">
                    {address.network}
                  </span>
                </div>
                <div className="relative">
                  <div className="flex items-center space-x-2 bg-gray-800 p-4 rounded-lg border border-gray-700">
                    <code className="text-blue-400 font-mono flex-1 break-all">
                      {address.address}
                    </code>
                    <button
                      onClick={() => handleCopyAddress(address.address)}
                      className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
                    >
                      <Copy className="w-5 h-5 text-gray-400 hover:text-white" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
            {cryptoAddresses.length === 0 && (
              <div className="text-center py-6 text-gray-500 dark:text-gray-400">
                Aucune adresse crypto configurée
              </div>
            )}
          </div>
        );
    }
  };

  return (
    <form onSubmit={handleDeposit} className="max-w-lg space-y-6">
      {step === 'amount' && renderAmountStep()}
      {step === 'method' && renderPaymentMethodStep()}
      {step === 'details' && (
        <div className="space-y-6">
          {renderPaymentDetails()}
          <div className="flex space-x-4">
            <button
              type="button"
              onClick={() => setStep('method')}
              className="flex-1 bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300 py-2 px-4 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
            >
              Retour
            </button>
            <button
              type="submit"
              className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors inline-flex items-center justify-center"
            >
              <span>Valider le dépôt</span>
              <ArrowRight className="ml-2 w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </form>
  );
}