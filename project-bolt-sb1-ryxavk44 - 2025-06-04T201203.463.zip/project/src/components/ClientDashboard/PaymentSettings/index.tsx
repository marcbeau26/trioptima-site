import React, { useState } from 'react';
import { Wallet, Building2 } from 'lucide-react';
import { CryptoAddresses } from './CryptoAddresses';
import { DepositAddresses } from './DepositAddresses';
import type { TabType } from '../../../types';
import { cn } from '../../../utils/cn';

interface TabButtonProps {
  icon: React.ReactNode;
  text: string;
  isActive: boolean;
  onClick: () => void;
}

const TabButton: React.FC<TabButtonProps> = ({ icon, text, isActive, onClick }) => (
  <button
    onClick={onClick}
    className={`py-4 px-1 inline-flex items-center space-x-2 border-b-2 font-medium text-sm ${
      isActive
        ? 'border-blue-500 text-blue-600 dark:text-blue-400'
        : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
    }`}
  >
    {icon}
    <span>{text}</span>
  </button>
);

export function PaymentSettings() {
  const [activeTab, setActiveTab] = useState<TabType>('addresses');

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
      <div className="border-b border-gray-200 dark:border-gray-700">
        <nav className="flex space-x-8 px-6" aria-label="Tabs">
          <TabButton
            icon={<Wallet size={20} />}
            text="Mes adresses de retrait"
            isActive={activeTab === 'addresses'}
            onClick={() => setActiveTab('addresses')}
          />
          <TabButton
            icon={<Building2 size={20} />}
            text="Adresses dépôt"
            isActive={activeTab === 'deposit'}
            onClick={() => setActiveTab('deposit')}
          />
        </nav>
      </div>

      <div className="p-6">
        {activeTab === 'addresses' && <CryptoAddresses />}
        {activeTab === 'deposit' && <DepositAddresses />}
      </div>
    </div>
  );
}