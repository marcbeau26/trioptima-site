import React, { useState, useEffect } from 'react';
import { AlertCircle, TrendingUp, TrendingDown, Check, X, Hash } from 'lucide-react';
import type { Lead, Proposal, Transaction } from '../../../types';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { FuturisticTimer } from '../../common/FuturisticTimer';
import { toast } from 'react-hot-toast';
import { generateId } from '../../../utils';
import { motion, AnimatePresence } from 'framer-motion';

export function Propositions() {
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [currentLead, setCurrentLead] = useState<Lead | null>(null);
  const [activeProposals, setActiveProposals] = useState<Proposal[]>([]);

  // Initialize current lead and active proposals
  useEffect(() => {
    const currentLeadStr = localStorage.getItem('currentLead');
    if (currentLeadStr) {
      const lead = JSON.parse(currentLeadStr) as Lead;
      setCurrentLead(lead);
      
      // Filter only active proposals and sort by creation date (newest first)
      const proposals = lead.proposals?.filter(p => p.status === 'Active') || [];
      const sorted = [...proposals].sort((a, b) => 
        new Date(b.dateCreated).getTime() - new Date(a.dateCreated).getTime()
      );
      setActiveProposals(sorted);
    }
  }, []);

  // Check for expired proposals every second
  useEffect(() => {
    if (!currentLead || !activeProposals.length) return;

    const checkExpiry = () => {
      const now = new Date().getTime();
      const hasExpired = activeProposals.some(proposal => 
        new Date(proposal.expiryDate).getTime() <= now
      );

      if (hasExpired) {
        // Update active proposals locally
        const updatedProposals = activeProposals.map(proposal => ({
          ...proposal,
          status: new Date(proposal.expiryDate).getTime() <= now 
            ? 'Expired' as const 
            : proposal.status
        }));
        
        // Filter out expired proposals
        setActiveProposals(updatedProposals.filter(p => p.status === 'Active'));

        // Update lead in localStorage and state
        if (currentLead) {
          const updatedLead = {
            ...currentLead,
            proposals: currentLead.proposals?.map(proposal => ({
              ...proposal,
              status: new Date(proposal.expiryDate).getTime() <= now && proposal.status === 'Active'
                ? 'Expired'
                : proposal.status
            }))
          };

          setCurrentLead(updatedLead);
          localStorage.setItem('currentLead', JSON.stringify(updatedLead));
          
          // Update leads array
          const updatedLeads = leads.map(lead => 
            lead.id === currentLead.id ? updatedLead : lead
          );
          setLeads(updatedLeads);
        }
      }
    };

    const interval = setInterval(checkExpiry, 1000);
    return () => clearInterval(interval);
  }, [currentLead, activeProposals, leads, setLeads]);

  if (!currentLead) {
    return (
      <div className="text-center py-12 text-gray-500 dark:text-gray-400 energy-offer-text">
        Chargement...
      </div>
    );
  }

  if (activeProposals.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500 dark:text-gray-400 energy-offer-text">
        Aucune proposition disponible pour le moment
      </div>
    );
  }

  const handleAcceptProposal = (proposal: Proposal) => {
    if (!currentLead) return;

    // Find the original holding
    const holding = currentLead.energyHoldings?.find(h => h.id === proposal.stockId);
    if (!holding) {
      toast.error('Stock introuvable');
      return;
    }

    // Calculate original purchase price for this quantity
    const originalPrice = holding.pricePerMegawatt * proposal.megawatts;

    // Create transaction with original purchase price in description
    const transaction: Transaction = {
      id: generateId(),
      amount: proposal.totalPrice,
      type: 'sale',
      description: `Vente de ${proposal.megawatts} MW à ${proposal.buyerName} (Achat: ${originalPrice.toLocaleString()}€) - Réf: ${proposal.reference}`,
      dateCreated: new Date().toISOString()
    };

    // Update holding quantity or remove if all sold
    const updatedHoldings = currentLead.energyHoldings?.map(h => {
      if (h.id === proposal.stockId) {
        const remainingMegawatts = h.megawatts - proposal.megawatts;
        if (remainingMegawatts <= 0) {
          return undefined; // Remove holding
        }
        return {
          ...h,
          megawatts: remainingMegawatts,
          totalPrice: remainingMegawatts * h.pricePerMegawatt
        };
      }
      return h;
    }).filter(Boolean);

    // Mark the accepted proposal as Accepted and all others as Rejected
    const updatedProposals = currentLead.proposals?.map(p => ({
      ...p,
      status: p.id === proposal.id ? 'Accepted' : 'Rejected'
    }));

    // Update the lead with new balance, transaction, and proposal status
    const updatedLead = {
      ...currentLead,
      proposals: updatedProposals,
      transactions: [...(currentLead.transactions || []), transaction],
      balance: (currentLead.balance || 0) + proposal.totalPrice,
      energyHoldings: updatedHoldings
    };
    
    // Update currentLead in localStorage and state
    localStorage.setItem('currentLead', JSON.stringify(updatedLead));
    setCurrentLead(updatedLead);
    
    // Update leads array
    const updatedLeads = leads.map(lead => 
      lead.id === currentLead.id ? updatedLead : lead
    );
    setLeads(updatedLeads);

    // Clear active proposals immediately
    setActiveProposals([]);
    
    toast.success(`Proposition acceptée. ${proposal.totalPrice.toLocaleString()}€ ajoutés à votre solde.`);
  };

  const handleRejectProposal = (proposal: Proposal) => {
    if (!currentLead) return;

    // Update the proposal status to Rejected
    const updatedProposals = currentLead.proposals?.map(p => 
      p.id === proposal.id 
        ? { ...p, status: 'Rejected' as const }
        : p
    );

    // Update the lead with the rejected proposal
    const updatedLead = {
      ...currentLead,
      proposals: updatedProposals
    };
    
    // Update currentLead in localStorage and state
    localStorage.setItem('currentLead', JSON.stringify(updatedLead));
    setCurrentLead(updatedLead);
    
    // Update leads array
    const updatedLeads = leads.map(lead => 
      lead.id === currentLead.id ? updatedLead : lead
    );
    setLeads(updatedLeads);

    // Remove the rejected proposal from active proposals
    setActiveProposals(activeProposals.filter(p => p.id !== proposal.id));
    
    toast.success('Proposition refusée');
  };

  const handleExpireProposal = (proposalId: string) => {
    if (!currentLead) return;

    // Update the proposal status to Expired
    const updatedProposals = currentLead.proposals?.map(p => 
      p.id === proposalId 
        ? { ...p, status: 'Expired' as const }
        : p
    );

    // Update the lead with the expired proposal
    const updatedLead = {
      ...currentLead,
      proposals: updatedProposals
    };
    
    // Update currentLead in localStorage and state
    localStorage.setItem('currentLead', JSON.stringify(updatedLead));
    setCurrentLead(updatedLead);
    
    // Update leads array
    const updatedLeads = leads.map(lead => 
      lead.id === currentLead.id ? updatedLead : lead
    );
    setLeads(updatedLeads);

    // Remove the expired proposal from active proposals
    setActiveProposals(activeProposals.filter(p => p.id !== proposalId));
  };

  return (
    <div className="space-y-8 energy-offer-text">
      <AnimatePresence>
        {activeProposals.map((proposal) => (
          <motion.div 
            key={proposal.id}
            initial={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20, transition: { duration: 0.3 } }}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6"
          >
            <div className="flex justify-between items-start mb-4">
              <div>
                <h4 className="text-base font-medium text-gray-900 dark:text-white">
                  Proposition de rachat
                </h4>
              </div>
              <div className="flex items-center space-x-2">
                {proposal.status === 'Active' && (
                  <>
                    <button
                      onClick={() => handleAcceptProposal(proposal)}
                      className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700"
                    >
                      <Check size={16} className="mr-1" />
                      Accepter
                    </button>
                    <button
                      onClick={() => handleRejectProposal(proposal)}
                      className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700"
                    >
                      <X size={16} className="mr-1" />
                      Refuser
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* Reference display */}
            <div className="mb-4 flex justify-center">
              <div className="reference-tag py-2 px-4 rounded-lg">
                <div className="flex items-center justify-center">
                  <Hash className="h-5 w-5 text-blue-400 mr-2" />
                  <span className="text-lg font-mono font-bold text-blue-300 tracking-widest">
                    RÉF: {proposal.reference}
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6 mb-4">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Acheteur</p>
                <p className="text-base font-medium text-gray-900 dark:text-white">
                  {proposal.buyerName}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Quantité</p>
                <p className="text-base font-medium text-gray-900 dark:text-white">
                  {proposal.megawatts} MW
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Prix par MW</p>
                <p className="text-base font-medium text-gray-900 dark:text-white">
                  {proposal.pricePerMegawatt.toLocaleString()}€
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Prix total</p>
                <p className="text-base font-medium text-gray-900 dark:text-white">
                  {proposal.totalPrice.toLocaleString()}€
                </p>
              </div>
            </div>

            {proposal.status === 'Active' && (
              <div className="mt-4 flex items-center justify-between">
                <div className="flex items-center">
                  <AlertCircle className="h-5 w-5 text-yellow-500 mr-2" />
                  <span className="text-sm text-gray-500 dark:text-gray-400">
                    Cette proposition expirera dans :
                  </span>
                </div>
                <FuturisticTimer 
                  expiryDate={proposal.expiryDate}
                  onExpire={() => handleExpireProposal(proposal.id)}
                />
              </div>
            )}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}