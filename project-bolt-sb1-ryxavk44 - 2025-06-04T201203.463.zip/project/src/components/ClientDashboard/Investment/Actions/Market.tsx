import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertCircle, DollarSign, Euro, Hash, Info, Gift, Shield, TrendingUp } from 'lucide-react';
import type { StockAction } from '../../../../types';
import { useLocalStorage } from '../../../../hooks/useLocalStorage';
import { formatDate, formatPrice } from '../../../../utils';
import { toast } from 'react-hot-toast';
import { cn } from '../../../../utils/cn';

interface InfoZoneProps {
  action: StockAction;
  isOpen: boolean;
}

interface ConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  action: StockAction;
  quantity: number;
  currentBalance: number;
}

const InfoZone: React.FC<InfoZoneProps> = ({ action, isOpen }) => {
  if (!isOpen) return null;

  // Only show the info zone if there's practical info or if showPracticalInfo is true
  if (!action.practicalInfo) return null;

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.3 }}
      className="mt-4 overflow-hidden"
    >
      <div className="bg-gray-800/50 border border-white/5 rounded-xl p-4 space-y-4">
        <div>
          <h4 className="text-lg font-medium text-white mb-2">À propos de {action.name}</h4>
          {action.practicalInfo ? (
            <div 
              className="prose prose-invert max-w-none text-gray-300"
              dangerouslySetInnerHTML={{ __html: action.practicalInfo }}
            />
          ) : (
            <p className="text-gray-400">
              {action.name} est une entreprise leader dans son secteur, offrant des opportunités d'investissement attractives avec un potentiel de croissance significatif.
            </p>
          )}
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <h5 className="text-sm font-medium text-gray-300 mb-1">Période de détention</h5>
            <p className="text-white">
              {action.holdingPeriodYears > 0 && `${action.holdingPeriodYears} an${action.holdingPeriodYears > 1 ? 's' : ''}`}
              {action.holdingPeriodMonths > 0 && ` ${action.holdingPeriodMonths} mois`}
              {action.holdingPeriodDays > 0 && ` ${action.holdingPeriodDays} jour${action.holdingPeriodDays > 1 ? 's' : ''}`}
            </p>
          </div>

          <div>
            <h5 className="text-sm font-medium text-gray-300 mb-1">Filet de sécurité</h5>
            <p className="text-white">
              {formatPrice(action.safetyNet)}€
            </p>
          </div>
        </div>

        <div>
          <h5 className="text-sm font-medium text-gray-300 mb-2">Avantages</h5>
          <ul className="space-y-2 text-gray-400">
            <li className="flex items-center">
              <Shield className="w-4 h-4 text-green-400 mr-2" />
              Protection du capital avec filet de sécurité
            </li>
            {action.bonusShares > 0 && (
              <li className="flex items-center">
                <Gift className="w-4 h-4 text-purple-400 mr-2" />
                {action.bonusShares} action{action.bonusShares > 1 ? 's' : ''} offerte{action.bonusShares > 1 ? 's' : ''}
              </li>
            )}
            <li className="flex items-center">
              <TrendingUp className="w-4 h-4 text-blue-400 mr-2" />
              Potentiel de croissance attractif
            </li>
          </ul>
        </div>

        <div className="bg-blue-900/20 border border-blue-500/20 rounded-lg p-3">
          <div className="flex items-center mb-2">
            <Info className="w-5 h-5 text-blue-400 mr-2" />
            <h5 className="text-sm font-medium text-blue-400">Information importante</h5>
          </div>
          <p className="text-sm text-blue-300">
            Les performances passées ne préjugent pas des performances futures. Investir comporte des risques, veuillez consulter notre documentation avant d'investir.
          </p>
        </div>
      </div>
    </motion.div>
  );
};

const ConfirmationModal: React.FC<ConfirmationModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  action,
  quantity,
  currentBalance
}) => {
  const [isSignatureConfirmed, setIsSignatureConfirmed] = useState(false);

  if (!isOpen) return null;

  const isUSD = action.priceUSD > 0 && action.price === 0;
  const price = isUSD ? action.priceUSD : action.price;
  const totalCost = price * quantity;
  const balanceAfterInvestment = currentBalance - totalCost;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-lg mx-4"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-6">
            Confirmation d'investissement
          </h2>

          <div className="space-y-6">
            {/* Investment Details */}
            <div className="bg-gray-800/50 border border-white/5 rounded-xl p-6 space-y-4">
              {/* Reference display */}
              {action.reference && (
                <div className="flex items-center justify-center mb-4">
                  <div className="reference-tag py-2 px-4 rounded-lg flex items-center">
                    <Hash className="h-5 w-5 text-blue-400 mr-2" />
                    <span className="text-lg font-mono font-bold text-blue-300 tracking-wider energy-offer-text">
                      RÉF: {action.reference}
                    </span>
                  </div>
                </div>
              )}
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-gray-400 text-sm">Action</p>
                  <p className="text-white font-medium">{action.name}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Quantité</p>
                  <p className="text-white font-medium">{quantity}</p>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Prix unitaire</p>
                  <div className="flex items-center text-white">
                    {isUSD ? (
                      <>
                        <DollarSign className="w-4 h-4 mr-1" />
                        <span>{formatPrice(price)}</span>
                      </>
                    ) : (
                      <>
                        <span>{formatPrice(price)}</span>
                        <Euro className="w-4 h-4 ml-1" />
                      </>
                    )}
                  </div>
                </div>
                <div>
                  <p className="text-gray-400 text-sm">Prix total</p>
                  <div className="flex items-center text-white">
                    {isUSD ? (
                      <>
                        <DollarSign className="w-4 h-4 mr-1" />
                        <span>{formatPrice(totalCost)}</span>
                      </>
                    ) : (
                      <>
                        <span>{formatPrice(totalCost)}</span>
                        <Euro className="w-4 h-4 ml-1" />
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Balance Info */}
            <div className="bg-gray-800/50 border border-white/5 rounded-xl p-6 space-y-4">
              <div>
                <p className="text-gray-400 text-sm">Solde actuel</p>
                <p className="text-white font-medium">{formatPrice(currentBalance)}€</p>
              </div>
              <div>
                <p className="text-gray-400 text-sm">Solde après investissement</p>
                <p className="text-white font-medium">{formatPrice(balanceAfterInvestment)}€</p>
              </div>
            </div>

            {/* Signature Confirmation */}
            <label className="flex items-center space-x-3 cursor-pointer">
              <input
                type="checkbox"
                checked={isSignatureConfirmed}
                onChange={(e) => setIsSignatureConfirmed(e.target.checked)}
                className="w-5 h-5 rounded border-gray-600 text-blue-600 focus:ring-blue-500 bg-gray-800"
              />
              <span className="text-gray-300">Je confirme ma signature électronique</span>
            </label>

            {/* Action Buttons */}
            <div className="flex space-x-4">
              <button
                onClick={onClose}
                className="flex-1 px-6 py-3 text-sm font-medium text-gray-300 bg-gray-800/50 hover:bg-gray-700/50 rounded-lg transition-colors"
              >
                Annuler
              </button>
              <motion.button
                onClick={onConfirm}
                disabled={!isSignatureConfirmed}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex-1 relative group overflow-hidden rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity"></div>
                <span className="relative text-sm font-medium text-white">
                  Valider l'investissement
                </span>
              </motion.button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export function Market() {
  const [actions] = useLocalStorage<StockAction[]>('stockActions', []);
  const [selectedAction, setSelectedAction] = useState<StockAction | null>(null);
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  const [quantityErrors, setQuantityErrors] = useState<Record<string, string>>({});
  const [currentLead] = useLocalStorage('currentLead', null);
  const [openInfoId, setOpenInfoId] = useState<string | null>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);

  const activeActions = actions.filter(action => action.status === 'Active');

  const handleQuantityChange = (action: StockAction, value: string) => {
    const numValue = parseInt(value) || 0;
    
    setQuantities(prev => ({
      ...prev,
      [action.id]: numValue
    }));

    setQuantityErrors(prev => ({
      ...prev,
      [action.id]: ''
    }));

    if (numValue > action.maxQuantity) {
      setQuantityErrors(prev => ({
        ...prev,
        [action.id]: `La quantité ne peut pas dépasser ${action.maxQuantity}`
      }));
    } else if (numValue < action.minQuantity) {
      setQuantityErrors(prev => ({
        ...prev,
        [action.id]: `La quantité minimum est de ${action.minQuantity}`
      }));
    }
  };

  const handleInvestment = () => {
    if (!selectedAction || !currentLead) {
      toast.error('Une erreur est survenue');
      return;
    }

    const quantity = quantities[selectedAction.id] || selectedAction.minQuantity;

    if (quantity > selectedAction.maxQuantity) {
      toast.error(`La quantité ne peut pas dépasser ${selectedAction.maxQuantity}`);
      return;
    }

    if (quantity < selectedAction.minQuantity) {
      toast.error(`La quantité minimum est de ${selectedAction.minQuantity}`);
      return;
    }

    const isUSD = selectedAction.priceUSD > 0 && selectedAction.price === 0;
    const price = isUSD ? selectedAction.priceUSD : selectedAction.price;
    const totalCost = price * quantity;

    if (totalCost > (currentLead.balance || 0)) {
      toast.error('Solde insuffisant pour cet investissement');
      return;
    }

    const holding = {
      id: Math.random().toString(36).substr(2, 9),
      name: selectedAction.name,
      quantity: quantity + (selectedAction.bonusShares || 0),
      purchasePrice: price,
      totalCost: totalCost,
      purchaseDate: new Date().toISOString(),
      currency: isUSD ? 'USD' : 'EUR',
      reference: selectedAction.reference
    };

    const transaction = {
      id: Math.random().toString(36).substr(2, 9),
      amount: -totalCost,
      type: 'investment' as const,
      description: `Achat de ${quantity} action${quantity > 1 ? 's' : ''} de ${selectedAction.name}${selectedAction.bonusShares ? ` (+ ${selectedAction.bonusShares} action${selectedAction.bonusShares > 1 ? 's' : ''} offerte${selectedAction.bonusShares > 1 ? 's' : ''})` : ''} - Réf: ${selectedAction.reference}`,
      dateCreated: new Date().toISOString()
    };

    const updatedLead = {
      ...currentLead,
      balance: (currentLead.balance || 0) - totalCost,
      stockHoldings: [...(currentLead.stockHoldings || []), holding],
      transactions: [...(currentLead.transactions || []), transaction]
    };

    localStorage.setItem('currentLead', JSON.stringify(updatedLead));

    setSelectedAction(null);
    setQuantities(prev => ({
      ...prev,
      [selectedAction.id]: 0
    }));
    setShowConfirmation(false);

    toast.success('Investissement effectué avec succès');
    window.location.reload();
  };

  if (activeActions.length === 0) {
    return (
      <div className="min-h-[400px] flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-800/50 backdrop-blur-xl mb-4">
            <AlertCircle className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-xl font-medium text-gray-300">
            Aucune action disponible
          </h3>
          <p className="text-gray-500 max-w-sm">
            Il n'y a actuellement aucune action disponible sur le marché. Revenez plus tard.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {activeActions.map((action, index) => {
        const isUSD = action.priceUSD > 0 && action.price === 0;
        const price = isUSD ? action.priceUSD : action.price;
        const marketPrice = isUSD ? action.currentMarketPriceUSD : action.currentMarketPrice;
        const safetyNetPrice = isUSD ? action.safetyNetUSD : action.safetyNet;
        const quantity = quantities[action.id] || action.minQuantity;
        const lotPrice = price * quantity;

        return (
          <motion.div
            key={action.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1 }}
            className="group relative"
          >
            {/* Glowing border effect */}
            <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
            
            {/* Card content */}
            <div className="relative bg-gray-900 rounded-lg p-6 ring-1 ring-gray-800/50">
              {/* Header */}
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h3 className="text-xl font-semibold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
                    {action.name}
                  </h3>
                  <p className="text-sm text-gray-500">{formatDate(action.startDate)}</p>
                </div>
              </div>

              {/* Reference display */}
              {action.reference && (
                <div className="mb-4 flex justify-center">
                  <div className="reference-tag py-2 px-4 rounded-lg">
                    <div className="flex items-center justify-center">
                      <Hash className="h-5 w-5 text-blue-400 mr-2" />
                      <span className="text-lg font-mono font-bold text-blue-300 tracking-widest energy-offer-text">
                        RÉF: {action.reference}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Bonus Shares Banner */}
              {action.bonusShares > 0 && (
                <div className="mb-4 bg-green-900/20 rounded-lg p-3 border border-green-500/20">
                  <div className="flex items-center">
                    <Gift className="w-5 h-5 text-green-400 mr-2" />
                    <p className="text-green-400 font-medium">
                      +{action.bonusShares} action{action.bonusShares > 1 ? 's' : ''} offerte{action.bonusShares > 1 ? 's' : ''} !
                    </p>
                  </div>
                </div>
              )}

              {/* Price Info */}
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-500">Prix</span>
                  <div className="flex items-center text-white">
                    {isUSD ? (
                      <>
                        <DollarSign className="h-4 w-4 mr-1" />
                        <span>{formatPrice(price)}</span>
                      </>
                    ) : (
                      <>
                        <span>{formatPrice(price)}</span>
                        <Euro className="h-4 w-4 ml-1" />
                      </>
                    )}
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-gray-500">Quantité</span>
                  <div className="text-sm text-gray-400 space-x-2">
                    <span>Min: {action.minQuantity}</span>
                    <span>•</span>
                    <span>Max: {action.maxQuantity}</span>
                  </div>
                </div>
                <input
                  type="number"
                  value={quantity}
                  onChange={(e) => handleQuantityChange(action, e.target.value)}
                  className={cn(
                    "w-full bg-gray-800 border border-gray-700 rounded px-3 py-2 text-white",
                    "focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                    "placeholder-gray-500",
                    quantityErrors[action.id] && "border-red-500 focus:ring-red-500"
                  )}
                />
                {quantityErrors[action.id] && (
                  <p className="text-sm text-red-500 mt-1">{quantityErrors[action.id]}</p>
                )}

                <div className="flex justify-between items-center">
                  <span className="text-gray-500">Prix total</span>
                  <div className="flex items-center text-white">
                    {isUSD ? (
                      <>
                        <DollarSign className="h-4 w-4 mr-1" />
                        <span>{formatPrice(lotPrice)}</span>
                      </>
                    ) : (
                      <>
                        <span>{formatPrice(lotPrice)}</span>
                        <Euro className="h-4 w-4 ml-1" />
                      </>
                    )}
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-gray-500">Filet sécurité</span>
                  <div className="flex items-center text-white">
                    {isUSD ? (
                      <>
                        <DollarSign className="h-4 w-4 mr-1" />
                        <span>{formatPrice(safetyNetPrice)}</span>
                      </>
                    ) : (
                      <>
                        <span>{formatPrice(safetyNetPrice)}</span>
                        <Euro className="h-4 w-4 ml-1" />
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 mt-6">
                <motion.button
                  onClick={() => {
                    setSelectedAction(action);
                    setShowConfirmation(true);
                  }}
                  disabled={!currentLead || quantity < action.minQuantity || quantity > action.maxQuantity || !!quantityErrors[action.id]}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full relative group overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-50 group-hover:opacity-70 transition-opacity"></div>
                  <div className="relative bg-gray-900/20 text-white py-3 px-4 rounded-md group-hover:bg-opacity-90 transition-colors">
                    Investir maintenant
                  </div>
                </motion.button>

                {/* Only show the Info button if there's practical info and showPracticalInfo is true */}
                {action.practicalInfo && (
                  <motion.button
                    onClick={() => setOpenInfoId(openInfoId === action.id ? null : action.id)}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full relative group overflow-hidden"
                  >
                    <div className="absolute inset-0 bg-gray-700 opacity-50 group-hover:opacity-70 transition-opacity"></div>
                    <div className="relative bg-gray-900/20 text-gray-300 py-3 px-4 rounded-md group-hover:bg-opacity-90 transition-colors flex items-center justify-center">
                      <Info className="w-4 h-4 mr-2" />
                      Info pratique
                    </div>
                  </motion.button>
                )}
              </div>

              {/* Info Zone */}
              <AnimatePresence>
                {openInfoId === action.id && (
                  <InfoZone action={action} isOpen={true} />
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        );
      })}

      {/* Confirmation Modal */}
      <AnimatePresence>
        {selectedAction && showConfirmation && (
          <ConfirmationModal
            isOpen={true}
            onClose={() => {
              setSelectedAction(null);
              setShowConfirmation(false);
            }}
            onConfirm={handleInvestment}
            action={selectedAction}
            quantity={quantities[selectedAction.id] || selectedAction.minQuantity}
            currentBalance={currentLead?.balance || 0}
          />
        )}
      </AnimatePresence>
    </div>
  );
}