import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '../../utils/cn';

interface StatCardProps {
  title: string;
  value: string;
  subValue?: string;
  textColor?: string;
  icon?: React.ReactNode;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, subValue, textColor = 'text-gray-900', icon }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="relative group"
  >
    {/* Glowing background effect */}
    <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-pink-500/20 rounded-xl blur-xl opacity-75 group-hover:opacity-100 transition duration-1000"></div>
    
    {/* Card content */}
    <div className="relative bg-black/40 backdrop-blur-xl border border-white/10 rounded-xl p-4 md:p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-medium text-gray-400">{title}</h3>
        {icon && (
          <div className="relative">
            <div className="absolute -inset-1 bg-blue-500/30 rounded-lg blur"></div>
            <div className="relative w-10 h-10 md:w-12 md:h-12 flex items-center justify-center bg-blue-500/10 rounded-lg border border-blue-500/20">
              {React.cloneElement(icon as React.ReactElement, {
                className: cn(
                  "w-5 h-5 md:w-6 md:h-6",
                  textColor === 'text-green-600' ? 'text-green-400' : 'text-blue-400'
                )
              })}
            </div>
          </div>
        )}
      </div>
      <div className="space-y-1">
        <p className={cn(
          "text-xl md:text-2xl font-bold",
          textColor === 'text-green-600' ? 'text-green-400' : 'text-white'
        )}>
          {value}
        </p>
        {subValue && (
          <p className={cn(
            "text-xs md:text-sm",
            textColor === 'text-green-600' ? 'text-green-400' : 'text-gray-400'
          )}>
            {subValue}
          </p>
        )}
      </div>
    </div>
  </motion.div>
);

export default React.memo(StatCard);