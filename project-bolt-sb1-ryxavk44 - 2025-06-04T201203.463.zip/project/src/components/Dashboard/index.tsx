import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  BarChart2, UserPlus, Users, Activity, Settings, 
  LogOut, Gift, Package, Zap, Building2, Wallet, LineChart,
  MessageSquare, Home, FileSpreadsheet, Share2, User, BookOpen,
  Paintbrush, ShoppingBag, Menu, X, UserCheck
} from 'lucide-react';
import { SidebarLink, StatCard } from '../common';
import { LeadsManager } from './LeadsManager';
import { BulkLeads } from './LeadsManager/BulkLeads';
import { OfferGenerator } from './OfferGenerator';
import { UsersManager } from './UsersManager';
import { StatusManager } from './StatusManager';
import { SettingsManager } from './SettingsManager';
import { OfferManager } from './OfferManager';
import { StockManager } from './StockManager';
import { ActionsManager } from './ActionsManager';
import { BankReferences } from './BankReferences';
import { TransactionsManager } from './TransactionsManager';
import { SubscribedActions } from './SubscribedActions';
import { ChatAdmin } from './ChatAdmin';
import { HomepageManager } from './HomepageManager';
import { LivretManager } from './LivretManager';
import { PlatformEditor } from './PlatformEditor';
import { ProductManager } from './ProductManager';
import { RegistrationsManager } from './RegistrationsManager';
import { Footer } from '../Footer';
import type { PageType } from '../../types';
import { getPageTitle } from '../../utils';
import { getCurrentUser, signOut } from '../../lib/auth';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { motion, AnimatePresence } from 'framer-motion';

export function Dashboard() {
  const navigate = useNavigate();
  const location = useLocation();
  const [activePage, setActivePage] = useState<PageType>('dashboard');
  const [userRole, setUserRole] = useState<'Admin' | 'Seller' | null>(null);
  const [userName, setUserName] = useState<string>('');
  const [stocks] = useLocalStorage('stocks', []);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const [settings] = useLocalStorage<any>('homepageSettings', {
    logoMode: 'image',
    logoText: 'Trioptima',
    logoTextColor: '#ffffff'
  });

  // Count active stocks
  const activeStocksCount = stocks.filter(stock => stock.status === 'Available').length;

  // Check if screen is mobile
  const isMobile = typeof window !== 'undefined' ? window.innerWidth < 768 : false;

  // Close sidebar on mobile when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (isMobile && isSidebarOpen && sidebarRef.current && !sidebarRef.current.contains(event.target as Node)) {
        setIsSidebarOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isMobile, isSidebarOpen]);

  // Close sidebar on mobile when changing routes
  useEffect(() => {
    if (isMobile) {
      setIsSidebarOpen(false);
    }
  }, [activePage, isMobile]);

  // Set sidebar state based on screen size
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setIsSidebarOpen(false);
      } else {
        setIsSidebarOpen(true);
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  useEffect(() => {
    const checkUser = async () => {
      const user = await getCurrentUser();
      if (!user) {
        navigate('/', { replace: true });
        return;
      }
      
      setUserRole(user.role as 'Admin' | 'Seller');
      setUserName(`${user.firstName} ${user.lastName}`);
    };

    checkUser();
  }, [navigate]);

  useEffect(() => {
    // Check if we have an activeTab in the location state
    if (location.state?.activeTab) {
      setActivePage(location.state.activeTab);
      // Clear the state so it doesn't persist
      window.history.replaceState({}, '');
    }
  }, [location]);

  const handleLogout = async () => {
    const { error } = await signOut();
    if (!error) {
      navigate('/', { replace: true });
    }
  };

  const calculateAccountPerformance = () => {
    const currentLeadStr = localStorage.getItem('currentLead');
    if (!currentLeadStr) return { balance: 0, profit: 0, profitPercentage: 0 };

    const currentLead = JSON.parse(currentLeadStr);
    const transactions = currentLead.transactions || [];

    // Calculate initial investment (sum of all deposits)
    const initialInvestment = transactions
      .filter(t => t.type === 'deposit')
      .reduce((sum, t) => sum + t.amount, 0);

    // Calculate total withdrawals
    const totalWithdrawals = transactions
      .filter(t => t.type === 'withdrawal')
      .reduce((sum, t) => sum + Math.abs(t.amount), 0);

    // Calculate current balance
    const currentBalance = currentLead.balance || 0;

    // Calculate total profit (current balance + withdrawals - deposits)
    const totalProfit = currentBalance + totalWithdrawals - initialInvestment;

    // Calculate profit percentage
    const profitPercentage = initialInvestment > 0 
      ? (totalProfit / initialInvestment) * 100 
      : 0;

    return {
      balance: currentBalance,
      profit: totalProfit,
      profitPercentage
    };
  };

  const renderContent = () => {
    switch (activePage) {
      case 'dashboard': {
        const performance = calculateAccountPerformance();
        
        return (
          <div className="space-y-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8">
              <StatCard 
                title="Administrateur" 
                value={userName}
                icon={<User className="h-5 w-5 text-blue-600" />}
              />
              <StatCard 
                title="Balance" 
                value={`${performance.balance.toLocaleString()}€`}
                icon={<BarChart2 className="h-5 w-5 text-blue-600" />}
              />
              <StatCard 
                title="Positions ouvertes" 
                value={activeStocksCount.toString()}
                icon={<Package className="h-5 w-5 text-violet-600" />}
              />
              <StatCard 
                title="Performance" 
                value={`${performance.profitPercentage >= 0 ? '+' : ''}${performance.profitPercentage.toFixed(2)}%`}
                subValue={`${performance.profit >= 0 ? '+' : ''}${performance.profit.toLocaleString()}€`}
                textColor={performance.profit >= 0 ? "text-green-600" : "text-red-600"}
                icon={<Activity className="h-5 w-5 text-green-600" />}
              />
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-gray-800 rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-medium text-white mb-4">
                  Performance du compte
                </h3>
                <div className="h-64 flex items-center justify-center">
                  <p className="text-gray-400">
                    Le graphique de performance sera disponible prochainement
                  </p>
                </div>
              </div>
              
              <div className="bg-gray-800 rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-medium text-white mb-4">
                  Positions ouvertes
                </h3>
                <div className="space-y-4">
                  {stocks.map(stock => (
                    <div key={stock.id} className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
                      <div>
                        <p className="font-medium text-white">{stock.companyName}</p>
                        <p className="text-sm text-gray-400">{stock.megawatts} MW</p>
                      </div>
                      <div className="text-right">
                        <p className={`font-medium ${stock.priceVariation >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {stock.priceVariation >= 0 ? '+' : ''}{stock.priceVariation}%
                        </p>
                        <p className="text-sm text-gray-400">
                          {stock.pricePerMegawatt.toLocaleString()}€/MW
                        </p>
                      </div>
                    </div>
                  ))}
                  {(!stocks || stocks.length === 0) && (
                    <p className="text-center text-gray-400">
                      Aucune position ouverte
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
        );
      }
      case 'leads':
        return <LeadsManager />;
      case 'bulk-leads':
        return <BulkLeads />;
      case 'offer-generator':
        return <OfferGenerator />;
      case 'users':
        return userRole === 'Admin' ? <UsersManager /> : null;
      case 'status':
        return userRole === 'Admin' ? <StatusManager /> : null;
      case 'offers':
        return userRole === 'Admin' ? <OfferManager /> : null;
      case 'stock':
        return userRole === 'Admin' ? <StockManager /> : null;
      case 'actions':
        return userRole === 'Admin' ? <ActionsManager /> : null;
      case 'subscribed-actions':
        return userRole === 'Admin' ? <SubscribedActions /> : null;
      case 'livret':
        return userRole === 'Admin' ? <LivretManager /> : null;
      case 'bank-references':
        return userRole === 'Admin' ? <BankReferences /> : null;
      case 'transactions':
        return userRole === 'Admin' ? <TransactionsManager /> : null;
      case 'chat-admin':
        return userRole === 'Admin' ? <ChatAdmin /> : null;
      case 'homepage':
        return userRole === 'Admin' ? <HomepageManager /> : null;
      case 'platform-editor':
        return userRole === 'Admin' ? <PlatformEditor /> : null;
      case 'products':
        return userRole === 'Admin' ? <ProductManager /> : null;
      case 'registrations':
        return userRole === 'Admin' ? <RegistrationsManager /> : null;
      case 'settings':
        return <SettingsManager />;
      default:
        return <div className="text-gray-400">Page en construction</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 flex flex-col">
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Mobile Header */}
        <div className="md:hidden flex items-center justify-between p-4 border-b border-gray-700" style={{ 
          backgroundColor: 'var(--color-header, #1e293b)',
          borderColor: 'var(--color-dividers, #374151)'
        }}>
          <div className="flex items-center">
            {settings.logoMode === 'image' ? (
              <BarChart2 className="h-6 w-6 text-blue-600" />
            ) : (
              <span 
                className="font-['Orbitron'] font-bold text-lg"
                style={{ 
                  color: settings.logoTextColor || '#ffffff',
                  textShadow: '0 0 5px currentColor'
                }}
              >
                {settings.logoText || 'Trioptima'}
              </span>
            )}
          </div>
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700"
          >
            {isSidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Left Sidebar */}
        <AnimatePresence>
          {isSidebarOpen && (
            <motion.div
              ref={sidebarRef}
              initial={{ x: -300, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -300, opacity: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="fixed md:relative z-40 md:z-auto inset-y-0 left-0 w-64 border-r border-gray-700 flex flex-col bg-opacity-95 md:bg-opacity-100 backdrop-blur-lg md:backdrop-blur-none"
              style={{ 
                backgroundColor: 'var(--color-sidebar, #0f172a)',
                borderColor: 'var(--color-dividers, #374151)'
              }}
            >
              {/* Logo Section - Hidden on mobile */}
              <div className="hidden md:flex h-16 items-center px-4 border-b border-gray-700" style={{ borderColor: 'var(--color-dividers, #374151)' }}>
                <div className="flex items-center ml-3">
                  {settings.logoMode === 'image' ? (
                    <BarChart2 className="h-5 w-5 text-blue-500" />
                  ) : (
                    <span 
                      className="font-['Orbitron'] font-bold text-lg"
                      style={{ 
                        color: settings.logoTextColor || '#ffffff',
                        textShadow: '0 0 5px currentColor'
                      }}
                    >
                      {settings.logoText || 'Trioptima'}
                    </span>
                  )}
                </div>
              </div>

              {/* Navigation */}
              <nav className="flex-1 overflow-y-auto py-6">
                <div className="px-4 space-y-1">
                  <SidebarLink 
                    icon={BarChart2} 
                    text="Tableau de bord" 
                    isActive={activePage === 'dashboard'}
                    onClick={() => setActivePage('dashboard')}
                  />
                  {userRole === 'Admin' && (
                    <SidebarLink 
                      icon={Users} 
                      text="Gestionnaire d'Utilisateurs"
                      isActive={activePage === 'users'}
                      onClick={() => setActivePage('users')}
                    />
                  )}
                  {userRole === 'Admin' && (
                    <SidebarLink 
                      icon={UserCheck} 
                      text="Inscriptions"
                      isActive={activePage === 'registrations'}
                      onClick={() => setActivePage('registrations')}
                    />
                  )}
                  <SidebarLink 
                    icon={FileSpreadsheet} 
                    text="Leads en Masse"
                    isActive={activePage === 'bulk-leads'}
                    onClick={() => setActivePage('bulk-leads')}
                  />
                  <SidebarLink 
                    icon={UserPlus} 
                    text="Gestionnaire de Leads"
                    isActive={activePage === 'leads'}
                    onClick={() => setActivePage('leads')}
                  />
                  {userRole === 'Admin' && (
                    <>
                      <SidebarLink 
                        icon={ShoppingBag} 
                        text="Liste des produits"
                        isActive={activePage === 'products'}
                        onClick={() => setActivePage('products')}
                      />
                      <SidebarLink 
                        icon={Zap} 
                        text="Énergie"
                        isActive={activePage === 'offers'}
                        onClick={() => setActivePage('offers')}
                      />
                      <SidebarLink 
                        icon={Share2} 
                        text="Générateur d'Offres"
                        isActive={activePage === 'offer-generator'}
                        onClick={() => setActivePage('offer-generator')}
                      />
                      <div className="relative">
                        <SidebarLink 
                          icon={Package} 
                          text="Stock Énergie"
                          isActive={activePage === 'stock'}
                          onClick={() => setActivePage('stock')}
                        />
                        {activeStocksCount > 0 && (
                          <span className="absolute top-1/2 -right-2 transform -translate-y-1/2 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white bg-blue-600 rounded-full">
                            {activeStocksCount}
                          </span>
                        )}
                      </div>
                      <SidebarLink 
                        icon={Activity} 
                        text="Gestion des Statuts"
                        isActive={activePage === 'status'}
                        onClick={() => setActivePage('status')}
                      />
                      <SidebarLink 
                        icon={Gift} 
                        text="Actions"
                        isActive={activePage === 'actions'}
                        onClick={() => setActivePage('actions')}
                      />
                      <SidebarLink 
                        icon={LineChart} 
                        text="Actions souscrites"
                        isActive={activePage === 'subscribed-actions'}
                        onClick={() => setActivePage('subscribed-actions')}
                      />
                      <SidebarLink 
                        icon={BookOpen} 
                        text="Gestionnaire de Livret"
                        isActive={activePage === 'livret'}
                        onClick={() => setActivePage('livret')}
                      />
                      <SidebarLink 
                        icon={Building2} 
                        text="Références Bancaires"
                        isActive={activePage === 'bank-references'}
                        onClick={() => setActivePage('bank-references')}
                      />
                      <SidebarLink 
                        icon={Wallet} 
                        text="Transactions"
                        isActive={activePage === 'transactions'}
                        onClick={() => setActivePage('transactions')}
                      />
                      <SidebarLink 
                        icon={MessageSquare} 
                        text="Chat Admin"
                        isActive={activePage === 'chat-admin'}
                        onClick={() => setActivePage('chat-admin')}
                      />
                      <SidebarLink 
                        icon={Home} 
                        text="Image page d'accueil"
                        isActive={activePage === 'homepage'}
                        onClick={() => setActivePage('homepage')}
                      />
                      <SidebarLink 
                        icon={Paintbrush} 
                        text="Édition plateforme"
                        isActive={activePage === 'platform-editor'}
                        onClick={() => setActivePage('platform-editor')}
                      />
                    </>
                  )}
                  <SidebarLink 
                    icon={Settings} 
                    text="Paramètres"
                    isActive={activePage === 'settings'}
                    onClick={() => setActivePage('settings')}
                  />
                </div>
              </nav>

              {/* Logout Button */}
              <div className="p-4 border-t border-gray-700" style={{ borderColor: 'var(--color-dividers, #374151)' }}>
                <SidebarLink 
                  icon={LogOut} 
                  text="Déconnexion"
                  onClick={handleLogout}
                  variant="danger"
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Mobile sidebar overlay */}
        {isSidebarOpen && isMobile && (
          <div 
            className="fixed inset-0 bg-black bg-opacity-50 z-30"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}

        {/* Main Content */}
        <div className="flex-1 flex flex-col min-w-0">
          {/* Header - Hidden on mobile */}
          <header className="hidden md:block border-b border-gray-700" style={{ 
            backgroundColor: 'var(--color-header, #1e293b)',
            borderColor: 'var(--color-dividers, #374151)'
          }}>
            <div className="h-16 px-6 flex items-center justify-between">
              <h1 className="text-2xl font-bold text-white">
                {getPageTitle(activePage)}
              </h1>
            </div>
          </header>

          {/* Main Content Area */}
          <main className="flex-1 overflow-auto p-4 md:p-8" style={{ backgroundColor: 'var(--color-main-content, #111827)' }}>
            {renderContent()}
          </main>
          
          {/* Footer */}
          <Footer />
        </div>
      </div>
    </div>
  );
}