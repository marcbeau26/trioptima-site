import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { 
  BookOpen, Percent, Clock, Euro, Calendar, Building2, Info, Hash, AlertCircle
} from 'lucide-react';
import type { Livret } from '../../../../types';
import { generateId, generateReference } from '../../../../utils';
import { useLocalStorage } from '../../../../hooks/useLocalStorage';
import { toast } from 'react-hot-toast';
import { cn } from '../../../../utils/cn';

// Sample livrets data
const sampleLivrets: Livret[] = [];

export function AvailableLivrets() {
  const [livrets, setLivrets] = useLocalStorage<Livret[]>('livrets', sampleLivrets);
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [selectedLivret, setSelectedLivret] = useState<Livret | null>(null);
  const [currentLead, setCurrentLead] = useState<Lead | null>(null);
  const [investmentAmounts, setInvestmentAmounts] = useState<Record<string, number>>({});
  const [formattedAmounts, setFormattedAmounts] = useState<Record<string, string>>({});

  // Load current lead
  useEffect(() => {
    const leadData = localStorage.getItem('currentLead');
    if (leadData) {
      setCurrentLead(JSON.parse(leadData));
    }
  }, []);

  // Initialize investment amounts with default values
  useEffect(() => {
    if (livrets.length > 0) {
      const initialAmounts: Record<string, number> = {};
      const initialFormattedAmounts: Record<string, string> = {};
      
      livrets.forEach(livret => {
        const defaultAmount = livret.minCapital || livret.initialCapital;
        initialAmounts[livret.id] = defaultAmount;
        initialFormattedAmounts[livret.id] = defaultAmount.toLocaleString();
      });
      
      setInvestmentAmounts(initialAmounts);
      setFormattedAmounts(initialFormattedAmounts);
    }
  }, [livrets]);

  // Filter only active livrets
  const activeLivrets = livrets.filter(livret => livret.status === 'Active');

  const handleSubscribe = (livretId: string, amount: number) => {
    if (!currentLead) return;

    const livret = livrets.find(l => l.id === livretId);
    if (!livret) return;

    // Check if user has enough balance
    if (currentLead.balance < amount) {
      toast.error('Solde insuffisant');
      return;
    }
    
    // Check if amount is within min/max capital limits
    if (amount < (livret.minCapital || 0) || amount > (livret.maxCapital || Infinity)) {
      toast.error(`Le montant doit être compris entre ${(livret.minCapital || 0).toLocaleString()}€ et ${(livret.maxCapital || 0).toLocaleString()}€`);
      return;
    }

    // Create subscription
    const subscription: LivretSubscription = {
      id: generateId(),
      livretId,
      livretName: livret.name,
      amount,
      interestRate: livret.interestRate,
      duration: { ...livret.duration },
      subscriptionDate: new Date().toISOString(),
      maturityDate: calculateMaturityDate(livret.duration),
      status: 'Active',
      reference: generateReference(5),
      logoUrl: livret.logoUrl
    };

    // Create transaction
    const transaction = {
      id: generateId(),
      amount: -amount,
      type: 'investment' as const,
      description: `Souscription au livret ${livret.name} (Réf: ${subscription.reference})`,
      dateCreated: new Date().toISOString()
    };

    // Update lead
    const updatedLead = {
      ...currentLead,
      balance: currentLead.balance - amount,
      livretSubscriptions: [...(currentLead.livretSubscriptions || []), subscription],
      transactions: [...(currentLead.transactions || []), transaction]
    };

    // Update leads array
    const updatedLeads = leads.map(lead => 
      lead.id === currentLead.id ? updatedLead : lead
    );
    setLeads(updatedLeads);

    // Update current lead in localStorage
    localStorage.setItem('currentLead', JSON.stringify(updatedLead));
    setCurrentLead(updatedLead);

    // Close modal and show success message
    setSelectedLivret(null);
    toast.success('Souscription au livret effectuée avec succès');
  };

  // Calculate maturity date based on duration
  const calculateMaturityDate = (duration: { value: number; unit: 'months' | 'years' }): string => {
    const now = new Date();
    const maturityDate = new Date(now);
    
    if (duration.unit === 'months') {
      maturityDate.setMonth(maturityDate.getMonth() + duration.value);
    } else {
      maturityDate.setFullYear(maturityDate.getFullYear() + duration.value);
    }
    
    return maturityDate.toISOString();
  };

  // Calculate expected benefit for a livret
  const calculateBenefit = (livret: Livret, amount: number): { total: number; monthly: number; annual: number } => {
    // Convert duration to years for calculation
    let durationInYears = livret.duration.value;
    if (livret.duration.unit === 'months') {
      durationInYears = livret.duration.value / 12;
    }
    
    // Simple interest calculation: P * r * t
    const totalBenefit = amount * (livret.interestRate / 100) * durationInYears;
    
    // Calculate monthly benefit
    const monthlyBenefit = totalBenefit / (livret.duration.unit === 'months' ? livret.duration.value : livret.duration.value * 12);
    
    // Calculate annual benefit
    const annualBenefit = amount * (livret.interestRate / 100);
    
    return { 
      total: totalBenefit,
      monthly: monthlyBenefit,
      annual: annualBenefit
    };
  };

  // Handle investment amount change
  const handleAmountChange = (livretId: string, value: string) => {
    // Remove non-numeric characters and parse as number
    const numericValue = value.replace(/[^\d]/g, '');
    const amount = parseInt(numericValue, 10) || 0;
    
    // Update both the numeric and formatted values
    setInvestmentAmounts({
      ...investmentAmounts,
      [livretId]: amount
    });
    
    setFormattedAmounts({
      ...formattedAmounts,
      [livretId]: amount.toLocaleString()
    });
  };

  return (
    <div className="min-h-[400px] flex items-center justify-center">
      <div className="text-center space-y-4">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-800/50 backdrop-blur-xl mb-4">
          <BookOpen className="w-8 h-8 text-gray-400" />
        </div>
        <h3 className="text-xl font-medium text-gray-300">
          Aucun livret disponible
        </h3>
        <p className="text-gray-500 max-w-sm">
          Il n'y a actuellement aucun livret disponible. Veuillez revenir plus tard.
        </p>
      </div>
    </div>
  );
}