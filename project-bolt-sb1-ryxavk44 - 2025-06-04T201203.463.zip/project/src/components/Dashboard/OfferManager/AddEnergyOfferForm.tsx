import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Clock, Zap, DollarSign, Building2, AlertCircle } from 'lucide-react';
import type { EnergyOffer } from '../../../types';
import { generateId, generateReference } from '../../../utils';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';

type EnergyOfferFormData = Omit<EnergyOffer, 'id' | 'dateCreated' | 'expiryDate' | 'status' | 'reference'>;

const initialFormData: EnergyOfferFormData = {
  companyName: '',
  megawatts: 0,
  saleDate: new Date().toISOString().split('T')[0],
  pricePerMegawatt: 0,
  totalPrice: 0,
  validityDays: 0,
  validityHours: 0,
  validityMinutes: 0,
  priceVariation: 0
};

export function AddEnergyOfferForm() {
  const [energyOffers, setEnergyOffers] = useLocalStorage<EnergyOffer[]>('energyOffers', []);
  const [formData, setFormData] = useState<EnergyOfferFormData>(initialFormData);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [focusedField, setFocusedField] = useState<string | null>(null);

  const calculateExpiryDate = (days: number, hours: number, minutes: number) => {
    const now = new Date();
    const expiryDate = new Date(now);
    expiryDate.setDate(expiryDate.getDate() + days);
    expiryDate.setHours(expiryDate.getHours() + hours);
    expiryDate.setMinutes(expiryDate.getMinutes() + minutes);
    return expiryDate.toISOString();
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.companyName.trim()) {
      newErrors.companyName = "Le nom de l'entreprise est requis";
    }
    if (formData.megawatts <= 0) {
      newErrors.megawatts = 'La quantité doit être supérieure à 0';
    }
    if (formData.pricePerMegawatt <= 0) {
      newErrors.pricePerMegawatt = 'Le prix par mégawatt doit être supérieur à 0';
    }
    if (formData.validityDays === 0 && formData.validityHours === 0 && formData.validityMinutes === 0) {
      newErrors.validity = 'La durée de validité doit être supérieure à 0';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    const expiryDate = calculateExpiryDate(
      formData.validityDays,
      formData.validityHours,
      formData.validityMinutes
    );

    // Generate a unique 5-character alphanumeric reference
    const reference = generateReference(5);

    // Important: Set all validity fields to 0 to mark this as a manually created offer
    // This ensures it will appear in "Offre marché ad" and not in "Offres générées en quantité"
    const newOffer: EnergyOffer = {
      ...formData,
      id: generateId(),
      dateCreated: new Date().toISOString(),
      expiryDate,
      status: 'Active',
      reference,
      validityDays: 0,
      validityHours: 0,
      validityMinutes: 0
    };

    setEnergyOffers([...energyOffers, newOffer]);
    setFormData(initialFormData);
    toast.success(`Offre créée avec succès. Référence: ${reference}`);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative max-w-4xl mx-auto"
    >
      {/* Background effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl" />
      <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl" />
      
      {/* Content */}
      <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-8">
          Créer une offre d'énergie
        </h2>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Company Info */}
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Nom de l'entreprise
              </label>
              <input
                type="text"
                value={formData.companyName}
                onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                onFocus={() => setFocusedField('companyName')}
                onBlur={() => setFocusedField(null)}
                className={cn(
                  "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                  "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                  "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                  errors.companyName && "border-red-500/50 focus:ring-red-500/50",
                  focusedField === 'companyName' && "shadow-[0_0_15px_rgba(59,130,246,0.5)]"
                )}
                placeholder="Ex: Entreprise Énergie SA"
              />
              {errors.companyName && (
                <p className="mt-2 text-sm text-red-400">{errors.companyName}</p>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                  <Zap className="w-4 h-4 mr-2 text-blue-400" />
                  Quantité (MW)
                </label>
                <input
                  type="number"
                  value={formData.megawatts || ''}
                  onChange={(e) => {
                    const megawatts = parseFloat(e.target.value) || 0;
                    setFormData({
                      ...formData,
                      megawatts,
                      totalPrice: megawatts * formData.pricePerMegawatt
                    });
                  }}
                  onFocus={() => setFocusedField('megawatts')}
                  onBlur={() => setFocusedField(null)}
                  className={cn(
                    "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                    "focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50",
                    "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                    errors.megawatts && "border-red-500/50 focus:ring-red-500/50",
                    focusedField === 'megawatts' && "shadow-[0_0_15px_rgba(147,51,234,0.5)]"
                  )}
                  min="0"
                  step="0.1"
                />
                {errors.megawatts && (
                  <p className="mt-2 text-sm text-red-400">{errors.megawatts}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                  <DollarSign className="w-4 h-4 mr-2 text-green-400" />
                  Prix par MW (€)
                </label>
                <input
                  type="number"
                  value={formData.pricePerMegawatt || ''}
                  onChange={(e) => {
                    const pricePerMegawatt = parseFloat(e.target.value) || 0;
                    setFormData({
                      ...formData,
                      pricePerMegawatt,
                      totalPrice: formData.megawatts * pricePerMegawatt
                    });
                  }}
                  onFocus={() => setFocusedField('pricePerMegawatt')}
                  onBlur={() => setFocusedField(null)}
                  className={cn(
                    "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                    "focus:outline-none focus:ring-2 focus:ring-green-500/50 focus:border-green-500/50",
                    "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                    errors.pricePerMegawatt && "border-red-500/50 focus:ring-red-500/50",
                    focusedField === 'pricePerMegawatt' && "shadow-[0_0_15px_rgba(34,197,94,0.5)]"
                  )}
                  min="0"
                  step="0.01"
                />
                {errors.pricePerMegawatt && (
                  <p className="mt-2 text-sm text-red-400">{errors.pricePerMegawatt}</p>
                )}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2 flex items-center">
                <Building2 className="w-4 h-4 mr-2 text-cyan-400" />
                Prix total (€)
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={formData.totalPrice || ''}
                  readOnly
                  className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3 opacity-75"
                />
                <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none">
                  <AlertCircle className="w-4 h-4 text-gray-400" />
                </div>
              </div>
              <p className="mt-1 text-sm text-gray-500">
                Calculé automatiquement: Prix par MW × Quantité
              </p>
            </div>
          </div>

          {/* Validity Period */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-white flex items-center">
              <Clock className="w-5 h-5 mr-2 text-purple-400" />
              Durée de validité
            </h3>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Jours
                </label>
                <input
                  type="number"
                  value={formData.validityDays || ''}
                  onChange={(e) => setFormData({ ...formData, validityDays: parseInt(e.target.value) || 0 })}
                  onFocus={() => setFocusedField('validityDays')}
                  onBlur={() => setFocusedField(null)}
                  className={cn(
                    "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                    "focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50",
                    "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                    focusedField === 'validityDays' && "shadow-[0_0_15px_rgba(147,51,234,0.5)]"
                  )}
                  min="0"
                  max="365"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Heures
                </label>
                <input
                  type="number"
                  value={formData.validityHours || ''}
                  onChange={(e) => setFormData({ ...formData, validityHours: parseInt(e.target.value) || 0 })}
                  onFocus={() => setFocusedField('validityHours')}
                  onBlur={() => setFocusedField(null)}
                  className={cn(
                    "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                    "focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50",
                    "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                    focusedField === 'validityHours' && "shadow-[0_0_15px_rgba(147,51,234,0.5)]"
                  )}
                  min="0"
                  max="23"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Minutes
                </label>
                <input
                  type="number"
                  value={formData.validityMinutes || ''}
                  onChange={(e) => setFormData({ ...formData, validityMinutes: parseInt(e.target.value) || 0 })}
                  onFocus={() => setFocusedField('validityMinutes')}
                  onBlur={() => setFocusedField(null)}
                  className={cn(
                    "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                    "focus:outline-none focus:ring-2 focus:ring-purple-500/50 focus:border-purple-500/50",
                    "placeholder-gray-500 backdrop-blur-sm transition-all duration-200",
                    focusedField === 'validityMinutes' && "shadow-[0_0_15px_rgba(147,51,234,0.5)]"
                  )}
                  min="0"
                  max="59"
                />
              </div>
            </div>
            {errors.validity && (
              <p className="mt-2 text-sm text-red-400">{errors.validity}</p>
            )}
          </div>

          {/* Submit Button */}
          <div className="flex justify-end">
            <motion.button
              type="submit"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="relative group px-8 py-3 rounded-lg overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
              <span className="relative text-white font-medium">
                Créer l'offre
              </span>
            </motion.button>
          </div>
        </form>
      </div>
    </motion.div>
  );
}