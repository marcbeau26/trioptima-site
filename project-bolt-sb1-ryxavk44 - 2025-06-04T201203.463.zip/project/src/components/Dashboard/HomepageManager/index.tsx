import { HomepageInterface } from '../PlatformEditor/HomepageInterface';

// Exporter le composant HomepageInterface sous le nom HomepageManager pour la compatibilité
export { HomepageInterface as HomepageManager };