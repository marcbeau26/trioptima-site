import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Calendar, DollarSign, Percent, Clock, Hash } from 'lucide-react';
import type { Lead, Transaction } from '../../../../types';
import { useLocalStorage } from '../../../../hooks/useLocalStorage';
import { formatDate } from '../../../../utils';

export function History() {
  const [currentLead] = useLocalStorage<Lead>('currentLead', null);
  
  // Filter transactions related to livrets
  const livretTransactions = currentLead?.transactions?.filter(
    transaction => transaction.description.includes('livret') || transaction.description.includes('Livret')
  ) || [];

  if (livretTransactions.length === 0) {
    return (
      <div className="min-h-[400px] flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-800/50 backdrop-blur-xl mb-4">
            <BookOpen className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-xl font-medium text-gray-300">
            Aucun historique de livret
          </h3>
          <p className="text-gray-500 max-w-sm">
            Vous n'avez pas encore effectué de transactions liées aux livrets.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {livretTransactions.map((transaction, index) => (
        <motion.div
          key={transaction.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className="relative group"
        >
          <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
          <div className="relative bg-gray-800/50 rounded-lg p-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              {/* Left side - Transaction info */}
              <div className="flex items-start space-x-4">
                {/* Icon */}
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-white" />
                </div>
                
                {/* Transaction details */}
                <div className="flex-1">
                  <div className="flex flex-col md:flex-row md:items-center gap-2">
                    <span className="text-base font-medium text-white">
                      {transaction.type === 'investment' ? 'Souscription' : 'Retrait'}
                    </span>
                    
                    {/* Extract reference if available */}
                    {transaction.description.includes('Réf:') && (
                      <div className="inline-flex items-center bg-blue-500/20 px-2 py-0.5 rounded-md border border-blue-500/30">
                        <Hash className="h-3 w-3 text-blue-400 mr-1" />
                        <span className="text-xs font-mono text-blue-300">
                          {transaction.description.match(/Réf: ([A-Z0-9]+)/)?.[1]}
                        </span>
                      </div>
                    )}
                  </div>
                  
                  <p className="text-white mt-1">{transaction.description}</p>
                  
                  <div className="text-xs text-gray-400 mt-1 flex items-center">
                    <Calendar className="w-3 h-3 mr-1" />
                    {formatDate(transaction.dateCreated)}
                  </div>
                </div>
              </div>
              
              {/* Right side - Amount */}
              <div className="flex flex-col items-end space-y-1">
                <div className={`flex items-center font-medium text-lg ${
                  transaction.amount >= 0 ? 'text-green-400' : 'text-red-400'
                }`}>
                  <DollarSign className="w-4 h-4 mr-1" />
                  <span>
                    {transaction.amount >= 0 ? '+' : ''}
                    {Math.abs(transaction.amount).toLocaleString()}€
                  </span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}