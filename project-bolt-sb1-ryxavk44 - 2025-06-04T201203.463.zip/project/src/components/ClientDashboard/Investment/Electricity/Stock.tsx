import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Package, TrendingUp, TrendingDown, Clock, Hash, Zap, Shield, DollarSign } from 'lucide-react';
import type { EnergyHolding, Lead, Transaction } from '../../../../types';
import { useLocalStorage } from '../../../../hooks/useLocalStorage';
import { formatDate } from '../../../../utils';
import { FuturisticTimer } from '../../../common/FuturisticTimer';
import { toast } from 'react-hot-toast';
import { cn } from '../../../../utils/cn';

interface SellModalProps {
  holding: EnergyHolding;
  isOpen: boolean;
  onClose: () => void;
  onSell: (holdingId: string, megawatts: number) => void;
}

function SellModal({ holding, isOpen, onClose, onSell }: SellModalProps) {
  const [megawatts, setMegawatts] = useState(holding.megawatts);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  // Calculate current price and profit
  const currentPrice = holding.pricePerMegawatt * (1 + holding.priceVariation / 100);
  const totalSalePrice = currentPrice * megawatts;
  const originalTotalPrice = holding.pricePerMegawatt * megawatts;
  const profit = totalSalePrice - originalTotalPrice;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (megawatts <= 0 || megawatts > holding.megawatts) {
      setError('Quantité invalide');
      return;
    }
    onSell(holding.id, megawatts);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-md mx-4"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8 energy-offer-text">
          <h3 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-6">
            Revendre de l'énergie
          </h3>
          
          {/* Reference display */}
          {holding.reference && (
            <div className="mb-6 flex justify-center">
              <div className="reference-tag py-3 px-5 rounded-lg">
                <div className="flex items-center justify-center">
                  <Hash className="h-6 w-6 text-blue-400 mr-2" />
                  <span className="text-xl font-mono font-bold text-blue-300 tracking-widest">
                    RÉF: {holding.reference}
                  </span>
                </div>
              </div>
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Quantité à vendre (MW)
                </label>
                <div className="relative">
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg blur opacity-75 group-hover:opacity-100 transition duration-1000"></div>
                  <input
                    type="number"
                    value={megawatts}
                    onChange={(e) => {
                      setMegawatts(Number(e.target.value));
                      setError('');
                    }}
                    min={0}
                    max={holding.megawatts}
                    step={0.1}
                    className="relative w-full bg-gray-800/80 text-white border border-white/10 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  />
                </div>
                {error && (
                  <p className="mt-2 text-sm text-red-400">{error}</p>
                )}
              </div>

              {/* Price Info with Glowing Effects */}
              <div className="bg-gradient-to-r from-blue-500/5 to-purple-500/5 rounded-xl p-4 border border-white/5">
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Prix d'achat initial:</span>
                    <span className="text-white font-medium">{originalTotalPrice.toLocaleString()}€</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Prix de vente actuel:</span>
                    <span className="text-white font-medium">{totalSalePrice.toLocaleString()}€</span>
                  </div>
                  <div className="flex justify-between text-sm font-medium pt-2 border-t border-white/10">
                    <span className="text-gray-300">Profit net:</span>
                    <span className={profit >= 0 ? "text-green-400" : "text-red-400"}>
                      {profit >= 0 ? '+' : ''}{profit.toLocaleString()}€
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex space-x-4">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-6 py-3 text-sm font-medium text-gray-300 bg-gray-800/50 hover:bg-gray-700/50 rounded-lg transition-colors"
              >
                Annuler
              </button>
              <motion.button
                type="submit"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex-1 relative group overflow-hidden rounded-lg"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity"></div>
                <span className="relative text-white font-medium py-3">
                  Confirmer la vente
                </span>
              </motion.button>
            </div>
          </form>
        </div>
      </motion.div>
    </div>
  );
}

export function Stock() {
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [stocks] = useLocalStorage<EnergyHolding[]>('stocks', []);
  const currentLeadStr = localStorage.getItem('currentLead');
  const currentLead = currentLeadStr ? JSON.parse(currentLeadStr) as Lead : null;
  const [selectedHolding, setSelectedHolding] = useState<EnergyHolding | null>(null);

  // Check for expired holdings and transfer them to history
  useEffect(() => {
    if (!currentLead || !currentLead.energyHoldings) return;

    const now = new Date().getTime();
    const expiredHoldings = currentLead.energyHoldings.filter(
      holding => new Date(holding.expiryDate).getTime() <= now
    );

    if (expiredHoldings.length > 0) {
      // Create transactions for expired holdings
      const expiredTransactions = expiredHoldings.map(holding => {
        const currentPrice = holding.pricePerMegawatt * (1 + holding.priceVariation / 100);
        const salePrice = currentPrice * holding.megawatts;
        const originalPrice = holding.totalPrice;
        const profit = salePrice - originalPrice;

        return {
          id: Math.random().toString(36).substr(2, 9),
          amount: salePrice,
          type: 'sale' as const,
          description: `Vente automatique (expiration) de ${holding.megawatts} MW d'énergie de ${holding.companyName} (Achat: ${originalPrice.toLocaleString()}€)${holding.reference ? ` - Réf: ${holding.reference}` : ''}`,
          dateCreated: new Date().toISOString()
        };
      });

      // Calculate total sale price from all expired holdings
      const totalSalePrice = expiredHoldings.reduce((sum, holding) => {
        const currentPrice = holding.pricePerMegawatt * (1 + holding.priceVariation / 100);
        return sum + (currentPrice * holding.megawatts);
      }, 0);

      // Update lead with new balance, transactions, and remove expired holdings
      const updatedLeads = leads.map(lead => {
        if (lead.id === currentLead.id) {
          return {
            ...lead,
            balance: (lead.balance || 0) + totalSalePrice,
            energyHoldings: lead.energyHoldings?.filter(
              holding => new Date(holding.expiryDate).getTime() > now
            ),
            transactions: [...(lead.transactions || []), ...expiredTransactions]
          };
        }
        return lead;
      });

      setLeads(updatedLeads);
      
      // Update current lead in localStorage
      const updatedLead = updatedLeads.find(l => l.id === currentLead.id);
      if (updatedLead) {
        localStorage.setItem('currentLead', JSON.stringify(updatedLead));
        
        // Show toast notification for each expired holding
        if (expiredHoldings.length === 1) {
          toast.success(`Un stock d'énergie a expiré et a été vendu automatiquement`);
        } else {
          toast.success(`${expiredHoldings.length} stocks d'énergie ont expiré et ont été vendus automatiquement`);
        }
      }
    }
  }, [currentLead, leads, setLeads]);

  const handleSell = (holdingId: string, megawatts: number) => {
    if (!currentLead) return;

    const holding = currentLead.energyHoldings?.find(h => h.id === holdingId);
    if (!holding) return;

    const currentPrice = holding.pricePerMegawatt * (1 + holding.priceVariation / 100);
    const salePrice = currentPrice * megawatts;
    const originalPrice = holding.pricePerMegawatt * megawatts;

    // Create transaction with original purchase price in description
    const transaction: Transaction = {
      id: Math.random().toString(36).substr(2, 9),
      amount: salePrice,
      type: 'sale',
      description: `Vente de ${megawatts} MW d'énergie de ${holding.companyName} (Achat: ${originalPrice.toLocaleString()}€)${holding.reference ? ` - Réf: ${holding.reference}` : ''}`,
      dateCreated: new Date().toISOString()
    };

    const updatedHoldings = currentLead.energyHoldings?.map(h => {
      if (h.id === holdingId) {
        if (h.megawatts === megawatts) {
          return undefined; // Remove the holding completely
        }
        return {
          ...h,
          megawatts: h.megawatts - megawatts,
          totalPrice: (h.megawatts - megawatts) * h.pricePerMegawatt
        };
      }
      return h;
    }).filter(Boolean) as EnergyHolding[];

    const updatedLead = {
      ...currentLead,
      balance: (currentLead.balance || 0) + salePrice,
      energyHoldings: updatedHoldings,
      transactions: [...(currentLead.transactions || []), transaction]
    };

    localStorage.setItem('currentLead', JSON.stringify(updatedLead));
    
    const updatedLeads = leads.map(lead => 
      lead.id === currentLead.id ? updatedLead : lead
    );
    localStorage.setItem('leads', JSON.stringify(updatedLeads));

    // Force a refresh to update the UI
    window.location.reload();
  };

  if (!currentLead || !currentLead.energyHoldings || currentLead.energyHoldings.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500 dark:text-gray-400 energy-offer-text">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-800/50 backdrop-blur-xl mb-4">
          <Package className="w-8 h-8 text-gray-400" />
        </div>
        <h3 className="text-xl font-medium text-gray-300">
          Aucun stock disponible
        </h3>
        <p className="text-gray-500 max-w-sm mx-auto">
          Vous n'avez pas encore d'énergie en stock. Consultez le marché pour investir.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 energy-offer-text">
      <div className="grid grid-cols-1 gap-6">
        {currentLead.energyHoldings.map((holding) => (
          <motion.div
            key={holding.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="relative group"
          >
            {/* Animated background glow */}
            <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-500/30 via-blue-500/30 to-purple-500/30 rounded-xl opacity-0 group-hover:opacity-100 blur-xl transition duration-1000 animate-pulse"></div>
            
            {/* Neon border */}
            <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500 rounded-xl opacity-75 group-hover:opacity-100 blur transition duration-1000"></div>
            
            {/* Glass card */}
            <div className="relative bg-black/40 backdrop-blur-xl border border-white/10 rounded-xl p-6">
              {/* Header with glowing effect */}
              <div className="relative mb-6">
                <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500 rounded-lg opacity-75 blur"></div>
                <div className="relative bg-black/60 backdrop-blur-xl border border-white/10 rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
                        {holding.companyName}
                      </h3>
                      <div className="flex items-center text-sm text-gray-400 mt-1">
                        <Clock className="w-4 h-4 mr-1" />
                        <span>Acheté le {formatDate(holding.purchaseDate)}</span>
                      </div>
                    </div>
                    <div className={cn(
                      "flex items-center px-3 py-1.5 rounded-full backdrop-blur-md",
                      holding.priceVariation >= 0 
                        ? "text-emerald-400 bg-emerald-500/10 border border-emerald-500/20"
                        : "text-red-400 bg-red-500/10 border border-red-500/20"
                    )}>
                      {holding.priceVariation >= 0 ? (
                        <TrendingUp className="h-4 w-4 mr-1" />
                      ) : (
                        <TrendingDown className="h-4 w-4 mr-1" />
                      )}
                      <span className="font-medium">
                        {holding.priceVariation >= 0 ? '+' : ''}{holding.priceVariation}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Reference display with futuristic styling */}
              {holding.reference && (
                <div className="mb-6 flex justify-center">
                  <div className="reference-tag py-3 px-5 rounded-lg">
                    <div className="flex items-center justify-center">
                      <Hash className="h-6 w-6 text-blue-400 mr-2" />
                      <span className="text-xl font-mono font-bold text-blue-300 tracking-widest">
                        RÉF: {holding.reference}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Main info sections with glowing icons */}
              <div className="grid grid-cols-2 gap-6 mb-6">
                {/* Quantity info with glowing icon */}
                <div className="bg-gradient-to-r from-blue-500/5 to-purple-500/5 rounded-xl p-4 border border-white/5">
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <div className="absolute -inset-1 bg-blue-500/30 rounded-lg blur"></div>
                      <div className="relative w-12 h-12 flex items-center justify-center bg-blue-500/10 rounded-lg border border-blue-500/20">
                        <Zap className="w-6 h-6 text-blue-400" />
                      </div>
                    </div>
                    <div>
                      <p className="text-sm text-gray-400">Quantité détenue</p>
                      <p className="text-xl font-bold text-white">{holding.megawatts} MW</p>
                    </div>
                  </div>
                </div>

                {/* Price info with glowing icon */}
                <div className="bg-gradient-to-r from-emerald-500/5 to-cyan-500/5 rounded-xl p-4 border border-white/5">
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <div className="absolute -inset-1 bg-emerald-500/30 rounded-lg blur"></div>
                      <div className="relative w-12 h-12 flex items-center justify-center bg-emerald-500/10 rounded-lg border border-emerald-500/20">
                        <DollarSign className="w-6 h-6 text-emerald-400" />
                      </div>
                    </div>
                    <div>
                      <p className="text-sm text-gray-400">Prix d'achat/MW</p>
                      <p className="text-xl font-bold text-white">{holding.pricePerMegawatt.toLocaleString()}€</p>
                    </div>
                  </div>
                </div>

                {/* Total price info with glowing icon */}
                <div className="bg-gradient-to-r from-purple-500/5 to-pink-500/5 rounded-xl p-4 border border-white/5">
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <div className="absolute -inset-1 bg-purple-500/30 rounded-lg blur"></div>
                      <div className="relative w-12 h-12 flex items-center justify-center bg-purple-500/10 rounded-lg border border-purple-500/20">
                        <Shield className="w-6 h-6 text-purple-400" />
                      </div>
                    </div>
                    <div>
                      <p className="text-sm text-gray-400">Prix total d'achat</p>
                      <p className="text-xl font-bold text-white">{holding.totalPrice.toLocaleString()}€</p>
                    </div>
                  </div>
                </div>

                {/* Current value info with glowing icon */}
                <div className="bg-gradient-to-r from-cyan-500/5 to-blue-500/5 rounded-xl p-4 border border-white/5">
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <div className="absolute -inset-1 bg-cyan-500/30 rounded-lg blur"></div>
                      <div className="relative w-12 h-12 flex items-center justify-center bg-cyan-500/10 rounded-lg border border-cyan-500/20">
                        <TrendingUp className="w-6 h-6 text-cyan-400" />
                      </div>
                    </div>
                    <div>
                      <p className="text-sm text-gray-400">Valeur actuelle</p>
                      <p className="text-xl font-bold text-white">
                        {(holding.totalPrice * (1 + holding.priceVariation / 100)).toLocaleString()}€
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Clock className="h-5 w-5 text-blue-400" />
                  <span className="text-sm text-blue-300">
                    <FuturisticTimer expiryDate={holding.expiryDate} />
                  </span>
                </div>
                <motion.button
                  onClick={() => setSelectedHolding(holding)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="relative group overflow-hidden px-6 py-3 rounded-lg"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity"></div>
                  <span className="relative text-white font-medium">
                    Revendre
                  </span>
                </motion.button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
        {selectedHolding && (
          <SellModal
            holding={selectedHolding}
            isOpen={true}
            onClose={() => setSelectedHolding(null)}
            onSell={handleSell}
          />
        )}
      </AnimatePresence>
    </div>
  );
}