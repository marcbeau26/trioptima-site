import React, { useState } from 'react';
import { Plus, List, Zap } from 'lucide-react';
import { AddActionForm } from './AddActionForm';
import { ActionsList } from './ActionsList';
import { ActiveActionsList } from './ActiveActionsList';
import type { TabType } from '../../../types';

export function ActionsManager() {
  const [activeTab, setActiveTab] = useState<TabType>('list');

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
      <div className="border-b border-gray-200 dark:border-gray-700">
        <nav className="flex space-x-8 px-6" aria-label="Tabs">
          <button
            onClick={() => setActiveTab('add')}
            className={`py-4 px-1 inline-flex items-center space-x-2 border-b-2 font-medium text-sm ${
              activeTab === 'add'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            <Plus size={20} />
            <span>Créer une offre d'action</span>
          </button>
          <button
            onClick={() => setActiveTab('active')}
            className={`py-4 px-1 inline-flex items-center space-x-2 border-b-2 font-medium text-sm ${
              activeTab === 'active'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            <Zap size={20} />
            <span>Actions actives</span>
          </button>
          <button
            onClick={() => setActiveTab('list')}
            className={`py-4 px-1 inline-flex items-center space-x-2 border-b-2 font-medium text-sm ${
              activeTab === 'list'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            <List size={20} />
            <span>Toutes les actions</span>
          </button>
        </nav>
      </div>

      <div className="p-6">
        {activeTab === 'add' && <AddActionForm />}
        {activeTab === 'active' && <ActiveActionsList />}
        {activeTab === 'list' && <ActionsList />}
      </div>
    </div>
  );
}