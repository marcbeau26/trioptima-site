import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Percent, Clock, Euro, Calendar, Hash, TrendingUp, ChevronDown, ChevronUp, Table } from 'lucide-react';
import type { Lead, LivretSubscription } from '../../../../types';
import { useLocalStorage } from '../../../../hooks/useLocalStorage';
import { formatDate } from '../../../../utils';
import { cn } from '../../../../utils/cn';

// Profitability table entry
interface ProfitabilityEntry {
  month: number;
  startingCapital: number;
  interest: number;
  endingCapital: number;
  date: Date;
}

// Composant pour afficher les bénéfices en temps réel
interface RealTimeBenefitsProps {
  monthlyBenefit: number;
  totalBenefit: number;
  startDate: string;
  endDate: string;
}

const RealTimeBenefits: React.FC<RealTimeBenefitsProps> = ({ 
  monthlyBenefit, 
  totalBenefit, 
  startDate, 
  endDate 
}) => {
  const [currentBenefit, setCurrentBenefit] = useState(0);
  const [lastUpdateTime, setLastUpdateTime] = useState(Date.now());
  const intervalRef = useRef<number | null>(null);
  
  useEffect(() => {
    // Calculer le bénéfice par seconde
    const startTime = new Date(startDate).getTime();
    const endTime = new Date(endDate).getTime();
    const totalDuration = endTime - startTime;
    const elapsedTime = Math.min(Date.now() - startTime, totalDuration);
    
    // Calculer le pourcentage de temps écoulé
    const progressPercentage = elapsedTime / totalDuration;
    
    // Calculer le bénéfice accumulé jusqu'à présent
    const accumulatedBenefit = totalBenefit * progressPercentage;
    
    // Calculer le bénéfice par seconde
    const benefitPerSecond = totalBenefit / (totalDuration / 1000);
    
    // Initialiser avec le bénéfice accumulé
    setCurrentBenefit(accumulatedBenefit);
    
    // Mettre à jour le bénéfice toutes les 5 secondes
    const updateBenefit = () => {
      const now = Date.now();
      const elapsedSeconds = (now - lastUpdateTime) / 1000;
      
      setCurrentBenefit(prev => {
        // Calculer le nouveau bénéfice basé sur le temps écoulé
        const newBenefit = prev + (benefitPerSecond * 5); // 5 secondes de bénéfice
        return Math.min(newBenefit, totalBenefit);
      });
      
      setLastUpdateTime(now);
    };
    
    // Démarrer l'intervalle
    intervalRef.current = window.setInterval(updateBenefit, 5000);
    
    // Nettoyer l'intervalle lors du démontage
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [startDate, endDate, totalBenefit, lastUpdateTime]);
  
  // Calculer le bénéfice par seconde
  const benefitPerSecond = totalBenefit / ((new Date(endDate).getTime() - new Date(startDate).getTime()) / 1000);
  
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <TrendingUp className="w-4 h-4 text-green-400 mr-1" />
          <span className="text-sm text-gray-400">Bénéfices en temps réel</span>
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-xs text-gray-400">Mensuel</p>
          <div className="flex items-center">
            <p className="text-lg font-bold text-blue-400">
              +{monthlyBenefit.toFixed(2)}€
            </p>
          </div>
        </div>
        <div>
          <p className="text-xs text-gray-400">Par seconde</p>
          <div className="flex items-center">
            <p className="text-lg font-bold text-blue-400">
              +{benefitPerSecond.toFixed(6)}€
            </p>
          </div>
        </div>
      </div>
      
      <div className="w-full bg-gray-700/50 h-1.5 mt-2">
        <div 
          className="bg-gradient-to-r from-blue-500 to-green-500 h-1.5 transition-all duration-500 ease-out"
          style={{ width: `${Math.min((currentBenefit / totalBenefit) * 100, 100)}%` }}
        ></div>
      </div>
    </div>
  );
};

// Calculate the number of days in a month
function getDaysInMonth(year: number, month: number): number {
  return new Date(year, month + 1, 0).getDate();
}

// Calculate prorated interest for partial month
function calculateProratedInterest(
  capital: number, 
  annualRate: number, 
  startDate: Date
): number {
  const daysInMonth = getDaysInMonth(startDate.getFullYear(), startDate.getMonth());
  const remainingDays = daysInMonth - startDate.getDate() + 1;
  
  // Calculate daily interest rate (annual rate / 365)
  const dailyRate = annualRate / 100 / 365;
  
  // Calculate prorated interest for remaining days
  return capital * dailyRate * remainingDays;
}

// Generate profitability table for a subscription
function generateProfitabilityTable(
  subscription: LivretSubscription
): ProfitabilityEntry[] {
  const table: ProfitabilityEntry[] = [];
  const startDate = new Date(subscription.subscriptionDate);
  const endDate = new Date(subscription.maturityDate);
  
  // Convert annual interest rate to monthly
  const monthlyRate = subscription.interestRate / 100 / 12;
  
  // Calculate number of months in the subscription
  const totalMonths = subscription.duration.unit === 'months' 
    ? subscription.duration.value 
    : subscription.duration.value * 12;
  
  let currentCapital = subscription.amount;
  let currentDate = new Date(startDate);
  
  // First month (partial)
  const firstMonthInterest = calculateProratedInterest(
    currentCapital,
    subscription.interestRate,
    startDate
  );
  
  currentCapital += firstMonthInterest;
  
  table.push({
    month: 1,
    startingCapital: subscription.amount,
    interest: firstMonthInterest,
    endingCapital: currentCapital,
    date: new Date(currentDate)
  });
  
  // Move to the first day of the next month
  currentDate = new Date(startDate.getFullYear(), startDate.getMonth() + 1, 1);
  
  // Calculate for remaining full months
  for (let i = 1; i < totalMonths; i++) {
    const startingCapital = currentCapital;
    const monthlyInterest = startingCapital * monthlyRate;
    currentCapital += monthlyInterest;
    
    table.push({
      month: i + 1,
      startingCapital,
      interest: monthlyInterest,
      endingCapital: currentCapital,
      date: new Date(currentDate)
    });
    
    // Move to next month
    currentDate.setMonth(currentDate.getMonth() + 1);
    
    // Stop if we've reached or passed the maturity date
    if (currentDate > endDate) break;
  }
  
  return table;
}

export function MyLivrets() {
  const [currentLead] = useLocalStorage<Lead>('currentLead', null);
  const [expandedLivret, setExpandedLivret] = useState<string | null>(null);
  const [profitabilityTables, setProfitabilityTables] = useState<Record<string, ProfitabilityEntry[]>>({});
  
  // Get user's livret subscriptions
  const subscriptions = currentLead?.livretSubscriptions || [];

  // Generate profitability tables when subscriptions change
  useEffect(() => {
    const tables: Record<string, ProfitabilityEntry[]> = {};
    
    subscriptions.forEach(subscription => {
      tables[subscription.id] = generateProfitabilityTable(subscription);
    });
    
    setProfitabilityTables(tables);
  }, [subscriptions]);

  // Calculate remaining time for a subscription
  const calculateRemainingTime = (maturityDate: string): { days: number; months: number; years: number } => {
    const now = new Date();
    const maturity = new Date(maturityDate);
    const diffTime = Math.max(0, maturity.getTime() - now.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    const years = Math.floor(diffDays / 365);
    const months = Math.floor((diffDays % 365) / 30);
    const days = diffDays % 30;
    
    return { days, months, years };
  };

  // Format remaining time as string
  const formatRemainingTime = (time: { days: number; months: number; years: number }): string => {
    const parts = [];
    
    if (time.years > 0) {
      parts.push(`${time.years} an${time.years > 1 ? 's' : ''}`);
    }
    
    if (time.months > 0) {
      parts.push(`${time.months} mois`);
    }
    
    if (time.days > 0) {
      parts.push(`${time.days} jour${time.days > 1 ? 's' : ''}`);
    }
    
    return parts.length > 0 ? parts.join(', ') : 'Arrivé à terme';
  };

  // Calculate expected benefit for a subscription
  const calculateBenefit = (subscription: LivretSubscription): { total: number; monthly: number } => {
    // Convert duration to years for calculation
    let durationInYears = subscription.duration.value;
    if (subscription.duration.unit === 'months') {
      durationInYears = subscription.duration.value / 12;
    }
    
    // Simple interest calculation: P * r * t
    const totalBenefit = subscription.amount * (subscription.interestRate / 100) * durationInYears;
    
    // Calculate monthly benefit
    const monthlyBenefit = totalBenefit / (subscription.duration.unit === 'months' ? subscription.duration.value : subscription.duration.value * 12);
    
    return { 
      total: totalBenefit,
      monthly: monthlyBenefit
    };
  };

  if (subscriptions.length === 0) {
    return (
      <div className="min-h-[400px] flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-800/50 backdrop-blur-xl mb-4">
            <BookOpen className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-xl font-medium text-gray-300">
            Aucun livret souscrit
          </h3>
          <p className="text-gray-500 max-w-sm">
            Vous n'avez pas encore souscrit à un livret. Consultez l'onglet "Livrets Disponibles" pour découvrir les offres disponibles.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {subscriptions.map((subscription, index) => {
        const benefit = calculateBenefit(subscription);
        const totalAmount = subscription.amount + benefit.total;
        const remainingTime = calculateRemainingTime(subscription.maturityDate);
        const remainingTimeStr = formatRemainingTime(remainingTime);
        const isMatured = new Date(subscription.maturityDate) <= new Date();
        const profitabilityTable = profitabilityTables[subscription.id] || [];
        const isExpanded = expandedLivret === subscription.id;
        
        return (
          <motion.div
            key={subscription.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="relative"
          >
            {/* Animated background glow */}
            <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500/30 via-purple-500/30 to-pink-500/30 opacity-0 group-hover:opacity-100 blur-xl transition duration-1000 animate-pulse"></div>
            
            {/* Neon border */}
            <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-75 blur transition duration-1000"></div>
            
            {/* Glass card */}
            <div className="relative bg-black/40 backdrop-blur-xl border border-white/10 p-6">
              {/* Header with glowing effect */}
              <div className="relative mb-6">
                <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-75 blur"></div>
                <div className="relative bg-black/60 backdrop-blur-xl border border-white/10 p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      {subscription.logoUrl ? (
                        <div className="w-10 h-10 overflow-hidden">
                          <img 
                            src={subscription.logoUrl} 
                            alt={`Logo ${subscription.livretName}`} 
                            className="w-full h-full object-contain"
                          />
                        </div>
                      ) : (
                        <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                          <BookOpen className="w-5 h-5 text-white" />
                        </div>
                      )}
                      <div>
                        <h3 className="text-xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                          {subscription.livretName}
                        </h3>
                        <div className="flex items-center text-sm text-gray-400 mt-1">
                          <Calendar className="w-4 h-4 mr-1" />
                          <span>Souscrit le {formatDate(subscription.subscriptionDate)}</span>
                        </div>
                      </div>
                    </div>
                    <div className="livret-reference-tag py-1 px-3 flex items-center bg-[rgba(0,0,0,0.3)] backdrop-blur-sm border border-blue-500/30 shadow-[0_0_15px_rgba(59,130,246,0.5)]">
                      <Hash className="h-3 w-3 text-blue-400 mr-1" />
                      <span className="text-xs font-mono font-bold text-blue-300 tracking-widest animate-pulse">
                        {subscription.reference}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Main info */}
              <div className="space-y-4">
                {/* Interest Rate and Capital */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-gray-400">Taux d'intérêt</p>
                    <div className="flex items-center">
                      <Percent className="w-4 h-4 text-green-400 mr-1" />
                      <p className="text-lg font-bold text-green-400">{subscription.interestRate}%</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400">Capital</p>
                    <div className="flex items-center">
                      <Euro className="w-4 h-4 text-purple-400 mr-1" />
                      <p className="text-lg font-bold text-white">{subscription.amount.toLocaleString()}€</p>
                    </div>
                  </div>
                </div>
                
                {/* Real-time Benefits */}
                <div className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 p-4 border border-blue-500/20">
                  <RealTimeBenefits
                    monthlyBenefit={benefit.monthly}
                    totalBenefit={benefit.total}
                    startDate={subscription.subscriptionDate}
                    endDate={subscription.maturityDate}
                  />
                </div>
                
                {/* Total Amount */}
                <div className="flex justify-between items-center pt-2 border-t border-white/10">
                  <p className="text-sm text-gray-400">Montant Total à Terme</p>
                  <p className="text-lg font-bold text-white">{totalAmount.toLocaleString()}€</p>
                </div>
                
                {/* Remaining Time */}
                <div className="flex justify-between items-center">
                  <p className="text-sm text-gray-400">Temps restant</p>
                  <p className={`text-sm font-medium ${isMatured ? 'text-green-400' : 'text-blue-400'}`}>
                    {isMatured ? 'Arrivé à terme' : remainingTimeStr}
                  </p>
                </div>
                
                {/* Profitability Table Toggle */}
                <button
                  onClick={() => setExpandedLivret(isExpanded ? null : subscription.id)}
                  className="w-full flex items-center justify-between p-2 bg-gray-800/50 hover:bg-gray-700/50 rounded-lg transition-colors"
                >
                  <span className="flex items-center text-sm text-gray-300">
                    <Table className="w-4 h-4 mr-2 text-blue-400" />
                    Tableau de rentabilité
                  </span>
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-gray-400" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-gray-400" />
                  )}
                </button>
                
                {/* Profitability Table */}
                {isExpanded && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <div className="bg-gray-800/50 border border-gray-700/50 rounded-lg p-4 mt-2">
                      <h4 className="text-sm font-medium text-white mb-3">
                        Évolution du capital
                      </h4>
                      
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead>
                            <tr className="border-b border-gray-700">
                              <th className="px-2 py-2 text-left text-gray-400">Mois</th>
                              <th className="px-2 py-2 text-left text-gray-400">Date</th>
                              <th className="px-2 py-2 text-right text-gray-400">Capital initial</th>
                              <th className="px-2 py-2 text-right text-gray-400">Intérêts</th>
                              <th className="px-2 py-2 text-right text-gray-400">Capital final</th>
                            </tr>
                          </thead>
                          <tbody>
                            {profitabilityTable.map((entry, entryIndex) => (
                              <tr 
                                key={entryIndex} 
                                className={cn(
                                  "border-b border-gray-700/50",
                                  entryIndex === 0 && "bg-blue-900/10"
                                )}
                              >
                                <td className="px-2 py-2 text-left text-white">{entry.month}</td>
                                <td className="px-2 py-2 text-left text-white">
                                  {entry.date.toLocaleDateString()}
                                </td>
                                <td className="px-2 py-2 text-right text-white">
                                  {entry.startingCapital.toLocaleString()}€
                                </td>
                                <td className="px-2 py-2 text-right text-green-400">
                                  +{entry.interest.toLocaleString()}€
                                </td>
                                <td className="px-2 py-2 text-right text-white">
                                  {entry.endingCapital.toLocaleString()}€
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      
                      {profitabilityTable.length > 0 && (
                        <p className="text-xs text-blue-400 mt-2">
                          * Le premier mois est calculé au prorata des jours restants
                        </p>
                      )}
                    </div>
                  </motion.div>
                )}
              </div>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}