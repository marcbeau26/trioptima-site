import React, { createContext, useContext, useEffect, useState } from 'react';
import { initializeFirebaseFromLocalStorage } from '../lib/firebaseService';
import { toast } from 'react-hot-toast';

interface FirebaseContextType {
  isInitialized: boolean;
  isInitializing: boolean;
  initializeFirebase: () => Promise<void>;
}

const FirebaseContext = createContext<FirebaseContextType>({
  isInitialized: false,
  isInitializing: false,
  initializeFirebase: async () => {}
});

export const useFirebase = () => useContext(FirebaseContext);

export const FirebaseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isInitialized, setIsInitialized] = useState(false);
  const [isInitializing, setIsInitializing] = useState(false);

  const initializeFirebase = async () => {
    if (isInitialized || isInitializing) return;
    
    setIsInitializing(true);
    try {
      await initializeFirebaseFromLocalStorage();
      setIsInitialized(true);
      toast.success('Données synchronisées avec Firebase');
    } catch (error) {
      console.error('Failed to initialize Firebase:', error);
      toast.error('Échec de la synchronisation avec Firebase');
    } finally {
      setIsInitializing(false);
    }
  };

  // Check if Firebase is initialized on mount
  useEffect(() => {
    const checkInitialization = async () => {
      // Logic to check if Firebase is initialized could be added here
      // For now, we'll assume it's not initialized
    };
    
    checkInitialization();
  }, []);

  return (
    <FirebaseContext.Provider value={{ isInitialized, isInitializing, initializeFirebase }}>
      {children}
    </FirebaseContext.Provider>
  );
};