import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider } from './contexts/ThemeContext';
import { GenerationProgressProvider } from './contexts/GenerationProgressContext';
import { CopyrightProvider } from './contexts/CopyrightContext';
import { MainContent } from './components/MainContent';
import { Dashboard } from './components/Dashboard';
import { SellerDashboard } from './components/Dashboard/SellerDashboard';
import { ClientDashboard } from './components/ClientDashboard';
import { LeadDetails } from './components/Dashboard/LeadsManager/LeadDetails';
import { Toaster } from 'react-hot-toast';
import { useLocalStorage } from './hooks/useLocalStorage';

function App() {
  const [borderColors] = useLocalStorage('borderColors', {
    borders: '#2d3748',
    dividers: '#374151',
    outlines: '#4b5563',
    boxShadow: 'rgba(0, 0, 0, 0.25)'
  });

  const [themeColors] = useLocalStorage('themeColors', {
    header: '#1e293b',
    sidebar: '#0f172a',
    mainContent: '#111827',
    text: '#ffffff',
  });

  const [clientColors] = useLocalStorage('clientColors', {
    header: '#1e293b',
    sidebar: '#0f172a',
    mainContent: '#111827',
    text: '#ffffff',
  });

  // Apply colors to CSS variables
  React.useEffect(() => {
    const root = document.documentElement;
    
    // Apply theme colors
    root.style.setProperty('--color-header', themeColors.header);
    root.style.setProperty('--color-sidebar', themeColors.sidebar);
    root.style.setProperty('--color-main-content', themeColors.mainContent);
    root.style.setProperty('--color-text', themeColors.text || '#ffffff');
    
    // Apply client colors
    root.style.setProperty('--client-header', clientColors.header);
    root.style.setProperty('--client-sidebar', clientColors.sidebar);
    root.style.setProperty('--client-main-content', clientColors.mainContent);
    root.style.setProperty('--client-text', clientColors.text || '#ffffff');
    
    // Apply border colors
    root.style.setProperty('--color-borders', borderColors.borders);
    root.style.setProperty('--color-dividers', borderColors.dividers);
    root.style.setProperty('--color-outlines', borderColors.outlines);
    root.style.setProperty('--color-box-shadow', borderColors.boxShadow);
    
    // Apply text colors to elements
    const style = document.createElement('style');
    style.textContent = `
      /* Admin interface text colors */
      .dark\\:text-white, 
      .text-white, 
      .text-gray-900.dark\\:text-white,
      h1, h2, h3, h4, h5, h6,
      .sidebar-link-text,
      .dashboard-header-text {
        color: var(--color-text) !important;
      }
      
      /* Client interface text colors */
      .client-dashboard-text,
      .client-sidebar-text,
      .client-header-text,
      .client-interface h1, 
      .client-interface h2, 
      .client-interface h3, 
      .client-interface h4, 
      .client-interface h5, 
      .client-interface h6,
      .client-interface p,
      .client-interface span,
      .client-interface div {
        color: var(--client-text) !important;
      }
    `;
    document.head.appendChild(style);
  }, [borderColors, themeColors, clientColors]);

  return (
    <ThemeProvider>
      <GenerationProgressProvider>
        <CopyrightProvider>
          <Router>
            <Routes>
              <Route path="/" element={<MainContent />} />
              <Route path="/dashboard/*" element={<Dashboard />} />
              <Route path="/seller-dashboard/*" element={<SellerDashboard />} />
              <Route path="/client/:id" element={<ClientDashboard />} />
              <Route path="/leads/:id" element={<LeadDetails />} />
              <Route path="*" element={<Navigate to="/\" replace />} />
            </Routes>
            <Toaster 
              position="top-right"
              toastOptions={{
                style: {
                  background: '#363636',
                  color: '#fff',
                  paddingLeft: '1rem',
                  paddingRight: '1rem',
                },
                success: {
                  duration: 5000,
                  className: '!bg-green-600',
                  icon: '✅',
                },
                error: {
                  duration: 5000,
                  className: '!bg-red-600',
                  icon: '❌',
                },
              }}
            />
          </Router>
        </CopyrightProvider>
      </GenerationProgressProvider>
    </ThemeProvider>
  );
}

export default App;