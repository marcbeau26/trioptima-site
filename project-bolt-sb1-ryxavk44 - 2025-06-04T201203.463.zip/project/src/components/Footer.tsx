import React, { useEffect, useState } from 'react';
import { useCopyright } from '../contexts/CopyrightContext';
import { useLocalStorage } from '../hooks/useLocalStorage';

export function Footer() {
  const { companyName, year } = useCopyright();
  const [settings] = useLocalStorage<any>('homepageSettings', {
    logoText: 'Trioptima'
  });
  const [displayName, setDisplayName] = useState(companyName);
  
  // Sync the footer company name with the logo text
  useEffect(() => {
    if (settings.logoText) {
      setDisplayName(settings.logoText);
    } else {
      setDisplayName(companyName);
    }
  }, [settings.logoText, companyName]);
  
  return (
    <div className="py-4 px-6 text-gray-400 text-sm">
      <span>© {year} {displayName}. Tous droits réservés.</span>
    </div>
  );
}