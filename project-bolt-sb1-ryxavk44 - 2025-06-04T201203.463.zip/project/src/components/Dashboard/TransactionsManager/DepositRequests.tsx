import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Check, X, Eye, Building2, CreditCard, Bitcoin, Trash2 } from 'lucide-react';
import type { Lead, DepositRequest } from '../../../types';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { formatDate } from '../../../utils';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';

interface DetailsModalProps {
  request: DepositRequest & { lead: Lead };
  isOpen: boolean;
  onClose: () => void;
}

function DetailsModal({ request, isOpen, onClose }: DetailsModalProps) {
  if (!isOpen) return null;

  const methodIcons = {
    bank: <Building2 className="w-5 h-5" />,
    card: <CreditCard className="w-5 h-5" />,
    crypto: <Bitcoin className="w-5 h-5" />
  };

  const methodLabels = {
    bank: 'Virement bancaire',
    card: 'Carte bancaire',
    crypto: 'Crypto-monnaie'
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-2xl mx-4"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <div className="flex justify-between items-start mb-6">
            <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Détails de la demande de dépôt
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-300 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="space-y-6">
            {/* Client Information */}
            <div className="bg-gray-800/50 border border-white/5 rounded-xl p-6">
              <h3 className="text-lg font-medium text-white mb-4">
                Informations client
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-400">Nom complet</p>
                  <p className="text-base font-medium text-white">
                    {request.lead.firstName} {request.lead.lastName}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Email</p>
                  <p className="text-base font-medium text-white">
                    {request.lead.email}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Téléphone</p>
                  <p className="text-base font-medium text-white">
                    {request.lead.phone}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Solde actuel</p>
                  <p className="text-base font-medium text-white">
                    {request.lead.balance?.toLocaleString()}€
                  </p>
                </div>
              </div>
            </div>

            {/* Transaction Details */}
            <div className="bg-gray-800/50 border border-white/5 rounded-xl p-6">
              <h3 className="text-lg font-medium text-white mb-4">
                Détails de la transaction
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-400">Montant</p>
                  <p className="text-lg font-semibold text-white">
                    {request.amount.toLocaleString()}€
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Méthode</p>
                  <div className="flex items-center space-x-2 text-white">
                    {methodIcons[request.method]}
                    <span>{methodLabels[request.method]}</span>
                  </div>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Date de la demande</p>
                  <p className="text-base font-medium text-white">
                    {formatDate(request.dateCreated)}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-gray-400">Statut</p>
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    request.status === 'pending'
                      ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100'
                      : request.status === 'approved'
                      ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100'
                      : 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100'
                  }`}>
                    {request.status === 'pending' ? 'En attente' : request.status === 'approved' ? 'Approuvé' : 'Refusé'}
                  </span>
                </div>
              </div>
            </div>

            {request.description && (
              <div className="bg-gray-800/50 border border-white/5 rounded-xl p-6">
                <h3 className="text-lg font-medium text-white mb-2">
                  Description
                </h3>
                <p className="text-gray-300">{request.description}</p>
              </div>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export function DepositRequests() {
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRequest, setSelectedRequest] = useState<(DepositRequest & { lead: Lead }) | null>(null);
  const [selectedRequests, setSelectedRequests] = useState<string[]>([]);

  // Get all deposit requests from all leads
  const allRequests = leads.flatMap(lead => 
    (lead.depositRequests || []).map(request => ({
      ...request,
      lead
    }))
  ).sort((a, b) => new Date(b.dateCreated).getTime() - new Date(a.dateCreated).getTime());

  // Filter requests based on search term
  const filteredRequests = allRequests.filter(request => {
    const searchString = `${request.lead.firstName} ${request.lead.lastName} ${request.lead.email}`.toLowerCase();
    return searchString.includes(searchTerm.toLowerCase());
  });

  const handleApprove = (request: DepositRequest & { lead: Lead }) => {
    const updatedLeads = leads.map(lead => {
      if (lead.id === request.leadId) {
        const updatedRequests = (lead.depositRequests || []).map(req =>
          req.id === request.id
            ? { ...req, status: 'approved' as const, dateProcessed: new Date().toISOString() }
            : req
        );

        return {
          ...lead,
          balance: (lead.balance || 0) + request.amount,
          depositRequests: updatedRequests,
          transactions: [
            ...(lead.transactions || []),
            {
              id: request.id,
              amount: request.amount,
              type: 'deposit',
              description: `Dépôt approuvé - ${request.method}`,
              dateCreated: new Date().toISOString()
            }
          ]
        };
      }
      return lead;
    });

    setLeads(updatedLeads);
    toast.success('Dépôt approuvé avec succès');
  };

  const handleReject = (request: DepositRequest & { lead: Lead }) => {
    const updatedLeads = leads.map(lead => {
      if (lead.id === request.leadId) {
        const updatedRequests = (lead.depositRequests || []).map(req =>
          req.id === request.id
            ? { ...req, status: 'rejected' as const, dateProcessed: new Date().toISOString() }
            : req
        );

        return {
          ...lead,
          depositRequests: updatedRequests
        };
      }
      return lead;
    });

    setLeads(updatedLeads);
    toast.success('Dépôt refusé');
  };

  // Toggle select all requests
  const toggleSelectAll = () => {
    if (selectedRequests.length === filteredRequests.length) {
      setSelectedRequests([]);
    } else {
      setSelectedRequests(filteredRequests.map(request => request.id));
    }
  };

  // Toggle select individual request
  const toggleSelectRequest = (requestId: string) => {
    if (selectedRequests.includes(requestId)) {
      setSelectedRequests(selectedRequests.filter(id => id !== requestId));
    } else {
      setSelectedRequests([...selectedRequests, requestId]);
    }
  };

  // Delete selected requests
  const handleDeleteSelected = () => {
    if (selectedRequests.length === 0) return;

    // Update leads by removing the selected deposit requests
    const updatedLeads = leads.map(lead => {
      const hasSelectedRequests = lead.depositRequests?.some(req => 
        selectedRequests.includes(req.id)
      );

      if (hasSelectedRequests) {
        return {
          ...lead,
          depositRequests: lead.depositRequests?.filter(req => 
            !selectedRequests.includes(req.id)
          )
        };
      }
      return lead;
    });

    setLeads(updatedLeads);
    
    // Clear selected requests
    setSelectedRequests([]);
    
    // Show success message
    toast.success(`${selectedRequests.length} demande${selectedRequests.length > 1 ? 's' : ''} supprimée${selectedRequests.length > 1 ? 's' : ''} avec succès`);
  };

  return (
    <div className="space-y-6">
      {/* Search Bar */}
      <div className="relative">
        <input
          type="text"
          placeholder="Rechercher par nom ou email..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:text-white"
        />
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
      </div>

      {/* Delete Selected Button */}
      {selectedRequests.length > 0 && (
        <div className="flex justify-end">
          <motion.button
            onClick={handleDeleteSelected}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="relative group overflow-hidden rounded-lg px-4 py-2"
          >
            <div className="absolute inset-0 bg-red-500/80 opacity-80 group-hover:opacity-100 transition-opacity"></div>
            <span className="relative flex items-center text-white">
              <Trash2 className="w-4 h-4 mr-2" />
              Supprimer ({selectedRequests.length})
            </span>
          </motion.button>
        </div>
      )}

      {/* Requests Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-800">
            <tr>
              <th scope="col" className="px-6 py-3 text-left">
                <input
                  type="checkbox"
                  checked={selectedRequests.length === filteredRequests.length && filteredRequests.length > 0}
                  onChange={toggleSelectAll}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700"
                />
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Client
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Montant
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Méthode
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Date
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Statut
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200 dark:bg-gray-900 dark:divide-gray-700">
            {filteredRequests.map((request) => (
              <tr key={request.id} className="hover:bg-gray-50 dark:hover:bg-gray-800">
                <td className="px-6 py-4 whitespace-nowrap">
                  <input
                    type="checkbox"
                    checked={selectedRequests.includes(request.id)}
                    onChange={() => toggleSelectRequest(request.id)}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700"
                  />
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900 dark:text-white">
                    {request.lead.firstName} {request.lead.lastName}
                  </div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    {request.lead.email}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900 dark:text-white">
                    {request.amount.toLocaleString()}€
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    {request.method === 'bank' && <Building2 className="w-5 h-5 text-blue-500 mr-2" />}
                    {request.method === 'card' && <CreditCard className="w-5 h-5 text-green-500 mr-2" />}
                    {request.method === 'crypto' && <Bitcoin className="w-5 h-5 text-yellow-500 mr-2" />}
                    <span className="text-sm text-gray-900 dark:text-white">
                      {request.method === 'bank' ? 'Virement' : request.method === 'card' ? 'Carte' : 'Crypto'}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                  {formatDate(request.dateCreated)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                    request.status === 'pending'
                      ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100'
                      : request.status === 'approved'
                      ? 'bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100'
                      : 'bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100'
                  }`}>
                    {request.status === 'pending' ? 'En attente' : request.status === 'approved' ? 'Approuvé' : 'Refusé'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                  {request.status === 'pending' && (
                    <>
                      <button
                        onClick={() => handleApprove(request)}
                        className="text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300"
                      >
                        <Check className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => handleReject(request)}
                        className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </>
                  )}
                  <button
                    onClick={() => setSelectedRequest(request)}
                    className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300"
                  >
                    <Eye className="w-5 h-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {filteredRequests.length === 0 && (
          <div className="text-center py-12 text-gray-500 dark:text-gray-400">
            Aucune demande de dépôt trouvée
          </div>
        )}
      </div>

      {selectedRequest && (
        <DetailsModal
          request={selectedRequest}
          isOpen={true}
          onClose={() => setSelectedRequest(null)}
        />
      )}
    </div>
  );
}