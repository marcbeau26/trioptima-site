import React, { useState } from 'react';
import { useLocalStorage } from '../../../../hooks/useLocalStorage';
import type { Lead, Transaction } from '../../../../types';
import { generateId } from '../../../../utils';
import { toast } from 'react-hot-toast';

export function Withdraw() {
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const currentLeadStr = localStorage.getItem('currentLead');
  const currentLead = currentLeadStr ? JSON.parse(currentLeadStr) as Lead : null;

  const handleWithdraw = (e: React.FormEvent) => {
    e.preventDefault();

    if (!currentLead || !amount) {
      toast.error('Veuillez saisir un montant');
      return;
    }

    const withdrawAmount = parseFloat(amount);
    if (isNaN(withdrawAmount) || withdrawAmount <= 0) {
      toast.error('Veuillez saisir un montant valide');
      return;
    }

    if ((currentLead.balance || 0) < withdrawAmount) {
      toast.error('Solde insuffisant pour effectuer ce retrait');
      return;
    }

    const transaction: Transaction = {
      id: generateId(),
      amount: -withdrawAmount,
      type: 'withdrawal',
      description: description || `Retrait de ${withdrawAmount.toLocaleString()}€`,
      dateCreated: new Date().toISOString()
    };

    const updatedLeads = leads.map(lead => {
      if (lead.id === currentLead.id) {
        return {
          ...lead,
          balance: (lead.balance || 0) - withdrawAmount,
          transactions: [...(lead.transactions || []), transaction]
        };
      }
      return lead;
    });

    setLeads(updatedLeads);
    
    // Update current lead in localStorage
    const updatedLead = updatedLeads.find(l => l.id === currentLead.id);
    if (updatedLead) {
      localStorage.setItem('currentLead', JSON.stringify(updatedLead));
    }

    setAmount('');
    setDescription('');
    toast.success('Retrait effectué avec succès');
  };

  return (
    <form onSubmit={handleWithdraw} className="max-w-lg space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Montant du retrait (€)
        </label>
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          className="w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
          min="0"
          step="0.01"
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Description (optionnelle)
        </label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
          rows={3}
        />
      </div>

      <button
        type="submit"
        className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
      >
        Valider le retrait
      </button>
    </form>
  );
}