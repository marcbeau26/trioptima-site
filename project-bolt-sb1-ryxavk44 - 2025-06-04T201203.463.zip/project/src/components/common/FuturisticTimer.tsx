import React, { useState, useEffect } from 'react';

interface FuturisticTimerProps {
  expiryDate: string;
  onExpire?: () => void;
}

export function FuturisticTimer({ expiryDate, onExpire }: FuturisticTimerProps) {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });
  const [isExpired, setIsExpired] = useState(false);

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date().getTime();
      const expiry = new Date(expiryDate).getTime();
      const difference = expiry - now;

      if (difference <= 0) {
        setIsExpired(true);
        onExpire?.();
        return;
      }

      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);

      setTimeLeft({ days, hours, minutes, seconds });
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(timer);
  }, [expiryDate, onExpire]);

  if (isExpired) {
    return (
      <div className="text-red-500 dark:text-red-400 text-[10px] bg-black/20 px-2 py-0.5 rounded-full border border-red-500/30 backdrop-blur-sm">
        Offre expirée
      </div>
    );
  }

  return (
    <div className="flex items-center space-x-1 bg-[#1a1b1e] rounded-lg p-1 border border-purple-500/20">
      {timeLeft.days > 0 && (
        <>
          <div className="flex flex-col relative">
            <div className="bg-[#2a2b2e] rounded px-2 py-1">
              <span className="font-mono font-bold text-purple-400 text-sm">
                {String(timeLeft.days).padStart(2, '0')}
              </span>
              <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-full">
                <span className="text-[8px] text-purple-500 bg-[#1a1b1e] px-1 rounded-full">
                  j
                </span>
              </div>
            </div>
          </div>
          <span className="text-purple-500 font-bold text-xs">:</span>
        </>
      )}

      <div className="flex flex-col relative">
        <div className="bg-[#2a2b2e] rounded px-2 py-1">
          <span className="font-mono font-bold text-purple-400 text-sm">
            {String(timeLeft.hours).padStart(2, '0')}
          </span>
          <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-full">
            <span className="text-[8px] text-purple-500 bg-[#1a1b1e] px-1 rounded-full">
              h
            </span>
          </div>
        </div>
      </div>

      <span className="text-purple-500 font-bold text-xs">:</span>

      <div className="flex flex-col relative">
        <div className="bg-[#2a2b2e] rounded px-2 py-1">
          <span className="font-mono font-bold text-purple-400 text-sm">
            {String(timeLeft.minutes).padStart(2, '0')}
          </span>
          <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-full">
            <span className="text-[8px] text-purple-500 bg-[#1a1b1e] px-1 rounded-full">
              m
            </span>
          </div>
        </div>
      </div>

      <span className="text-purple-500 font-bold text-xs">:</span>

      <div className="flex flex-col relative">
        <div className="bg-[#2a2b2e] rounded px-2 py-1">
          <span className="font-mono font-bold text-purple-400 text-sm">
            {String(timeLeft.seconds).padStart(2, '0')}
          </span>
          <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-full">
            <span className="text-[8px] text-purple-500 bg-[#1a1b1e] px-1 rounded-full">
              s
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}