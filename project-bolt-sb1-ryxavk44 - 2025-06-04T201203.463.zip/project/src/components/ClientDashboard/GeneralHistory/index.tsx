import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  TrendingUp, TrendingDown, Calendar, Filter, Search, 
  Zap, DollarSign, ArrowUpRight, ArrowDownRight, 
  Wallet, Clock, Hash, Package, LineChart, RefreshCw
} from 'lucide-react';
import type { Lead, Transaction } from '../../../types';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { formatDate } from '../../../utils';
import { cn } from '../../../utils/cn';

// Transaction type filter options
type TransactionTypeFilter = 'all' | 'deposit' | 'withdrawal' | 'investment' | 'sale' | 'trading';

// Asset type filter options
type AssetTypeFilter = 'all' | 'electricity' | 'stock' | 'funds';

export function GeneralHistory() {
  const [currentLead] = useLocalStorage<Lead>('currentLead', null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([]);
  const [typeFilter, setTypeFilter] = useState<TransactionTypeFilter>('all');
  const [assetFilter, setAssetFilter] = useState<AssetTypeFilter>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');

  // Initialize transactions from current lead
  useEffect(() => {
    if (currentLead?.transactions) {
      // Enhance transactions with additional metadata
      const enhancedTransactions = currentLead.transactions.map(transaction => {
        // Determine asset type
        let assetType: AssetTypeFilter = 'funds';
        
        if (transaction.description.includes('MW') || 
            transaction.description.includes('énergie')) {
          assetType = 'electricity';
        } else if (transaction.description.includes('action')) {
          assetType = 'stock';
        }

        // Extract reference if present
        const refMatch = transaction.description.match(/Réf: ([A-Z0-9]+)/);
        const reference = refMatch ? refMatch[1] : null;

        // Calculate balance impact
        const balanceImpact = transaction.type === 'investment' ? -Math.abs(transaction.amount) : transaction.amount;

        return {
          ...transaction,
          assetType,
          reference,
          balanceImpact
        };
      });

      setTransactions(enhancedTransactions);
      applyFilters(enhancedTransactions, typeFilter, assetFilter, searchTerm, sortOrder);
    }
  }, [currentLead]);

  // Apply filters when they change
  useEffect(() => {
    applyFilters(transactions, typeFilter, assetFilter, searchTerm, sortOrder);
  }, [typeFilter, assetFilter, searchTerm, sortOrder]);

  // Filter and sort transactions
  const applyFilters = (
    allTransactions: Transaction[], 
    type: TransactionTypeFilter, 
    asset: AssetTypeFilter, 
    search: string,
    order: 'newest' | 'oldest'
  ) => {
    let filtered = [...allTransactions];

    // Apply type filter
    if (type !== 'all') {
      filtered = filtered.filter(t => t.type === type);
    }

    // Apply asset filter
    if (asset !== 'all') {
      filtered = filtered.filter(t => {
        if (asset === 'electricity') {
          return t.description.includes('MW') || t.description.includes('énergie');
        } else if (asset === 'stock') {
          return t.description.includes('action') && !t.description.includes('MW');
        } else if (asset === 'funds') {
          return t.type === 'deposit' || t.type === 'withdrawal';
        }
        return true;
      });
    }

    // Apply search filter
    if (search) {
      const searchLower = search.toLowerCase();
      filtered = filtered.filter(t => 
        t.description.toLowerCase().includes(searchLower)
      );
    }

    // Apply sort order
    filtered = filtered.sort((a, b) => {
      const dateA = new Date(a.dateCreated).getTime();
      const dateB = new Date(b.dateCreated).getTime();
      return order === 'newest' ? dateB - dateA : dateA - dateB;
    });

    setFilteredTransactions(filtered);
  };

  // Get transaction icon based on type and description
  const getTransactionIcon = (transaction: Transaction) => {
    if (transaction.type === 'deposit') {
      return <ArrowUpRight className="w-5 h-5 text-green-400" />;
    } else if (transaction.type === 'withdrawal') {
      return <ArrowDownRight className="w-5 h-5 text-red-400" />;
    } else if (transaction.type === 'investment') {
      if (transaction.description.includes('MW') || transaction.description.includes('énergie')) {
        return <Zap className="w-5 h-5 text-blue-400" />;
      } else {
        return <LineChart className="w-5 h-5 text-purple-400" />;
      }
    } else if (transaction.type === 'sale') {
      if (transaction.description.includes('MW') || transaction.description.includes('énergie')) {
        return <Zap className="w-5 h-5 text-cyan-400" />;
      } else {
        return <Package className="w-5 h-5 text-pink-400" />;
      }
    } else if (transaction.type === 'trading') {
      return <RefreshCw className="w-5 h-5 text-amber-400" />;
    }
    return <DollarSign className="w-5 h-5 text-gray-400" />;
  };

  // Get transaction color based on amount
  const getTransactionColor = (amount: number) => {
    if (amount > 0) return "text-green-400";
    if (amount < 0) return "text-red-400";
    return "text-gray-400";
  };

  // Get transaction label based on type and description
  const getTransactionLabel = (transaction: Transaction) => {
    if (transaction.type === 'deposit') {
      return "Dépôt";
    } else if (transaction.type === 'withdrawal') {
      return "Retrait";
    } else if (transaction.type === 'investment') {
      if (transaction.description.includes('MW') || transaction.description.includes('énergie')) {
        return "Achat d'énergie";
      } else {
        return "Souscription d'action";
      }
    } else if (transaction.type === 'sale') {
      if (transaction.description.includes('MW') || transaction.description.includes('énergie')) {
        return "Vente d'énergie";
      } else {
        return "Vente d'action";
      }
    } else if (transaction.type === 'trading') {
      return "Trading";
    }
    return "Transaction";
  };

  // Calculate running balance for each transaction
  const calculateRunningBalances = (transactions: Transaction[]) => {
    let runningBalance = 0;
    
    // If sorting by oldest first, we need to calculate from the beginning
    const sortedTransactions = [...transactions];
    if (sortOrder === 'oldest') {
      sortedTransactions.sort((a, b) => 
        new Date(a.dateCreated).getTime() - new Date(b.dateCreated).getTime()
      );
    }
    
    return sortedTransactions.map(transaction => {
      // For investment transactions, the amount is negative but affects balance negatively
      const balanceImpact = transaction.type === 'investment' 
        ? -Math.abs(transaction.amount) 
        : transaction.amount;
      
      runningBalance += balanceImpact;
      
      return {
        ...transaction,
        runningBalance
      };
    });
  };

  // Add running balances to transactions
  const transactionsWithBalance = calculateRunningBalances(filteredTransactions);
  
  // If sorting by newest first, we need to reverse the order for display
  const displayTransactions = sortOrder === 'newest' 
    ? transactionsWithBalance 
    : [...transactionsWithBalance].reverse();

  if (!currentLead) {
    return (
      <div className="text-center py-12 text-gray-400">
        Chargement...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with title and filters */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
          Historique Général des Transactions
        </h2>
        
        <div className="flex flex-wrap gap-2">
          {/* Sort order toggle */}
          <button
            onClick={() => setSortOrder(sortOrder === 'newest' ? 'oldest' : 'newest')}
            className="inline-flex items-center px-3 py-1.5 bg-gray-800/50 hover:bg-gray-700/50 text-gray-300 rounded-lg transition-colors"
          >
            <Clock className="w-4 h-4 mr-2" />
            {sortOrder === 'newest' ? 'Plus récentes' : 'Plus anciennes'}
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Search filter */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Rechercher dans les transactions..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-gray-800/50 border border-gray-700/50 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50"
          />
        </div>

        {/* Transaction type filter */}
        <div className="relative">
          <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value as TransactionTypeFilter)}
            className="w-full pl-10 pr-4 py-2 bg-gray-800/50 border border-gray-700/50 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 appearance-none"
          >
            <option value="all">Tous les types</option>
            <option value="deposit">Dépôts</option>
            <option value="withdrawal">Retraits</option>
            <option value="investment">Investissements</option>
            <option value="sale">Ventes</option>
            <option value="trading">Trading</option>
          </select>
        </div>

        {/* Asset type filter */}
        <div className="relative">
          <Package className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <select
            value={assetFilter}
            onChange={(e) => setAssetFilter(e.target.value as AssetTypeFilter)}
            className="w-full pl-10 pr-4 py-2 bg-gray-800/50 border border-gray-700/50 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500/50 appearance-none"
          >
            <option value="all">Tous les actifs</option>
            <option value="electricity">Électricité</option>
            <option value="stock">Actions</option>
            <option value="funds">Fonds</option>
          </select>
        </div>
      </div>

      {/* Transactions list */}
      <div className="space-y-4">
        {displayTransactions.length > 0 ? (
          displayTransactions.map((transaction, index) => (
            <motion.div
              key={transaction.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05, duration: 0.3 }}
              className="relative group"
            >
              <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
              <div className="relative bg-gray-800/50 backdrop-blur-xl border border-white/10 rounded-lg p-4">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  {/* Left side - Transaction info */}
                  <div className="flex items-start space-x-4">
                    {/* Icon */}
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gray-700/50 flex items-center justify-center">
                      {getTransactionIcon(transaction)}
                    </div>
                    
                    {/* Transaction details */}
                    <div className="flex-1">
                      <div className="flex flex-col md:flex-row md:items-center gap-2">
                        <span className="text-sm font-medium text-gray-300">
                          {getTransactionLabel(transaction)}
                        </span>
                        
                        {/* Transaction badge */}
                        <span className={cn(
                          "px-2 py-0.5 text-xs rounded-full",
                          transaction.assetType === 'electricity' && "bg-blue-500/20 text-blue-300 border border-blue-500/30",
                          transaction.assetType === 'stock' && "bg-purple-500/20 text-purple-300 border border-purple-500/30",
                          transaction.assetType === 'funds' && "bg-green-500/20 text-green-300 border border-green-500/30"
                        )}>
                          {transaction.assetType === 'electricity' ? 'Électricité' : 
                           transaction.assetType === 'stock' ? 'Action' : 'Fonds'}
                        </span>
                        
                        {/* Reference tag if available */}
                        {transaction.reference && (
                          <div className="inline-flex items-center bg-gray-700/50 px-2 py-0.5 rounded-md">
                            <Hash className="h-3 w-3 text-blue-400 mr-1" />
                            <span className="text-xs font-mono text-blue-300">{transaction.reference}</span>
                          </div>
                        )}
                      </div>
                      
                      <p className="text-white mt-1">{transaction.description}</p>
                      
                      <div className="text-xs text-gray-400 mt-1 flex items-center">
                        <Calendar className="w-3 h-3 mr-1" />
                        {formatDate(transaction.dateCreated)}
                      </div>
                    </div>
                  </div>
                  
                  {/* Right side - Amount and balance */}
                  <div className="flex flex-col items-end space-y-1">
                    {/* Transaction amount */}
                    <div className={cn(
                      "flex items-center font-medium text-lg",
                      getTransactionColor(transaction.balanceImpact)
                    )}>
                      {transaction.balanceImpact >= 0 ? (
                        <TrendingUp className="w-4 h-4 mr-1" />
                      ) : (
                        <TrendingDown className="w-4 h-4 mr-1" />
                      )}
                      <span>
                        {transaction.balanceImpact >= 0 ? '+' : ''}
                        {transaction.balanceImpact.toLocaleString()}€
                      </span>
                    </div>
                    
                    {/* Running balance */}
                    <div className="flex items-center text-sm text-gray-400">
                      <Wallet className="w-3 h-3 mr-1" />
                      <span>Solde: {transaction.runningBalance.toLocaleString()}€</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="text-center py-12 bg-gray-800/30 rounded-lg border border-gray-700/50">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-800/50 backdrop-blur-xl mb-4">
              <Clock className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-xl font-medium text-gray-300">
              Aucune transaction trouvée
            </h3>
            <p className="text-gray-500 max-w-sm mx-auto mt-2">
              Ajustez vos filtres ou effectuez des transactions pour les voir apparaître ici.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}