import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  X, TrendingUp, TrendingDown, DollarSign, ArrowUpRight, ArrowDownRight, 
  BarChart2, RefreshCw, Activity, Check, AlertCircle, Filter, Search
} from 'lucide-react';
import type { Lead, TradingAPIPosition } from '../../../types';
import { formatDate, formatPrice } from '../../../utils';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';

interface TradingPositionsModalProps {
  lead: Lead;
  isOpen: boolean;
  onClose: () => void;
  onUpdate: (updatedLead: Lead) => void;
}

interface EditPositionModalProps {
  position: TradingAPIPosition;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedPosition: TradingAPIPosition) => void;
}

function EditPositionModal({ position, isOpen, onClose, onSave }: EditPositionModalProps) {
  const [type, setType] = useState<'buy' | 'sell'>(position.type);
  const [pnl, setPnl] = useState<number>(position.pnl);
  const [pnlPercentage, setPnlPercentage] = useState<number>(position.pnlPercentage);

  if (!isOpen) return null;

  const handleSave = () => {
    const updatedPosition: TradingAPIPosition = {
      ...position,
      type,
      pnl,
      pnlPercentage
    };
    
    onSave(updatedPosition);
  };

  // Calculate new pnl percentage when pnl changes
  useEffect(() => {
    if (position.amount > 0) {
      setPnlPercentage((pnl / position.amount) * 100);
    }
  }, [pnl, position.amount]);

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[200]">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-lg mx-4"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <div className="flex justify-between items-start mb-6">
            <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Modifier la position
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-300 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="space-y-6">
            {/* Position Info */}
            <div className="bg-gray-800/50 border border-white/5 rounded-xl p-4 space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Symbole</span>
                <span className="text-white">{position.symbol}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Montant</span>
                <span className="text-white">{formatPrice(position.amount)}€</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Prix d'entrée</span>
                <span className="text-white">${position.entryPrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Prix actuel</span>
                <span className="text-white">${position.currentPrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Date de création</span>
                <span className="text-white">{formatDate(position.dateCreated)}</span>
              </div>
            </div>

            {/* Type Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Type de position
              </label>
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setType('buy')}
                  className={cn(
                    "p-4 rounded-lg border transition-colors text-center",
                    type === 'buy'
                      ? "bg-green-600/20 border-green-500/50 text-green-400"
                      : "bg-gray-800/50 border-gray-700/50 text-gray-400 hover:bg-gray-700/50"
                  )}
                >
                  <ArrowUpRight className="w-6 h-6 mx-auto mb-2" />
                  <span>Achat</span>
                </button>
                <button
                  type="button"
                  onClick={() => setType('sell')}
                  className={cn(
                    "p-4 rounded-lg border transition-colors text-center",
                    type === 'sell'
                      ? "bg-red-600/20 border-red-500/50 text-red-400"
                      : "bg-gray-800/50 border-gray-700/50 text-gray-400 hover:bg-gray-700/50"
                  )}
                >
                  <ArrowDownRight className="w-6 h-6 mx-auto mb-2" />
                  <span>Vente</span>
                </button>
              </div>
            </div>

            {/* P&L Input */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                P&L (Profit/Perte)
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={pnl}
                  onChange={(e) => setPnl(parseFloat(e.target.value) || 0)}
                  className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-10 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                  step="0.01"
                />
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              </div>
              <p className="mt-2 text-sm text-gray-400">
                Pourcentage P&L: {pnlPercentage.toFixed(2)}%
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-end space-x-4">
              <button
                onClick={onClose}
                className="px-6 py-3 text-sm font-medium text-gray-300 bg-gray-800/50 hover:bg-gray-700/50 rounded-lg transition-colors"
              >
                Annuler
              </button>
              <motion.button
                onClick={handleSave}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="relative group px-6 py-3 rounded-lg overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
                <span className="relative flex items-center text-white font-medium">
                  <Check className="w-5 h-5 mr-2" />
                  Enregistrer
                </span>
              </motion.button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export function TradingPositionsModal({ lead, isOpen, onClose, onUpdate }: TradingPositionsModalProps) {
  const [positions, setPositions] = useState<TradingAPIPosition[]>([]);
  const [filteredPositions, setFilteredPositions] = useState<TradingAPIPosition[]>([]);
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'expired'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPosition, setSelectedPosition] = useState<TradingAPIPosition | null>(null);
  const [currentPrice, setCurrentPrice] = useState<number>(3223.455); // Default gold price

  // Initialize positions from lead
  useEffect(() => {
    if (lead.tradingAPIPositions) {
      setPositions(lead.tradingAPIPositions);
      applyFilters(lead.tradingAPIPositions, statusFilter, searchTerm);
    }
  }, [lead]);

  // Apply filters when they change
  useEffect(() => {
    applyFilters(positions, statusFilter, searchTerm);
  }, [statusFilter, searchTerm]);

  // Apply filters to positions
  const applyFilters = (allPositions: TradingAPIPosition[], status: string, search: string) => {
    let filtered = [...allPositions];

    // Apply search filter
    if (search) {
      const searchLower = search.toLowerCase();
      filtered = filtered.filter(p => 
        p.symbol.toLowerCase().includes(searchLower) ||
        p.type.toLowerCase().includes(searchLower)
      );
    }

    // Apply status filter
    if (status === 'active') {
      filtered = filtered.filter(p => p.pnl >= 0);
    } else if (status === 'expired') {
      filtered = filtered.filter(p => p.pnl < 0);
    }

    setFilteredPositions(filtered);
  };

  // Handle position edit
  const handleEditPosition = (position: TradingAPIPosition) => {
    setSelectedPosition(position);
  };

  // Save edited position
  const handleSavePosition = (updatedPosition: TradingAPIPosition) => {
    // Update positions array
    const updatedPositions = positions.map(p => 
      p.id === updatedPosition.id ? updatedPosition : p
    );
    
    setPositions(updatedPositions);
    
    // Update lead
    const updatedLead = {
      ...lead,
      tradingAPIPositions: updatedPositions
    };
    
    onUpdate(updatedLead);
    setSelectedPosition(null);
    
    toast.success('Position mise à jour avec succès');
  };

  // Toggle position type
  const handleTogglePositionType = (position: TradingAPIPosition) => {
    const newType = position.type === 'buy' ? 'sell' : 'buy';
    
    // Update position
    const updatedPosition = {
      ...position,
      type: newType
    };
    
    // Update positions array
    const updatedPositions = positions.map(p => 
      p.id === position.id ? updatedPosition : p
    );
    
    setPositions(updatedPositions);
    
    // Update lead
    const updatedLead = {
      ...lead,
      tradingAPIPositions: updatedPositions
    };
    
    onUpdate(updatedLead);
    
    toast.success(`Type de position changé en ${newType === 'buy' ? 'achat' : 'vente'}`);
  };

  // Invert position P&L
  const handleInvertPnL = (position: TradingAPIPosition) => {
    // Invert P&L
    const updatedPosition = {
      ...position,
      pnl: -position.pnl,
      pnlPercentage: -position.pnlPercentage
    };
    
    // Update positions array
    const updatedPositions = positions.map(p => 
      p.id === position.id ? updatedPosition : p
    );
    
    setPositions(updatedPositions);
    
    // Update lead
    const updatedLead = {
      ...lead,
      tradingAPIPositions: updatedPositions
    };
    
    onUpdate(updatedLead);
    
    toast.success(`P&L inversé avec succès (${position.pnl >= 0 ? 'gain → perte' : 'perte → gain'})`);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-6xl mx-4 max-h-[90vh] overflow-auto"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                Positions Trading API
              </h2>
              <p className="text-gray-400 mt-1">
                Client: {lead.firstName} {lead.lastName}
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-300 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Filters */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
            <div className="relative w-full md:w-64">
              <input
                type="text"
                placeholder="Rechercher..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            </div>
            
            <div className="flex space-x-4">
              <div className="relative">
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as 'all' | 'active' | 'expired')}
                  className="bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-9 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500/50 appearance-none"
                >
                  <option value="all">Tous les statuts</option>
                  <option value="active">Positions en gain</option>
                  <option value="expired">Positions en perte</option>
                </select>
                <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
              </div>
              
              <button
                onClick={() => {
                  // Refresh current price
                  setCurrentPrice(prev => {
                    // Generate a random price change between -5 and +5 dollars
                    const priceChange = (Math.random() * 10 - 5);
                    // Apply the change to the current price
                    return Math.max(2200, Math.min(2250, prev + priceChange));
                  });
                  
                  toast.success('Prix actualisé');
                }}
                className="p-2 rounded-lg bg-gray-800/50 hover:bg-gray-700/50 text-gray-400 hover:text-white transition-colors"
              >
                <RefreshCw className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Positions Table */}
          {filteredPositions.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-700">
                <thead className="bg-gray-800/50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Symbole
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Type
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Montant
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Levier
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Prix d'entrée
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Prix actuel
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      P&L
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Date
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Statut
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-gray-900 divide-y divide-gray-800">
                  <AnimatePresence>
                    {filteredPositions.map((position) => (
                      <motion.tr 
                        key={position.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className="hover:bg-gray-800/50 transition-colors"
                      >
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <BarChart2 className="w-5 h-5 text-yellow-400 mr-2" />
                            <span className="text-white">{position.symbol}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={cn(
                            "px-2 py-1 rounded-full text-xs font-medium",
                            position.type === 'buy' 
                              ? "bg-green-500/10 text-green-400 border border-green-500/20"
                              : "bg-red-500/10 text-red-400 border border-red-500/20"
                          )}>
                            {position.type === 'buy' ? 'Achat' : 'Vente'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="text-white">{formatPrice(position.amount)}€</span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="text-white">x{position.leverage}</span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="text-white">${position.entryPrice.toFixed(2)}</span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="text-white">${position.currentPrice.toFixed(2)}</span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex flex-col">
                            <div className={cn(
                              "flex items-center",
                              position.pnl >= 0 ? "text-green-400" : "text-red-400"
                            )}>
                              {position.pnl >= 0 ? (
                                <TrendingUp className="w-4 h-4 mr-1" />
                              ) : (
                                <TrendingDown className="w-4 h-4 mr-1" />
                              )}
                              <span className="font-medium">
                                {position.pnl >= 0 ? '+' : ''}{formatPrice(position.pnl)}€
                              </span>
                            </div>
                            <span className={cn(
                              "text-xs",
                              position.pnlPercentage >= 0 ? "text-green-400" : "text-red-400"
                            )}>
                              {position.pnlPercentage >= 0 ? '+' : ''}{position.pnlPercentage.toFixed(2)}%
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="text-gray-400 text-sm">
                            {formatDateTime(position.dateCreated)}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-500/20 text-blue-400 border border-blue-500/30">
                            Position en cours
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex space-x-2">
                            <button
                              onClick={() => handleTogglePositionType(position)}
                              className={cn(
                                "p-1.5 rounded-md transition-colors",
                                position.type === 'buy' 
                                  ? "bg-red-500/20 text-red-400 hover:bg-red-500/30" 
                                  : "bg-green-500/20 text-green-400 hover:bg-green-500/30"
                              )}
                              title={`Changer en ${position.type === 'buy' ? 'vente' : 'achat'}`}
                            >
                              {position.type === 'buy' ? (
                                <ArrowDownRight className="w-4 h-4" />
                              ) : (
                                <ArrowUpRight className="w-4 h-4" />
                              )}
                            </button>
                            <button
                              onClick={() => handleInvertPnL(position)}
                              className={cn(
                                "p-1.5 rounded-md transition-colors",
                                position.pnl >= 0 
                                  ? "bg-red-500/20 text-red-400 hover:bg-red-500/30" 
                                  : "bg-green-500/20 text-green-400 hover:bg-green-500/30"
                              )}
                              title={`Inverser le P&L (${position.pnl >= 0 ? 'gain → perte' : 'perte → gain'})`}
                            >
                              {position.pnl >= 0 ? (
                                <TrendingDown className="w-4 h-4" />
                              ) : (
                                <TrendingUp className="w-4 h-4" />
                              )}
                            </button>
                            <button
                              onClick={() => handleEditPosition(position)}
                              className="p-1.5 bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 rounded-md transition-colors"
                              title="Modifier la position"
                            >
                              <Activity className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </motion.tr>
                    ))}
                  </AnimatePresence>
                </tbody>
              </table>
            </div>
          ) : (
            <div className="text-center py-12 bg-gray-800/30 rounded-lg border border-gray-700/50">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-800/50 backdrop-blur-xl mb-4">
                <AlertCircle className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-xl font-medium text-gray-300">
                Aucune position trouvée
              </h3>
              <p className="text-gray-500 max-w-sm mx-auto mt-2">
                {searchTerm || statusFilter !== 'all' 
                  ? "Aucune position ne correspond à vos critères de recherche. Essayez de modifier vos filtres."
                  : "Ce client n'a pas encore de positions de trading API."}
              </p>
            </div>
          )}
        </div>
      </motion.div>

      {/* Edit Position Modal */}
      <AnimatePresence>
        {selectedPosition && (
          <EditPositionModal
            position={selectedPosition}
            isOpen={true}
            onClose={() => setSelectedPosition(null)}
            onSave={handleSavePosition}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

// Format date for display
function formatDateTime(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
}