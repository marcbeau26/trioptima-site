import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Edit2, Check, RotateCcw, Info } from 'lucide-react';
import { useCopyright } from '../../../contexts/CopyrightContext';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';

export function CopyrightSettings() {
  const { companyName, year, updateCopyright } = useCopyright();
  const [isEditing, setIsEditing] = useState(false);
  const [editCompanyName, setEditCompanyName] = useState(companyName);
  const [editYear, setEditYear] = useState(year);

  const handleSave = () => {
    updateCopyright(editCompanyName, editYear);
    setIsEditing(false);
    toast.success('Texte de copyright mis à jour avec succès');
  };

  const handleReset = () => {
    setEditCompanyName('AvaTrade');
    setEditYear('2025');
    updateCopyright('AvaTrade', '2025');
    toast.success('Texte de copyright réinitialisé');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative"
    >
      {/* Background effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
      <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
      
      {/* Content */}
      <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
        <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-6">
          Paramètres du Copyright
        </h2>

        <div className="space-y-6">
          {/* Current Copyright Display */}
          <div className="bg-gray-800/50 border border-gray-700/50 rounded-lg p-6">
            <h3 className="text-lg font-medium text-white mb-4">
              Texte de copyright actuel
            </h3>
            <div className="flex items-center justify-between">
              <div className="text-gray-300 text-lg">
                © {year} {companyName}. Tous droits réservés.
              </div>
              <button
                onClick={() => setIsEditing(true)}
                className="p-2 text-blue-400 hover:text-blue-300 transition-colors rounded-lg hover:bg-blue-900/20"
              >
                <Edit2 className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Edit Form */}
          {isEditing && (
            <div className="bg-gray-800/50 border border-gray-700/50 rounded-lg p-6">
              <h3 className="text-lg font-medium text-white mb-4">
                Modifier le texte de copyright
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Année
                  </label>
                  <input
                    type="text"
                    value={editYear}
                    onChange={(e) => setEditYear(e.target.value)}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200"
                    )}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Nom de la société
                  </label>
                  <input
                    type="text"
                    value={editCompanyName}
                    onChange={(e) => setEditCompanyName(e.target.value)}
                    className={cn(
                      "w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3",
                      "focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500/50",
                      "placeholder-gray-500 backdrop-blur-sm transition-all duration-200"
                    )}
                  />
                </div>
                <div className="flex justify-end space-x-4">
                  <button
                    onClick={() => setIsEditing(false)}
                    className="px-4 py-2 text-sm font-medium text-gray-300 bg-gray-800/50 hover:bg-gray-700/50 rounded-lg transition-colors"
                  >
                    Annuler
                  </button>
                  <motion.button
                    onClick={handleSave}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="relative group px-4 py-2 rounded-lg overflow-hidden"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
                    <span className="relative flex items-center text-white text-sm">
                      <Check className="w-4 h-4 mr-2" />
                      Enregistrer
                    </span>
                  </motion.button>
                </div>
              </div>
            </div>
          )}

          {/* Information Section */}
          <div className="bg-blue-900/20 border border-blue-500/20 rounded-lg p-4">
            <div className="flex items-center mb-2">
              <Info className="w-5 h-5 text-blue-400 mr-2" />
              <h4 className="text-blue-400 font-medium">Information</h4>
            </div>
            <p className="text-blue-300 text-sm">
              Le texte de copyright sera affiché en bas de toutes les pages du site, y compris la page d'accueil, 
              le panel administrateur, le panel vendeur et l'interface client. Les modifications sont appliquées 
              instantanément sur toutes les interfaces.
            </p>
          </div>

          {/* Reset Button */}
          <div className="flex justify-end">
            <motion.button
              onClick={handleReset}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="relative group px-4 py-2 rounded-lg overflow-hidden"
            >
              <div className="absolute inset-0 bg-gray-700 opacity-80 group-hover:opacity-100 transition-opacity" />
              <span className="relative flex items-center text-white text-sm">
                <RotateCcw className="w-4 h-4 mr-2" />
                Réinitialiser
              </span>
            </motion.button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}