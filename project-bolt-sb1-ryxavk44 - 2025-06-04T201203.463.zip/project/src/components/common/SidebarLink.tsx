import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';
import { cn } from '../../utils/cn';

interface SidebarLinkProps {
  icon: LucideIcon;
  text: string;
  isActive?: boolean;
  onClick?: () => void;
  variant?: 'default' | 'danger';
}

const SidebarLink: React.FC<SidebarLinkProps> = ({ 
  icon: Icon, 
  text, 
  isActive = false, 
  onClick,
  variant = 'default'
}) => {
  const baseClasses = "flex items-center space-x-2 w-full px-4 py-3 text-sm";
  const variantClasses = {
    default: isActive 
      ? 'text-blue-600 bg-blue-50 border-l-4 border-blue-600 bg-gray-700 text-blue-400'
      : 'text-gray-300 hover:bg-gray-700 hover:text-white',
    danger: 'text-red-600 hover:bg-red-900/20 text-red-400 hover:bg-red-900/20'
  };

  return (
    <button
      onClick={onClick}
      className={cn(baseClasses, variantClasses[variant])}
    >
      <Icon size={20} />
      <span>{text}</span>
    </button>
  );
};

export default React.memo(SidebarLink);