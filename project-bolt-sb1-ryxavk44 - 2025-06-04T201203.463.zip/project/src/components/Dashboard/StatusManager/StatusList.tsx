import React, { useState } from 'react';
import { Trash2, Edit2 } from 'lucide-react';
import type { Status } from '../../../types';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { formatDate } from '../../../utils';

interface EditStatusModalProps {
  status: Status;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedStatus: Status) => void;
  existingColors: string[];
}

function EditStatusModal({ status, isOpen, onClose, onSave, existingColors }: EditStatusModalProps) {
  const [editedStatus, setEditedStatus] = useState(status);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-8 max-w-md w-full">
        <h2 className="text-2xl font-bold mb-6 text-gray-900 dark:text-white">Modifier le statut</h2>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Nom du statut
            </label>
            <input
              type="text"
              value={editedStatus.name}
              onChange={(e) => setEditedStatus({ ...editedStatus, name: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Couleur
            </label>
            <input
              type="color"
              value={editedStatus.color}
              onChange={(e) => setEditedStatus({ ...editedStatus, color: e.target.value })}
              className="mt-1 block w-full h-10 rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
          {existingColors.length > 0 && (
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                Couleurs existantes
              </label>
              <select
                value={editedStatus.color}
                onChange={(e) => setEditedStatus({ ...editedStatus, color: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
              >
                <option value="">Sélectionner une couleur existante</option>
                {existingColors.map((color) => (
                  <option key={color} value={color}>
                    {color}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
        <div className="mt-6 flex space-x-4">
          <button
            onClick={() => onSave(editedStatus)}
            className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
          >
            Enregistrer
          </button>
          <button
            onClick={onClose}
            className="flex-1 bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-200 py-2 px-4 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
          >
            Annuler
          </button>
        </div>
      </div>
    </div>
  );
}

export function StatusList() {
  const [statuses, setStatuses] = useLocalStorage<Status[]>('statuses', []);
  const [selectedStatuses, setSelectedStatuses] = useState<string[]>([]);
  const [editingStatus, setEditingStatus] = useState<Status | null>(null);

  const existingColors = [...new Set(statuses.map(status => status.color))];

  const toggleSelectAll = () => {
    if (selectedStatuses.length === statuses.length) {
      setSelectedStatuses([]);
    } else {
      setSelectedStatuses(statuses.map(status => status.id));
    }
  };

  const toggleStatus = (statusId: string) => {
    if (selectedStatuses.includes(statusId)) {
      setSelectedStatuses(selectedStatuses.filter(id => id !== statusId));
    } else {
      setSelectedStatuses([...selectedStatuses, statusId]);
    }
  };

  const handleDelete = () => {
    setStatuses(statuses.filter(status => !selectedStatuses.includes(status.id)));
    setSelectedStatuses([]);
  };

  const handleEdit = (status: Status) => {
    setEditingStatus(status);
  };

  const handleSaveEdit = (updatedStatus: Status) => {
    setStatuses(statuses.map(status => 
      status.id === updatedStatus.id ? updatedStatus : status
    ));
    setEditingStatus(null);
  };

  return (
    <div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-800">
            <tr>
              <th scope="col" className="px-6 py-3 text-left">
                <input
                  type="checkbox"
                  checked={selectedStatuses.length === statuses.length && statuses.length > 0}
                  onChange={toggleSelectAll}
                  className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700"
                />
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Nom
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Couleur
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Date de création
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200 dark:bg-gray-900 dark:divide-gray-700">
            {statuses.map((status) => (
              <tr key={status.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <input
                    type="checkbox"
                    checked={selectedStatuses.includes(status.id)}
                    onChange={() => toggleStatus(status.id)}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 dark:border-gray-600 dark:bg-gray-700"
                  />
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-3 py-1 rounded-full text-sm" style={{ backgroundColor: status.color }}>
                    {status.name}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center space-x-2">
                    <div className="w-6 h-6 rounded" style={{ backgroundColor: status.color }}></div>
                    <span className="text-gray-900 dark:text-gray-300">{status.color}</span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-gray-900 dark:text-gray-300">
                  {formatDate(status.dateCreated)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <button
                    onClick={() => handleEdit(status)}
                    className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                  >
                    <Edit2 size={16} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedStatuses.length > 0 && (
        <div className="mt-4">
          <button
            onClick={handleDelete}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 dark:focus:ring-offset-gray-800"
          >
            <Trash2 size={16} className="mr-2" />
            Supprimer ({selectedStatuses.length})
          </button>
        </div>
      )}

      {editingStatus && (
        <EditStatusModal
          status={editingStatus}
          isOpen={true}
          onClose={() => setEditingStatus(null)}
          onSave={handleSaveEdit}
          existingColors={existingColors}
        />
      )}
    </div>
  );
}