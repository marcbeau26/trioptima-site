import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, Trash2, UserCheck, MessageSquare, LogIn, Wallet, FileText, Users, Calendar, Hash, DollarSign, 
  Phone, Mail, User, TrendingUp, TrendingDown, Filter, Eye, Activity
} from 'lucide-react';
import type { Lead } from '../../../../types';
import { useLocalStorage } from '../../../../hooks/useLocalStorage';
import { formatDate } from '../../../../utils';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { cn } from '../../../../utils/cn';
import { BalanceModal } from '../LeadDetails/BalanceModal';
import { TradingPositionsModal } from '../TradingPositionsModal';

interface SearchFilters {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  assignedUserId?: string;
}

interface ReassignModalProps {
  isOpen: boolean;
  onClose: () => void;
  onReassign: (userId: string) => void;
  users: UserType[];
  currentAssignedUserId?: string;
  selectedLeads?: Lead[];
  multiSelect?: boolean;
}

function ReassignModal({ isOpen, onClose, onReassign, users, currentAssignedUserId, selectedLeads, multiSelect = false }: ReassignModalProps) {
  const [selectedUser, setSelectedUser] = useState('');

  if (!isOpen) return null;

  // Add admin@plate.com as a special option if not already in the users list
  const hasAdminOption = users.some(u => u.email === 'admin@plate.com');
  
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative w-full max-w-lg mx-4"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-6">
            {multiSelect 
              ? `Réassigner ${selectedLeads?.length} lead${selectedLeads?.length !== 1 ? 's' : ''}`
              : 'Réassigner le lead'}
          </h2>

          {selectedLeads && selectedLeads.length > 0 && (
            <div className="mb-6 bg-gray-800/50 border border-white/5 rounded-xl p-4">
              <h3 className="text-lg font-medium text-white mb-2">Leads sélectionnés</h3>
              <div className="max-h-32 overflow-y-auto custom-scrollbar">
                <ul className="space-y-1">
                  {selectedLeads.map(lead => (
                    <li key={lead.id} className="text-gray-300 text-sm">
                      {lead.firstName} {lead.lastName} ({lead.email})
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Sélectionner un nouvel utilisateur
              </label>
              <select
                value={selectedUser}
                onChange={(e) => setSelectedUser(e.target.value)}
                className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              >
                <option value="">Choisir un utilisateur...</option>
                {/* Add admin@plate.com as a special option if not already in the list */}
                {!hasAdminOption && (
                  <option value="admin@plate.com">Admin (admin@plate.com)</option>
                )}
                {users
                  .filter(user => multiSelect || user.id !== currentAssignedUserId)
                  .map(user => (
                    <option key={user.id} value={user.id}>
                      {user.firstName} {user.lastName} ({user.role})
                    </option>
                  ))}
              </select>
            </div>

            <div className="flex justify-end space-x-4">
              <button
                onClick={onClose}
                className="px-6 py-3 text-sm font-medium text-gray-300 bg-gray-800/50 hover:bg-gray-700/50 rounded-lg transition-colors"
              >
                Annuler
              </button>
              <motion.button
                onClick={() => {
                  if (selectedUser) {
                    onReassign(selectedUser);
                    onClose();
                  }
                }}
                disabled={!selectedUser}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="relative group px-6 py-3 rounded-lg overflow-hidden disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
                <span className="relative text-white font-medium">
                  Réassigner
                </span>
              </motion.button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export function AssignedLeads() {
  const navigate = useNavigate();
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [users] = useLocalStorage<UserType[]>('users', []);
  const [searchFilters, setSearchFilters] = useState<SearchFilters>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    assignedUserId: '',
  });
  const [selectedLeads, setSelectedLeads] = useState<string[]>([]);
  const [showReassignModal, setShowReassignModal] = useState(false);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [showMultiReassignModal, setShowMultiReassignModal] = useState(false);
  const [selectedLeadForBalance, setSelectedLeadForBalance] = useState<Lead | null>(null);
  const [selectedLeadForPositions, setSelectedLeadForPositions] = useState<Lead | null>(null);

  // Get all leads that are assigned to users and are not registrations
  const assignedLeads = leads.filter(lead => 
    lead.assignedTo && 
    (!lead.isRegistration || lead.registrationStatus === 'approved')
  );

  const handleSearchChange = (field: keyof SearchFilters, value: string) => {
    setSearchFilters(prev => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleLeadLogin = (lead: Lead) => {
    localStorage.setItem('currentLead', JSON.stringify(lead));
    navigate(`/client/${lead.id}`, { replace: true });
  };

  const handleViewDetails = (leadId: string) => {
    navigate(`/leads/${leadId}`);
  };

  const getAssignedUserName = (userId: string) => {
    const user = users.find(u => u.id === userId);
    return user ? `${user.firstName} ${user.lastName}` : 'Utilisateur inconnu';
  };

  const handleReassign = (userId: string) => {
    if (!selectedLead) return;

    // Special case for admin@plate.com
    if (userId === 'admin@plate.com') {
      // Find admin user or create a placeholder
      const adminUser = users.find(u => u.email === 'admin@plate.com') || {
        id: 'admin-user',
        firstName: 'Admin',
        lastName: 'User',
        email: 'admin@plate.com',
        role: 'Admin'
      };
      
      const updatedLeads = leads.map(lead => {
        if (lead.id === selectedLead.id) {
          return {
            ...lead,
            assignedTo: adminUser.id
          };
        }
        return lead;
      });

      setLeads(updatedLeads);
      setSelectedLead(null);
      
      toast.success(`Lead réassigné à ${adminUser.firstName} ${adminUser.lastName}`);
      return;
    }

    const updatedLeads = leads.map(lead => {
      if (lead.id === selectedLead.id) {
        return {
          ...lead,
          assignedTo: userId
        };
      }
      return lead;
    });

    setLeads(updatedLeads);
    setSelectedLead(null);
    
    const newUser = users.find(u => u.id === userId);
    if (newUser) {
      toast.success(`Lead réassigné à ${newUser.firstName} ${newUser.lastName}`);
    }
  };

  const handleMultiReassign = (userId: string) => {
    if (selectedLeads.length === 0) return;

    // Special case for admin@plate.com
    if (userId === 'admin@plate.com') {
      // Find admin user or create a placeholder
      const adminUser = users.find(u => u.email === 'admin@plate.com') || {
        id: 'admin-user',
        firstName: 'Admin',
        lastName: 'User',
        email: 'admin@plate.com',
        role: 'Admin'
      };
      
      const updatedLeads = leads.map(lead => {
        if (selectedLeads.includes(lead.id)) {
          return {
            ...lead,
            assignedTo: adminUser.id
          };
        }
        return lead;
      });

      setLeads(updatedLeads);
      setSelectedLeads([]);
      
      toast.success(`${selectedLeads.length} lead${selectedLeads.length > 1 ? 's' : ''} réassigné${selectedLeads.length > 1 ? 's' : ''} à ${adminUser.firstName} ${adminUser.lastName}`);
      return;
    }

    const updatedLeads = leads.map(lead => {
      if (selectedLeads.includes(lead.id)) {
        return {
          ...lead,
          assignedTo: userId
        };
      }
      return lead;
    });

    setLeads(updatedLeads);
    setSelectedLeads([]);
    
    const newUser = users.find(u => u.id === userId);
    if (newUser) {
      toast.success(`${selectedLeads.length} lead${selectedLeads.length > 1 ? 's' : ''} réassigné${selectedLeads.length > 1 ? 's' : ''} à ${newUser.firstName} ${newUser.lastName}`);
    }
  };

  const handleDeleteLeads = () => {
    if (selectedLeads.length === 0) return;

    const updatedLeads = leads.map(lead => {
      if (selectedLeads.includes(lead.id)) {
        // Remove assignedTo field instead of deleting the lead
        const { assignedTo, ...rest } = lead;
        return rest;
      }
      return lead;
    });

    setLeads(updatedLeads);
    setSelectedLeads([]);
    toast.success(`${selectedLeads.length} lead${selectedLeads.length > 1 ? 's' : ''} supprimé${selectedLeads.length > 1 ? 's' : ''}`);
  };

  const toggleSelectAll = () => {
    if (selectedLeads.length === filteredLeads.length) {
      setSelectedLeads([]);
    } else {
      setSelectedLeads(filteredLeads.map(lead => lead.id));
    }
  };

  const toggleLead = (leadId: string) => {
    if (selectedLeads.includes(leadId)) {
      setSelectedLeads(selectedLeads.filter(id => id !== leadId));
    } else {
      setSelectedLeads([...selectedLeads, leadId]);
    }
  };

  const handleViewTradingPositions = (lead: Lead) => {
    setSelectedLeadForPositions(lead);
  };

  // Filter leads based on search criteria and assigned user
  const filteredLeads = assignedLeads.filter(lead => {
    const matchFirstName = lead.firstName.toLowerCase().includes(searchFilters.firstName.toLowerCase());
    const matchLastName = lead.lastName.toLowerCase().includes(searchFilters.lastName.toLowerCase());
    const matchEmail = lead.email.toLowerCase().includes(searchFilters.email.toLowerCase());
    const matchPhone = lead.phone.includes(searchFilters.phone);
    const matchAssignedUser = !searchFilters.assignedUserId || lead.assignedTo === searchFilters.assignedUserId;

    return matchFirstName && matchLastName && matchEmail && matchPhone && matchAssignedUser;
  });

  return (
    <div className="space-y-6">
      {/* Search Filters with Futuristic Design */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative mb-6"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/10 to-pink-500/10 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/80 backdrop-blur-xl border border-white/10 rounded-xl p-6">
          <h2 className="text-xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-4">
            Recherche de leads
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <User className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                value={searchFilters.firstName}
                onChange={(e) => handleSearchChange('firstName', e.target.value)}
                placeholder="Prénom..."
                className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-10 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>
            
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <User className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                value={searchFilters.lastName}
                onChange={(e) => handleSearchChange('lastName', e.target.value)}
                placeholder="Nom..."
                className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-10 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>
            
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Mail className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                value={searchFilters.email}
                onChange={(e) => handleSearchChange('email', e.target.value)}
                placeholder="Email..."
                className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-10 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>
            
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Phone className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                value={searchFilters.phone}
                onChange={(e) => handleSearchChange('phone', e.target.value)}
                placeholder="Téléphone..."
                className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-10 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              />
            </div>
          </div>
          
          <div className="mt-4">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Users className="h-5 w-5 text-gray-400" />
              </div>
              <select
                value={searchFilters.assignedUserId || ''}
                onChange={(e) => handleSearchChange('assignedUserId', e.target.value)}
                className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg pl-10 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50 appearance-none"
              >
                <option value="">Tous les utilisateurs</option>
                {users.map(user => (
                  <option key={user.id} value={user.id}>
                    {user.firstName} {user.lastName} ({user.role})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Leads Table with Futuristic Design */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="relative"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/5 to-pink-500/5 rounded-xl blur-xl"></div>
        
        {/* Content */}
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-800">
              <thead className="bg-gray-800/70">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left">
                    <input
                      type="checkbox"
                      checked={selectedLeads.length === filteredLeads.length && filteredLeads.length > 0}
                      onChange={toggleSelectAll}
                      className="rounded border-gray-600 text-blue-500 focus:ring-blue-500 bg-gray-700"
                    />
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 mr-2" />
                      Date d'entrée
                    </div>
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    <div className="flex items-center">
                      <User className="w-4 h-4 mr-2" />
                      Nom
                    </div>
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    <div className="flex items-center">
                      <Mail className="w-4 h-4 mr-2" />
                      Email
                    </div>
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    <div className="flex items-center">
                      <Phone className="w-4 h-4 mr-2" />
                      Téléphone
                    </div>
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Assigné à
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    <div className="flex items-center">
                      <DollarSign className="w-4 h-4 mr-2" />
                      Solde
                    </div>
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800">
                {filteredLeads.map((lead) => (
                  <tr key={lead.id} className="hover:bg-gray-800/50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <input
                        type="checkbox"
                        checked={selectedLeads.includes(lead.id)}
                        onChange={() => toggleLead(lead.id)}
                        className="rounded border-gray-600 text-blue-500 focus:ring-blue-500 bg-gray-700"
                      />
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 text-gray-400 mr-2" />
                        <span className="text-sm text-gray-300">{formatDate(lead.dateCreated)}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10">
                          <div className="h-10 w-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                            <User className="h-5 w-5 text-white" />
                          </div>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-white">
                            {lead.firstName} {lead.lastName}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Mail className="w-4 h-4 text-gray-400 mr-2" />
                        <span className="text-sm text-gray-300">{lead.email}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <Phone className="w-4 h-4 text-gray-400 mr-2" />
                        <span className="text-sm text-gray-300">{lead.phone}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 mr-2">
                          {getAssignedUserName(lead.assignedTo!)}
                        </span>
                        <button
                          onClick={() => {
                            setSelectedLead(lead);
                            setShowReassignModal(true);
                          }}
                          className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                          title="Réassigner le lead"
                        >
                          <Users size={16} />
                        </button>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-2">
                        <span className={cn(
                          "text-sm font-medium",
                          (lead.balance || 0) > 0 ? "text-green-400" : "text-gray-300"
                        )}>
                          {(lead.balance || 0).toLocaleString()}€
                        </span>
                        <button
                          onClick={() => setSelectedLeadForBalance(lead)}
                          className="p-1 text-gray-400 hover:text-blue-400 transition-colors rounded-md hover:bg-blue-500/10"
                          title="Gérer le solde"
                        >
                          <Wallet size={16} />
                        </button>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handleViewDetails(lead.id)}
                          className="p-1.5 text-gray-400 hover:text-blue-400 transition-colors rounded-md hover:bg-blue-500/10"
                          title="Voir la fiche"
                        >
                          <Eye size={16} />
                        </button>
                        <button
                          onClick={() => handleLeadLogin(lead)}
                          className="p-1.5 text-gray-400 hover:text-blue-400 transition-colors rounded-md hover:bg-blue-500/10"
                          title="Se connecter en tant que lead"
                        >
                          <LogIn size={16} />
                        </button>
                        <button
                          onClick={() => handleViewTradingPositions(lead)}
                          className="p-1.5 text-gray-400 hover:text-blue-400 transition-colors rounded-md hover:bg-blue-500/10"
                          title="Gérer les positions Trading API"
                        >
                          <Activity size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {filteredLeads.length === 0 && (
              <div className="text-center py-12">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-800/50 backdrop-blur-xl mb-4">
                  <Search className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-300 mb-2">
                  Aucun lead trouvé
                </h3>
                <p className="text-gray-500 max-w-md mx-auto">
                  Essayez de modifier vos critères de recherche ou d'ajouter de nouveaux leads.
                </p>
              </div>
            )}
          </div>
        </div>
      </motion.div>

      {/* Selected Leads Actions */}
      {selectedLeads.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed bottom-8 left-1/2 transform -translate-x-1/2 z-10"
        >
          <div className="relative">
            <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl blur opacity-75"></div>
            <div className="relative bg-gray-900 rounded-lg p-4 flex space-x-4">
              <motion.button
                onClick={() => setShowMultiReassignModal(true)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-800"
              >
                <UserCheck size={16} className="mr-2" />
                Réassigner ({selectedLeads.length})
              </motion.button>
              <motion.button
                onClick={handleDeleteLeads}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 dark:focus:ring-offset-gray-800"
              >
                <Trash2 size={16} className="mr-2" />
                Supprimer ({selectedLeads.length})
              </motion.button>
            </div>
          </div>
        </motion.div>
      )}

      {/* Reassign Modal */}
      {selectedLead && (
        <ReassignModal
          isOpen={showReassignModal}
          onClose={() => {
            setShowReassignModal(false);
            setSelectedLead(null);
          }}
          onReassign={handleReassign}
          users={users}
          currentAssignedUserId={selectedLead.assignedTo}
          selectedLeads={[selectedLead]}
          multiSelect={false}
        />
      )}

      {/* Multi Reassign Modal */}
      {showMultiReassignModal && (
        <ReassignModal
          isOpen={showMultiReassignModal}
          onClose={() => setShowMultiReassignModal(false)}
          onReassign={handleMultiReassign}
          users={users}
          selectedLeads={leads.filter(lead => selectedLeads.includes(lead.id))}
          multiSelect={true}
        />
      )}

      {/* Balance Modal */}
      {selectedLeadForBalance && (
        <BalanceModal
          lead={selectedLeadForBalance}
          isOpen={true}
          onClose={() => setSelectedLeadForBalance(null)}
          onUpdate={(updatedLead) => {
            const updatedLeads = leads.map(lead => 
              lead.id === updatedLead.id ? updatedLead : lead
            );
            setLeads(updatedLeads);
            setSelectedLeadForBalance(null);
          }}
        />
      )}

      {/* Trading Positions Modal */}
      {selectedLeadForPositions && (
        <TradingPositionsModal
          lead={selectedLeadForPositions}
          isOpen={true}
          onClose={() => setSelectedLeadForPositions(null)}
          onUpdate={(updatedLead) => {
            const updatedLeads = leads.map(lead => 
              lead.id === updatedLead.id ? updatedLead : lead
            );
            setLeads(updatedLeads);
            setSelectedLeadForPositions(null);
          }}
        />
      )}
    </div>
  );
}