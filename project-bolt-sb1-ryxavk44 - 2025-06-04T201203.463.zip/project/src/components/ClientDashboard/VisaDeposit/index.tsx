import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  CreditCard, Calendar, Lock, X, Loader2, Shield, 
  ChevronRight, Info, Check, ChevronsUp, AlertCircle,
  Wallet, DollarSign, Euro
} from 'lucide-react';
import { toast } from 'react-hot-toast';
import type { Lead, Transaction, DepositRequest } from '../../../types';
import { generateId } from '../../../utils';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { cn } from '../../../utils/cn';

interface CardPaymentProps {
  onClose: () => void;
  onSuccess: (amount: number, cardHolder: string, cardNumber: string, expiryDate: string, cvv: string) => void;
}

function CardPayment({ onClose, onSuccess }: CardPaymentProps) {
  const [cardNumber, setCardNumber] = useState('');
  const [cardHolder, setCardHolder] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');
  const [amount, setAmount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [focusedField, setFocusedField] = useState<string | null>(null);

  const formatCardNumber = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    const groups = numbers.match(/.{1,4}/g) || [];
    return groups.join(' ').substr(0, 19);
  };

  const formatExpiry = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length >= 2) {
      return `${numbers.slice(0, 2)}/${numbers.slice(2, 4)}`;
    }
    return numbers;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    if (!cardNumber || !cardHolder || !expiry || !cvv || !amount) {
      toast.error('Veuillez remplir tous les champs');
      return;
    }
    
    if (cardNumber.replace(/\s/g, '').length !== 16) {
      toast.error('Numéro de carte invalide');
      return;
    }
    
    if (!/^\d{2}\/\d{2}$/.test(expiry)) {
      toast.error('Date d\'expiration invalide');
      return;
    }
    
    if (cvv.length !== 3) {
      toast.error('CVV invalide');
      return;
    }
    
    const amountValue = parseFloat(amount);
    if (isNaN(amountValue) || amountValue <= 0) {
      toast.error('Montant invalide');
      return;
    }
    
    setIsProcessing(true);

    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsProcessing(false);
    setShowConfirmation(true);
    
    // Call the success callback with all card details
    onSuccess(amountValue, cardHolder, cardNumber, expiry, cvv);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <AnimatePresence mode="wait">
        {!showConfirmation ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="relative w-full max-w-lg"
          >
            {/* Animated background effects */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-2xl blur-2xl animate-pulse"></div>
            <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-2xl blur-xl animate-pulse" style={{ animationDelay: '0.5s' }}></div>
            
            {/* Main content */}
            <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-2xl overflow-hidden">
              {/* Animated border */}
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-50 animate-gradient-x"></div>
              <div className="absolute inset-[1px] bg-gray-900 rounded-2xl"></div>

              {/* Content */}
              <div className="relative">
                {/* Header */}
                <div className="p-6 flex justify-between items-center border-b border-white/10">
                  <div className="space-y-1">
                    <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                      Paiement par carte Visa
                    </h2>
                  </div>
                  <button
                    onClick={onClose}
                    className="text-gray-400 hover:text-white transition-colors"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <form onSubmit={handleSubmit} className="p-6 space-y-6">
                  {/* Amount input */}
                  <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Montant à déposer
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Euro className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="number"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        className="block w-full pl-10 pr-3 py-3 bg-gray-800/50 text-white border border-gray-700/50 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/50 placeholder-gray-500"
                        placeholder="Montant"
                        required
                        min="1"
                        step="any"
                      />
                    </div>
                  </div>

                  {/* Card number */}
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-gray-300">
                      Numéro de carte
                    </label>
                    <div className={`relative group ${
                      focusedField === 'cardNumber' ? 'animate-pulse' : ''
                    }`}>
                      <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg blur opacity-75 group-hover:opacity-100 transition duration-1000"></div>
                      <div className="relative bg-gray-900 rounded-lg border border-white/10">
                        <input
                          type="text"
                          value={cardNumber}
                          onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                          onFocus={() => setFocusedField('cardNumber')}
                          onBlur={() => setFocusedField(null)}
                          className="w-full bg-transparent text-white pl-12 pr-4 py-3 rounded-lg focus:outline-none"
                          placeholder="**** **** **** ****"
                          maxLength={19}
                          required
                        />
                        <CreditCard className="absolute left-4 top-1/2 transform -translate-y-1/2 text-blue-400" />
                      </div>
                    </div>
                  </div>

                  {/* Card holder */}
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-gray-300">
                      Titulaire de la carte
                    </label>
                    <div className={`relative group ${
                      focusedField === 'cardHolder' ? 'animate-pulse' : ''
                    }`}>
                      <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg blur opacity-75 group-hover:opacity-100 transition duration-1000"></div>
                      <input
                        type="text"
                        value={cardHolder}
                        onChange={(e) => setCardHolder(e.target.value.toUpperCase())}
                        onFocus={() => setFocusedField('cardHolder')}
                        onBlur={() => setFocusedField(null)}
                        className="relative w-full bg-gray-900 text-white px-4 py-3 rounded-lg border border-white/10 focus:outline-none"
                        placeholder="NOM PRÉNOM"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    {/* Expiry date */}
                    <div className="space-y-2">
                      <label className="block text-sm font-medium text-gray-300">
                        Date d'expiration
                      </label>
                      <div className={`relative group ${
                        focusedField === 'expiry' ? 'animate-pulse' : ''
                      }`}>
                        <div className="absolute -inset-0.5 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-lg blur opacity-75 group-hover:opacity-100 transition duration-1000"></div>
                        <div className="relative bg-gray-900 rounded-lg border border-white/10">
                          <input
                            type="text"
                            value={expiry}
                            onChange={(e) => setExpiry(formatExpiry(e.target.value))}
                            onFocus={() => setFocusedField('expiry')}
                            onBlur={() => setFocusedField(null)}
                            className="w-full bg-transparent text-white pl-12 pr-4 py-3 rounded-lg focus:outline-none"
                            placeholder="MM/YY"
                            maxLength={5}
                            required
                          />
                          <Calendar className="absolute left-4 top-1/2 transform -translate-y-1/2 text-cyan-400" />
                        </div>
                      </div>
                    </div>

                    {/* CVV */}
                    <div className="space-y-2">
                      <label className="block text-sm font-medium text-gray-300">
                        CVV
                      </label>
                      <div className={`relative group ${
                        focusedField === 'cvv' ? 'animate-pulse' : ''
                      }`}>
                        <div className="absolute -inset-0.5 bg-gradient-to-r from-pink-500 to-purple-500 rounded-lg blur opacity-75 group-hover:opacity-100 transition duration-1000"></div>
                        <div className="relative bg-gray-900 rounded-lg border border-white/10">
                          <input
                            type="text"
                            value={cvv}
                            onChange={(e) => setCvv(e.target.value.replace(/\D/g, '').slice(0, 3))}
                            onFocus={() => setFocusedField('cvv')}
                            onBlur={() => setFocusedField(null)}
                            className="w-full bg-transparent text-white pl-12 pr-4 py-3 rounded-lg focus:outline-none"
                            placeholder="***"
                            maxLength={3}
                            required
                          />
                          <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-pink-400" />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Payment methods */}
                  <div className="flex items-center justify-center space-x-8 py-4">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" alt="Visa" className="h-8 opacity-70 hover:opacity-100 transition-opacity" />
                    <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" alt="Mastercard" className="h-8 opacity-70 hover:opacity-100 transition-opacity" />
                  </div>

                  {/* Security notice */}
                  <div className="bg-blue-900/20 border border-blue-500/20 rounded-lg p-3">
                    <div className="flex items-center mb-2">
                      <Info className="w-5 h-5 text-blue-400 mr-2" />
                      <h5 className="text-sm font-medium text-blue-400">Paiement sécurisé</h5>
                    </div>
                    <p className="text-sm text-blue-300">
                      Toutes vos informations de paiement sont cryptées et sécurisées. Nous ne stockons pas les détails de votre carte.
                    </p>
                  </div>

                  {/* Submit button */}
                  <motion.button
                    type="submit"
                    disabled={isProcessing}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="relative w-full group overflow-hidden rounded-xl"
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity animate-gradient-x"></div>
                    <div className="relative flex items-center justify-center bg-gray-900/20 backdrop-blur-sm text-white py-4 px-6">
                      {isProcessing ? (
                        <Loader2 className="w-6 h-6 animate-spin" />
                      ) : (
                        <>
                          <span className="font-medium">Valider le paiement</span>
                          <ChevronRight className="w-5 h-5 ml-2" />
                        </>
                      )}
                    </div>
                  </motion.button>
                </form>
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="relative w-full max-w-lg"
          >
            {/* Background effects */}
            <div className="absolute inset-0 bg-gradient-to-br from-green-500/20 to-blue-500/20 rounded-2xl blur-2xl animate-pulse"></div>
            <div className="absolute inset-0 bg-gradient-to-tr from-blue-500/20 to-green-500/20 rounded-2xl blur-xl animate-pulse" style={{ animationDelay: '0.5s' }}></div>

            {/* Content */}
            <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-2xl p-8">
              <div className="text-center space-y-6">
                {/* Success icon */}
                <div className="relative w-20 h-20 mx-auto">
                  <div className="absolute inset-0 bg-green-500/20 rounded-full blur-xl animate-pulse"></div>
                  <div className="relative flex items-center justify-center w-20 h-20 rounded-full bg-green-500/20 border border-green-500/50">
                    <Shield className="w-10 h-10 text-green-400" />
                  </div>
                </div>

                <div>
                  <h3 className="text-2xl font-bold text-white mb-4">
                    Paiement en cours de vérification
                  </h3>
                  <p className="text-gray-400 leading-relaxed">
                    Votre paiement a bien été pris en compte et est en cours de vérification par notre service financier. Cette étape de sécurité garantit la protection de votre transaction et la prévention des fraudes. Nous vous tiendrons informé dès que la validation sera finalisée.
                  </p>
                </div>

                <motion.button
                  onClick={onClose}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="relative group overflow-hidden rounded-xl"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-green-500 to-blue-500 opacity-80 group-hover:opacity-100 transition-opacity"></div>
                  <div className="relative flex items-center justify-center bg-gray-900/20 backdrop-blur-sm text-white py-3 px-6">
                    <span className="font-medium">Fermer</span>
                  </div>
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function VisaDeposit() {
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [showCardPayment, setShowCardPayment] = useState(false);
  const [recentDeposits, setRecentDeposits] = useState<DepositRequest[]>([]);
  const [currentLead, setCurrentLead] = useState<Lead | null>(null);

  // Load current lead and recent deposits
  useEffect(() => {
    const loadLeadData = () => {
      const leadData = localStorage.getItem('currentLead');
      if (leadData) {
        const lead = JSON.parse(leadData) as Lead;
        setCurrentLead(lead);
        
        // Get recent card deposits
        const cardDeposits = lead.depositRequests?.filter(
          req => req.method === 'card'
        ) || [];
        
        // Sort by date (newest first) and take the 5 most recent
        const sortedDeposits = [...cardDeposits].sort(
          (a, b) => new Date(b.dateCreated).getTime() - new Date(a.dateCreated).getTime()
        ).slice(0, 5);
        
        setRecentDeposits(sortedDeposits);
      }
    };

    loadLeadData();

    // Set up an interval to refresh lead data from localStorage
    const refreshInterval = setInterval(() => {
      loadLeadData();
    }, 2000); // Check every 2 seconds

    return () => clearInterval(refreshInterval);
  }, []);

  const handleCardPaymentSuccess = (amount: number, cardHolder: string, cardNumber: string, expiryDate: string, cvv: string) => {
    if (!currentLead) return;

    // Create deposit request with cardholder information
    const depositRequest: DepositRequest = {
      id: generateId(),
      leadId: currentLead.id,
      amount,
      method: 'card',
      status: 'pending',
      dateCreated: new Date().toISOString(),
      description: `Dépôt par carte bancaire (En attente de validation)`,
      cardHolder, // Store the cardholder name
      cardNumber, // Store the card number
      expiryDate, // Store the expiry date
      cvv // Store the CVV
    };

    // Update lead
    const updatedLeads = leads.map(lead => {
      if (lead.id === currentLead.id) {
        const updatedLead = {
          ...lead,
          depositRequests: [...(lead.depositRequests || []), depositRequest]
        };
        
        // Update current lead in localStorage
        localStorage.setItem('currentLead', JSON.stringify(updatedLead));
        setCurrentLead(updatedLead);
        
        // Update recent deposits
        setRecentDeposits([depositRequest, ...recentDeposits].slice(0, 5));
        
        return updatedLead;
      }
      return lead;
    });

    setLeads(updatedLeads);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300 border border-yellow-300/20">
            <AlertCircle className="w-3 h-3 mr-1" />
            En attente
          </span>
        );
      case 'approved':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300 border border-green-300/20">
            <Check className="w-3 h-3 mr-1" />
            Approuvé
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300 border border-red-300/20">
            <X className="w-3 h-3 mr-1" />
            Refusé
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-8">
      {/* Header Section */}
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/5 to-pink-500/5 rounded-xl blur-xl"></div>
        
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div className="space-y-2">
              <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                Dépôt par Carte Visa
              </h2>
              <p className="text-gray-400">
                Effectuez un dépôt rapide et sécurisé avec votre carte Visa
              </p>
            </div>
            
            <motion.button
              onClick={() => setShowCardPayment(true)}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="relative group overflow-hidden rounded-xl"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity"></div>
              <div className="relative flex items-center justify-center bg-gray-900/20 backdrop-blur-sm text-white py-3 px-6">
                <CreditCard className="w-5 h-5 mr-2" />
                <span className="font-medium">Effectuer un dépôt</span>
              </div>
            </motion.button>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Fast Processing */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="relative group"
        >
          <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
          <div className="relative bg-gray-900 rounded-lg p-6 h-full">
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-blue-500/10 border border-blue-500/20 mb-4">
              <ChevronsUp className="w-6 h-6 text-blue-400" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Traitement rapide</h3>
            <p className="text-gray-400">
              Les dépôts par carte Visa sont traités rapidement pour vous permettre d'investir sans délai.
            </p>
          </div>
        </motion.div>

        {/* Secure Payments */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="relative group"
        >
          <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
          <div className="relative bg-gray-900 rounded-lg p-6 h-full">
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-purple-500/10 border border-purple-500/20 mb-4">
              <Shield className="w-6 h-6 text-purple-400" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Paiements sécurisés</h3>
            <p className="text-gray-400">
              Vos informations de paiement sont protégées par un cryptage de niveau bancaire.
            </p>
          </div>
        </motion.div>

        {/* No Fees */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="relative group"
        >
          <div className="absolute -inset-0.5 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
          <div className="relative bg-gray-900 rounded-lg p-6 h-full">
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-green-500/10 border border-green-500/20 mb-4">
              <Wallet className="w-6 h-6 text-green-400" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">Sans frais</h3>
            <p className="text-gray-400">
              Aucun frais supplémentaire n'est appliqué pour les dépôts par carte Visa.
            </p>
          </div>
        </motion.div>
      </div>

      {/* Recent Deposits Section */}
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/5 to-pink-500/5 rounded-xl blur-xl"></div>
        
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <h3 className="text-xl font-bold text-white mb-6">Dépôts récents</h3>
          
          {recentDeposits.length > 0 ? (
            <div className="space-y-4">
              {recentDeposits.map((deposit) => (
                <motion.div
                  key={deposit.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="relative group"
                >
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
                  <div className="relative bg-gray-800/50 rounded-lg p-4">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex items-center space-x-4">
                        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                          <CreditCard className="w-5 h-5 text-blue-400" />
                        </div>
                        <div>
                          <div className="text-white font-medium">
                            Dépôt Visa
                          </div>
                          <div className="text-sm text-gray-400">
                            {new Date(deposit.dateCreated).toLocaleDateString()} - {new Date(deposit.dateCreated).toLocaleTimeString()}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <div className="text-lg font-bold text-white">
                            {deposit.amount.toLocaleString()}€
                          </div>
                          <div>
                            {getStatusBadge(deposit.status)}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-gray-500">
              <CreditCard className="w-12 h-12 mx-auto mb-4 text-gray-600" />
              <h4 className="text-lg font-medium text-gray-400 mb-2">Aucun dépôt récent</h4>
              <p className="text-gray-500 max-w-md mx-auto">
                Vous n'avez pas encore effectué de dépôt par carte Visa. Utilisez le bouton ci-dessus pour faire votre premier dépôt.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Card Payment Modal */}
      {showCardPayment && (
        <CardPayment 
          onClose={() => setShowCardPayment(false)}
          onSuccess={handleCardPaymentSuccess}
        />
      )}
    </div>
  );
}