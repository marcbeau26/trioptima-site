import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    strictPort: true,
    host: true,
    watch: {
      usePolling: false, // Désactivation du polling pour éviter les réactualisations automatiques
      interval: 1000, // Augmentation de l'intervalle de vérification
      ignored: ['**/node_modules/**', '**/dist/**'] // Ignorer certains dossiers
    },
    hmr: {
      overlay: false // Désactiver l'overlay HMR qui peut causer des rechargements
    }
  },
  preview: {
    port: 4173,
    strictPort: true,
    host: true
  },
  build: {
    minify: 'terser',
    target: 'esnext',
    rollupOptions: {
      output: {
        manualChunks: {
          'react-vendor': ['react', 'react-dom'],
          'router': ['react-router-dom'],
          'ui': ['framer-motion', 'lucide-react', 'react-hot-toast'],
          'state': ['@tanstack/react-query']
        }
      }
    }
  },
  optimizeDeps: {
    include: [
      'react',
      'react-dom',
      'react-router-dom',
      'framer-motion', 
      'lucide-react',
      'react-hot-toast',
      '@tanstack/react-query'
    ]
  }
});