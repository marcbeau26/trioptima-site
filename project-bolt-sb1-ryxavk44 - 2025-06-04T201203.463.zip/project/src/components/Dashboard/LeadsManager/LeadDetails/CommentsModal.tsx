import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Send, X, Trash2 } from 'lucide-react';
import type { Lead, Comment } from '../../../../types';
import { formatDate, generateId } from '../../../../utils';
import { toast } from 'react-hot-toast';
import { cn } from '../../../../utils/cn';

interface CommentsModalProps {
  lead: Lead;
  isOpen: boolean;
  onClose: () => void;
  onUpdate: (updatedLead: Lead) => void;
}

export function CommentsModal({ lead, isOpen, onClose, onUpdate }: CommentsModalProps) {
  const [newComment, setNewComment] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newComment.trim()) {
      toast.error('Le commentaire ne peut pas être vide');
      return;
    }

    const comment: Comment = {
      id: generateId(),
      text: newComment.trim(),
      dateCreated: new Date().toISOString()
    };

    const updatedLead = {
      ...lead,
      comments: [...(lead.comments || []), comment]
    };

    onUpdate(updatedLead);
    setNewComment('');
    toast.success('Commentaire ajouté avec succès');
  };

  const handleDeleteComment = (commentId: string) => {
    const updatedLead = {
      ...lead,
      comments: lead.comments?.filter(c => c.id !== commentId) || []
    };

    onUpdate(updatedLead);
    toast.success('Commentaire supprimé');
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-4xl mx-4"
      >
        {/* Background effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl blur-2xl" />
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-pink-500/20 rounded-xl blur-xl" />
        
        <div className="relative bg-gray-900/90 backdrop-blur-xl border border-white/10 rounded-xl p-8">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                Commentaires
              </h2>
              <p className="mt-2 text-gray-400">
                Client : {lead.firstName} {lead.lastName}
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-300 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Comments List */}
          <div className="space-y-4 max-h-[400px] overflow-y-auto custom-scrollbar pr-4 mb-6">
            {lead.comments?.length ? (
              lead.comments
                .sort((a, b) => new Date(b.dateCreated).getTime() - new Date(a.dateCreated).getTime())
                .map((comment) => (
                  <motion.div
                    key={comment.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="relative group"
                  >
                    <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
                    <div className="relative bg-gray-800/50 rounded-lg p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className="text-white whitespace-pre-wrap">
                            {comment.text}
                          </p>
                          <p className="text-sm text-gray-400 mt-2">
                            {formatDate(comment.dateCreated)}
                          </p>
                        </div>
                        <button
                          onClick={() => handleDeleteComment(comment.id)}
                          className="ml-4 text-gray-400 hover:text-red-400 transition-colors opacity-0 group-hover:opacity-100"
                          title="Supprimer le commentaire"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ))
            ) : (
              <div className="text-center py-8">
                <MessageSquare className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400">
                  Aucun commentaire pour le moment
                </p>
              </div>
            )}
          </div>

          {/* Add Comment Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Nouveau commentaire
              </label>
              <textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                rows={3}
                placeholder="Écrivez votre commentaire..."
              />
            </div>

            <div className="flex justify-end space-x-4">
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-3 text-sm font-medium text-gray-300 bg-gray-800/50 hover:bg-gray-700/50 rounded-lg"
              >
                Annuler
              </button>
              <motion.button
                type="submit"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="relative group px-6 py-3 rounded-lg overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
                <span className="relative flex items-center text-white font-medium">
                  <Send className="w-4 h-4 mr-2" />
                  Ajouter
                </span>
              </motion.button>
            </div>
          </form>
        </div>
      </motion.div>
    </div>
  );
}