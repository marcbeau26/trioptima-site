import React, { useState } from 'react';
import type { Status } from '../../../types';
import { generateId } from '../../../utils';
import { useLocalStorage } from '../../../hooks/useLocalStorage';

type StatusFormData = Omit<Status, 'id' | 'dateCreated'>;

const initialFormData: StatusFormData = {
  name: '',
  color: '#3B82F6', // Default blue color
};

export function AddStatusForm() {
  const [statuses, setStatuses] = useLocalStorage<Status[]>('statuses', []);
  const [formData, setFormData] = useState<StatusFormData>(initialFormData);

  // Get unique colors from existing statuses
  const existingColors = [...new Set(statuses.map(status => status.color))];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newStatus: Status = {
      ...formData,
      id: generateId(),
      dateCreated: new Date().toISOString(),
    };
    setStatuses([...statuses, newStatus]);
    setFormData(initialFormData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-2xl">
      <div className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
            Nom du statut
          </label>
          <input
            type="text"
            id="name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
            required
          />
        </div>

        <div>
          <label htmlFor="color" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
            Couleur du statut
          </label>
          <input
            type="color"
            id="color"
            value={formData.color}
            onChange={(e) => setFormData({ ...formData, color: e.target.value })}
            className="mt-1 block w-full h-10 rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        {existingColors.length > 0 && (
          <div>
            <label htmlFor="existingColor" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Couleurs existantes
            </label>
            <select
              id="existingColor"
              value={formData.color}
              onChange={(e) => setFormData({ ...formData, color: e.target.value })}
              className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
            >
              <option value="">Sélectionner une couleur existante</option>
              {existingColors.map((color) => (
                <option key={color} value={color}>
                  {color}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      <div>
        <button
          type="submit"
          className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-offset-gray-800"
        >
          Valider
        </button>
      </div>
    </form>
  );
}