import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  User, Mail, Phone, 
  MapPin, Calendar, Clock, Shield, Info, Edit, 
  Save, X, Check, Home, MapPinned, Globe
} from 'lucide-react';
import { formatDate } from '../../utils';
import type { Lead } from '../../types';
import { useLocalStorage } from '../../hooks/useLocalStorage';
import { toast } from 'react-hot-toast';

export function Settings() {
  const [leads, setLeads] = useLocalStorage<Lead[]>('leads', []);
  const [lead, setLead] = useState<Lead | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editedLead, setEditedLead] = useState<Lead | null>(null);

  // Load lead data from localStorage
  useEffect(() => {
    const leadData = localStorage.getItem('currentLead');
    if (leadData) {
      const parsedLead = JSON.parse(leadData);
      setLead(parsedLead);
      setEditedLead(parsedLead);
    }
  }, []);

  const handleSaveChanges = () => {
    if (!editedLead || !lead) return;

    // Update lead in localStorage
    localStorage.setItem('currentLead', JSON.stringify(editedLead));
    
    // Update lead in state
    setLead(editedLead);
    
    // Update lead in leads array
    const updatedLeads = leads.map(l => 
      l.id === editedLead.id ? editedLead : l
    );
    setLeads(updatedLeads);
    
    setIsEditing(false);
    toast.success('Informations mises à jour avec succès');
  };

  const handleCancelEdit = () => {
    setEditedLead(lead);
    setIsEditing(false);
  };

  // Format date in French format with one hour less
  const formatFrenchDate = (dateString: string) => {
    const date = new Date(dateString);
    // Subtract one hour
    date.setHours(date.getHours() - 1);
    
    // Format date in French format: DD/MM/YYYY HH:MM
    return date.toLocaleString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!lead) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-gray-400">Chargement...</div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Client Information Card */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative overflow-hidden"
      >
        {/* Background gradient effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 rounded-xl blur-2xl"></div>
        <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/5 to-emerald-500/5 rounded-xl blur-xl"></div>
        
        {/* Main content */}
        <div className="relative bg-white/80 dark:bg-gray-800/80 backdrop-blur-xl rounded-xl shadow-xl border border-white/20 dark:border-gray-700/20">
          {/* Glowing border */}
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-cyan-500"></div>
          
          {/* Header */}
          <div className="p-6 border-b border-gray-200/50 dark:border-gray-700/50">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <User className="h-6 w-6 text-blue-500" />
                <div>
                  <h2 className="text-xl font-bold bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
                    Informations personnelles
                  </h2>
                  <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
                    Vos informations de compte
                  </p>
                </div>
              </div>
              
              {isEditing ? (
                <div className="flex space-x-2">
                  <button
                    onClick={handleCancelEdit}
                    className="p-2 text-gray-400 hover:text-gray-300 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                  <button
                    onClick={handleSaveChanges}
                    className="p-2 text-green-500 hover:text-green-400 transition-colors"
                  >
                    <Save className="w-5 h-5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setIsEditing(true)}
                  className="p-2 text-blue-500 hover:text-blue-400 transition-colors"
                >
                  <Edit className="w-5 h-5" />
                </button>
              )}
            </div>
          </div>

          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Personal Information */}
              <div className="space-y-6">
                {/* Name */}
                <div className="space-y-2">
                  <div className="flex items-center">
                    <User className="w-5 h-5 text-blue-500 mr-2" />
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                      Nom et prénom
                    </h3>
                  </div>
                  {isEditing ? (
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm text-gray-500 dark:text-gray-400 mb-1">Prénom</label>
                        <input
                          type="text"
                          value={editedLead?.firstName || ''}
                          onChange={(e) => setEditedLead(prev => prev ? {...prev, firstName: e.target.value} : null)}
                          className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg px-4 py-2 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm text-gray-500 dark:text-gray-400 mb-1">Nom</label>
                        <input
                          type="text"
                          value={editedLead?.lastName || ''}
                          onChange={(e) => setEditedLead(prev => prev ? {...prev, lastName: e.target.value} : null)}
                          className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg px-4 py-2 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="bg-gray-50 dark:bg-gray-700/30 rounded-lg p-4">
                      <div className="flex justify-between">
                        <div>
                          <p className="text-sm text-gray-500 dark:text-gray-400">Prénom</p>
                          <p className="text-lg font-medium text-gray-900 dark:text-white">{lead.firstName}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-gray-500 dark:text-gray-400">Nom</p>
                          <p className="text-lg font-medium text-gray-900 dark:text-white">{lead.lastName}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Contact Information */}
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Mail className="w-5 h-5 text-purple-500 mr-2" />
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                      Coordonnées
                    </h3>
                  </div>
                  {isEditing ? (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm text-gray-500 dark:text-gray-400 mb-1">Email</label>
                        <input
                          type="email"
                          value={editedLead?.email || ''}
                          onChange={(e) => setEditedLead(prev => prev ? {...prev, email: e.target.value} : null)}
                          className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg px-4 py-2 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm text-gray-500 dark:text-gray-400 mb-1">Téléphone</label>
                        <input
                          type="tel"
                          value={editedLead?.phone || ''}
                          onChange={(e) => setEditedLead(prev => prev ? {...prev, phone: e.target.value} : null)}
                          className="w-full bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg px-4 py-2 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="bg-gray-50 dark:bg-gray-700/30 rounded-lg p-4 space-y-4">
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Email</p>
                        <p className="text-base font-medium text-gray-900 dark:text-white">{lead.email}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Téléphone</p>
                        <p className="text-base font-medium text-gray-900 dark:text-white">{lead.phone || "Non renseigné"}</p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Address Information */}
                <div className="space-y-2">
                  <div className="flex items-center">
                    <MapPin className="w-5 h-5 text-emerald-500 mr-2" />
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                      Adresse
                    </h3>
                  </div>
                  {isEditing ? (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm text-gray-500 dark:text-gray-400 mb-1">Adresse</label>
                        <div className="flex items-center bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2">
                          <Home className="w-4 h-4 text-gray-400 mr-2" />
                          <input
                            type="text"
                            value={editedLead?.address || ''}
                            onChange={(e) => setEditedLead(prev => prev ? {...prev, address: e.target.value} : null)}
                            className="flex-1 bg-transparent border-none focus:ring-0 text-gray-900 dark:text-white"
                            placeholder="Votre adresse"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm text-gray-500 dark:text-gray-400 mb-1">Ville</label>
                          <div className="flex items-center bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2">
                            <MapPinned className="w-4 h-4 text-gray-400 mr-2" />
                            <input
                              type="text"
                              value={editedLead?.city || ''}
                              onChange={(e) => setEditedLead(prev => prev ? {...prev, city: e.target.value} : null)}
                              className="flex-1 bg-transparent border-none focus:ring-0 text-gray-900 dark:text-white"
                              placeholder="Votre ville"
                            />
                          </div>
                        </div>
                        <div>
                          <label className="block text-sm text-gray-500 dark:text-gray-400 mb-1">Code postal</label>
                          <div className="flex items-center bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2">
                            <Globe className="w-4 h-4 text-gray-400 mr-2" />
                            <input
                              type="text"
                              value={editedLead?.postalCode || ''}
                              onChange={(e) => setEditedLead(prev => prev ? {...prev, postalCode: e.target.value} : null)}
                              className="flex-1 bg-transparent border-none focus:ring-0 text-gray-900 dark:text-white"
                              placeholder="Code postal"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-gray-50 dark:bg-gray-700/30 rounded-lg p-4 space-y-4">
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Adresse</p>
                        <p className="text-base font-medium text-gray-900 dark:text-white">
                          {lead.address || "Non renseignée"}
                        </p>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-sm text-gray-500 dark:text-gray-400">Ville</p>
                          <p className="text-base font-medium text-gray-900 dark:text-white">
                            {lead.city || "Non renseignée"}
                          </p>
                        </div>
                        <div>
                          <p className="text-sm text-gray-500 dark:text-gray-400">Code postal</p>
                          <p className="text-base font-medium text-gray-900 dark:text-white">
                            {lead.postalCode || "Non renseigné"}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Account Information */}
              <div className="space-y-6">
                {/* Account Details */}
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Shield className="w-5 h-5 text-cyan-500 mr-2" />
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                      Informations du compte
                    </h3>
                  </div>
                  <div className="bg-gray-50 dark:bg-gray-700/30 rounded-lg p-4 space-y-4">
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Date de création</p>
                      <div className="flex items-center mt-1">
                        <Calendar className="w-4 h-4 text-cyan-500 mr-2" />
                        <p className="text-base font-medium text-gray-900 dark:text-white">
                          {formatFrenchDate(lead.dateCreated)}
                        </p>
                      </div>
                    </div>
                    {lead.statusId && (
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">Statut</p>
                        <div className="flex items-center mt-1">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                            {lead.statusId}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Save Changes Button (when editing) */}
            {isEditing && (
              <div className="mt-6 flex justify-end">
                <motion.button
                  onClick={handleSaveChanges}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="relative group px-6 py-3 rounded-lg overflow-hidden"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-80 group-hover:opacity-100 transition-opacity" />
                  <span className="relative flex items-center text-white font-medium">
                    <Check className="w-4 h-4 mr-2" />
                    Enregistrer les modifications
                  </span>
                </motion.button>
              </div>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}