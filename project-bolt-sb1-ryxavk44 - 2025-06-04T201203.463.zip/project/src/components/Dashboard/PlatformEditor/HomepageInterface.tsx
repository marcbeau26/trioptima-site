import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Image as ImageIcon, Upload, X, Check, RotateCcw, Wand2, 
  Type, Layout, Sidebar, Palette, Eye, EyeOff, Sliders,
  Plus, Save, Trash2, BarChart2
} from 'lucide-react';
import { useLocalStorage } from '../../../hooks/useLocalStorage';
import { toast } from 'react-hot-toast';
import { cn } from '../../../utils/cn';

// URL de l'image par défaut - remplacez par l'URL de votre image
const DEFAULT_IMAGE_URL = 'https://images.unsplash.com/photo-1579547945413-497e1b99dac0?q=80&w=1470&auto=format&fit=crop';

interface HomepageSettings {
  imageUrl: string;
  neonBorderColor?: string;
  leftBackgroundColor?: string;
  emailBorderColor?: string;
  passwordBorderColor?: string;
  loginButtonColor?: string;
  welcomeTextColor?: string;
  passwordDotsColor?: string;
  trakitLineColor?: string;
  logoBackgroundColor?: string;
  neonEffectsEnabled?: boolean;
  logoSize?: number;
  logoUrl?: string;
  logoMode?: 'image' | 'text';
  logoText?: string;
  logoTextColor?: string;
}

// Color picker component
interface ColorPickerProps {
  color: string;
  onChange: (color: string) => void;
  title: string;
}

function ColorPicker({ color, onChange, title }: ColorPickerProps) {
  const [selectedColor, setSelectedColor] = useState(color);
  const [eyedropperActive, setEyedropperActive] = useState(false);
  const [customColors, setCustomColors] = useLocalStorage<string[]>('customColors', []);
  const [showSaveButton, setShowSaveButton] = useState(false);
  
  // Default preset colors
  const defaultPresetColors = [
    // Dark blues
    '#0f172a', '#1e293b', '#1e3a8a', '#1e40af', '#1d4ed8',
    // Dark purples
    '#4c1d95', '#5b21b6', '#6d28d9', '#7e22ce', '#9333ea',
    // Dark greens
    '#064e3b', '#065f46', '#047857', '#059669', '#10b981',
    // Dark reds
    '#7f1d1d', '#991b1b', '#b91c1c', '#dc2626', '#ef4444',
    // Dark grays
    '#111827', '#1f2937', '#374151', '#4b5563', '#6b7280',
    // Text colors
    '#ffffff', '#f9fafb', '#f3f4f6', '#e5e7eb', '#d1d5db',
    '#9ca3af', '#6b7280', '#4b5563', '#374151', '#1f2937',
  ];

  const handleColorChange = (newColor: string) => {
    setSelectedColor(newColor);
    onChange(newColor);
    setShowSaveButton(true);
  };

  const activateEyedropper = async () => {
    if (!window.EyeDropper) {
      toast.error("Votre navigateur ne prend pas en charge l'API EyeDropper");
      return;
    }

    try {
      setEyedropperActive(true);
      const eyeDropper = new window.EyeDropper();
      const result = await eyeDropper.open();
      handleColorChange(result.sRGBHex);
      setEyedropperActive(false);
    } catch (e) {
      setEyedropperActive(false);
      console.error('EyeDropper error:', e);
    }
  };

  const saveCustomColor = () => {
    if (!customColors.includes(selectedColor)) {
      setCustomColors([...customColors, selectedColor]);
      toast.success('Couleur personnalisée enregistrée');
    } else {
      toast.info('Cette couleur est déjà enregistrée');
    }
    setShowSaveButton(false);
  };

  const removeCustomColor = (colorToRemove: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setCustomColors(customColors.filter(c => c !== colorToRemove));
    toast.success('Couleur personnalisée supprimée');
  };

  return (
    <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-4 space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-white font-medium">{title}</h3>
        <div 
          className="w-6 h-6 rounded border border-white/20" 
          style={{ backgroundColor: selectedColor }}
        ></div>
      </div>
      
      <div className="space-y-4">
        {/* Color preview */}
        <div className="h-12 rounded-md" style={{ backgroundColor: selectedColor }}></div>
        
        {/* Custom color input */}
        <div>
          <label className="block text-sm text-gray-300 mb-1">Couleur personnalisée</label>
          <div className="flex space-x-2">
            <input
              type="color"
              value={selectedColor}
              onChange={(e) => handleColorChange(e.target.value)}
              className="flex-1 h-10 rounded-md bg-transparent border border-gray-700"
            />
            {showSaveButton && (
              <button
                onClick={saveCustomColor}
                className="px-3 py-2 bg-green-600 hover:bg-green-700 text-white rounded-md flex items-center"
              >
                <Save className="w-4 h-4 mr-1" />
                <span>Enregistrer</span>
              </button>
            )}
          </div>
        </div>
        
        {/* Eyedropper button */}
        <button
          onClick={activateEyedropper}
          disabled={eyedropperActive}
          className={cn(
            "w-full flex items-center justify-center space-x-2 py-2 px-4 rounded-md transition-colors",
            eyedropperActive 
              ? "bg-purple-600/50 text-white cursor-wait" 
              : "bg-purple-600 hover:bg-purple-700 text-white"
          )}
        >
          <Wand2 className="w-4 h-4" />
          <span>{eyedropperActive ? 'Sélection en cours...' : 'Utiliser la pipette'}</span>
        </button>
        
        {/* Custom colors */}
        {customColors.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm text-gray-300">Mes couleurs personnalisées</label>
            </div>
            <div className="grid grid-cols-5 gap-2">
              {customColors.map((customColor) => (
                <div key={customColor} className="relative group">
                  <button
                    onClick={() => handleColorChange(customColor)}
                    className={`w-8 h-8 rounded-md ${selectedColor === customColor ? 'ring-2 ring-blue-500' : ''}`}
                    style={{ backgroundColor: customColor }}
                    aria-label={`Color ${customColor}`}
                  />
                  <button
                    onClick={(e) => removeCustomColor(customColor, e)}
                    className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-4 h-4 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Preset colors */}
        <div>
          <label className="block text-sm text-gray-300 mb-2">Couleurs prédéfinies</label>
          <div className="grid grid-cols-5 gap-2">
            {defaultPresetColors.map((presetColor) => (
              <button
                key={presetColor}
                onClick={() => handleColorChange(presetColor)}
                className={`w-8 h-8 rounded-md ${selectedColor === presetColor ? 'ring-2 ring-blue-500' : ''}`}
                style={{ backgroundColor: presetColor }}
                aria-label={`Color ${presetColor}`}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// Logo settings component
interface LogoSettingsProps {
  settings: HomepageSettings;
  onUpdate: (settings: Partial<HomepageSettings>) => void;
}

function LogoSettings({ settings, onUpdate }: LogoSettingsProps) {
  const [logoMode, setLogoMode] = useState<'image' | 'text'>(settings.logoMode || 'text');
  const [logoSize, setLogoSize] = useState(settings.logoSize || 80);
  const [logoText, setLogoText] = useState(settings.logoText || 'Trioptima');
  const [logoTextColor, setLogoTextColor] = useState(settings.logoTextColor || '#ffffff');
  const [logoUrl, setLogoUrl] = useState(settings.logoUrl || '');
  const [isDragging, setIsDragging] = useState(false);

  // Update document title when logo text changes
  useEffect(() => {
    document.title = logoText;
    const pageTitle = document.getElementById('page-title');
    if (pageTitle) {
      pageTitle.textContent = logoText;
    }
  }, [logoText]);

  const handleLogoModeChange = (mode: 'image' | 'text') => {
    setLogoMode(mode);
    onUpdate({ logoMode: mode });
  };

  const handleLogoSizeChange = (size: number) => {
    setLogoSize(size);
    onUpdate({ logoSize: size });
  };

  const handleLogoTextChange = (text: string) => {
    setLogoText(text);
    onUpdate({ logoText: text });
    
    // Update document title
    document.title = text;
    const pageTitle = document.getElementById('page-title');
    if (pageTitle) {
      pageTitle.textContent = text;
    }
  };

  const handleLogoTextColorChange = (color: string) => {
    setLogoTextColor(color);
    onUpdate({ logoTextColor: color });
  };

  const handleLogoUpload = (file: File) => {
    // Create object URL for the uploaded file
    const imageUrl = URL.createObjectURL(file);
    setLogoUrl(imageUrl);
    onUpdate({ logoUrl: imageUrl });
    toast.success('Logo mis à jour avec succès');
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const file = files[0];
      if (file.type.startsWith('image/')) {
        handleLogoUpload(file);
      } else {
        toast.error('Veuillez sélectionner une image');
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      if (file.type.startsWith('image/')) {
        handleLogoUpload(file);
      } else {
        toast.error('Veuillez sélectionner une image');
      }
    }
  };

  const handleRemoveLogo = () => {
    setLogoUrl('');
    onUpdate({ logoUrl: undefined });
    toast.success('Logo supprimé');
  };

  return (
    <div className="space-y-6">
      <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6">
        <h3 className="text-lg font-medium text-white mb-4">
          Type de logo
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={() => handleLogoModeChange('image')}
            className={cn(
              "p-4 rounded-lg border transition-colors text-center",
              logoMode === 'image'
                ? "bg-blue-600/20 border-blue-500/50 text-blue-400"
                : "bg-gray-800/50 border-gray-700/50 text-gray-400 hover:bg-gray-700/50"
            )}
          >
            <ImageIcon className="w-8 h-8 mx-auto mb-2" />
            Image
          </button>
          <button
            onClick={() => handleLogoModeChange('text')}
            className={cn(
              "p-4 rounded-lg border transition-colors text-center",
              logoMode === 'text'
                ? "bg-blue-600/20 border-blue-500/50 text-blue-400"
                : "bg-gray-800/50 border-gray-700/50 text-gray-400 hover:bg-gray-700/50"
            )}
          >
            <Type className="w-8 h-8 mx-auto mb-2" />
            Texte
          </button>
        </div>
      </div>

      {/* Logo Size Slider */}
      <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6">
        <h3 className="text-lg font-medium text-white mb-4">
          Taille du logo
        </h3>
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-400">Petit</span>
            <span className="text-sm text-white">{logoSize}px</span>
            <span className="text-sm text-gray-400">Grand</span>
          </div>
          <input
            type="range"
            min="40"
            max="200"
            value={logoSize}
            onChange={(e) => handleLogoSizeChange(parseInt(e.target.value))}
            className="w-full"
          />
        </div>
      </div>

      {/* Logo specific settings based on mode */}
      {logoMode === 'image' ? (
        <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6">
          <h3 className="text-lg font-medium text-white mb-4">
            Image du logo
          </h3>
          <div 
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={cn(
              "relative border-2 border-dashed p-4 transition-all duration-200 cursor-pointer",
              isDragging
                ? "border-blue-500 bg-blue-500/10"
                : "border-gray-700 hover:border-blue-500/50 hover:bg-gray-800/50"
            )}
          >
            <input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            
            <div className="flex flex-col items-center justify-center space-y-2 text-center">
              <Upload className="w-8 h-8 text-gray-400" />
              <p className="text-sm text-gray-300">
                {isDragging
                  ? "Déposez l'image ici..."
                  : "Glissez-déposez une image ici, ou cliquez pour sélectionner"}
              </p>
              <p className="text-xs text-gray-500">
                PNG, JPG, GIF jusqu'à 2MB
              </p>
            </div>
          </div>

          {/* Logo Preview */}
          {logoUrl && (
            <div className="mt-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-medium text-white">Aperçu du logo</h4>
                <button
                  onClick={handleRemoveLogo}
                  className="p-1 text-red-400 hover:text-red-300 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="relative aspect-square w-20 overflow-hidden border border-gray-700 bg-gray-800/50">
                <img 
                  src={logoUrl} 
                  alt="Logo preview" 
                  className="w-full h-full object-contain"
                />
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6">
            <h3 className="text-lg font-medium text-white mb-4">
              Texte du logo
            </h3>
            <input
              type="text"
              value={logoText}
              onChange={(e) => handleLogoTextChange(e.target.value)}
              className="w-full bg-gray-800/50 text-white border border-gray-700/50 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
              placeholder="Trioptima"
            />
          </div>

          <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6">
            <h3 className="text-lg font-medium text-white mb-4">
              Couleur du texte
            </h3>
            <ColorPicker 
              color={logoTextColor}
              onChange={handleLogoTextColorChange}
              title="Couleur du texte du logo"
            />
          </div>
        </div>
      )}
    </div>
  );
}

export function HomepageInterface() {
  const [settings, setSettings] = useLocalStorage<HomepageSettings>('homepageSettings', {
    imageUrl: DEFAULT_IMAGE_URL, // Utiliser l'image par défaut
    logoSize: 80,
    logoMode: 'text', // Définir le mode texte par défaut
    logoText: 'Trioptima',
    logoTextColor: '#ffffff'
  });
  const [homepageColors, setHomepageColors] = useLocalStorage('homepageColors', {
    neonBorder: '#9333ea', // Default purple neon
    leftBackground: '#111827', // Default dark background
    emailBorder: '#9333ea', // Default purple for email field
    passwordBorder: '#9333ea', // Default purple for password field
    loginButton: '#9333ea', // Default purple for login button
    welcomeText: '#ffffff', // Default white for welcome text
    passwordDots: '#9333ea', // Default purple for password dots
    trakitLine: '#9333ea', // Default purple for trakit line
    logoBackground: '#111827', // Default dark background for logo area
  });
  const [neonEffectsEnabled, setNeonEffectsEnabled] = useLocalStorage('neonEffectsEnabled', true);
  const [isDragging, setIsDragging] = useState(false);
  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'colors' | 'logo'>('colors');

  // Update document title when logo text changes
  useEffect(() => {
    document.title = settings.logoText || 'Trioptima';
    const pageTitle = document.getElementById('page-title');
    if (pageTitle) {
      pageTitle.textContent = settings.logoText || 'Trioptima';
    }
  }, [settings.logoText]);

  // Initialiser l'image par défaut si aucune image n'est définie
  useEffect(() => {
    if (!settings.imageUrl) {
      setSettings({ ...settings, imageUrl: DEFAULT_IMAGE_URL });
    }
  }, [settings, setSettings]);

  const updateSettings = (newSettings: Partial<HomepageSettings>) => {
    setSettings({ ...settings, ...newSettings });
  };

  const updateColor = (key: string, color: string) => {
    setHomepageColors({ ...homepageColors, [key]: color });
  };

  const handleImageUpload = (file: File) => {
    // Create object URL for the uploaded file
    const imageUrl = URL.createObjectURL(file);
    setSettings({ ...settings, imageUrl });
    toast.success('Image mise à jour avec succès');
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const file = files[0];
      if (file.type.startsWith('image/')) {
        handleImageUpload(file);
      } else {
        toast.error('Veuillez sélectionner une image');
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      if (file.type.startsWith('image/')) {
        handleImageUpload(file);
      } else {
        toast.error('Veuillez sélectionner une image');
      }
    }
  };

  const handleRemoveImage = () => {
    setSettings({ ...settings, imageUrl: DEFAULT_IMAGE_URL });
    toast.success('Image réinitialisée à la valeur par défaut');
  };

  const handleToggleNeonEffects = () => {
    setNeonEffectsEnabled(!neonEffectsEnabled);
    toast.success(`Effets néon ${!neonEffectsEnabled ? 'activés' : 'désactivés'}`);
  };

  const handleReset = () => {
    setSettings({
      imageUrl: DEFAULT_IMAGE_URL,
      logoSize: 80,
      logoMode: 'text',
      logoText: 'Trioptima',
      logoTextColor: '#ffffff'
    });
    setHomepageColors({
      neonBorder: '#9333ea',
      leftBackground: '#111827',
      emailBorder: '#9333ea',
      passwordBorder: '#9333ea',
      loginButton: '#9333ea',
      welcomeText: '#ffffff',
      passwordDots: '#9333ea',
      trakitLine: '#9333ea',
      logoBackground: '#111827',
    });
    setNeonEffectsEnabled(true);
    toast.success('Paramètres réinitialisés');
    
    // Update document title
    document.title = 'Trioptima';
    const pageTitle = document.getElementById('page-title');
    if (pageTitle) {
      pageTitle.textContent = 'Trioptima';
    }
  };

  const getColorPickerForElement = () => {
    switch (selectedElement) {
      case 'neonBorder':
        return (
          <ColorPicker 
            color={homepageColors.neonBorder} 
            onChange={(color) => updateColor('neonBorder', color)} 
            title="Bordure néon"
          />
        );
      case 'leftBackground':
        return (
          <ColorPicker 
            color={homepageColors.leftBackground} 
            onChange={(color) => updateColor('leftBackground', color)} 
            title="Fond gauche"
          />
        );
      case 'logoBackground':
        return (
          <ColorPicker 
            color={homepageColors.logoBackground} 
            onChange={(color) => updateColor('logoBackground', color)} 
            title="Fond logo"
          />
        );
      case 'emailBorder':
        return (
          <ColorPicker 
            color={homepageColors.emailBorder} 
            onChange={(color) => updateColor('emailBorder', color)} 
            title="Champ email"
          />
        );
      case 'passwordBorder':
        return (
          <ColorPicker 
            color={homepageColors.passwordBorder} 
            onChange={(color) => updateColor('passwordBorder', color)} 
            title="Champ mot de passe"
          />
        );
      case 'loginButton':
        return (
          <ColorPicker 
            color={homepageColors.loginButton} 
            onChange={(color) => updateColor('loginButton', color)} 
            title="Bouton"
          />
        );
      case 'welcomeText':
        return (
          <ColorPicker 
            color={homepageColors.welcomeText} 
            onChange={(color) => updateColor('welcomeText', color)} 
            title="Texte bienvenue"
          />
        );
      case 'passwordDots':
        return (
          <ColorPicker 
            color={homepageColors.passwordDots} 
            onChange={(color) => updateColor('passwordDots', color)} 
            title="Ronds mot de passe"
          />
        );
      case 'trakitLine':
        return (
          <ColorPicker 
            color={homepageColors.trakitLine} 
            onChange={(color) => updateColor('trakitLine', color)} 
            title="Trait horizontal"
          />
        );
      default:
        return (
          <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6 flex items-center justify-center">
            <p className="text-gray-400">Sélectionnez un élément pour modifier sa couleur</p>
          </div>
        );
    }
  };

  return (
    <div className="space-y-8">
      {/* Header with title and neon toggle */}
      <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-xl font-bold text-white">Personnalisation de la page d'accueil</h2>
            <p className="text-gray-400 mt-1">Modifiez l'apparence de la page d'accueil selon vos préférences</p>
          </div>
          <button
            onClick={handleToggleNeonEffects}
            className={cn(
              "px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors",
              neonEffectsEnabled 
                ? "bg-purple-600 hover:bg-purple-700 text-white" 
                : "bg-gray-700 hover:bg-gray-600 text-gray-300"
            )}
          >
            <Sliders className="w-4 h-4" />
            <span>Effets néon {neonEffectsEnabled ? 'activés' : 'désactivés'}</span>
          </button>
        </div>
      </div>

      {/* Main tabs */}
      <div className="bg-gray-800/50 border border-gray-700 rounded-lg overflow-hidden">
        <div className="border-b border-gray-700">
          <div className="flex">
            <button
              onClick={() => setActiveTab('colors')}
              className={cn(
                "px-6 py-4 text-sm font-medium transition-colors",
                activeTab === 'colors' 
                  ? "bg-gray-700/50 text-white border-b-2 border-blue-500" 
                  : "text-gray-400 hover:text-gray-300 hover:bg-gray-700/30"
              )}
            >
              <div className="flex items-center">
                <Palette className="w-4 h-4 mr-2" />
                Personnalisation des couleurs
              </div>
            </button>
            <button
              onClick={() => setActiveTab('logo')}
              className={cn(
                "px-6 py-4 text-sm font-medium transition-colors",
                activeTab === 'logo' 
                  ? "bg-gray-700/50 text-white border-b-2 border-blue-500" 
                  : "text-gray-400 hover:text-gray-300 hover:bg-gray-700/30"
              )}
            >
              <div className="flex items-center">
                <ImageIcon className="w-4 h-4 mr-2" />
                Configuration du logo
              </div>
            </button>
          </div>
        </div>

        <div className="p-6">
          {activeTab === 'logo' ? (
            <div className="space-y-6">
              <div className="bg-gray-700/30 border border-gray-600/30 rounded-lg p-4">
                <p className="text-gray-300">
                  Configurez l'apparence du logo qui sera affiché sur la page d\'accueil. Vous pouvez choisir entre une image ou du texte.
                </p>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <LogoSettings settings={settings} onUpdate={updateSettings} />
                
                <div className="space-y-6">
                  <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6">
                    <h3 className="text-lg font-medium text-white mb-4">
                      Aperçu du logo
                    </h3>
                    <div className="flex items-center justify-center p-6 bg-gray-900 rounded-lg">
                      {settings.logoMode === 'image' ? (
                        <div style={{ width: `${settings.logoSize || 80}px`, height: 'auto' }}>
                          {settings.logoUrl ? (
                            <img src={settings.logoUrl} alt="Logo" className="h-full w-full object-contain" />
                          ) : (
                            <div className="h-full w-full flex items-center justify-center text-purple-500">
                              <BarChart2 className="h-full w-full" />
                            </div>
                          )}
                        </div>
                      ) : (
                        <div 
                          className="font-['Orbitron'] font-bold"
                          style={{ 
                            fontSize: `${(settings.logoSize || 80)/3}px`, 
                            color: settings.logoTextColor || '#ffffff',
                            textShadow: neonEffectsEnabled 
                              ? `0 0 5px ${settings.logoTextColor}, 0 0 10px ${settings.logoTextColor}`
                              : 'none',
                            letterSpacing: '2px'
                          }}
                        >
                          {settings.logoText || 'Trioptima'}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="bg-gray-700/30 border border-gray-600/30 rounded-lg p-4">
                <p className="text-gray-300">
                  Cliquez sur un élément de l'aperçu pour le sélectionner, puis utilisez le sélecteur de couleur pour le personnaliser.
                  {neonEffectsEnabled && " Les effets néon sont activés pour un rendu plus lumineux."}
                </p>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Left Column - Preview */}
                <div className="space-y-6">
                  {/* Login Form Preview */}
                  <div className="border border-gray-700 rounded-lg overflow-hidden h-auto relative cursor-pointer">
                    {/* Logo Area */}
                    <div 
                      className="p-4 flex items-center justify-center cursor-pointer"
                      style={{ backgroundColor: homepageColors.logoBackground }}
                      onClick={() => setSelectedElement('logoBackground')}
                    >
                      {settings.logoMode === 'image' ? (
                        <div style={{ width: `${settings.logoSize || 80}px`, height: 'auto' }}>
                          {settings.logoUrl ? (
                            <img src={settings.logoUrl} alt="Logo" className="h-full w-full object-contain" />
                          ) : (
                            <div className="h-full w-full flex items-center justify-center text-purple-500">
                              <BarChart2 className="h-full w-full" />
                            </div>
                          )}
                        </div>
                      ) : (
                        <div 
                          className="font-['Orbitron'] font-bold"
                          style={{ 
                            fontSize: `${(settings.logoSize || 80)/3}px`, 
                            color: settings.logoTextColor || '#ffffff',
                            textShadow: neonEffectsEnabled 
                              ? `0 0 5px ${settings.logoTextColor}, 0 0 10px ${settings.logoTextColor}`
                              : 'none',
                            letterSpacing: '2px'
                          }}
                        >
                          {settings.logoText || 'Trioptima'}
                        </div>
                      )}
                    </div>
                    
                    {/* Trakit Line */}
                    <div 
                      className="w-full cursor-pointer"
                      style={{ 
                        height: '2px',
                        backgroundColor: homepageColors.trakitLine,
                        boxShadow: neonEffectsEnabled ? `0 0 10px ${homepageColors.trakitLine}` : 'none'
                      }}
                      onClick={() => setSelectedElement('trakitLine')}
                    ></div>
                    
                    {/* Form Area */}
                    <div 
                      className="p-6 cursor-pointer"
                      style={{ backgroundColor: homepageColors.leftBackground }}
                      onClick={() => setSelectedElement('leftBackground')}
                    >
                      {/* Welcome Text */}
                      <div 
                        className="mb-4 cursor-pointer"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedElement('welcomeText');
                        }}
                      >
                        <p 
                          className="text-xl font-bold mb-1"
                          style={{ color: homepageColors.welcomeText }}
                        >
                          Bienvenue
                        </p>
                        <p 
                          className="text-sm"
                          style={{ color: homepageColors.welcomeText }}
                        >
                          Connectez-vous à votre compte
                        </p>
                      </div>
                      
                      {/* Email Field */}
                      <div 
                        className="relative mb-4 cursor-pointer"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedElement('emailBorder');
                        }}
                      >
                        <div 
                          className="absolute -inset-0.5 blur opacity-75"
                          style={{ 
                            backgroundColor: homepageColors.emailBorder,
                            boxShadow: neonEffectsEnabled ? `0 0 10px ${homepageColors.emailBorder}` : 'none'
                          }}
                        ></div>
                        <div className="relative bg-gray-900 border p-3" style={{ borderColor: homepageColors.emailBorder }}>
                          Entrez votre email
                        </div>
                      </div>
                      
                      {/* Password Field */}
                      <div 
                        className="relative mb-4 cursor-pointer"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedElement('passwordBorder');
                        }}
                      >
                        <div 
                          className="absolute -inset-0.5 blur opacity-75"
                          style={{ 
                            backgroundColor: homepageColors.passwordBorder,
                            boxShadow: neonEffectsEnabled ? `0 0 10px ${homepageColors.passwordBorder}` : 'none'
                          }}
                        ></div>
                        <div className="relative bg-gray-900 border p-3" style={{ borderColor: homepageColors.passwordBorder }}>
                          <div className="flex justify-between items-center">
                            <span className="text-gray-400 text-sm">Mot de passe:</span>
                            <div className="flex space-x-2">
                              {Array.from({ length: 6 }).map((_, i) => (
                                <div
                                  key={i}
                                  className="w-3 h-3 rounded-full"
                                  style={{ 
                                    backgroundColor: i < 3 ? homepageColors.passwordDots : '#374151',
                                    cursor: 'pointer'
                                  }}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedElement('passwordDots');
                                  }}
                                />
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      {/* Login Button */}
                      <div 
                        className="w-full py-2 text-center text-white cursor-pointer"
                        style={{ backgroundColor: homepageColors.loginButton }}
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedElement('loginButton');
                        }}
                      >
                        Se connecter
                      </div>
                    </div>
                  </div>
                  
                  {/* Right Side Preview */}
                  <div 
                    className="border border-gray-700 rounded-lg overflow-hidden h-40 relative cursor-pointer"
                    onClick={() => setSelectedElement('neonBorder')}
                  >
                    {/* Neon border effect */}
                    <div 
                      className="absolute inset-0 pointer-events-none"
                      style={{ 
                        boxShadow: neonEffectsEnabled ? `0 0 10px ${homepageColors.neonBorder}, 0 0 20px ${homepageColors.neonBorder}` : 'none',
                        border: `2px solid ${homepageColors.neonBorder}`,
                        zIndex: 10
                      }}
                    ></div>
                    
                    {settings.imageUrl ? (
                      <img
                        src={settings.imageUrl}
                        alt="Homepage"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-gray-800 flex items-center justify-center">
                        <p className="text-gray-400 text-sm">Image à définir</p>
                      </div>
                    )}
                  </div>
                  
                  {/* Image Upload Area */}
                  <div
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={handleDrop}
                    className={cn(
                      "relative border-2 border-dashed rounded-lg p-4 transition-all duration-200",
                      isDragging
                        ? "border-purple-500 bg-purple-500/10"
                        : "border-gray-700 hover:border-purple-500/50 hover:bg-gray-800/50"
                    )}
                  >
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                    
                    <div className="flex flex-col items-center justify-center space-y-2">
                      <div className="p-2 bg-purple-500/10 rounded-full">
                        <ImageIcon className="w-6 h-6 text-purple-400" />
                      </div>
                      <div className="text-center">
                        <p className="text-sm font-medium text-white">
                          Déposez votre image ici
                        </p>
                        <p className="text-xs text-gray-400 mt-1">
                          ou cliquez pour sélectionner un fichier
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right Column - Color Picker */}
                <div className="space-y-6">
                  {/* Color Picker */}
                  {getColorPickerForElement()}
                  
                  {/* Color Buttons Grid */}
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-sm text-gray-400">Bordure néon</label>
                        <div 
                          className="w-5 h-5 rounded border border-white/20" 
                          style={{ backgroundColor: homepageColors.neonBorder }}
                        ></div>
                      </div>
                      <button
                        onClick={() => setSelectedElement('neonBorder')}
                        className="w-full h-10 rounded-lg flex items-center justify-center transition-colors hover:opacity-90 bg-gray-800 border border-gray-700"
                      >
                        <span className="text-sm text-gray-300">Bordure néon</span>
                      </button>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-sm text-gray-400">Fond gauche</label>
                        <div 
                          className="w-5 h-5 rounded border border-white/20" 
                          style={{ backgroundColor: homepageColors.leftBackground }}
                        ></div>
                      </div>
                      <button
                        onClick={() => setSelectedElement('leftBackground')}
                        className="w-full h-10 rounded-lg flex items-center justify-center transition-colors hover:opacity-90"
                        style={{ backgroundColor: homepageColors.leftBackground }}
                      >
                        <span className="text-sm text-gray-300">Fond gauche</span>
                      </button>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-sm text-gray-400">Fond logo</label>
                        <div 
                          className="w-5 h-5 rounded border border-white/20" 
                          style={{ backgroundColor: homepageColors.logoBackground }}
                        ></div>
                      </div>
                      <button
                        onClick={() => setSelectedElement('logoBackground')}
                        className="w-full h-10 rounded-lg flex items-center justify-center transition-colors hover:opacity-90"
                        style={{ backgroundColor: homepageColors.logoBackground }}
                      >
                        <span className="text-sm text-gray-300">Fond logo</span>
                      </button>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-sm text-gray-400">Champ email</label>
                        <div 
                          className="w-5 h-5 rounded border border-white/20" 
                          style={{ backgroundColor: homepageColors.emailBorder }}
                        ></div>
                      </div>
                      <button
                        onClick={() => setSelectedElement('emailBorder')}
                        className="w-full h-10 rounded-lg flex items-center justify-center transition-colors hover:opacity-90 border"
                        style={{ borderColor: homepageColors.emailBorder, backgroundColor: 'rgba(17, 24, 39, 0.8)' }}
                      >
                        <span className="text-sm text-gray-300">Champ email</span>
                      </button>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-sm text-gray-400">Champ mot de passe</label>
                        <div 
                          className="w-5 h-5 rounded border border-white/20" 
                          style={{ backgroundColor: homepageColors.passwordBorder }}
                        ></div>
                      </div>
                      <button
                        onClick={() => setSelectedElement('passwordBorder')}
                        className="w-full h-10 rounded-lg flex items-center justify-center transition-colors hover:opacity-90 border"
                        style={{ borderColor: homepageColors.passwordBorder, backgroundColor: 'rgba(17, 24, 39, 0.8)' }}
                      >
                        <span className="text-sm text-gray-300">Champ mot de passe</span>
                      </button>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-sm text-gray-400">Bouton</label>
                        <div 
                          className="w-5 h-5 rounded border border-white/20" 
                          style={{ backgroundColor: homepageColors.loginButton }}
                        ></div>
                      </div>
                      <button
                        onClick={() => setSelectedElement('loginButton')}
                        className="w-full h-10 rounded-lg flex items-center justify-center transition-colors hover:opacity-90"
                        style={{ backgroundColor: homepageColors.loginButton }}
                      >
                        <span className="text-sm text-white">Bouton</span>
                      </button>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-sm text-gray-400">Texte bienvenue</label>
                        <div 
                          className="w-5 h-5 rounded border border-white/20" 
                          style={{ backgroundColor: homepageColors.welcomeText }}
                        ></div>
                      </div>
                      <button
                        onClick={() => setSelectedElement('welcomeText')}
                        className="w-full h-10 rounded-lg flex items-center justify-center transition-colors hover:opacity-90 bg-gray-800"
                      >
                        <span className="text-sm" style={{ color: homepageColors.welcomeText }}>Texte bienvenue</span>
                      </button>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-sm text-gray-400">Ronds mot de passe</label>
                        <div 
                          className="w-5 h-5 rounded border border-white/20" 
                          style={{ backgroundColor: homepageColors.passwordDots }}
                        ></div>
                      </div>
                      <button
                        onClick={() => setSelectedElement('passwordDots')}
                        className="w-full h-10 rounded-lg flex items-center justify-center transition-colors hover:opacity-90 bg-gray-800"
                      >
                        <div className="flex space-x-1">
                          {Array.from({ length: 3 }).map((_, i) => (
                            <div
                              key={i}
                              className="w-2 h-2 rounded-full"
                              style={{ backgroundColor: homepageColors.passwordDots }}
                            />
                          ))}
                        </div>
                      </button>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="text-sm text-gray-400">Trait horizontal</label>
                        <div 
                          className="w-5 h-5 rounded border border-white/20" 
                          style={{ backgroundColor: homepageColors.trakitLine }}
                        ></div>
                      </div>
                      <button
                        onClick={() => setSelectedElement('trakitLine')}
                        className="w-full h-10 rounded-lg flex items-center justify-center transition-colors hover:opacity-90"
                      >
                        <div 
                          className="w-full h-1"
                          style={{ backgroundColor: homepageColors.trakitLine }}
                        ></div>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-end space-x-4">
        <motion.button
          onClick={handleReset}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="relative group px-6 py-3 rounded-lg overflow-hidden"
        >
          <div className="absolute inset-0 bg-gray-700 opacity-80 group-hover:opacity-100 transition-opacity" />
          <span className="relative flex items-center text-white font-medium">
            <RotateCcw className="w-5 h-5 mr-2" />
            Réinitialiser
          </span>
        </motion.button>
        
        <motion.button
          onClick={() => toast.success('Paramètres sauvegardés')}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="relative group px-6 py-3 rounded-lg overflow-hidden"
        >
          <div className="absolute inset-0 bg-green-600 opacity-80 group-hover:opacity-100 transition-opacity" />
          <span className="relative flex items-center text-white font-medium">
            <Check className="w-5 h-5 mr-2" />
            Sauvegarder
          </span>
        </motion.button>
      </div>
    </div>
  );
}