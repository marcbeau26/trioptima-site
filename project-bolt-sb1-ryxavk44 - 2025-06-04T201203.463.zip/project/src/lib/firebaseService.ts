import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc, 
  query, 
  where,
  addDoc,
  serverTimestamp,
  DocumentData,
  QueryDocumentSnapshot,
  FieldValue
} from 'firebase/firestore';
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut as firebaseSignOut,
  UserCredential
} from 'firebase/auth';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, auth, storage } from './firebase';
import type { 
  User, 
  Lead, 
  Status, 
  EnergyOffer, 
  EnergyHolding, 
  StockAction, 
  Transaction,
  Document as DocumentType,
  Livret,
  Proposal
} from '../types';

// Helper to convert Firestore timestamp to ISO string
const convertTimestamps = (data: any): any => {
  if (!data) return data;
  
  const result = { ...data };
  
  // Convert Firestore timestamps to ISO strings
  Object.keys(result).forEach(key => {
    if (result[key] && typeof result[key].toDate === 'function') {
      result[key] = result[key].toDate().toISOString();
    } else if (result[key] && typeof result[key] === 'object') {
      result[key] = convertTimestamps(result[key]);
    }
  });
  
  return result;
};

// Convert Firestore document to our app type
const convertDoc = <T>(doc: QueryDocumentSnapshot<DocumentData>): T => {
  const data = doc.data();
  return {
    id: doc.id,
    ...convertTimestamps(data)
  } as T;
};

// Authentication Services
const signUp = async (email: string, password: string): Promise<UserCredential> => {
  return createUserWithEmailAndPassword(auth, email, password);
};

const signIn = async (email: string, password: string): Promise<{ data: any, error: Error | null }> => {
  try {
    // Special case for admin@plate.com
    if (email === 'admin@plate.com' && password === '123456') {
      // Check if admin exists in Firestore
      const adminQuery = query(collection(db, 'users'), where('email', '==', 'admin@plate.com'));
      const adminSnapshot = await getDocs(adminQuery);
      
      let adminUser;
      
      if (adminSnapshot.empty) {
        // Admin doesn't exist, create it
        const adminData = {
          email: 'admin@plate.com',
          firstName: 'Admin',
          lastName: 'User',
          phone: '+33123456789',
          password: '123456',
          role: 'Admin',
          dateCreated: new Date().toISOString()
        };
        
        // Create admin document directly in Firestore
        const adminRef = doc(collection(db, 'users'), 'admin-user');
        await setDoc(adminRef, {
          ...adminData,
          dateCreated: new Date()
        });
        
        adminUser = {
          ...adminData,
          id: 'admin-user'
        };
      } else {
        // Admin exists, get data
        const adminDoc = adminSnapshot.docs[0];
        adminUser = {
          ...convertTimestamps(adminDoc.data()),
          id: adminDoc.id
        };
      }
      
      // Store in localStorage
      localStorage.setItem('user', JSON.stringify(adminUser));
      
      return { data: { user: adminUser }, error: null };
    }
    
    // First try to sign in as a user
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const userDoc = await getDoc(doc(db, 'users', userCredential.user.uid));
      
      if (userDoc.exists()) {
        const userData = userDoc.data() as User;
        return { 
          data: { 
            user: {
              ...userData,
              id: userDoc.id
            }
          }, 
          error: null 
        };
      }
    } catch (error) {
      // If user login fails, try lead login
      const leadsQuery = query(collection(db, 'leads'), where('email', '==', email));
      const leadsSnapshot = await getDocs(leadsQuery);
      
      if (!leadsSnapshot.empty) {
        const leadDoc = leadsSnapshot.docs[0];
        const leadData = leadDoc.data() as Lead;
        
        if (leadData.password === password) {
          return { 
            data: { 
              lead: {
                ...convertTimestamps(leadData),
                id: leadDoc.id
              }
            }, 
            error: null 
          };
        }
      }
      
      throw new Error('Email ou mot de passe invalide');
    }
    
    throw new Error('Email ou mot de passe invalide');
  } catch (error) {
    return { data: null, error: error as Error };
  }
};

const signOut = async (): Promise<{ error: Error | null }> => {
  try {
    await firebaseSignOut(auth);
    return { error: null };
  } catch (error) {
    return { error: error as Error };
  }
};

const getCurrentUser = async (): Promise<User | null> => {
  const user = auth.currentUser;
  if (!user) return null;
  
  try {
    const userDoc = await getDoc(doc(db, 'users', user.uid));
    if (userDoc.exists()) {
      return {
        ...convertTimestamps(userDoc.data()),
        id: userDoc.id
      } as User;
    }
    return null;
  } catch (error) {
    console.error('Error getting current user:', error);
    return null;
  }
};

// User Services
const createUser = async (userData: Omit<User, 'id' | 'dateCreated'>): Promise<User> => {
  try {
    // Create auth user
    const userCredential = await createUserWithEmailAndPassword(auth, userData.email, userData.password);
    const uid = userCredential.user.uid;
    
    // Create user document
    const userRef = doc(db, 'users', uid);
    const newUser = {
      ...userData,
      dateCreated: serverTimestamp() as FieldValue
    };
    
    await setDoc(userRef, newUser);
    
    return {
      ...userData,
      id: uid,
      dateCreated: new Date().toISOString()
    } as User;
  } catch (error) {
    console.error('Error creating user:', error);
    throw error;
  }
};

const getUsers = async (): Promise<User[]> => {
  try {
    const usersSnapshot = await getDocs(collection(db, 'users'));
    return usersSnapshot.docs.map(doc => convertDoc<User>(doc));
  } catch (error) {
    console.error('Error getting users:', error);
    throw error;
  }
};

const updateUser = async (id: string, userData: Partial<User>): Promise<void> => {
  try {
    const userRef = doc(db, 'users', id);
    await updateDoc(userRef, userData);
  } catch (error) {
    console.error('Error updating user:', error);
    throw error;
  }
};

const deleteUser = async (id: string): Promise<void> => {
  try {
    await deleteDoc(doc(db, 'users', id));
  } catch (error) {
    console.error('Error deleting user:', error);
    throw error;
  }
};

// Lead Services
const createLead = async (leadData: Omit<Lead, 'id' | 'dateCreated'>): Promise<Lead> => {
  try {
    const leadRef = collection(db, 'leads');
    const newLead = {
      ...leadData,
      dateCreated: serverTimestamp() as FieldValue,
      balance: leadData.balance || 0
    };
    
    const docRef = await addDoc(leadRef, newLead);
    
    return {
      ...leadData,
      id: docRef.id,
      dateCreated: new Date().toISOString()
    } as Lead;
  } catch (error) {
    console.error('Error creating lead:', error);
    throw error;
  }
};

const getLeads = async (): Promise<Lead[]> => {
  try {
    const leadsSnapshot = await getDocs(collection(db, 'leads'));
    return leadsSnapshot.docs.map(doc => convertDoc<Lead>(doc));
  } catch (error) {
    console.error('Error getting leads:', error);
    throw error;
  }
};

const getLead = async (id: string): Promise<Lead | null> => {
  try {
    const leadDoc = await getDoc(doc(db, 'leads', id));
    if (leadDoc.exists()) {
      return {
        ...convertTimestamps(leadDoc.data()),
        id: leadDoc.id
      } as Lead;
    }
    return null;
  } catch (error) {
    console.error('Error getting lead:', error);
    throw error;
  }
};

const updateLead = async (id: string, leadData: Partial<Lead>): Promise<void> => {
  try {
    const leadRef = doc(db, 'leads', id);
    await updateDoc(leadRef, leadData);
  } catch (error) {
    console.error('Error updating lead:', error);
    throw error;
  }
};

const deleteLead = async (id: string): Promise<void> => {
  try {
    await deleteDoc(doc(db, 'leads', id));
  } catch (error) {
    console.error('Error deleting lead:', error);
    throw error;
  }
};

// Status Services
const createStatus = async (statusData: Omit<Status, 'id' | 'dateCreated'>): Promise<Status> => {
  try {
    const statusRef = collection(db, 'statuses');
    const newStatus = {
      ...statusData,
      dateCreated: serverTimestamp() as FieldValue
    };
    
    const docRef = await addDoc(statusRef, newStatus);
    
    return {
      ...statusData,
      id: docRef.id,
      dateCreated: new Date().toISOString()
    } as Status;
  } catch (error) {
    console.error('Error creating status:', error);
    throw error;
  }
};

const getStatuses = async (): Promise<Status[]> => {
  try {
    const statusesSnapshot = await getDocs(collection(db, 'statuses'));
    return statusesSnapshot.docs.map(doc => convertDoc<Status>(doc));
  } catch (error) {
    console.error('Error getting statuses:', error);
    throw error;
  }
};

// Energy Offer Services
const createEnergyOffer = async (offerData: Omit<EnergyOffer, 'id' | 'dateCreated'>): Promise<EnergyOffer> => {
  try {
    const offerRef = collection(db, 'energyOffers');
    const newOffer = {
      ...offerData,
      dateCreated: serverTimestamp() as FieldValue
    };
    
    const docRef = await addDoc(offerRef, newOffer);
    
    return {
      ...offerData,
      id: docRef.id,
      dateCreated: new Date().toISOString()
    } as EnergyOffer;
  } catch (error) {
    console.error('Error creating energy offer:', error);
    throw error;
  }
};

const getEnergyOffers = async (): Promise<EnergyOffer[]> => {
  try {
    const offersSnapshot = await getDocs(collection(db, 'energyOffers'));
    return offersSnapshot.docs.map(doc => convertDoc<EnergyOffer>(doc));
  } catch (error) {
    console.error('Error getting energy offers:', error);
    throw error;
  }
};

const updateEnergyOffer = async (id: string, offerData: Partial<EnergyOffer>): Promise<void> => {
  try {
    const offerRef = doc(db, 'energyOffers', id);
    await updateDoc(offerRef, offerData);
  } catch (error) {
    console.error('Error updating energy offer:', error);
    throw error;
  }
};

// Stock Action Services
const createStockAction = async (actionData: Omit<StockAction, 'id' | 'dateCreated'>): Promise<StockAction> => {
  try {
    const actionRef = collection(db, 'stockActions');
    const newAction = {
      ...actionData,
      dateCreated: serverTimestamp() as FieldValue
    };
    
    const docRef = await addDoc(actionRef, newAction);
    
    return {
      ...actionData,
      id: docRef.id,
      dateCreated: new Date().toISOString()
    } as StockAction;
  } catch (error) {
    console.error('Error creating stock action:', error);
    throw error;
  }
};

const getStockActions = async (): Promise<StockAction[]> => {
  try {
    const actionsSnapshot = await getDocs(collection(db, 'stockActions'));
    return actionsSnapshot.docs.map(doc => convertDoc<StockAction>(doc));
  } catch (error) {
    console.error('Error getting stock actions:', error);
    throw error;
  }
};

// Transaction Services
const createTransaction = async (leadId: string, transactionData: Omit<Transaction, 'id' | 'dateCreated'>): Promise<Transaction> => {
  try {
    const transactionRef = collection(db, `leads/${leadId}/transactions`);
    const newTransaction = {
      ...transactionData,
      dateCreated: serverTimestamp() as FieldValue
    };
    
    const docRef = await addDoc(transactionRef, newTransaction);
    
    // Update lead balance
    const leadRef = doc(db, 'leads', leadId);
    const leadDoc = await getDoc(leadRef);
    
    if (leadDoc.exists()) {
      const leadData = leadDoc.data() as Lead;
      const currentBalance = leadData.balance || 0;
      const newBalance = currentBalance + transactionData.amount;
      
      await updateDoc(leadRef, { balance: newBalance });
    }
    
    return {
      ...transactionData,
      id: docRef.id,
      dateCreated: new Date().toISOString()
    } as Transaction;
  } catch (error) {
    console.error('Error creating transaction:', error);
    throw error;
  }
};

const getTransactions = async (leadId: string): Promise<Transaction[]> => {
  try {
    const transactionsSnapshot = await getDocs(collection(db, `leads/${leadId}/transactions`));
    return transactionsSnapshot.docs.map(doc => convertDoc<Transaction>(doc));
  } catch (error) {
    console.error('Error getting transactions:', error);
    throw error;
  }
};

// Document Services
const uploadDocument = async (leadId: string, file: File, documentData: Omit<DocumentType, 'id' | 'dateUploaded' | 'url' | 'size'>): Promise<DocumentType> => {
  try {
    // Upload file to storage
    const storageRef = ref(storage, `documents/${leadId}/${file.name}`);
    await uploadBytes(storageRef, file);
    
    // Get download URL
    const downloadURL = await getDownloadURL(storageRef);
    
    // Create document record
    const documentRef = collection(db, `leads/${leadId}/documents`);
    const newDocument = {
      ...documentData,
      url: downloadURL,
      dateUploaded: serverTimestamp() as FieldValue,
      size: file.size
    };
    
    const docRef = await addDoc(documentRef, newDocument);
    
    return {
      ...documentData,
      id: docRef.id,
      url: downloadURL,
      dateUploaded: new Date().toISOString(),
      size: file.size
    } as DocumentType;
  } catch (error) {
    console.error('Error uploading document:', error);
    throw error;
  }
};

const getDocuments = async (leadId: string): Promise<DocumentType[]> => {
  try {
    const documentsSnapshot = await getDocs(collection(db, `leads/${leadId}/documents`));
    return documentsSnapshot.docs.map(doc => convertDoc<DocumentType>(doc));
  } catch (error) {
    console.error('Error getting documents:', error);
    throw error;
  }
};

// Livret Services
const createLivret = async (livretData: Omit<Livret, 'id' | 'dateCreated'>): Promise<Livret> => {
  try {
    const livretRef = collection(db, 'livrets');
    const newLivret = {
      ...livretData,
      dateCreated: serverTimestamp() as FieldValue
    };
    
    const docRef = await addDoc(livretRef, newLivret);
    
    return {
      ...livretData,
      id: docRef.id,
      dateCreated: new Date().toISOString()
    } as Livret;
  } catch (error) {
    console.error('Error creating livret:', error);
    throw error;
  }
};

const getLivrets = async (): Promise<Livret[]> => {
  try {
    const livretsSnapshot = await getDocs(collection(db, 'livrets'));
    return livretsSnapshot.docs.map(doc => convertDoc<Livret>(doc));
  } catch (error) {
    console.error('Error getting livrets:', error);
    throw error;
  }
};

// Proposal Services
const createProposal = async (leadId: string, proposalData: Omit<Proposal, 'id' | 'dateCreated'>): Promise<Proposal> => {
  try {
    const proposalRef = collection(db, `leads/${leadId}/proposals`);
    const newProposal = {
      ...proposalData,
      dateCreated: serverTimestamp() as FieldValue
    };
    
    const docRef = await addDoc(proposalRef, newProposal);
    
    return {
      ...proposalData,
      id: docRef.id,
      dateCreated: new Date().toISOString()
    } as Proposal;
  } catch (error) {
    console.error('Error creating proposal:', error);
    throw error;
  }
};

const getProposals = async (leadId: string): Promise<Proposal[]> => {
  try {
    const proposalsSnapshot = await getDocs(collection(db, `leads/${leadId}/proposals`));
    return proposalsSnapshot.docs.map(doc => convertDoc<Proposal>(doc));
  } catch (error) {
    console.error('Error getting proposals:', error);
    throw error;
  }
};

// Energy Holding Services
const createEnergyHolding = async (leadId: string, holdingData: Omit<EnergyHolding, 'id'>): Promise<EnergyHolding> => {
  try {
    const holdingRef = collection(db, `leads/${leadId}/energyHoldings`);
    
    const docRef = await addDoc(holdingRef, holdingData);
    
    return {
      ...holdingData,
      id: docRef.id
    } as EnergyHolding;
  } catch (error) {
    console.error('Error creating energy holding:', error);
    throw error;
  }
};

const getEnergyHoldings = async (leadId: string): Promise<EnergyHolding[]> => {
  try {
    const holdingsSnapshot = await getDocs(collection(db, `leads/${leadId}/energyHoldings`));
    return holdingsSnapshot.docs.map(doc => convertDoc<EnergyHolding>(doc));
  } catch (error) {
    console.error('Error getting energy holdings:', error);
    throw error;
  }
};

// Initialize data from localStorage to Firebase
export const initializeFirebaseFromLocalStorage = async (): Promise<void> => {
  try {
    // Check if data has already been initialized
    const initDoc = await getDoc(doc(db, 'system', 'initialization'));
    if (initDoc.exists() && initDoc.data().completed) {
      console.log('Firebase already initialized');
      return;
    }
    
    // Create admin user if it doesn't exist
    const adminQuery = query(collection(db, 'users'), where('email', '==', 'admin@plate.com'));
    const adminSnapshot = await getDocs(adminQuery);
    
    if (adminSnapshot.empty) {
      // Admin doesn't exist, create it
      const adminData = {
        email: 'admin@plate.com',
        firstName: 'Admin',
        lastName: 'Plate',
        phone: '+33123456789',
        password: '123456',
        role: 'Admin',
        dateCreated: new Date()
      };
      
      // Create admin document directly in Firestore
      const adminRef = doc(collection(db, 'users'), 'admin-user');
      await setDoc(adminRef, adminData);
      
      console.log('Admin user created in Firebase');
    }
    
    // Users
    const usersStr = localStorage.getItem('users');
    if (usersStr) {
      const users = JSON.parse(usersStr) as User[];
      for (const user of users) {
        const { id, ...userData } = user;
        await setDoc(doc(db, 'users', id), {
          ...userData,
          dateCreated: new Date(user.dateCreated)
        });
      }
    }
    
    // Leads
    const leadsStr = localStorage.getItem('leads');
    if (leadsStr) {
      const leads = JSON.parse(leadsStr) as Lead[];
      for (const lead of leads) {
        const { id, transactions, energyHoldings, proposals, documents, ...leadData } = lead;
        
        // Create lead document
        await setDoc(doc(db, 'leads', id), {
          ...leadData,
          dateCreated: new Date(lead.dateCreated),
          balance: lead.balance || 0
        });
        
        // Add transactions
        if (transactions) {
          for (const transaction of transactions) {
            await addDoc(collection(db, `leads/${id}/transactions`), {
              ...transaction,
              dateCreated: new Date(transaction.dateCreated)
            });
          }
        }
        
        // Add energy holdings
        if (energyHoldings) {
          for (const holding of energyHoldings) {
            await addDoc(collection(db, `leads/${id}/energyHoldings`), {
              ...holding,
              purchaseDate: new Date(holding.purchaseDate),
              expiryDate: new Date(holding.expiryDate)
            });
          }
        }
        
        // Add proposals
        if (proposals) {
          for (const proposal of proposals) {
            await addDoc(collection(db, `leads/${id}/proposals`), {
              ...proposal,
              dateCreated: new Date(proposal.dateCreated),
              expiryDate: new Date(proposal.expiryDate)
            });
          }
        }
        
        // Documents would require actual files, so we'll skip them for now
      }
    }
    
    // Statuses
    const statusesStr = localStorage.getItem('statuses');
    if (statusesStr) {
      const statuses = JSON.parse(statusesStr) as Status[];
      for (const status of statuses) {
        const { id, ...statusData } = status;
        await setDoc(doc(db, 'statuses', id), {
          ...statusData,
          dateCreated: new Date(status.dateCreated)
        });
      }
    }
    
    // Energy Offers
    const offersStr = localStorage.getItem('energyOffers');
    if (offersStr) {
      const offers = JSON.parse(offersStr) as EnergyOffer[];
      for (const offer of offers) {
        const { id, ...offerData } = offer;
        await setDoc(doc(db, 'energyOffers', id), {
          ...offerData,
          dateCreated: new Date(offer.dateCreated),
          expiryDate: new Date(offer.expiryDate),
          saleDate: new Date(offer.saleDate)
        });
      }
    }
    
    // Stock Actions
    const actionsStr = localStorage.getItem('stockActions');
    if (actionsStr) {
      const actions = JSON.parse(actionsStr) as StockAction[];
      for (const action of actions) {
        const { id, ...actionData } = action;
        await setDoc(doc(db, 'stockActions', id), {
          ...actionData,
          dateCreated: new Date(action.dateCreated)
        });
      }
    }
    
    // Livrets
    const livretsStr = localStorage.getItem('livrets');
    if (livretsStr) {
      const livrets = JSON.parse(livretsStr) as Livret[];
      for (const livret of livrets) {
        const { id, ...livretData } = livret;
        await setDoc(doc(db, 'livrets', id), {
          ...livretData,
          dateCreated: new Date(livret.dateCreated)
        });
      }
    }
    
    // Mark initialization as completed
    await setDoc(doc(db, 'system', 'initialization'), {
      completed: true,
      timestamp: serverTimestamp()
    });
    
    console.log('Firebase initialized with localStorage data');
  } catch (error) {
    console.error('Error initializing Firebase from localStorage:', error);
    throw error;
  }
};